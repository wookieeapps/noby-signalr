import {
    HubConnection,
    HubConnectionBuilder,
    HubConnectionState,
    HttpTransportType,
    LogLevel
} from "@microsoft/signalr";

/**
 * Methods exposed by the NobyHub server.
 */
export interface NobyHubServer {
    /**
     * Sends a chat response chunk for a specific chat session.
     */
    sendChatResponse(chatId: string, message: string, isComplete?: boolean): Promise<void>;
}

/**
 * Callbacks that the SPA must implement to receive events pushed by NobyHub.
 */
export interface NobyHubClient {
    /**
     * Fired whenever the backend delivers a chat response chunk.
     */
    receiveChatResponse(chatId: string, message: string, isComplete: boolean): void;
}

export interface SendChatResponsePayload {
    chatId: string;
    message: string;
    isComplete?: boolean;
}

export interface NobyHubConnectionOptions {
    /** Base URL of NOBY.Api, e.g. https://noby.dev.bank.cz */
    baseUrl: string;
    /** When true (default), SignalR sends browser cookies (required for NobyHub). */
    withCredentials?: boolean;
    /** Optional override for transport mode (defaults to WebSockets). */
    transport?: HttpTransportType;
    /** Optional logger level for SignalR tracing. */
    logging?: LogLevel;
    /** Optional automatic reconnect configuration. */
    automaticReconnect?: boolean | number[];
}

/**
 * Creates a configured HubConnection targeting /api/nobyhub.
 */
export const buildNobyHubConnection = (options: NobyHubConnectionOptions): HubConnection =>
{
    const builder = new HubConnectionBuilder()
        .withUrl(`${options.baseUrl.replace(/\/$/, "")}/api/nobyhub`, {
            transport: options.transport ?? HttpTransportType.WebSockets,
            withCredentials: options.withCredentials ?? true
        });

    if (options.logging)
    {
        builder.configureLogging(options.logging);
    }

    const reconnect = options.automaticReconnect;
    if (reconnect === undefined)
    {
        builder.withAutomaticReconnect([0, 2000, 5000, 10000]);
    }
    else if (reconnect)
    {
        builder.withAutomaticReconnect(Array.isArray(reconnect) ? reconnect : undefined);
    }

    return builder.build();
};

/**
 * Wires client callbacks to the hub connection.
 */
export const registerNobyHubClient = (connection: HubConnection, client: NobyHubClient): void =>
{
    connection.off("receiveChatResponse");
    connection.on("receiveChatResponse", (chatId: string, message: string, isComplete: boolean) =>
    {
        client.receiveChatResponse(chatId, message, isComplete);
    });
};

/**
 * Type guard ensuring the connection can be invoked.
 */
export const ensureConnectionReady = (connection: HubConnection): void =>
{
    if (connection.state !== HubConnectionState.Connected)
    {
        throw new Error("NobyHub connection is not active. Call start() before invoking server methods.");
    }
};

/**
 * Convenience wrapper around the SendChatResponse server method.
 */
export const invokeSendChatResponse = async (connection: HubConnection, payload: SendChatResponsePayload): Promise<void> =>
{
    ensureConnectionReady(connection);
    await connection.invoke("SendChatResponse", payload.chatId, payload.message, payload.isComplete ?? false);
};
