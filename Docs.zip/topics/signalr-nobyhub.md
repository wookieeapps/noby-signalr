# NobyHub SignalR kontrakt pro Vue SPA

Hub `NobyHub` je vystaven z aplikace `NOBY.Api` na adrese `/api/nobyhub` a slou�� pro realtime doru?ov�n� odpov?d� chatbotu sm?rem k frontendov�m klient?m. Hub pou��v� **cookie autentizaci** (stejn? jako zbytek NOBY.Api), tak�e v SPA sta?� zajistit, aby byly p?i p?ipojen� odes�l�ny prohl�e?ov� cookies.

## P?ehled serverov�ch a klientsk�ch metod

| Typ | Metoda | Popis | Parametry |
| --- | --- | --- | --- |
| Server -> Backend | `SendChatResponse(chatId, message, isComplete?)` | Odesl�n� chunku chatbot odpov?di zp?t klientovi, nap?. p?i manu�ln�ch korekc�ch v admin n�stroji. | `chatId: string`, `message: string`, `isComplete: boolean = false` |
| Backend -> Klient | `receiveChatResponse(chatId, message, isComplete)` | Streamovan� event s textem chatbotu. Nast�v� pro v�echny aktivn� klienty p?ihl�en� do konkr�tn� relace. | `chatId: string`, `message: string`, `isComplete: boolean` |

Aktu�ln� schema hubu je mo�n� kdykoliv ov??it p?es endpoint `GET /api/v1/signalrdocs`, kter� je generovan� reflex� (`SignalRDocumentationService`).

## TypeScript kontrakt

V repozit�?i je p?ipraven� soubor `Docs/examples/signalr/nobyHub.contract.ts`, kter� lze p?ekop�rovat do SPA projektu nebo sd�let p?es intern� npm bal�?ek. Soubor poskytuje:

- rozhran� `NobyHubServer` a `NobyHubClient` s pln? typovan�mi metodami
- helper `buildNobyHubConnection` vytv�?ej�c� instanci `HubConnection` c�lenou na `/api/nobyhub` a s `withCredentials: true`
- registraci klientsk�ch handler? (`registerNobyHubClient`)
- hl�da? stavu (`ensureConnectionReady`) a wrapper pro vol�n� `SendChatResponse`

> **Pozn�mka:** Kontrakt pou��v� ofici�ln� klient `@microsoft/signalr` (kompatibiln� s .NET 9 serverem). Instala?n� p?�kaz: `npm install @microsoft/signalr`.

## Postup integrace do Vue 3 / Vite

### 1. P?idejte z�vislosti
```bash
npm install @microsoft/signalr
```

D�le zkop�rujte soubor `nobyHub.contract.ts` do sd�len� slo�ky (nap?. `src/contracts/signalr/`).

### 2. Vytvo?te composable `useNobyHub`
```ts
// src/composables/useNobyHub.ts
import { ref, onMounted, onBeforeUnmount } from "vue";
import {
    buildNobyHubConnection,
    registerNobyHubClient,
    invokeSendChatResponse,
    NobyHubClient,
    NobyHubConnectionOptions
} from "@/contracts/signalr/nobyHub.contract";

export function useNobyHub(options: NobyHubConnectionOptions, client: NobyHubClient)
{
    const connection = ref(buildNobyHubConnection(options));
    const isConnected = ref(false);

    const start = async () =>
    {
        registerNobyHubClient(connection.value, client);
        await connection.value.start();
        isConnected.value = true;
    };

    const stop = async () =>
    {
        if (isConnected.value)
        {
            await connection.value.stop();
            isConnected.value = false;
        }
    };

    onMounted(start);
    onBeforeUnmount(stop);

    return {
        connection,
        isConnected,
        sendChatResponse: (payload) => invokeSendChatResponse(connection.value, payload)
    };
}
```

### 3. Zajist?te cookie autentizaci
`buildNobyHubConnection` standardn? vol� SignalR s `withCredentials: true`, tak�e jsou odesl�ny cookies aktu�ln�ho u�ivatele. SPA mus� pouze zajistit, �e u�ivatel je p?ihl�en (nap?. p?es FE API login flow) a �e se request nezablokuje CORS politikou. Pokud vol�te API z jin� dom�ny, nakonfigurujte v `NOBY.Api` i ve SPA odpov�daj�c� `SameSite`, CORS a `withCredentials`.

### 4. O�et?ete reconnect a monitoring
- `automaticReconnect` je defaultn? nastaven na `[0, 2000, 5000, 10000]`
- Sledujte eventy `connection.onclose` a logujte pomoc� `builder.configureLogging`
- Debugov�n�: do?asn? p?epn?te `logging` na `LogLevel.Information`

## Testov�n� a lad?n�
- `GET /api/v1/signalrdocs` � ov??en� aktu�ln�ho kontraktu hubu
- `NOBY.Api/wwwroot/signalr-test.html` � jednoduch� HTML tester na backendu
- `NOBY.Api/wwwroot/chatbot-test.html` � roz��?en� tester chatbot integrace v?etn? UI simulace streamov�n� odpov?d�
- V dev prost?ed� lze pomoc� browser devtools sledovat handshake na `/api/nobyhub` (transport WebSockets)

Dodr�ov�n�m v��e uveden�ch krok? z�sk� Vue SPA robustn�, typov? bezpe?n� napojen� na `NobyHub`, kter� reflektuje server-side kontrakt a lze jej snadno sd�let nap?�? front-end t�my.
