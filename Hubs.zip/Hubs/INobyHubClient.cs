namespace NOBY.Api.Hubs;

/// <summary>
/// Client interface for NobyHub - defines methods that can be called on connected clients
/// </summary>
public interface INobyHubClient
{
    Task ReceiveChatResponse(string chatId, string message, CancellationToken cancellationToken = default);
}
