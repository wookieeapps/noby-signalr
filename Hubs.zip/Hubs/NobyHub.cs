using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace NOBY.Api.Hubs;

/// <summary>
/// SignalR hub for real-time communication with NOBY frontend clients
/// </summary>
[Authorize]
public sealed class NobyHub(ILogger<NobyHub> _logger) : Hub<INobyHubClient>
{
    /// <summary>
    /// Sends a chat response to the calling client
    /// </summary>
    public async Task SendChatResponse(string chatId, string message, CancellationToken cancellationToken = default)
    {
        _logger.LogDebug("Sending chat response to connection {ConnectionId}", Context.ConnectionId);
        
        await Clients.Caller.ReceiveChatResponse(chatId, message, cancellationToken);
    }

    public override async Task OnConnectedAsync()
    {
        _logger.LogInformation("Client connected to NobyHub. ConnectionId: {ConnectionId}, User: {User}", 
            Context.ConnectionId, 
            Context.User?.Identity?.Name ?? "Unknown");
        
        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        _logger.LogInformation("Client disconnected from NobyHub. ConnectionId: {ConnectionId}, Exception: {Exception}", 
            Context.ConnectionId, 
            exception?.Message);
        
        await base.OnDisconnectedAsync(exception);
    }
}
