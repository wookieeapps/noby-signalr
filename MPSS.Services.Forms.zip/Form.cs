﻿using System;
using System.Collections.Generic;

namespace MPSS.Services.Forms
{
    internal class Form
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public string PdfFile { get; set; }

        public List<FormField> Fields { get; set; }
    }
}