﻿using System;

namespace MPSS.Services.Forms
{
    internal class FormField
    {
        public int ID { get; set; }

        public float X { get; set; }

        public float Y { get; set; }

        public string AcroId { get; set; }

        public float Width { get; set; }

        public float Height { get; set; }

        public float CharWidth { get; set; }

        public float FontSize { get; set; }

        public ceTe.DynamicPDF.TextAlign TextAlign { get; set; }

        public int Page { get; set; }

        public FormFieldTypes Type { get; set; }
    }
}