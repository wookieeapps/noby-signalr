﻿using System;

namespace MPSS.Services.Forms
{
    internal enum FormFieldTypes
    {
        Textbox = 1,
        Checkbox = 2,
        CurrencyFormattedNumber = 3,
        PercentageFormattedNumber = 4
    }
}