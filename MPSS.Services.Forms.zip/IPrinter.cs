﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace MPSS.Services.Forms
{
    [ServiceContract(Namespace="MPSS.Services.Forms.v1")]
    public interface IPrinter
    {
        /// <summary>
        /// Tiskne formulare podle zadaneho ID.
        /// </summary>
        /// <param name="formId">ID formulare.</param>
        /// <param name="values">Kolekce hodnot, ktere se maji vyplnit do formulare.</param>
        /// <returns>Vytisteny PDF formular.</returns>
        [OperationContract]
        byte[] PrintForm(int formId, IDictionary<int, string> values);

        /// <summary>
        /// Znovu nacte nastaveni formularu a jejich poli z databaze.
        /// </summary>
        [OperationContract]
        void RefreshForms();

        /// <summary>
        /// Tiskne testovaci formular podle zadaneho ID.
        /// </summary>
        /// <param name="formId">ID formulare.</param>
        /// <param name="showGrid">Zobrazeni zamerovaci mrizky.</param>
        /// <returns>Vytisteny PDF formular.</returns>
        [OperationContract]
        byte[] PrintDebugForm(int formId, bool showGrid);

        /// <summary>
        /// Seznam vsech formularu podporovanych sluzbou.
        /// </summary>
        [OperationContract]
        Dictionary<int, string> FormsList();
    }
}
