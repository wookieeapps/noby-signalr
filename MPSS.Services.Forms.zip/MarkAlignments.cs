﻿using System;

namespace MPSS.Services.Forms
{
    internal enum MarkAlignments
    {
        Horizontaly = 0,
        Verticaly = 1
    }
}