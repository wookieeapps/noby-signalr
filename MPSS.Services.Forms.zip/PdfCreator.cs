﻿using System;
using System.Collections.Generic;
using ceTe.DynamicPDF;
using ceTe.DynamicPDF.PageElements;
using ceTe.DynamicPDF.Text;
using System.Globalization;

namespace MPSS.Services.Forms
{
    internal class PdfCreator
    {
        public bool ShowDebugBoxes;
        public bool ShowDebugGrid;
        private ceTe.DynamicPDF.Color DefaultColor;
        private ceTe.DynamicPDF.Font DefaultFont;
        private bool MarkDoc;
        private Document PdfDoc;

        private const string AcroExportValue = "On";

        private static NumberFormatInfo nfNumber;
        private static NumberFormatInfo nfPercent;

        // create formatters
        static PdfCreator()
        {
            nfNumber = new CultureInfo("cs-CZ").NumberFormat;
            nfNumber.NumberDecimalDigits = 0;
            nfNumber.NumberGroupSeparator = " ";
            nfPercent = new CultureInfo("cs-CZ").NumberFormat;
            nfPercent.NumberDecimalDigits = 2;
        }

        public PdfCreator()
        {
            this.ShowDebugBoxes = false;
            this.ShowDebugGrid = false;
            //this.DefaultFont = new Helvetica(Encoder.CentralEurope);
            this.DefaultFont = new OpenTypeFont(System.Web.Hosting.HostingEnvironment.MapPath("~/fonts/arial.TTF"));
            this.MarkDoc = false;
        }

        public byte[] CreateDocument(Form form, IDictionary<int, string> values)
        {
            ceTe.DynamicPDF.Document.AddLicense("DPS50NPDFHMIDOmx0oPeZ+nF3z6VFeFQHDwPiglUKQ/xyRdT8Uvdb5Moivhseqj3bxlt//+w6FtkfFfsGjYwOAJOXNbss5x7huJQ");
            this.DefaultColor = ShowDebugBoxes ? ceTe.DynamicPDF.RgbColor.Red : ceTe.DynamicPDF.RgbColor.Black;

            PdfDoc = new ceTe.DynamicPDF.Merger.MergeDocument(form.PdfFile);
            // verze
            PdfDoc.PdfVersion = PdfVersion.v1_3;
            // komprese
            PdfDoc.CompressionLevel = 9;

            foreach (FormField pole in form.Fields)
            {
                if (this.ShowDebugBoxes)
                {
                    #region debug
                    switch (pole.Type)
                    {
                        case FormFieldTypes.Checkbox:
                            // tisk checkboxu
                            PrintCheckbox(pole);

                            // id pole
                            PdfDoc.Pages[pole.Page].Elements.Add(new ceTe.DynamicPDF.PageElements.Label(pole.ID.ToString(), pole.X, pole.Y + pole.Height - 2f, pole.Width, pole.Height, this.DefaultFont, 5f, ceTe.DynamicPDF.TextAlign.Center, this.DefaultColor));
                            break;

                        default:
                                // id pole
                                PdfDoc.Pages[pole.Page].Elements.Add(new ceTe.DynamicPDF.PageElements.Label(pole.ID.ToString(), pole.X, pole.Y + 1f, pole.Width, pole.Height, this.DefaultFont, 5f, ceTe.DynamicPDF.TextAlign.Center, this.DefaultColor));

                                // ohraniceni
                                Rectangle rect = new Rectangle(pole.X + 0.05f, pole.Y + 0.05f, pole.Width - 0.2f, pole.Height - 0.2f);
                                rect.BorderWidth = 0.11f;
                                rect.BorderStyle = LineStyle.DashSmall;
                                rect.BorderColor = RgbColor.Red;
                                this.PdfDoc.Pages[pole.Page].Elements.Add(rect);
                            break;
                    }
                    #endregion
                }
                else
                {
                    // pokud kolekce hodnot obsahuje hodnotu pro dane pole
                    if (values.ContainsKey(pole.ID))
                    {
                        string value = values[pole.ID];

                        if (!string.IsNullOrEmpty(value))
                        {
                            // preformat value
                            switch (pole.Type)
                            {
                                case FormFieldTypes.CurrencyFormattedNumber:
                                    double valuex;
                                    if (double.TryParse(value.Replace(".", ","), NumberStyles.Any, nfNumber, out valuex))
                                        value = valuex.ToString("N", nfNumber);
                                    break;
                                case FormFieldTypes.PercentageFormattedNumber:
                                    double valuex2;
                                    if (double.TryParse(value.Replace(".", ","), NumberStyles.Any, nfPercent, out valuex2))
                                        value = valuex2.ToString("N", nfPercent);
                                    break;
                            }

                            if (!string.IsNullOrEmpty(pole.AcroId))
                            {
                                var afield = PdfDoc.Form.Fields[pole.AcroId];
                                if (afield != null)
                                {
                                    if (pole.Type == FormFieldTypes.Checkbox)
                                        afield.Value = AcroExportValue;
                                    else
                                        afield.Value = value.Trim();
                                }
                            }
                            else
                            {
                                switch (pole.Type)
                                {
                                    case FormFieldTypes.Checkbox:
                                        // tisk checkboxu / pokud je neco vyplneno
                                        if (value.ToLower() != "false")
                                            PrintCheckbox(pole);
                                        break;

                                    default:
                                        // tisk textoveho pole
                                        PdfDoc.Pages[pole.Page].Elements.Add(new ceTe.DynamicPDF.PageElements.Label(value, pole.X, pole.Y, pole.Width, pole.Height, this.DefaultFont, pole.FontSize, pole.TextAlign, this.DefaultColor));
                                        break;
                                }
                            }
                        }
                    }
                }
            }

            // oznakcovat dokument
            if (this.MarkDoc)
                this.CreateMarks(MarkAlignments.Horizontaly);

            // zobrazit zamerovaci mrizku
            if (this.ShowDebugGrid)
            {
                LayoutGrid grid = new LayoutGrid();
                grid.ShowTitle = false;
                grid.Type = LayoutGrid.GridType.Decimal;
                foreach (ceTe.DynamicPDF.Page p in PdfDoc.Pages)
                    p.Elements.Add(grid);
            }

            // vratit document
            return PdfDoc.Draw();
        }

        /// <summary>
        /// Vytisknout checkbox
        /// </summary>
        private void PrintCheckbox(FormField pole)
        {
            Line line1 = new Line(pole.X, pole.Y, pole.X + pole.Width, pole.Y + pole.Height);
            Line line2 = new Line(pole.X + pole.Width, pole.Y, pole.X, pole.Y + pole.Height);
            line1.Color = line2.Color = DefaultColor;
            PdfDoc.Pages[pole.Page].Elements.Add(line1);
            PdfDoc.Pages[pole.Page].Elements.Add(line2);
        }

        #region create marks
        private void CreateMarks(MarkAlignments alignment)
        {
            Group grp = new Group();
            int[] grpMarks = new int[6];
            float originalX = (PdfDoc.Pages[0].Dimensions.Width / 2f) - 30f;
            float originalY = 3;
            float x = originalX;
            float y = originalY;
            Random rnd = new Random();
            for (var i = 0; i < grpMarks.Length; i++)
            {
                grpMarks[i] = rnd.Next((int)0, (int)3);
                switch (grpMarks[i])
                {
                    case 0:
                        Rectangle r1 = new Rectangle(x, y, 10, 10, RgbColor.Black, RgbColor.White, 2, LineStyle.Solid);
                        grp.Add(r1);
                        break;
                    case 1:
                        Rectangle r2 = new Rectangle(x, y, 10, 10, RgbColor.Black, RgbColor.Black, 2, LineStyle.Solid);
                        grp.Add(r2);
                        break;
                    case 2:
                        Circle c1 = new Circle(x + 5, y + 5, 5, RgbColor.Black, RgbColor.White, 2, LineStyle.Solid);
                        grp.Add(c1);
                        break;
                    case 3:
                        Circle c2 = new Circle(x + 5, y + 5, 5, RgbColor.Black, RgbColor.Black, 2, LineStyle.Solid);
                        grp.Add(c2);
                        break;
                }
                // posunuti dalsiho elementu
                if (alignment == MarkAlignments.Horizontaly)
                    x += 15;
                else
                    y += 15;
            }

            Label lbl = new Label(Guid.NewGuid().ToString().Replace("-",""), originalX, y + 12, 70, 10, this.DefaultFont, 6, RgbColor.Black);
            grp.Add(lbl);

            foreach (Page p in PdfDoc.Pages)
            {
                p.Elements.Add(grp);

                // docasne elektronicka verze
                /*Label elverze = new Label("elektronická verze", 20, 240, 200, 20, font, 8);
                elverze.Angle = 270;
                p.Elements.Add(elverze);*/
            }
        }
        #endregion
    }
}