﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace MPSS.Services.Forms
{
    public class Printer : IPrinter
    {
        /// <summary>
        /// Tiskne formulare podle zadaneho ID.
        /// </summary>
        /// <param name="formId">ID formulare.</param>
        /// <param name="values">Kolekce hodnot, ktere se maji vyplnit do formulare.</param>
        /// <returns>Vytisteny PDF formular.</returns>
        public byte[] PrintForm(int formId, IDictionary<int, string> values)
        {
            Encoding enc = new UTF8Encoding();

            // kolekce hodnot je prazdna
            if (values == null)
            {
                return enc.GetBytes("values parameter is null");
            }
            else
            {
                Form form = Repository.Formulare.Find(t => t.ID == formId);
                // id formulare nebylo nalezeno
                if (form == null)
                {
                    return enc.GetBytes("formId can not be found");
                }
                else
                {
                    PdfCreator pdf = new PdfCreator();
                    return pdf.CreateDocument(form, values); ;
                }
            }
        }

        /// <summary>
        /// Tiskne testovaci formular podle zadaneho ID.
        /// </summary>
        /// <param name="formId">ID formulare.</param>
        /// <param name="showGrid">Zobrazeni zamerovaci mrizky.</param>
        /// <returns>Vytisteny PDF formular.</returns>
        public byte[] PrintDebugForm(int formId, bool showGrid)
        {
            Form form = Repository.Formulare.Find(t => t.ID == formId);
            // id formulare nebylo nalezeno
            if (form == null)
            {
                Encoding enc = new UTF8Encoding();
                return enc.GetBytes("formId can not be found");
            }
            else
            {
                PdfCreator pdf = new PdfCreator();
                pdf.ShowDebugBoxes = true;
                pdf.ShowDebugGrid = showGrid;
                return pdf.CreateDocument(form, new Dictionary<int, string>()); ;
            }
        }

        /// <summary>
        /// Seznam vsech formularu podporovanych sluzbou.
        /// </summary>
        public Dictionary<int, string> FormsList()
        {
            Dictionary<int, string> list = new Dictionary<int, string>();

            foreach (Form form in Repository.Formulare)
            {
                list.Add(form.ID, form.Name);
            }

            return list;
        }

        /// <summary>
        /// Znovu nacte nastaveni formularu a jejich poli z databaze.
        /// </summary>
        public void RefreshForms()
        {
            Repository.Init();
        }
    }
}
