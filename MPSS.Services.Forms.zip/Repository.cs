﻿using System;
using System.Collections.Generic;
using System.Web;
using MPSS.Utils;
using System.Data;

namespace MPSS.Services.Forms
{
    internal class Repository
    {
        private static bool FormulareFilling;

        public static List<Form> Formulare
        {
            get
            {
                while (FormulareFilling)
                {
                    System.Threading.Thread.Sleep(500);
                }

                if (_Formulare == null)
                {
                    Init();
                }

                return _Formulare;
            }
        }
        private static List<Form> _Formulare;

        static Repository()
        {
            FormulareFilling = false;
        }

        public static void Init()
        {
            FormulareFilling = true;

            CData data = new CData(System.Configuration.ConfigurationManager.ConnectionStrings["default"].ConnectionString);
            DataSet ds = data.SelectDataSet("SELECT * FROM k01formular;SELECT * FROM k02pole;");
            DataRelation dr1 = new DataRelation("dr1", ds.Tables[0].Columns["k01id"], ds.Tables[1].Columns["k01id"]);
            ds.Relations.Add(dr1);

            _Formulare = new List<Form>();
            foreach (DataRow rForm in ds.Tables[0].Rows)
            {
                Form form = new Form
                {
                    ID = Convert.ToInt32(rForm["k01id"]),
                    Name = rForm["k01nazev"].ToString(),
                    Fields = new List<FormField>()
                };
                form.PdfFile = string.Format("{0}{1}.pdf", System.Configuration.ConfigurationManager.AppSettings["pdfPath"], form.ID);

                foreach (DataRow rPole in rForm.GetChildRows("dr1"))
                {
                    FormField pole = new FormField
                    {
                        ID = Convert.ToInt32(rPole["k02id"]),
                        X = (float)Convert.ToDouble(rPole["k02x"]),
                        Y = (float)Convert.ToDouble(rPole["k02y"])
                    };
                    // acro forms
                    //pole.AcroId = rPole["k02acro_id"].ToString();
                    // typ pole
                    if (rPole.IsNull("k02type"))
                        pole.Type = FormFieldTypes.Textbox;
                    else
                    {
                        int type = Convert.ToInt32(rPole["k02type"]);
                        if (type > 0 && type <= 4)
                            pole.Type = (FormFieldTypes)type;
                        else
                            pole.Type = FormFieldTypes.Textbox;
                    }
                    // sirka
                    if (rPole.IsNull("k02width") && pole.Type == FormFieldTypes.Checkbox)
                        pole.Width = 11;
                    else
                        pole.Width = (float)Convert.ToDouble(rPole["k02width"]);
                    // vyska
                    if (rPole.IsNull("k02height"))
                        pole.Height = pole.Type == FormFieldTypes.Textbox ? 16 : 11;
                    else
                        pole.Height = (float)Convert.ToDouble(rPole["k02height"]);
                    // strana
                    pole.Page = (rPole.IsNull("k02page") ? 1 : Convert.ToInt32(rPole["k02page"])) - 1;
                    pole.CharWidth = 11.4f;
                    pole.FontSize = 11f;
                    pole.TextAlign = rPole.IsNull("k02text_align") ? ceTe.DynamicPDF.TextAlign.Left : (rPole["k02text_align"].ToString().ToLower() == "lr" ? ceTe.DynamicPDF.TextAlign.Left : ceTe.DynamicPDF.TextAlign.Right);

                    form.Fields.Add(pole);
                }

                _Formulare.Add(form);
            }

            FormulareFilling = false;
        }
    }
}