using NOBY.Api.BackgroundServices.Chatbot;

namespace NOBY.Api.StartupExtensions;

internal static class NobyChatbotStreaming
{
    /// <summary>
    /// Adds chatbot streaming services including background service and message queue
    /// </summary>
    public static WebApplicationBuilder AddNobyChatbotStreaming(this WebApplicationBuilder builder)
    {
        // Register the message queue as singleton (shared between producer and consumer)
        builder.Services.AddSingleton<IChatMessageQueue, ChatMessageQueue>();

        // Register the background service
        builder.Services.AddHostedService<ChatbotStreamingBackgroundService>();

        return builder;
    }
}
