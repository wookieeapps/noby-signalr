﻿namespace NOBY.AppHost.Dto;

internal class ExternalServicesDto
{
    public string CustomerManagement { get; init; } = string.Empty;
    public string IdentifiedSubjectBr { get; init; } = string.Empty;
    public string MpDigi { get; init; } = string.Empty;
    public string Eas { get; init; } = string.Empty;
    public string EasSimulationHT { get; init; } = string.Empty;
    public string SbWebApi { get; init ; } = string.Empty;
    public string Sdf { get; init; } = string.Empty;
    public string Sulm { get; init; } = string.Empty;
    public string ESignatures { get; init; } = string.Empty;
    public string Kamila { get; init; } = string.Empty;
    public string EMA { get; init; } = string.Empty;
    public string Pcp { get; init;} = string.Empty;
    public string ProductInstance { get; init; } = string.Empty;
    public string PreorderService { get; init; } = string.Empty;
    public string LuxApiService { get; init; } = string.Empty;
    public string C4MCreditWorthiness { get; init; } = string.Empty;
    public string C4MCustomerExposure { get; init; } = string.Empty;
    public string C4MLoanApplication { get; init; } = string.Empty;
    public string C4MLoanApplicationAssessment { get; init; } = string.Empty;
    public string C4MRiskBusinessCase { get; init; } = string.Empty;
    public string C4MRiskCharacteristics { get; init; } = string.Empty;
    public string RuianAddress { get; init; } = string.Empty;
    public string AddressWhispererService { get; init; } = string.Empty;
    public string PartyService { get; init; } = string.Empty;
    public string ChatbotInternal { get; init; } = string.Empty;
    public string ChatbotExternal { get; init; } = string.Empty;
}
