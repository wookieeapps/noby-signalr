﻿using NOBY.AppHost.Dto;

namespace NOBY.AppHost;

internal static class ExternalServicesExtensions
{
    public static IResourceBuilder<TDestination> AddCustomerManagement<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-customermanagement-v2", externalServices.CustomerManagement);
    }

    public static IResourceBuilder<TDestination> AddEMA<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-ema-v1", externalServices.EMA);
    }

    public static IResourceBuilder<TDestination> AddContactsService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-contacts-v1", externalServices.CustomerManagement);
    }

    public static IResourceBuilder<TDestination> AddIdentifiedSubjectBr<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-identifiedsubjectbr-v1", externalServices.CustomerManagement);
    }

    public static IResourceBuilder<TDestination> AddKycService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-kyc-v1", externalServices.CustomerManagement);
    }

    public static IResourceBuilder<TDestination> AddCustomerProfile<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-customerprofile-v1", externalServices.CustomerManagement);
    }

    public static IResourceBuilder<TDestination> AddMpHome<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-mphome-v1", externalServices.MpDigi);
    }

    public static IResourceBuilder<TDestination> AddEasService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-eas-v1", externalServices.Eas);
    }

    public static IResourceBuilder<TDestination> AddEasSimulationHTService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-eassimulationht-v1", externalServices.EasSimulationHT);
    }

    public static IResourceBuilder<TDestination> AddSbWebApi<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-sbwebapi-v1", externalServices.SbWebApi);
    }

    public static IResourceBuilder<TDestination> AddSdfService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-sdf-v1", externalServices.Sdf);
    }

    public static IResourceBuilder<TDestination> AddSulmService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-sulm-v1", externalServices.Sulm);
    }

    public static IResourceBuilder<TDestination> AddESignatures<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-esignatures-v1", externalServices.ESignatures);
    }

    public static IResourceBuilder<TDestination> AddKamila<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-kamila-v1", externalServices.Kamila);
    }

    public static IResourceBuilder<TDestination> AddPcpService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-pcp-v3", externalServices.Pcp);
    }

    public static IResourceBuilder<TDestination> AddProductInstanceApi<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-productinstance-v1", externalServices.ProductInstance);
    }

    public static IResourceBuilder<TDestination> AddPreorderService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-preorderservice-v1", externalServices.PreorderService);
    }

    public static IResourceBuilder<TDestination> AddLuxApiService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-luxapiservice-v1", externalServices.LuxApiService);
    }

    public static IResourceBuilder<TDestination> AddRuianAddressService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-ruianaddress-v1", externalServices.RuianAddress);
    }

    public static IResourceBuilder<TDestination> AddAddressWhispererService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-addresswhisperer-v2", externalServices.AddressWhispererService);
    }

    public static IResourceBuilder<TDestination> AddPartyService<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-party-v1", externalServices.PartyService);
    }

    public static IResourceBuilder<TDestination> AddRipServices<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-c4mcreditworthiness-v1", externalServices.C4MCreditWorthiness)
                      .WithExternalServiceReference("es-c4mcustomerexposure-v1", externalServices.C4MCustomerExposure)
                      .WithExternalServiceReference("es-c4mloanapplication-v1", externalServices.C4MLoanApplication)
                      .WithExternalServiceReference("es-c4mloanapplicationassessment-v1", externalServices.C4MLoanApplicationAssessment)
                      .WithExternalServiceReference("es-c4mriskbusinesscase-v1", externalServices.C4MRiskBusinessCase)
                      .WithExternalServiceReference("es-c4mriskcharacteristics-v1", externalServices.C4MRiskCharacteristics);
    }

    public static IResourceBuilder<TDestination> AddChatbotServices<TDestination>(
        this IResourceBuilder<TDestination> builder, ExternalServicesDto externalServices)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithExternalServiceReference("es-aichatbot-internal", externalServices.ChatbotInternal)
                      .WithExternalServiceReference("es-aichatbot-external", externalServices.ChatbotExternal);
    }

    private static IResourceBuilder<TDestination> WithExternalServiceReference<TDestination>(
        this IResourceBuilder<TDestination> builder, string serviceName, string address)
        where TDestination : IResourceWithEnvironment
    {
        return builder.WithEnvironment($"services__{serviceName}__default__0", address);
    }
}
