using Microsoft.Extensions.Configuration;
using NOBY.AppHost;
using NOBY.AppHost.Dto;

var builder = DistributedApplication.CreateBuilder(args);

var externalServices = builder.Configuration.GetSection("ExternalServices").Get<ExternalServicesDto>()!;

var codebookService = builder.AddProject<Projects.DomainServices_CodebookService_Api>("ds-codebookservice").SetAspireEnvironment();
var userService = builder.AddProject<Projects.DomainServices_UserService_Api>("ds-userservice").SetAspireEnvironment();
var caseService = builder.AddProject<Projects.DomainServices_CaseService_Api>("ds-caseservice").SetAspireEnvironment();
var customerService = builder.AddProject<Projects.DomainServices_CustomerService_Api>("ds-customerservice").SetAspireEnvironment();
var documentArchiveService = builder.AddProject<Projects.DomainServices_DocumentArchiveService_Api>("ds-documentarchiveservice").WithExplicitStart().SetAspireEnvironment();
var documentOnSaService = builder.AddProject<Projects.DomainServices_DocumentOnSAService_Api>("ds-documentonsaservice").SetAspireEnvironment();
var salesArrangementService = builder.AddProject<Projects.DomainServices_SalesArrangementService_Api>("ds-salesarrangementservice").SetAspireEnvironment();
var householdService = builder.AddProject<Projects.DomainServices_HouseholdService_Api>("ds-householdservice").SetAspireEnvironment();
var offerService = builder.AddProject<Projects.DomainServices_OfferService_Api>("ds-offerservice").SetAspireEnvironment();
var productService = builder.AddProject<Projects.DomainServices_ProductService_Api>("ds-productservice").SetAspireEnvironment();
var riskIntegrationService = builder.AddProject<Projects.DomainServices_RiskIntegrationService_Api>("ds-riskintegrationservice").WithExplicitStart().SetAspireEnvironment();
var realEstateValuationService = builder.AddProject<Projects.DomainServices_RealEstateValuationService_Api>("ds-realestatevaluationservice").WithExplicitStart().SetAspireEnvironment();
var notificationService = builder.AddProject<Projects.CIS_InternalServices_NotificationService_Api>("cis-notificationservice").WithExplicitStart().SetAspireEnvironment();
var dataAggregatorService = builder.AddProject<Projects.CIS_InternalServices_DataAggregatorService_Api>("cis-dataaggregatorservice").WithExplicitStart().SetAspireEnvironment();
var documentGeneratorService = builder.AddProject<Projects.CIS_InternalServices_DocumentGeneratorService_Api>("cis-documentgeneratorservice").WithExplicitStart().SetAspireEnvironment();

caseService.WithReference(codebookService)
           .WithReference(salesArrangementService)
           .WithReference(documentOnSaService)
           .WithReference(householdService)
           .WithReference(productService)
           .WithReference(userService)
           .WithReference(riskIntegrationService)
           .AddMpHome(externalServices)
           .AddEasService(externalServices)
           .AddSbWebApi(externalServices);

customerService.WithReference(codebookService)
               .WithReference(userService)
               .WithReference(caseService)
               .WithReference(salesArrangementService)
               .WithReference(householdService)
               .AddCustomerManagement(externalServices)
               .AddContactsService(externalServices)
               .AddIdentifiedSubjectBr(externalServices)
               .AddKycService(externalServices)
               .AddCustomerProfile(externalServices)
               .AddMpHome(externalServices);

documentArchiveService.WithReference(codebookService)
                      .WithReference(userService)
                      .AddSdfService(externalServices);

documentOnSaService.WithReference(codebookService)
                   .WithReference(userService)
                   .WithReference(caseService)
                   .WithReference(salesArrangementService)
                   .WithReference(customerService)
                   .WithReference(productService)
                   .WithReference(documentArchiveService)
                   .WithReference(dataAggregatorService)
                   .WithReference(documentGeneratorService)
                   .AddEasService(externalServices)
                   .AddSulmService(externalServices)
                   .AddESignatures(externalServices);

householdService.WithReference(codebookService)
                .WithReference(userService)
                .WithReference(caseService)
                .WithReference(salesArrangementService)
                .WithReference(customerService)
                .WithReference(offerService)
                .WithReference(documentOnSaService)
                .AddEasService(externalServices)
                .AddSulmService(externalServices)
                .AddKamila(externalServices);

offerService.WithReference(codebookService)
            .WithReference(userService)
            .WithReference(caseService)
            .WithReference(riskIntegrationService)
            .AddEasSimulationHTService(externalServices)
            .AddSbWebApi(externalServices)
            .AddEasService(externalServices);

productService.WithReference(codebookService)
              .WithReference(userService)
              .WithReference(offerService)
              .WithReference(caseService)
              .WithReference(salesArrangementService)
              .WithReference(householdService)
              .AddEasService(externalServices)
              .AddMpHome(externalServices)
              .AddPcpService(externalServices)
              .AddProductInstanceApi(externalServices);

salesArrangementService.WithReference(codebookService)
                       .WithReference(userService)
                       .WithReference(caseService)
                       .WithReference(customerService)
                       .WithReference(offerService)
                       .WithReference(householdService)
                       .WithReference(documentArchiveService)
                       .WithReference(documentOnSaService)
                       .WithReference(productService)
                       .WithReference(realEstateValuationService)
                       .WithReference(notificationService)
                       .WithReference(dataAggregatorService)
                       .WithReference(documentGeneratorService)
                       .AddEasService(externalServices)
                       .AddKamila(externalServices)
                       .AddEMA(externalServices)
                       .AddMpHome(externalServices);

realEstateValuationService.WithReference(codebookService)
                          .WithReference(userService)
                          .WithReference(productService)
                          .WithReference(salesArrangementService)
                          .WithReference(documentArchiveService)
                          .WithReference(customerService)
                          .WithReference(caseService)
                          .WithReference(offerService)
                          .AddPreorderService(externalServices)
                          .AddLuxApiService(externalServices);

riskIntegrationService.WithReference(codebookService)
                      .WithReference(userService)
                      .AddRipServices(externalServices);

notificationService.WithReference(codebookService).WithReference(userService);

dataAggregatorService.WithReference(codebookService)
                     .WithReference(userService)
                     .WithReference(salesArrangementService)
                     .WithReference(caseService)
                     .WithReference(offerService)
                     .WithReference(customerService)
                     .WithReference(productService)
                     .WithReference(householdService)
                     .WithReference(documentOnSaService);

documentGeneratorService.WithReference(codebookService).WithReference(userService);

builder.AddProject<Projects.NOBY_Api>("noby-api")
       .WithUrlForEndpoint("https", url =>
       {
           url.DisplayText = "Swagger";
           url.Url = "/swagger/index.html";
       })
       .WithReference(codebookService)
       .WithReference(caseService)
       .WithReference(customerService)
       .WithReference(documentArchiveService)
       .WithReference(documentOnSaService)
       .WithReference(salesArrangementService)
       .WithReference(householdService)
       .WithReference(offerService)
       .WithReference(productService)
       .WithReference(riskIntegrationService)
       .WithReference(realEstateValuationService)
       .WithReference(dataAggregatorService)
       .WithReference(documentGeneratorService)
       .WithReference(userService)
       .AddMpHome(externalServices)
       .AddSbWebApi(externalServices)
       .AddRuianAddressService(externalServices)
       .AddAddressWhispererService(externalServices)
       .AddPartyService(externalServices)
       .AddChatbotServices(externalServices)
       .SetAspireEnvironment();

builder.Build().Run();
