﻿namespace CIS.Core;

/// <summary>
/// Globální konstanty aplikace.
/// </summary>
public static class CisGlobalConstants
{
    /// <summary>
    /// Klíč v appsettings.json pro výchozí DB connection string aplikace
    /// </summary>
    public const string DefaultConnectionStringKey = "default";

    /// <summary>
    /// URL health check endpointu pro vsechny sluzby/aplikace.
    /// </summary>
    public const string CisHealthCheckEndpointUrl = "/health";

    /// <summary>
    /// Name of section in appsettings.json which holds configuration settings for external services.
    /// </summary>
    public const string ExternalServicesConfigurationSectionName = "ExternalServices";

    /// <summary>
    /// Prefix for external service's Key in ServiceDiscovery database.
    /// </summary>
    public const string ExternalServicesServiceDiscoveryKeyPrefix = "ES:";

    /// <summary>
    /// Name of section in appsettings.json which holds CIS environment configuration
    /// </summary>
    public const string EnvironmentConfigurationSectionName = "CisEnvironmentConfiguration";

    public const string ServiceAuthenticationSectionName = "CisSecurity:ServiceAuthentication";

    public const string DefaultAppConfigurationSectionName = "AppConfiguration";
}