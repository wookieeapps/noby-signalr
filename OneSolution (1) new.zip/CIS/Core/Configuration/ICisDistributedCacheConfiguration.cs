﻿namespace CIS.Core.Configuration;

public interface ICisDistributedCacheConfiguration
{
    string? KeyPrefix { get; }

    SerializationTypes SerializationType { get; }

    CacheTypes CacheType { get; }

    public enum CacheTypes
    {
        None = 0,
        Redis = 1,
        MsSql = 2
    }

    public enum SerializationTypes
    {
        Json = 0,
        Protobuf = 1
    }
}