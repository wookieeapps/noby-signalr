﻿namespace CIS.Core.Configuration;

public enum SecretsSource
{
    Default = 0,
    ConjurEnvironmentVariables = 1
}