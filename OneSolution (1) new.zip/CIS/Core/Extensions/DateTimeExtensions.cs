﻿namespace CIS.Core.Extensions;

public static class DateTimeExtensions
{
    private static TimeZoneInfo _pragueTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Central Europe Standard Time");

    public static DateTime ConvertFromUtc(this DateTime utcDateTime)
    {
        var utc = DateTime.SpecifyKind(utcDateTime, DateTimeKind.Utc);
        return TimeZoneInfo.ConvertTimeFromUtc(utc, _pragueTimeZone);
    }

    public static DateTime? ConvertFromUtc(this DateTime? utcDateTime)
    {
        if (utcDateTime == null)
        {
            return default;
        }

        var utc = DateTime.SpecifyKind(utcDateTime.Value, DateTimeKind.Utc);
        return TimeZoneInfo.ConvertTimeFromUtc(utc, _pragueTimeZone);
    }
}
