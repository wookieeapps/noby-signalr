﻿namespace Microsoft.Extensions.Hosting;

public static class EnvironmentExtensions
{
    private const string _aspireEnvironmentName = "Aspire";

    public static bool IsAspire(this IHostEnvironment env)
    {
        return env.IsEnvironment(_aspireEnvironmentName);
    }
}