﻿namespace CIS.Infrastructure.Caching;

public static class Constants
{
    /// <summary>
    /// Nazev tabulky na mssql ve ktere je ulozena kes
    /// </summary>
    public const string MsSqlCacheTableName = "AppCache";

    /// <summary>
    /// Nazev sekce v appsettings.json kde je konfigurace kese
    /// </summary>
    public const string CisDistributedCacheConfigurationKey = "CisDistributedCache";

    /// <summary>
    /// Nazev connection stringu v appsettings.json kde je CS na redis nebo mssql
    /// </summary>
    public const string CacheConnectionStringKey = "cisDistributedCache";

    /// <summary>
    /// Nazev grpc response cache
    /// </summary>
    public const string GrpcResponseCacheName = "CISGrpcResponses";

    /// <summary>
    /// Prefix klice nakesovaneho gRPC response objektu
    /// </summary>
    public const string GrpcResponseCachePrefix = "GrpcClient:";

    /// <summary>
    /// Doba platnosti nakesovaneho gRPC response objektu
    /// </summary>
    public const int GrpcResponseCacheDurationMins = 30;
}
