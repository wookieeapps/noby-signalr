﻿using Microsoft.Extensions.DependencyInjection;
using CIS.Core.Configuration;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using CIS.Infrastructure.Caching.Configuration;
using CIS.Infrastructure.Caching;
using ZiggyCreatures.Caching.Fusion;
using ZiggyCreatures.Caching.Fusion.Serialization.SystemTextJson;
using ZiggyCreatures.Caching.Fusion.Serialization;
using CIS.Infrastructure.Caching.Grpc;
using System.Diagnostics.CodeAnalysis;

#pragma warning disable IDE0130 // Namespace does not match folder structure
namespace CIS.Infrastructure.StartupExtensions;
#pragma warning restore IDE0130 // Namespace does not match folder structure

public static class DistributedCachingStartupExtensions
{
    public static WebApplicationBuilder AddCisCache([NotNull] this WebApplicationBuilder builder)
    {
        // pridat configuration
        var configuration = builder.Configuration
            .GetSection(Constants.CisDistributedCacheConfigurationKey)
            .Get<CisDistributedCacheConfiguration>()
            ?? new CisDistributedCacheConfiguration
            {
                CacheType = ICisDistributedCacheConfiguration.CacheTypes.None
            };

        // insert configuration to DI
        builder.Services.AddSingleton(configuration);

        if (configuration.CacheType != ICisDistributedCacheConfiguration.CacheTypes.None)
        {
            switch (configuration.CacheType)
            {
                case ICisDistributedCacheConfiguration.CacheTypes.Redis:
                    registerRedis(builder, configuration);
                    break;

                case ICisDistributedCacheConfiguration.CacheTypes.MsSql:
                    registerMsSql(builder);
                    break;
            }

            // add 1st level general cache
            builder.Services
                .AddFusionCache()
                .WithDefaultEntryOptions(options =>
                {
                    options.AllowBackgroundDistributedCacheOperations = true;
                    options.DistributedCacheSoftTimeout = TimeSpan.FromSeconds(1);
                    options.DistributedCacheHardTimeout = TimeSpan.FromSeconds(2);
                })
                .WithSerializer(GetDistributedCacheSerializer(configuration.SerializationType))
                .WithDistributedCache(provider => provider.GetRequiredService<IDistributedCache>());
        }
        else
        {
            builder.Services.AddDistributedMemoryCache();

            // add 1st level general cache
            builder.Services.AddFusionCache();
        }

        // add grpc response cache
        builder.AddGrpcResponseCache(configuration);

        return builder;
    }

    internal static IFusionCacheSerializer GetDistributedCacheSerializer(ICisDistributedCacheConfiguration.SerializationTypes serializationType)
    {
        return serializationType switch
        {
            ICisDistributedCacheConfiguration.SerializationTypes.Json => new FusionCacheSystemTextJsonSerializer(new System.Text.Json.JsonSerializerOptions
            {
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
                DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull,
                IncludeFields = true,
                WriteIndented = false
            }),

            ICisDistributedCacheConfiguration.SerializationTypes.Protobuf => new ZiggyCreatures.Caching.Fusion.Serialization.ProtoBufNet.FusionCacheProtoBufNetSerializer(),

            _ => throw new Core.Exceptions.CisConfigurationNotFound("Unknown serialization type")
        };
    }

    private static WebApplicationBuilder registerRedis(
        WebApplicationBuilder builder,
        CisDistributedCacheConfiguration distributedCacheConfiguration)
    {
        var cs = getConnectionString(builder);
        builder.Services.AddStackExchangeRedisCache(options =>
        {
            options.Configuration = cs;
            options.InstanceName = distributedCacheConfiguration.KeyPrefix + ":";
        });

        return builder;
    }

    private static WebApplicationBuilder registerMsSql(WebApplicationBuilder builder)
    {
        var cs = getConnectionString(builder);
        builder.Services.AddDistributedSqlServerCache(options =>
        {
            options.ConnectionString = cs;
            options.SchemaName = "dbo";
            options.TableName = Constants.MsSqlCacheTableName;
        });

        return builder;
    }

    /// <summary>
    /// Vraci connection string pro cache nebo vyhodi vyjimku
    /// </summary>
    private static string getConnectionString(WebApplicationBuilder builder)
    {
        var cs = builder.Configuration.GetConnectionString(Constants.CacheConnectionStringKey);
        if (string.IsNullOrEmpty(cs)) 
        {
            throw new Core.Exceptions.CisConfigurationNotFound($"{Constants.CacheConnectionStringKey} connection string not found");
        }
        return cs;
    }
}
