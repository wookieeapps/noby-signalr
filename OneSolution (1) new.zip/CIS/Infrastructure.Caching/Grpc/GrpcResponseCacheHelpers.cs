﻿namespace CIS.Infrastructure.Caching.Grpc;

internal static class GrpcResponseCacheHelpers
{
    public static string CreateCacheKey(in string methodName, in object key)
    {
        return $"{methodName}-{key}";
    }
}
