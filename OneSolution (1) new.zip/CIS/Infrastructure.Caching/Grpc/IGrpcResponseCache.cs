﻿using System.Runtime.CompilerServices;

namespace CIS.Infrastructure.Caching.Grpc;

public interface IGrpcResponseCache
{
    Task<TResponse> GetLocalOrDistributed<TResponse>(
        object key,
        Func<CancellationToken, Task<TResponse>> getObject,
        CancellationToken cancellationToken = default,
        [CallerMemberName]  string memberName = "")
        where TResponse : class;

    Task<TResponse> GetDistributedOnly<TResponse>(
        object key,
        Func<CancellationToken, Task<TResponse>> getObject,
        CancellationToken cancellationToken = default,
        [CallerMemberName] string memberName = "")
        where TResponse : class;

    Task<TResponse> GetLocalOnly<TResponse>(
        object key,
        Func<CancellationToken, Task<TResponse>> getObject,
        CancellationToken cancellationToken = default,
        [CallerMemberName] string memberName = "")
        where TResponse : class;

    Task<TResponse> GetLocalOrDistributed<TResponse>(
        object key,
        Func<CancellationToken, Task<TResponse>> getObject,
        Func<TResponse, bool> validateEntry,
        CancellationToken cancellationToken = default,
        [CallerMemberName] string memberName = "")
        where TResponse : class;

    Task InvalidateEntry(object key, string methodName, CancellationToken cancellationToken = default);

    void InvalidateLocalEntries();
}