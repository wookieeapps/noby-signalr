﻿using Microsoft.Extensions.Logging;

namespace CIS.Infrastructure.Caching;

internal static class LoggerExtensions
{
    public enum CacheTypes
    {
        Local,
        Distributed
    };

    private static readonly Action<ILogger, CacheTypes, string, string, Exception> _usingCacheInsteadOfRpc =
        LoggerMessage.Define<CacheTypes, string, string>(
            LogLevel.Debug,
            new EventId(890, nameof(UsingCacheInsteadOfRpc)),
            "Using cached value from {CacheType} for {MethodName} with key {Key}"
        );

    // public accessor
    public static void UsingCacheInsteadOfRpc(this ILogger logger, in CacheTypes cacheType, in string key, in string methodName) =>
        _usingCacheInsteadOfRpc(logger, cacheType, methodName, key, null!);

}
