﻿using CIS.Core.Configuration;
using SharedTypes.Types;

namespace CIS.Infrastructure.ExternalServicesHelpers;

public static class HttpHandlersExtensions
{
    /// <summary>
    /// Přidá do HttpClient try-catch tak, aby se nevraceli výchozí vyjímky, ale jejich CIS ekvivalenty.
    /// </summary>
    /// <param name="serviceName">Název ExternalServices proxy</param>
    public static IHttpClientBuilder AddExternalServicesErrorHandling(this IHttpClientBuilder builder, string serviceName, bool registerBadRequestAsError = false)
        => builder.AddHttpMessageHandler(b => new HttpHandlers.ErrorHandlingHttpHandler(serviceName, registerBadRequestAsError));

    /// <summary>
    /// Prida do kazdeho requestu HttpClienta hlavicky vyzadovane v KB.
    /// </summary>
    /// <param name="appComponent">Hodnota appComp v hlavičce X-KB-Caller-System-Identity. Pokud není vyplněno, je nastavena na "NOBY".</param>
    public static IHttpClientBuilder AddExternalServicesKbHeaders(this IHttpClientBuilder builder, string? appComponent = null, string? appComponentOriginator = null)
        => builder.AddHttpMessageHandler(b => new HttpHandlers.KbHeadersHttpHandler(appComponent, appComponentOriginator));

    /// <summary>
    /// Prida KB hlavicku Customer-Journey
    /// </summary>
    public static IHttpClientBuilder AddCustomerJourneyKbHeaders(this IHttpClientBuilder builder, string processId)
        => builder.AddHttpMessageHandler(services =>
        {
            var configuration = services.GetRequiredService<ICisEnvironmentConfiguration>();
            return new HttpHandlers.KbCustomerJourneyHttpHandler(configuration.EnvironmentName, processId);
        });

    /// <summary>
    /// Prida do kazdeho requestu HttpClienta hlavicku s aktualnim uzivatelem vyzadovanou v KB.
    /// </summary>
    public static IHttpClientBuilder AddExternalServicesKbPartyHeaders(this IHttpClientBuilder builder)
        => builder.AddHttpMessageHandler(b => new HttpHandlers.KbPartyHeaderHttpHandler(b));

	/// <summary>
	/// Prida do kazdeho requestu HttpClienta hlavicku s aktualnim uzivatelem vyzadovanou v KB.
	/// </summary>
    /// <remarks>
    /// Pokud neexistuje kontext aktualniho uzivatele, fallbackuje na identitu zadanou v parametru.
    /// </remarks>
	public static IHttpClientBuilder AddExternalServicesKbPartyHeadersWithFallback(this IHttpClientBuilder builder, UserIdentity fallbackIdentity)
		=> builder.AddHttpMessageHandler(b => new HttpHandlers.KbPartyHeaderHttpHandler(b, fallbackIdentity));

	/// <summary>
	/// Doplňuje do každého requestu Correlation Id z OT.
	/// </summary>
	/// <param name="headerKey">Klíč v hlavičce, kam se má Id zapsat. Pokud není vyplněno, ne nastavena na "X-Correlation-ID".</param>
	public static IHttpClientBuilder AddExternalServicesCorrelationIdForwarding(this IHttpClientBuilder builder, string? headerKey = null)
        => builder.AddHttpMessageHandler(b => new HttpHandlers.CorrelationIdForwardingHttpHandler(headerKey));
}
