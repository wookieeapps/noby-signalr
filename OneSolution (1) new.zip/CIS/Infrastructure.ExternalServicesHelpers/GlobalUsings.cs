﻿global using CIS.Infrastructure.Logging;
global using CIS.Core.Exceptions;
global using Microsoft.Extensions.Logging;
global using Microsoft.Extensions.DependencyInjection;