﻿namespace CIS.Infrastructure.ExternalServicesHelpers;

public enum ServiceImplementationTypes
{
    Unknown,
    
    Mock,

    Real
}
