﻿using System.Xml.Serialization;

namespace CIS.Infrastructure.ExternalServicesHelpers.Soap;

public class WsseSecurityHeaderModel
{
    [XmlAttribute(AttributeName = "mustUnderstand", Namespace = "http://schemas.xmlsoap.org/soap/envelope/")]
    public string MustUnderstand { get; set; } = "1";

    [XmlElement(ElementName = "UsernameToken", Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")]
    public required UsernameToken UsernameToken { get; set; }
}

public class UsernameToken
{
    [XmlAttribute(AttributeName = "Id", Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd")]
    public required string Id { get; set; }

    [XmlElement(ElementName = "Username", Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")]
    public required string Username { get; set; }

    [XmlElement(ElementName = "Password", Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")]
    public required Password Password { get; set; }

    [XmlElement(ElementName = "Nonce", Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")]
    public required Nonce Nonce { get; set; }

    [XmlElement(ElementName = "Created", Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd")]
    public required string Created { get; set; }
}

public class Password
{
    /// <summary>
    /// Default: http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText
    /// </summary>
    [XmlAttribute(AttributeName = "Type")] 
    public string Type { get; set; } = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText";

    [XmlText]
    public required string Value { get; set; }
}

public class Nonce
{
    /// <summary>
    /// Default: http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary
    /// </summary>
    [XmlAttribute(AttributeName = "EncodingType")]
    public string EncodingType { get; set; } = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary";

    [XmlText]
    public required string Value { get; set; }
}