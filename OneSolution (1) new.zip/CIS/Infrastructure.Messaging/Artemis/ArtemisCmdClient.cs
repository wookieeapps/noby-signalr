﻿using MassTransit;

namespace CIS.Infrastructure.Messaging.Artemis;

internal class ArtemisCmdClient(ISendEndpointProvider sendEndpointProvider) 
    : IArtemisCmdClient
{
    public async Task<Guid> Send<TMessage>(TMessage message) where TMessage : class
    {
        if (!IsEndpointConfigured<TMessage>())
        {
            return Guid.Empty;
        }

        return await SendMessage(message);
    }

    public async Task<Guid> Send<TMessage>(TMessage message, ArtemisEndpoint replyToEndpoint) where TMessage : class
    {
        if (!IsEndpointConfigured<TMessage>())
        {
            return Guid.Empty;
        }

        return await SendMessage(message, (context) => context.Headers.Set("JMSReplyTo", replyToEndpoint.GetKbFullAddress()));
    }

    private async Task<Guid> SendMessage<TMessage>(TMessage message, Action<SendContext<TMessage>>? configure = null) where TMessage : class
    {
        Guid messageId = Guid.Empty;

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(10));

        await sendEndpointProvider.Send(message, Pipe.Execute<SendContext<TMessage>>(context =>
        {
            context.CorrelationId = messageId = Guid.NewGuid();

            configure?.Invoke(context);
        }), cts.Token);

        return messageId;
    }

    private static bool IsEndpointConfigured<TMessage>() where TMessage : class
    {
        return EndpointConvention.TryGetDestinationAddress<TMessage>(out var _);
    }
}
