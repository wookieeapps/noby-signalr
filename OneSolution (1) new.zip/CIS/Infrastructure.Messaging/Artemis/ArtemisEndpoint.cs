﻿namespace CIS.Infrastructure.Messaging.Artemis;

public record ArtemisEndpoint
{
    public required string Name { get; init; }

    public ArtemisEndpointType EndpointType { get; init; } = ArtemisEndpointType.Queue;

    public bool IsDisabled { get; init; }

    public string GetKbFullAddress()
    {
        return EndpointType switch
        {
            ArtemisEndpointType.Queue => $"queue://{Name}",
            ArtemisEndpointType.Topic => $"topic://{Name}",
            _ => throw new InvalidOperationException()
        };
    }

    public string GetFullAddress()
    {
        return EndpointType switch
        {
            ArtemisEndpointType.Queue => $"queue:{Name}",
            ArtemisEndpointType.Topic => $"topic:{Name}",
            _ => throw new InvalidOperationException()
        };
    }

    public enum ArtemisEndpointType
    {
        Queue,
        Topic
    }
}
