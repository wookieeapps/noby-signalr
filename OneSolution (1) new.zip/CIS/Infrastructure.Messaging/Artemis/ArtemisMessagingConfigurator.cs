﻿using CIS.Core.Configuration;
using MassTransit;
using Microsoft.Extensions.Configuration;

namespace CIS.Infrastructure.Messaging.Artemis;

internal class ArtemisMessagingConfigurator(IConfiguration configuration) : IArtemisMessagingConfigurator
{
    private readonly Dictionary<string, Action<IRegistrationContext, IActiveMqReceiveEndpointConfigurator>> _receiveEndpoints = [];

    private Action<IRegistrationConfigurator> _registration = delegate { };

    internal void Register(IRegistrationConfigurator registration) => _registration(registration);

    internal void ConfigureReceiveEndpoints(IRegistrationContext context, IActiveMqBusFactoryConfigurator configurator)
    {
        foreach (var item in _receiveEndpoints)
        {
            configurator.ReceiveEndpoint(item.Key, cfgEndpoint =>
            {
                cfgEndpoint.ConfigureConsumeTopology = false;
                cfgEndpoint.Durable = false;

                item.Value(context, cfgEndpoint);
            });
        }
    }

    public void AddConsumer<TConsumer>(ArtemisEndpoint endpoint) where TConsumer : class, IConsumer
    {
        if (endpoint.IsDisabled)
            return;

        var endpointName = endpoint.EndpointType switch
        {
            ArtemisEndpoint.ArtemisEndpointType.Queue => endpoint.Name,
            ArtemisEndpoint.ArtemisEndpointType.Topic => GetTopicName(endpoint),
            _ => throw new InvalidOperationException(),
        };

        _registration += cfg => cfg.AddConsumer<TConsumer>();

        var receiveEndpointConfig = _receiveEndpoints.GetValueOrDefault(endpointName) ?? delegate { };

        receiveEndpointConfig += static (context, cfgEndpoint) => cfgEndpoint.ConfigureConsumer<TConsumer>(context);

        _receiveEndpoints[endpointName] = receiveEndpointConfig;
    }

    public void AddArtemisCmdClient<TMessage>(ArtemisEndpoint endpoint) where TMessage : class
    {
        if (!endpoint.IsDisabled)
        {
            EndpointConvention.Map<TMessage>(new Uri(endpoint.GetFullAddress()));
        }
    }

    private string GetTopicName(ArtemisEndpoint endpoint) => $"{endpoint.Name}::{GetAppName(configuration)}.{endpoint.Name}";

    private static string GetAppName(IConfiguration configuration)
    {
        var environmentConfiguration = configuration
                                       .GetSection(Core.CisGlobalConstants.EnvironmentConfigurationSectionName)
                                       .Get<CisEnvironmentConfiguration>()!;

        return $"{environmentConfiguration.DefaultApplicationKey}-{environmentConfiguration.EnvironmentName}";
    }
}
