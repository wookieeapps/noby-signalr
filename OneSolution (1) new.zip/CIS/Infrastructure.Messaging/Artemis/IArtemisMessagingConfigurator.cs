﻿using MassTransit;

namespace CIS.Infrastructure.Messaging.Artemis;

public interface IArtemisMessagingConfigurator
{
    void AddConsumer<TConsumer>(ArtemisEndpoint endpoint) where TConsumer : class, IConsumer;

    void AddArtemisCmdClient<TMessage>(ArtemisEndpoint endpoint) where TMessage : class;
}
