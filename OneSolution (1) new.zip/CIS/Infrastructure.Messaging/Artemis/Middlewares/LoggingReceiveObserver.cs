﻿using CIS.Infrastructure.Messaging.Shared.Logging;
using cz.kb.speed.exception.error.model;
using MassTransit;
using Microsoft.Extensions.Logging;
using System.Text;

namespace CIS.Infrastructure.Messaging.Artemis.Middlewares;

internal class LoggingReceiveObserver(ILogger<LoggingReceiveObserver> logger) : IReceiveObserver, IConsumeObserver
{
    private const string _messageJmsCorrelationHeaderName = "JMSCorrelationID";

    private readonly MessagingLogger _messagingLogger = new(logger, "Artemis");

    public Task PreReceive(ReceiveContext context)
    {
        var b3 = context.TransportHeaders.Get<string>("b3");

        if (!string.IsNullOrWhiteSpace(b3))
        {
            _messagingLogger.StartActivityByB3Header(b3);
        }

        var messageReceived = new MessageInformationToLogDto
        {
            MessageId = GetMessageId(context),
            TopicOrQueue = context.InputAddress.ToString(),
            Headers = context.TransportHeaders.GetAll().ToDictionary(),
        };

        _messagingLogger.MessageReceived(messageReceived);

        return Task.CompletedTask;
    }

    public Task PreConsume<T>(ConsumeContext<T> context) where T : class
    {
        _messagingLogger.MessageDeserialized(GetMessageId(context.ReceiveContext), context.Message);

        return Task.CompletedTask;
    }

    private static Guid? GetMessageId(ReceiveContext context)
    {
        return context.TransportHeaders.GetCorrelationId() ?? context.TransportHeaders.GetHeaderId(_messageJmsCorrelationHeaderName);
    }

    public Task ConsumeFault<T>(ConsumeContext<T> context, TimeSpan duration, string consumerType, Exception exception) where T : class => Task.CompletedTask;
    public Task PostConsume<T>(ConsumeContext<T> context, TimeSpan duration, string consumerType) where T : class => Task.CompletedTask;
    public Task PostReceive(ReceiveContext context) => Task.CompletedTask;
    public Task ReceiveFault(ReceiveContext context, Exception exception) => Task.CompletedTask;
    public Task PostConsume<T>(ConsumeContext<T> context) where T : class => Task.CompletedTask;
    public Task ConsumeFault<T>(ConsumeContext<T> context, Exception exception) where T : class => Task.CompletedTask;
}
