﻿using System.Net.Mime;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal static class ArtemisSerializerVariables
{
    public const string AvroContentTypeName = "avro/binary";
    public const string JsonContentTypeName = MediaTypeNames.Application.Json;

    public static readonly ContentType AvroContentType = new(AvroContentTypeName);
    public static readonly ContentType JsonContentType = new(JsonContentTypeName);
}
