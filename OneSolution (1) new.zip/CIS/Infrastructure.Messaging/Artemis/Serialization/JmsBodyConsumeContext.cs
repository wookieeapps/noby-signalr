﻿using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using Apache.NMS;
using MassTransit;
using MassTransit.ActiveMqTransport;
using MassTransit.Serialization;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal class JmsBodyConsumeContext : BodyConsumeContext
{
    private readonly ActiveMqReceiveContext activeMqReceiveContext;

    private Guid? requestId;
    private Guid? messageId;
    private Guid? correlationId;
    private Uri? responseAddress;

    public JmsBodyConsumeContext([DisallowNull] ActiveMqReceiveContext receiveContext, [DisallowNull] SerializerContext serializerContext) : base(receiveContext, serializerContext)
    {
        activeMqReceiveContext = receiveContext ?? throw new ArgumentNullException(nameof(receiveContext));
    }

    public override Guid? RequestId => requestId ??= GetCorrelationId();

    public override Guid? MessageId => messageId ??= GetMessageId();

    public override Guid? CorrelationId => correlationId ??= GetCorrelationId();

    public override Uri ResponseAddress => responseAddress ??= GetResponseAddress();

    private Guid? GetMessageId()
    {
        return GetNmsId(activeMqReceiveContext.TransportMessage.NMSMessageId);
    }

    private Guid? GetCorrelationId()
    {
        return GetNmsId(activeMqReceiveContext.TransportMessage.NMSCorrelationID);
    }

    private static Guid? GetNmsId(string id)
    {
        if (id is not null && (Guid.TryParse(id, CultureInfo.InvariantCulture, out Guid guid) || Guid.TryParse(id.Split(":")[1], CultureInfo.InvariantCulture, out guid)))
        {
            return guid;
        }
        return null;
    }

    private Uri GetResponseAddress()
    {
        var replyToddress = activeMqReceiveContext.TransportMessage.NMSReplyTo;
        return replyToddress switch
        {
            null => base.ResponseAddress,
            IQueue queue => new Uri($"queue:{queue.QueueName}"),
            ITopic topic => new Uri($"topic:{topic.TopicName}"),
            _ => throw new Exception($"Unknown reply to address type: {replyToddress?.GetType()?.FullName}")
        };
    }
}
