﻿using MassTransit.ActiveMqTransport;

namespace CIS.Infrastructure.Messaging.Artemis;

internal class TemporaryVirtualConsumerQueueNameFormater : IActiveMqConsumerEndpointQueueNameFormatter
{
    public string Format(string topic, string endpointName)
    {
        return $"temp-queue://{topic}::Consumer.{endpointName}.{topic}";
    }
}
