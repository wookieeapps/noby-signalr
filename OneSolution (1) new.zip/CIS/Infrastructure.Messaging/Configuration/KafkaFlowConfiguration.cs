﻿using CIS.Infrastructure.Messaging.KafkaFlow.Configuration.WorkersCountStrategy;
using Confluent.Kafka;

namespace CIS.Infrastructure.Messaging.Configuration;

public enum SchemaIdentificationType
{
    ContentId,
    GlobalId
}

public class KafkaFlowConfiguration
{
    public bool Disabled { get; set; }

    public IEnumerable<string> Brokers { get; set; } = [];

    public SchemaRegistryConfiguration? SchemaRegistry { get; set; }

    public int BufferSize { get; set; } = 5;

    public int WorkersCount { get; set; } = 10;

    public Dictionary<string, WorkersCountStrategyConfiguration> WorkersCountStrategy { get; set; } = new();

    public bool LogConsumingMessagePayload { get; set; } = true;

    public SecurityProtocol SecurityProtocol { get; set; } = SecurityProtocol.Ssl;

    public string? SslKeyLocation { get; set; }

    public string? SslKeyPassword { get; set; }

    public string? SslCertificateLocation { get; set; }
}