﻿namespace CIS.Infrastructure.Messaging.Configuration;

public class SchemaRegistryConfiguration
{
    public string SchemaRegistryUrl { get; set; } = null!;

    public SchemaIdentificationType SchemaIdentificationType { get; set; } = SchemaIdentificationType.ContentId;
}
