﻿using KafkaFlow;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Text.Json;
using CIS.Infrastructure.Messaging.Configuration;

namespace CIS.Infrastructure.Messaging.KafkaFlow.Middlewares;

internal sealed class LoggingKnownMessagesMiddleware(
    KafkaFlowConfiguration _configuration, 
    ILogger<LoggingKnownMessagesMiddleware> _logger) 
    : IMessageMiddleware
{
    private static readonly JsonSerializerOptions _jsonSerializerOptions = new() { IgnoreReadOnlyProperties = true, IgnoreReadOnlyFields = true };

    public Task Invoke(IMessageContext context, MiddlewareDelegate next)
    {
        if (context.Message.Value is null or byte[])
            return next(context);

        var messageKey = GetOrSetKey(context);

        var loggerData = new Dictionary<string, object>
        {
            { "ConsumerName", context.ConsumerContext.ConsumerName },
            { "MessageType", context.Message.Value.GetType().FullName! },
            { "KafkaOffset", context.ConsumerContext.Offset }
        };

        if (_configuration.LogConsumingMessagePayload)
        {
            var messageData = JsonSerializer.Serialize(context.Message.Value, _jsonSerializerOptions);

            loggerData.Add("Payload", messageData);
        }

        using (_logger.BeginScope(loggerData))
        {
            _logger.ConsumingKnownMessage(context.Message.Value.GetType().FullName!, messageKey, context.ConsumerContext.Topic);
        }

        return next(context);
    }

    private static string GetOrSetKey(IMessageContext context)
    {
        if (context.Message.Key is byte[] keyBytes)
        {
            return Encoding.UTF8.GetString(keyBytes);
        }

        var newKey = $"NOBY-{Guid.NewGuid}";

        context.SetMessage(Encoding.UTF8.GetBytes(newKey), context.Message);

        return newKey;
    }
}