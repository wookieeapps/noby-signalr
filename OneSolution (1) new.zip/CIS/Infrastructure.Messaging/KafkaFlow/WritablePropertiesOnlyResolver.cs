﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace CIS.Infrastructure.Messaging.KafkaFlow;

internal class WritablePropertiesOnlyResolver : DefaultContractResolver
{
    protected override IList<JsonProperty> CreateProperties(Type type, MemberSerialization memberSerialization)
    {
        return base.CreateProperties(type, memberSerialization).Where(p => p.Writable).ToList();
    }
}
