﻿namespace CIS.Infrastructure.Messaging.Shared;

internal interface IKbSpeedMessagingHeadersProvider
{
    public delegate void SetHeaderDelegate(string key, string? value);

    void SetKbHeaders(SetHeaderDelegate headerSetter);
}