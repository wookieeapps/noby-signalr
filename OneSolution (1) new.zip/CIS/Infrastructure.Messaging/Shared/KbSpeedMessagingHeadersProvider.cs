﻿using CIS.Core.Configuration;
using CIS.Core.Security;
using System.Diagnostics;

namespace CIS.Infrastructure.Messaging.Shared;

internal class KbSpeedMessagingHeadersProvider(
    ICurrentUserAccessor _currentUserAccessor,
    ICisEnvironmentConfiguration _cisEnvironmentConfiguration) 
    : IKbSpeedMessagingHeadersProvider
{
    private const string _defaultAppValue = "NOBY";
    private const string _defaultAppCompOriginatorValue = "NOBY-FEAPI";

    public void SetKbHeaders(IKbSpeedMessagingHeadersProvider.SetHeaderDelegate headerSetter)
    {
        headerSetter("b3", $"{Activity.Current!.TraceId}-{Activity.Current.SpanId}-1-{Activity.Current.ParentSpanId}");
        headerSetter("x_HYPHEN_kb_HYPHEN_orig_HYPHEN_system_HYPHEN_identity", $$"""{"app":"{{_defaultAppValue}}","appComp":"{{_defaultAppCompOriginatorValue}}"}""");
        headerSetter("x_HYPHEN_kb_HYPHEN_caller_HYPHEN_system_HYPHEN_identity", $$"""{"app":"{{_defaultAppValue}}","appComp":"{{_cisEnvironmentConfiguration.DefaultApplicationKey!}}"}""");

        if (!string.IsNullOrEmpty(_currentUserAccessor?.User?.Login))
        {
            var index = _currentUserAccessor.User.Login.IndexOf('=');

            if (index > 0)
            {
                headerSetter("x_HYPHEN_kb_HYPHEN_party_HYPHEN_identity_HYPHEN_in_HYPHEN_service",
                    $$"""{"partyIdIS":[{"partyId":{"idScheme":"{{_currentUserAccessor.User.Login[..index]}}","id":"{{_currentUserAccessor.User.Login[(index + 1)..]}}"},"usg":"BA"}]}""");
            }
        }
    }
}
