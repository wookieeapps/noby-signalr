﻿using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Text.Json;

namespace CIS.Infrastructure.Messaging.Shared.Logging;

internal class MessagingLogger(ILogger logger, string messagingProvider)
{
    private const string _payloadKeyword = "Payload";

    private static readonly JsonSerializerOptions _jsonSerializerOptions = new() { IgnoreReadOnlyProperties = true, IgnoreReadOnlyFields = true };

    public void StartActivityByB3Header(string b3Value)
    {
        var traceId = b3Value.Split('-').ElementAtOrDefault(0);

        if (string.IsNullOrWhiteSpace(traceId))
        {
            return;
        }

        var activityTraceId = ActivityTraceId.CreateFromString(traceId);

        var activity = new Activity(messagingProvider).SetIdFormat(ActivityIdFormat.W3C);
        activity.SetParentId(activityTraceId, ActivitySpanId.CreateRandom(), ActivityTraceFlags.Recorded);

        activity.Start();
        Activity.Current = activity;
    }

    public void MessageReceived(MessageInformationToLogDto messageInformationToLog)
    {
        var loggerData = new Dictionary<string, object>()
        {
            { _payloadKeyword, messageInformationToLog.Headers }
        };

        using (logger.BeginScope(loggerData))
        {
            logger.MessageReceived(messagingProvider, messageInformationToLog.MessageId, messageInformationToLog.TopicOrQueue);
        }
    }

    public void MessageDeserialized<TMessage>(Guid? messageId, TMessage messageBody) where TMessage : class
    {
        var loggerData = new Dictionary<string, object>
        {
            { "MessageType", typeof(TMessage).FullName! },
            { _payloadKeyword, JsonSerializer.Serialize(messageBody, _jsonSerializerOptions) }
        };

        using (logger.BeginScope(loggerData))
        {
            logger.MessageDeserialized(messagingProvider, messageId);
        }
    }

    public void MessageSent(MessageInformationToLogDto messageInformationToLog)
    {
        var payloadObj = new PayloadLogDto
        {
            Headers = messageInformationToLog.Headers,
            Message = messageInformationToLog.Message!
        };

        var loggerData = new Dictionary<string, object>()
        {
            { _payloadKeyword, JsonSerializer.Serialize(payloadObj, _jsonSerializerOptions) }
        };

        using (logger.BeginScope(loggerData))
        {
            logger.MessageSent(messagingProvider, messageInformationToLog.MessageId, messageInformationToLog.TopicOrQueue);
        }
    }
}
