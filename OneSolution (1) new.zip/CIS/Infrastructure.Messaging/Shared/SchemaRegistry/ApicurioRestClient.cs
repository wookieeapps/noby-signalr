﻿using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Confluent.SchemaRegistry;
using KB.Speed.Messaging.Kafka.SchemaRegistry;
using Microsoft.Extensions.Logging;

namespace CIS.Infrastructure.Messaging.Shared.SchemaRegistry;

public class ApicurioRestClient : IApicurioRestClient
{
    private const string DefaultGroupName = "default";
    private const string SchemaUri = "/apis/registry/v2/ids/contentIds/{0}";

    private readonly HttpClient _httpClient;
    private readonly ILogger<ApicurioClient>? _logger;
    private readonly JsonSerializerOptions _serializerOptions;

    public ApicurioRestClient(HttpClient httpClient, ILogger<ApicurioClient> logger)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _logger = logger;

        _serializerOptions = new JsonSerializerOptions();
        _serializerOptions.Converters.Add(new SchemaTypeConverter());
    }

    /// <inheritdoc/>
    public Task<Schema> GetSchemaAsync(int id)
    {
        return GetSchemaAsync(id, CancellationToken.None);
    }

    /// <inheritdoc/>
    public async Task<Schema> GetSchemaAsync(int id, CancellationToken cancellationToken)
    {
        var uri = new Uri(string.Format(CultureInfo.InvariantCulture, SchemaUri, id), UriKind.Relative);
        var (statusCode, schema) = await ExecuteGetAsync(uri, cancellationToken);

        return statusCode switch
        {
            HttpStatusCode.OK => new Schema(schema, SchemaType.Avro),
            HttpStatusCode.NotFound => throw new SchemaRegistryException("Schema not found", statusCode, (int)statusCode),
            _ => throw new SchemaRegistryException("Schema unknown error", statusCode, (int)statusCode)
        };
    }

    /// <inheritdoc/>
    public Task<RegisteredSchema> GetSchemaAsync(string subject, int version)
    {
        return GetSchemaAsync(subject, version, CancellationToken.None);
    }

    /// <inheritdoc/>
    public Task<RegisteredSchema> GetSchemaAsync(string subject, int version, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(subject))
        {
            throw new ArgumentNullException(nameof(subject));
        }

        var (groupId, artifactId) = GetSchemaIdentificationWithDefaultGroup(subject);
        var uri = new Uri($"/apis/registry/v2/groups/{groupId}/artifacts/{artifactId}/versions/{version}/meta", UriKind.Relative);
        return GetSchemaImplAsync(subject, uri, cancellationToken);
    }

    /// <inheritdoc/>
    public Task<RegisteredSchema> LookupSchemaAsync(string subject, Schema schema)
    {
        return LookupSchemaAsync(subject, schema, CancellationToken.None);
    }

    /// <inheritdoc/>
    public async Task<RegisteredSchema> LookupSchemaAsync(string subject, Schema schema, CancellationToken cancellationToken)
    {
        var identification = GetSchemaIdentificationWithDefaultGroup(subject, schema);
        var uri = new Uri($"/apis/registry/v2/groups/{identification.groupId}/artifacts/{identification.artifactId}/meta", UriKind.Relative);
        var content = new StringContent(schema.SchemaString);
        content.Headers.ContentType!.MediaType = "application/vnd.schemaregistry.v1+json";

        var response = await _httpClient.PostAsync(uri, content, cancellationToken);
        if (response.StatusCode == HttpStatusCode.NotFound)
        {
            return await LookupSchemaAsyncByVersionAsync(subject, identification, schema, cancellationToken);
        }
        if (response.StatusCode != HttpStatusCode.OK)
        {
            throw new SchemaRegistryException("Schema metada not found", response.StatusCode, (int)response.StatusCode);
        }
        var metadata = await response.Content.ReadFromJsonAsync<SchemaMetadata>(_serializerOptions, cancellationToken);

        return new RegisteredSchema(
            subject,
            int.Parse(metadata!.Version!, CultureInfo.InvariantCulture),
            metadata!.ContentId,
            schema.SchemaString,
            schema.SchemaType,
            null);
    }

    /// <inheritdoc/>
    public Task<List<int>> GetAvailableVersionsAsync(string subject)
    {
        return GetAvailableVersionsAsync(subject, CancellationToken.None);
    }

    ///<inheritdocs/>
    public async Task<List<int>> GetAvailableVersionsAsync(string subject, CancellationToken cancellationToken)
    {
        var (groupId, artifactId) = GetSchemaIdentificationWithDefaultGroup(subject)
            ;
        var uri = new Uri($"/apis/registry/v2/groups/{groupId}/artifacts/{artifactId}/versions", UriKind.Relative);
        var (statusCode, data) = await ExecuteGetAsync<AvailableVersions>(uri, _serializerOptions, cancellationToken);

        return statusCode switch
        {
            HttpStatusCode.OK when data is not null && data.Versions is not null =>
                new List<int>(data.Versions.Where(v => !string.IsNullOrEmpty(v.Version)).Select(v => int.Parse(v.Version!, CultureInfo.InvariantCulture))),
            HttpStatusCode.OK => throw new SchemaRegistryException("Schema version not found", statusCode, (int)statusCode),
            HttpStatusCode.NotFound => throw new SchemaRegistryException("Schema not found", statusCode, (int)statusCode),
            _ => throw new SchemaRegistryException("Schema metada not found", statusCode, (int)statusCode)
        };
    }

    private async Task<RegisteredSchema> LookupSchemaAsyncByVersionAsync(string subject, (string groupId, string artifactId) identification, Schema schema, CancellationToken cancellationToken)
    {
        var uri = new Uri($"/apis/registry/v2/groups/{identification.groupId}/artifacts/{identification.artifactId}/versions", UriKind.Relative);
        var response = await ExecuteGetAsync<AvailableVersions>(uri, _serializerOptions, cancellationToken);
        if (response.data == null || response.data.Versions == null)
        {
            throw new SchemaRegistryException("Metadata not found", HttpStatusCode.NotFound, (int)HttpStatusCode.NotFound);
        }
        foreach (var item in response.data.Versions.OrderByDescending(v => int.Parse(v.Version!, CultureInfo.InvariantCulture)))
        {
            var versionUri = new Uri($"/apis/registry/v2/groups/{identification.groupId}/artifacts/{identification.artifactId}/versions/{item.Version}", UriKind.Relative);
            var (statusCode, versionSchemaText) = await ExecuteGetAsync(versionUri, cancellationToken);
            if (statusCode != HttpStatusCode.OK)
            {
                continue;
            }
            var versionSchema = Avro.Schema.Parse(versionSchemaText);
            var normalizeSchema = Avro.Schema.Parse(schema.SchemaString);
            if (string.Equals(versionSchema.ToString(), normalizeSchema.ToString(), StringComparison.InvariantCultureIgnoreCase))
            {
                return new RegisteredSchema(subject, int.Parse(item.Version!, CultureInfo.InvariantCulture), item.ContentId, versionSchemaText, SchemaType.Avro, null);
            }
        }
        throw new SchemaRegistryException("Schema metada not found", HttpStatusCode.NotFound, (int)HttpStatusCode.NotFound);
    }

    private async Task<RegisteredSchema> GetSchemaImplAsync(string subject, Uri uri, CancellationToken cancellationToken)
    {
        var (statusCode, metaData) = await ExecuteGetAsync<SchemaMetadata>(uri, _serializerOptions, cancellationToken);
        return statusCode switch
        {
            HttpStatusCode.OK when metaData is not null => await GetSchemaAsync(metaData, subject, cancellationToken),
            HttpStatusCode.NotFound => throw new SchemaRegistryException("Schema metada not found", statusCode, (int)statusCode),
            _ => throw new SchemaRegistryException("Schema metada not found", statusCode, (int)statusCode)
        };
    }

    private async Task<RegisteredSchema> GetSchemaAsync(SchemaMetadata metaData, string subject, CancellationToken cancellationToken)
    {
        var schema = await GetSchemaAsync(metaData.ContentId, cancellationToken);
        return new RegisteredSchema(subject, int.Parse(metaData.Version!, CultureInfo.InvariantCulture), metaData.ContentId, schema.SchemaString, metaData.Type.GetValueOrDefault(SchemaType.Avro), null);
    }

    private static (string groupId, string artifactId) GetSchemaIdentificationWithDefaultGroup(string subject, Schema schema)
    {
        return (DefaultGroupName, WebUtility.UrlEncode(subject));
    }

    private static (string groupId, string artifactId) GetSchemaIdentificationWithDefaultGroup(string subject)
    {
        return (DefaultGroupName, WebUtility.UrlEncode(subject));
    }

    private async Task<(HttpStatusCode statusCode, T? data)> ExecuteGetAsync<T>(Uri uri, JsonSerializerOptions serializationOptions, CancellationToken cancellationToken)
    {
        var result = await _httpClient.GetAsync(uri, cancellationToken);
        if (!result.IsSuccessStatusCode)
        {
            return (result.StatusCode, default(T));
        }
        var data = await result.Content.ReadFromJsonAsync<T>(serializationOptions, cancellationToken);
        return (result.StatusCode, data);
    }

    private async Task<(HttpStatusCode statusCode, string? data)> ExecuteGetAsync(Uri uri, CancellationToken cancellationToken)
    {
        var result = await _httpClient.GetAsync(uri, cancellationToken);
        if (!result.IsSuccessStatusCode)
        {
            return (result.StatusCode, null);
        }
        var data = await result.Content.ReadAsStringAsync(cancellationToken);
        return (result.StatusCode, data);
    }
}
