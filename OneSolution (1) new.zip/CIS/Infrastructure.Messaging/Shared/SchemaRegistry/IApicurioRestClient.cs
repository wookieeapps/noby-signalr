﻿using Confluent.SchemaRegistry;

namespace KB.Speed.Messaging.Kafka.SchemaRegistry;

/// <summary>
/// Apicurio rest client interface
/// </summary>
public interface IApicurioRestClient
{
    /// <summary>
    ///     Gets the schema uniquely identified by <paramref name="id" />.
    /// </summary>
    /// <param name="id">
    ///     The unique id of schema to get.
    /// </param>
    /// <returns>
    ///     The schema identified by <paramref name="id" />.
    /// </returns>
    Task<Schema> GetSchemaAsync(int id);

    /// <summary>
    ///     Gets the schema uniquely identified by <paramref name="id" />.
    /// </summary>
    /// <param name="id">
    ///     The unique id of schema to get.
    /// </param>
    /// <param name="cancellationToken"></param>
    /// <returns>
    ///     The schema identified by <paramref name="id" />.
    /// </returns>
    Task<Schema> GetSchemaAsync(int id, CancellationToken cancellationToken);

    /// <summary>
    ///     Gets a schema given a <paramref name="subject" /> and <paramref name="version" /> number.
    /// </summary>
    /// <param name="subject">
    ///     The subject to get the schema for.
    /// </param>
    /// <param name="version">
    ///     The version number of schema to get.
    /// </param>
    /// <returns>
    ///     The schema identified by the specified <paramref name="subject" /> and <paramref name="version" />.
    /// </returns>
    Task<RegisteredSchema> GetSchemaAsync(string subject, int version);

    /// <summary>
    ///     Gets a schema given a <paramref name="subject" /> and <paramref name="version" /> number.
    /// </summary>
    /// <param name="subject">
    ///     The subject to get the schema for.
    /// </param>
    /// <param name="version">
    ///     The version number of schema to get.
    /// </param>
    /// <param name="cancellationToken"></param>
    /// <returns>
    ///     The schema identified by the specified <paramref name="subject" /> and <paramref name="version" />.
    /// </returns>
    Task<RegisteredSchema> GetSchemaAsync(string subject, int version, CancellationToken cancellationToken);

    /// <summary>
    ///     Get the registered schema details (including version and id)
    ///     given a subject name and schema, or throw an exception if
    ///     the schema is not registered against the subject.
    /// </summary>
    /// <param name="subject">
    ///     The subject name the schema is registered against.
    /// </param>
    /// <param name="schema">
    ///     The schema to lookup.
    /// </param>
    /// <returns>
    ///     The schema identified by the specified <paramref name="subject" /> and <paramref name="schema" />.
    /// </returns>
    Task<RegisteredSchema> LookupSchemaAsync(string subject, Schema schema);

    /// <summary>
    ///     Get the registered schema details (including version and id)
    ///     given a subject name and schema, or throw an exception if
    ///     the schema is not registered against the subject.
    /// </summary>
    /// <param name="subject">
    ///     The subject name the schema is registered against.
    /// </param>
    /// <param name="schema">
    ///     The schema to lookup.
    /// </param>
    /// <param name="cancellationToken"></param>
    /// <returns>
    ///     The schema identified by the specified <paramref name="subject" /> and <paramref name="schema" />.
    /// </returns>
    Task<RegisteredSchema> LookupSchemaAsync(string subject, Schema schema, CancellationToken cancellationToken);

    /// <summary>
    /// Get list of version numbers for a specific schema
    /// </summary>
    /// <param name="subject">The subject name the schema is registered against.</param>
    /// <returns></returns>
    Task<List<int>> GetAvailableVersionsAsync(string subject);

    /// <summary>
    /// Get list of version numbers for a specific schema
    /// </summary>
    /// <param name="subject">The subject name the schema is registered against.</param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    Task<List<int>> GetAvailableVersionsAsync(string subject, CancellationToken cancellationToken);
}
