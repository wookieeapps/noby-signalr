﻿namespace cz.kb.speed.exception.error.model;

public class ErrorModel
{
    public int Category { get; set; }

    public string? Code { get; set; }

    public string? Detail { get; set; }

    public string? Message { get; set; }

    public string? Uuid { get; set; }
}
