﻿namespace CIS.Infrastructure.Security
{
    /// <summary>
    /// Konfigurace a helpery pro autentizaci gRPC služeb.
    /// </summary>
    internal static class AssemblyDoc { }

    /// <summary>
    /// Helpery pro autentizaci gRPC služeb.
    /// </summary>
    internal static class NamespaceDoc { }
}

namespace CIS.Infrastructure.Security.Configuration
{
    /// <summary>
    /// Nastavení konfigurace autentizace z appsettings.json.
    /// </summary>
    internal static class NamespaceDoc { }
}
