﻿namespace CIS.Infrastructure.Security;

public struct InternalServicesAuthentication
{
    public const string DefaultSchemeName = "CISInternalService";

    public const string ContextUserSchemeName = "CISInternalServiceContext";
}
