﻿namespace CIS.Infrastructure.Telemetry.Configuration;

public enum LogBehaviourTypes
{
    Any,
    WebApi,
    Grpc
}