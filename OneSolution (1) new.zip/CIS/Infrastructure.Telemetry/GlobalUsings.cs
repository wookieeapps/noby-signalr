﻿global using Microsoft.Extensions.DependencyInjection;
global using CIS.Infrastructure.Telemetry.Configuration;
