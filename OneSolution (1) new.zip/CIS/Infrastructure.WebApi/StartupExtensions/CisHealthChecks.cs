﻿using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace CIS.Infrastructure.WebApi;

public static class CisHealthChecks
{
    public static IHealthChecksBuilder AddCisHealthChecks(this WebApplicationBuilder builder)
    {
        // base hc
        var hc = builder.Services.AddHealthChecks();

        // health check na databaze podle dostupnych connection stringu
        var cs = builder.Configuration.GetConnectionString("default");
        if (!string.IsNullOrEmpty(cs))
        {
            hc.AddSqlServer(cs, name: "default");
        }

        return hc;
    }

    public static IEndpointConventionBuilder MapCisHealthChecks(this IEndpointRouteBuilder endpoints)
    {
        return endpoints.MapHealthChecks(CIS.Core.CisGlobalConstants.CisHealthCheckEndpointUrl, new HealthCheckOptions
        {
            ResultStatusCodes =
            {
                [HealthStatus.Healthy] = StatusCodes.Status200OK,
                [HealthStatus.Degraded] = StatusCodes.Status200OK,
                [HealthStatus.Unhealthy] = StatusCodes.Status503ServiceUnavailable
            }
        });
    }
}
