﻿using CIS.Core.Exceptions;
using CIS.Core.Exceptions.ExternalServices;
using CIS.Infrastructure.ConcurrentExecution;
using CIS.Infrastructure.Logging;
using Google.Rpc;
using Grpc.Core;
using Grpc.Core.Interceptors;
using Microsoft.Extensions.Logging;

#pragma warning disable CA1860 // Avoid using 'Enumerable.Any()' extension method

namespace CIS.Infrastructure.gRPC;

/// <summary>
/// Client Interceptor pro konverzi RpcException na CIS vyjímky.
/// </summary>
/// <remarks>
/// Používáme, abychom chyby z doménových služeb přetavili z generické RpcException na konkrétní vyjímky, které vyhodila daná doménová služba.
/// </remarks>
public sealed class GenericClientExceptionInterceptor
    : Interceptor
{
    private readonly ILogger<GenericClientExceptionInterceptor> _logger;

    public GenericClientExceptionInterceptor(ILogger<GenericClientExceptionInterceptor> logger)
    {
        _logger = logger;
    }

    public override AsyncUnaryCall<TResponse> AsyncUnaryCall<TRequest, TResponse>(TRequest request,
        ClientInterceptorContext<TRequest, TResponse> context,
        AsyncUnaryCallContinuation<TRequest, TResponse> continuation)
    {
        var newOptions = context.Options.WithDeadline(DateTime.UtcNow.AddMinutes(5));
        var newContext = new ClientInterceptorContext<TRequest, TResponse>(context.Method, context.Host, newOptions);

        var response = continuation(request, newContext);
        var task = catcher(response, context.Method.ServiceName, context.Method.FullName);
        return new AsyncUnaryCall<TResponse>(task, response.ResponseHeadersAsync, response.GetStatus, response.GetTrailers, response.Dispose);
    }

    private async Task<TResponse> catcher<TResponse>(AsyncUnaryCall<TResponse> responseAsync, string serviceName, string methodFullName)
    {
        try
        {
            return await responseAsync;
        }
        // DS neni dostupna
        catch (RpcException ex) when (ex.StatusCode == StatusCode.Unavailable) // nedostupna sluzba
        {
            _logger.ServiceUnavailable("GRPC service unavailable", ex);
            throw new CisServiceUnavailableException(serviceName, methodFullName, ex.Message);
        }
        // 403
        catch (RpcException ex) when (ex.StatusCode == StatusCode.PermissionDenied)
        {
            var detail = ex.GetRpcStatus()?.GetDetail<PreconditionFailure>();
            throw new CisAuthorizationException(ex.Message, detail?.Violations?.FirstOrDefault()?.Subject);
        }
        // entity neexistuje
        catch (RpcException ex) when (ex.StatusCode == StatusCode.NotFound)
        {
            var detail = ex.GetRpcStatus()?.GetDetail<ResourceInfo>();
            _ = int.TryParse(detail?.Description, out int exceptionCode);
            if (string.IsNullOrEmpty(detail?.ResourceType))
            {
                throw new CisNotFoundException(exceptionCode, ex.Status.Detail);
            }
            else
            {
                throw new CisNotFoundException(exceptionCode, detail.ResourceType, detail.ResourceName ?? "");
            }
        }
        // entita jiz existuje
        catch (RpcException ex) when (ex.StatusCode == StatusCode.AlreadyExists)
        {
            var detail = ex.GetRpcStatus()?.GetDetail<ResourceInfo>();
            _ = int.TryParse(detail?.Description, out int exceptionCode);
            throw new CisAlreadyExistsException(exceptionCode, detail?.ResourceType ?? "", detail?.ResourceName ?? "");
        }
        // validacni chyby vyvolane validatorem nebo rucne
        catch (RpcException ex) when (ex.Trailers != null && ex.StatusCode == StatusCode.InvalidArgument)
        {
            var detail = ex.GetRpcStatus()?.GetDetail<BadRequest>();
            if (detail?.FieldViolations.Any() ?? false)
            {
                throw new CisValidationException(detail.FieldViolations.Select(t => new CisExceptionItem(t.Field, t.Description)));
            }
            else
            {
                throw new CisValidationException(ex.Status.Detail);
            }
        }
        // externi sluzba neni dostupna nebo vratila 500
        catch (RpcException ex) when (ex.StatusCode == StatusCode.Aborted)
        {
            var detailResource = ex.GetRpcStatus()?.GetDetail<ResourceInfo>();
            var detailInfo = ex.GetRpcStatus()?.GetDetail<ErrorInfo>();
            _ = int.TryParse(detailInfo?.Reason, out int exceptionCode);
            _ = int.TryParse(detailResource?.Description, out int internalCode);

            // externi sluzba vratila http 500
            if (internalCode == CisExternalServiceServerErrorException.DefaultExceptionCode)
            {
                throw new CisExternalServiceUnavailableException(exceptionCode, detailResource?.ResourceName ?? "");
            }
            else if (detailResource?.ResourceType == nameof(ConcurrentRequestException))
            {
                throw new ConcurrentRequestException();
            }
            else
            {
                throw new CisExternalServiceUnavailableException(exceptionCode, detailResource?.ResourceName ?? "");
            }
        }
        catch (RpcException ex) when (ex.Trailers != null && ex.StatusCode == StatusCode.Unknown)
        {
            var detail = ex.GetRpcStatus()?.GetDetail<ErrorInfo>();
            _logger.ClientUncoughtRpcException($"RPC exception in {methodFullName}; Domain: {detail?.Domain}; Reason: {detail?.Reason}", ex);
            
            throw new CisValidationException(detail?.Domain ?? "", detail?.Reason ?? "");
        }
        catch (RpcException ex)
        {
            _logger.ClientUncoughtRpcException(methodFullName, ex);
            throw;
        }
    }
}
