﻿namespace CIS.Infrastructure.ConcurrentExecution;

public sealed class ConcurrentRequestException : Exception
{
    public ConcurrentRequestException(string message) : base(message)
    {
    }

    public ConcurrentRequestException(string message, Exception innerException) : base(message, innerException)
    {
    }

    public ConcurrentRequestException()
    {
    }
}