﻿namespace CIS.Infrastructure.ConcurrentExecution;

public interface IConcurrentExecutionService
{
    Task<IAsyncDisposable> PreventConcurrentExecutionAsync<TKey>(TKey key, string callerName) where TKey : notnull;
}