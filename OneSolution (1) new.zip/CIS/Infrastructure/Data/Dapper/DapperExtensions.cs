﻿using System.Data;
using CIS.Core.Data;
using Dapper;

namespace CIS.Infrastructure.Data;

public static class DapperExtensions
{
    public static async Task<List<T>> ExecuteDapperRawSqlToListAsync<T>(this IConnectionProvider connectionProvider, string sqlQuery, CancellationToken cancellationToken = default)
        => await connectionProvider.ExecuteDapperQueryAsync<List<T>>(async c => (await c.QueryAsync<T>(sqlQuery)).AsList(), cancellationToken);
    
    public static async Task<List<T>> ExecuteDapperRawSqlToListAsync<T>(this IConnectionProvider connectionProvider, string sqlQuery, object param, CancellationToken cancellationToken = default)
        => await connectionProvider.ExecuteDapperQueryAsync<List<T>>(async c => (await c.QueryAsync<T>(sqlQuery, param)).AsList(), cancellationToken);

    public static async Task<List<dynamic>> ExecuteDapperRawSqlToDynamicListAsync(this IConnectionProvider connectionProvider, string sqlQuery, object? param = null, CancellationToken cancellationToken = default)
        => await connectionProvider.ExecuteDapperQueryAsync<List<dynamic>>(async c => (await c.QueryAsync(sqlQuery, param)).AsList(), cancellationToken);

    public static async Task<T?> ExecuteDapperRawSqlFirstOrDefaultAsync<T>(this IConnectionProvider connectionProvider, string sqlQuery, CancellationToken cancellationToken = default)
        => await connectionProvider.ExecuteDapperQueryAsync<T?>(async c => await c.QueryFirstOrDefaultAsync<T>(sqlQuery), cancellationToken);
    
    public static async Task<T?> ExecuteDapperRawSqlFirstOrDefaultAsync<T>(this IConnectionProvider connectionProvider, string sqlQuery, object param, CancellationToken cancellationToken = default)
        => await connectionProvider.ExecuteDapperQueryAsync<T?>(async c => await c.QueryFirstOrDefaultAsync<T>(sqlQuery, param), cancellationToken);

    public static async Task<T?> ExecuteDapperFirstOrDefaultAsync<T>(this IConnectionProvider connectionProvider, string sqlQuery, object param, CancellationToken cancellationToken = default)
        => await connectionProvider.ExecuteDapperQueryAsync<T?>(async c => await c.QueryFirstOrDefaultAsync<T>(sqlQuery, param), cancellationToken);

    public static async Task<T?> ExecuteDapperStoredProcedureFirstOrDefaultAsync<T>(this IConnectionProvider connectionProvider, string sqlQuery, object param, CancellationToken cancellationToken = default)
        => await connectionProvider.ExecuteDapperQueryAsync<T?>(async c => await c.QueryFirstOrDefaultAsync<T>(sqlQuery, param, commandType: CommandType.StoredProcedure), cancellationToken);

    public static T? ExecuteDapperStoredProcedureFirstOrDefault<T>(this IConnectionProvider connectionProvider, string sqlQuery, object param)
        => connectionProvider.ExecuteDapperQuery<T?>(c => c.QueryFirstOrDefault<T>(sqlQuery, param, commandType: CommandType.StoredProcedure));

    public static async Task<List<T>> ExecuteDapperStoredProcedureSqlToListAsync<T>(this IConnectionProvider connectionProvider, string sqlQuery, object param, CancellationToken cancellationToken = default)
        => await connectionProvider.ExecuteDapperQueryAsync<List<T>>(async c => (await c.QueryAsync<T>(sqlQuery, param, commandType: CommandType.StoredProcedure)).AsList(), cancellationToken);

    public static async Task<T?> ExecuteDapperScalarAsync<T>(this IConnectionProvider connectionProvider, string sqlQuery,
        object param, CancellationToken cancellationToken = default)
    {
        await using var connection = connectionProvider.Create();
        await connection.OpenAsync(cancellationToken);

        var command = new CommandDefinition(sqlQuery, parameters: param, cancellationToken: cancellationToken);

        return await connection.ExecuteScalarAsync<T>(command);
    }

    public static async Task<int> ExecuteDapperAsync(this IConnectionProvider connectionProvider, string sqlQuery,
        object param, CancellationToken cancellationToken = default)
    {
        await using var connection = connectionProvider.Create();
        await connection.OpenAsync(cancellationToken);

        var command = new CommandDefinition(sqlQuery, parameters: param, cancellationToken: cancellationToken);

        return await connection.ExecuteAsync(command);
    }

    public static int ExecuteDapper(this IConnectionProvider connectionProvider, string sqlQuery, object param)
    {
        using var connection = connectionProvider.Create();
        connection.Open();

        var command = new CommandDefinition(sqlQuery, parameters: param);

        return connection.Execute(command);
    }

    public static async Task<T> ExecuteDapperQueryAsync<T>(this IConnectionProvider connectionProvider, Func<IDbConnection, Task<T>> getData, CancellationToken cancellationToken = default)
    {
        await using var connection = connectionProvider.Create();
        await connection.OpenAsync(cancellationToken);
        return await getData(connection);
    }
    
    public static async Task ExecuteDapperQueryAsync(this IConnectionProvider connectionProvider, Func<IDbConnection, Task> getData, CancellationToken cancellationToken = default)
    {
        await using var connection = connectionProvider.Create();
        await connection.OpenAsync(cancellationToken);
        await getData(connection);
    }
    
    public static async Task<TResult> ExecuteDapperQueryAsync<TRead, TResult>(this IConnectionProvider connectionProvider, Func<IDbConnection, Task<TRead>> getData, Func<TRead, Task<TResult>> process, CancellationToken cancellationToken = default)
    {
        await using var connection = connectionProvider.Create();
        await connection.OpenAsync(cancellationToken);
        var data = await getData(connection);
        return await process(data);
    }
}