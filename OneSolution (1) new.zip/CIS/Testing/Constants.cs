﻿namespace CIS.Testing;

public static class Constants
{
    public const string CisSecurityUsername = "test";
    public const string CisSecurityPassword = "Test";
    public const int HeaderServiceContextUserId = 3048;
    public const string HeaderServiceContextIdent = "KBUID=A09FK3";
    public const string CisEnvironmentNameTest = "TEST";
}
