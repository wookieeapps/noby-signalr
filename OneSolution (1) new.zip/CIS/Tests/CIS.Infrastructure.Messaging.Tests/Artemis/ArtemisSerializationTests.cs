﻿using CIS.Infrastructure.Messaging.Artemis.Serialization;
using CIS.Infrastructure.Messaging.Tests.TestData;
using cz.kb.api.dmsxservice.contentmanagement.contentmanagementcmd.v1.mergecontent;
using FluentAssertions;
using MassTransit;
using MassTransit.InMemoryTransport;
using MassTransit.Serialization;
using MassTransit.Testing;

namespace CIS.Infrastructure.Messaging.Tests.Artemis;

public class ArtemisSerializationTests(ArtemisSerializationFixture fixture) : IClassFixture<ArtemisSerializationFixture>
{
    [Fact]
    public async Task SendJson_ShouldUseJsonSerializer()
    {
        var harness = fixture.CreateHarness();

        harness.Bus.ConnectReceiveEndpoint("test-message", (cfg) =>
        {
            cfg.Handler<TestMessage>(x => Task.CompletedTask);
        });

        EndpointConvention.Map<TestMessage>(new Uri("queue:test-message"));

        await harness.Start();
        await harness.Bus.Send(DefaultTestData.JsonTestMessage);

        var sentMessage = await harness.Sent.SelectAsync<TestMessage>().FirstOrDefault();
        var sendContext = (InMemorySendContext<TestMessage>)sentMessage.Context;

        sendContext.Serializer.Should().BeOfType<JmsSerializer>();
        sendContext.Body.Should().BeOfType<SystemTextJsonRawMessageBody<TestMessage>>();
        sendContext.ContentType.Should().Be(ArtemisSerializerVariables.JsonContentType);
    }

    [Fact]
    public async Task SendAvro_ShouldUseAvroSerializer()
    {
        var harness = fixture.CreateHarness();

        harness.Bus.ConnectReceiveEndpoint("test-message", (cfg) =>
        {
            cfg.Handler<MergeContentPayload>(x => Task.CompletedTask);
        });

        EndpointConvention.Map<MergeContentPayload>(new Uri("queue:test-message"));

        await harness.Start();

        await harness.Bus.Send(DefaultTestData.AvroTestMessage);

        var sentMessage = await harness.Sent.SelectAsync<MergeContentPayload>().FirstOrDefault();
        var sendContext = (InMemorySendContext<MergeContentPayload>)sentMessage.Context;

        sendContext.Serializer.Should().BeOfType<JmsSerializer>();
        sendContext.Body.Should().BeOfType<AvroMessageBody<MergeContentPayload>>();
        sendContext.ContentType.Should().Be(ArtemisSerializerVariables.AvroContentType);
    }

    [Fact]
    public async Task ReceiveJson_ShouldUseJsonDeserializer()
    {
        var harness = fixture.CreateHarness();

        harness.Bus.ConnectReceiveEndpoint("test-message", (cfg) =>
        {
            cfg.Handler<MergeContentPayload>(x => Task.CompletedTask);
            cfg.Handler<TestMessage>(x => Task.CompletedTask);
        });

        EndpointConvention.Map<MergeContentPayload>(new Uri("queue:test-message"));
        EndpointConvention.Map<TestMessage>(new Uri("queue:test-message"));

        await harness.Start();

        await harness.Bus.Send(DefaultTestData.JsonTestMessage);

        var consumedMessage = await harness.Consumed.SelectAsync<TestMessage>().FirstOrDefault();

        consumedMessage.MessageObject.Should().BeOfType<TestMessage>();
        consumedMessage.Context.ReceiveContext.ContentType.Should().Be(ArtemisSerializerVariables.JsonContentType);
        consumedMessage.Context.SerializerContext.Should().BeOfType<SystemTextJsonRawSerializerContext>();
    }

    [Fact]
    public async Task ReceiveJson_ShouldUseAvroDeserializer()
    {
        var harness = fixture.CreateHarness();

        harness.Bus.ConnectReceiveEndpoint("test-message", (cfg) =>
        {
            cfg.Handler<TestMessage>(x => Task.CompletedTask);
            cfg.Handler<MergeContentPayload>(x => Task.CompletedTask);
        });

        EndpointConvention.Map<MergeContentPayload>(new Uri("queue:test-message"));
        EndpointConvention.Map<TestMessage>(new Uri("queue:test-message"));

        await harness.Start();

        await harness.Bus.Send(DefaultTestData.AvroTestMessage);

        var consumedMessage = await harness.Consumed.SelectAsync<MergeContentPayload>().FirstOrDefault();

        consumedMessage.MessageObject.Should().BeOfType<MergeContentPayload>();
        consumedMessage.Context.ReceiveContext.ContentType.Should().Be(ArtemisSerializerVariables.AvroContentType);
        consumedMessage.Context.SerializerContext.Should().BeOfType<AvroSerializerContext>();
    }
}