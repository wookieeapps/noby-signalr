﻿using cz.kb.api.dmsxservice.contentmanagement.contentmanagementcmd.v1.mergecontent;

namespace CIS.Infrastructure.Messaging.Tests.TestData;

internal class DefaultTestData
{
    public static TestMessage JsonTestMessage { get; } = new TestMessage
    {
        Id = long.MaxValue,
        Message = "test"
    };

    public static MergeContentPayload AvroTestMessage { get; } = new MergeContentPayload
    {
        inputBucket = new()
        {
            hostname = "hostname",
            name = "test",
            inputContents = []
        },
        outputBucket = new()
        {
            hostname = "hostname",
            name = "test"
        },
        outputContent = new()
        {
            documentType = "docType",
        },
        processDefinition = new()
        {
            id = Guid.NewGuid().ToString()
        },
        pendingTimeSettings = new()
        {
            maxMilis = 30000,
            exceptionWhenReached = true
        },
        mergeSettings = new()
        {
            maxOutputFileSize = 70 * 1024 * 1024,
            evenPageBlank = false
        },
        sourceApplication = new()
        {
            code = "MPSS.NOBY"
        }
    };
}
