#### [CIS.Core](index.md 'index')
### [CIS.Core.Data](CIS.Core.Data.md 'CIS.Core.Data')

## IIsActual Interface

EF entita obsahuje sloupec IsActual.

```csharp
public interface IIsActual
```

Derived  
&#8627; [BaseIsActual](CIS.Core.Data.BaseIsActual.md 'CIS.Core.Data.BaseIsActual')

### Remarks
IsActual se používá pro soft-delete entit. False znamená smazanou entitu.