#### [CIS.Core](index.md 'index')

## CIS.Core.Validation Namespace

| Interfaces | |
| :--- | :--- |
| [IValidatableRequest](CIS.Core.Validation.IValidatableRequest.md 'CIS.Core.Validation.IValidatableRequest') | Marker interface, který označuje request zapojený do custom validace v rámci Mediator pipeline. |
