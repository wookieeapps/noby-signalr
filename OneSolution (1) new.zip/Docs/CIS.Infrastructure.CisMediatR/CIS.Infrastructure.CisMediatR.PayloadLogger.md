#### [CIS.Infrastructure.CisMediatR](index.md 'index')

## CIS.Infrastructure.CisMediatR.PayloadLogger Namespace

| Classes | |
| :--- | :--- |
| [PayloadLoggerBehaviorConfiguration](CIS.Infrastructure.CisMediatR.PayloadLogger.PayloadLoggerBehaviorConfiguration.md 'CIS.Infrastructure.CisMediatR.PayloadLogger.PayloadLoggerBehaviorConfiguration') | |
