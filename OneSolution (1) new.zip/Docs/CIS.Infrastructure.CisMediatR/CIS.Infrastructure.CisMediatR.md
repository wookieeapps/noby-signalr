#### [CIS.Infrastructure.CisMediatR](index.md 'index')

## CIS.Infrastructure.CisMediatR Namespace

| Classes | |
| :--- | :--- |
| [CisMediatrStartupExtensions](CIS.Infrastructure.CisMediatR.CisMediatrStartupExtensions.md 'CIS.Infrastructure.CisMediatR.CisMediatrStartupExtensions') | Extension metody do startupu aplikace pro registraci behaviors. |
| [GrpcValidationBehavior&lt;TRequest,TResponse&gt;](CIS.Infrastructure.CisMediatR.GrpcValidationBehavior_TRequest,TResponse_.md 'CIS.Infrastructure.CisMediatR.GrpcValidationBehavior<TRequest,TResponse>') | MediatR pipeline, která přidává do flow requestu FluentValidation. |
