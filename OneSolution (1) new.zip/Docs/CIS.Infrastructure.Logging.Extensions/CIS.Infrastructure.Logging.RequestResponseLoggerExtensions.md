#### [CIS.Infrastructure.Logging.Extensions](index.md 'index')
### [CIS.Infrastructure.Logging](CIS.Infrastructure.Logging.md 'CIS.Infrastructure.Logging')

## RequestResponseLoggerExtensions Class

Extension metody pro ILogger pro logování HTTP requestů a responsů.

```csharp
public static class RequestResponseLoggerExtensions
```

Inheritance [System.Object](https://docs.microsoft.com/en-us/dotnet/api/System.Object 'System.Object') &#129106; RequestResponseLoggerExtensions