#### [CIS.Infrastructure.Logging.Extensions](index.md 'index')

## CIS.Infrastructure.Logging.Extensions Assembly

ILogger extension methods

| Namespaces | |
| :--- | :--- |
| [CIS.Infrastructure.Logging](CIS.Infrastructure.Logging.md 'CIS.Infrastructure.Logging') | Extension metody pro logování. |
