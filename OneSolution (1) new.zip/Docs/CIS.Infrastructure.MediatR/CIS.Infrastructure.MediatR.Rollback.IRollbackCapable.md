#### [CIS.Infrastructure.MediatR](index.md 'index')
### [CIS.Infrastructure.MediatR.Rollback](CIS.Infrastructure.MediatR.Rollback.md 'CIS.Infrastructure.MediatR.Rollback')

## IRollbackCapable Interface

Marker interface pro Mediatr Request, ktery ma podporovat rollback pipeline.

```csharp
public interface IRollbackCapable
```