#### [CIS.Infrastructure.Messaging](index.md 'index')

## CIS.Infrastructure.Messaging Assembly

Konfigurace a helpery pro autentizaci gRPC služeb.

| Namespaces | |
| :--- | :--- |
| [CIS.Infrastructure.Messaging.Configuration](CIS.Infrastructure.Messaging.Configuration.md 'CIS.Infrastructure.Messaging.Configuration') | Nastavení konfigurace autentizace z appsettings.json. |
| [CIS.Infrastructure.Messaging.Kafka](CIS.Infrastructure.Messaging.Kafka.md 'CIS.Infrastructure.Messaging.Kafka') | Helpery pro konzumacia produkování zpráv do Kafky |
