#### [CIS.Infrastructure.Security](index.md 'index')

## CIS.Infrastructure.Security Namespace

Helpery pro autentizaci gRPC služeb.

| Classes | |
| :--- | :--- |
| [CisServiceAuthenticationOptions](CIS.Infrastructure.Security.CisServiceAuthenticationOptions.md 'CIS.Infrastructure.Security.CisServiceAuthenticationOptions') | |
| [StartupExtensions](CIS.Infrastructure.Security.StartupExtensions.md 'CIS.Infrastructure.Security.StartupExtensions') | Extension metody do startupu aplikace. |
