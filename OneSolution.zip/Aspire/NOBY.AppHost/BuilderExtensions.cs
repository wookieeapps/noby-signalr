﻿namespace NOBY.AppHost;

internal static class BuilderExtensions
{
    public static IResourceBuilder<T> SetAspireEnvironment<T>(this IResourceBuilder<T> builder) 
        where T : IResourceWithEnvironment
    {
        return builder.WithEnvironment("DOTNET_ENVIRONMENT", "Aspire");
    }
}
