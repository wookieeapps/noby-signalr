﻿namespace CIS.Core.Attributes;

[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
public sealed class AsImplementedInterfacesServiceAttribute : Attribute
{
}