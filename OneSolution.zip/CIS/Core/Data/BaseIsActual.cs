﻿namespace CIS.Core.Data;

/// <summary>
/// Implementace <see cref="IIsActual"/>
/// </summary>
public class BaseIsActual
    : IIsActual
{
    public bool IsActual { get; set; }
}