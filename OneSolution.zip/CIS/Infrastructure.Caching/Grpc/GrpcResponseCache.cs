﻿using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using ZiggyCreatures.Caching.Fusion;

namespace CIS.Infrastructure.Caching.Grpc;

internal sealed class GrpcResponseCache(
    IFusionCacheProvider cacheProvider,
    ILogger<GrpcResponseCache> logger)
        : IGrpcResponseCache
{
    private readonly IFusionCache _cache = cacheProvider.GetCache(Constants.GrpcResponseCacheName);
    private readonly ILogger<GrpcResponseCache> _logger = logger;

    public async Task<TResponse> GetLocalOrDistributed<TResponse>(
        object key,
        Func<CancellationToken, Task<TResponse>> getObject,
        CancellationToken cancellationToken = default,
        [CallerMemberName] string memberName = "")
        where TResponse : class
        => await getLocalOrDistributedInner(key, getObject, null, cancellationToken, memberName);

    public async Task<TResponse> GetLocalOrDistributed<TResponse>(
        object key,
        Func<CancellationToken, Task<TResponse>> getObject,
        Func<TResponse, bool> validateEntry,
        CancellationToken cancellationToken = default,
        [CallerMemberName] string memberName = "")
        where TResponse : class
        => await getLocalOrDistributedInner(key, getObject, validateEntry, cancellationToken, memberName);

    private async Task<TResponse> getLocalOrDistributedInner<TResponse>(
        object key,
        Func<CancellationToken, Task<TResponse>> getObject,
        Func<TResponse, bool>? validateEntry,
        CancellationToken cancellationToken = default,
        [CallerMemberName] string memberName = "")
        where TResponse : class
    {
        if (_localCacheValues.TryGetValue((memberName, key), out var cachedValue))
        {
            logPayload(cachedValue, key, LoggerExtensions.CacheTypes.Local, memberName);
            return (TResponse)cachedValue;
        }
        else if (_cache is not null) // mame zapnutou distr. cache, zkusime ziskat hodnotu z ni
        {
            var distrKey = GrpcResponseCacheHelpers.CreateCacheKey(memberName, key);

            var distCachedValue = await _cache.GetOrDefaultAsync<TResponse>(distrKey, token: cancellationToken);
            if (distCachedValue is null)
            {
                distCachedValue = await getObject(cancellationToken);

                if (validateEntry is null || validateEntry(distCachedValue))
                {
                    await _cache.SetAsync(
                        distrKey,
                        distCachedValue,
                        token: cancellationToken);

                    _localCacheValues.Add((memberName, key), distCachedValue);
                }
            }
            else
            {
                logPayload(distCachedValue, key, LoggerExtensions.CacheTypes.Distributed, memberName);
            }

            return distCachedValue;
        }

        var response = await getObject(cancellationToken);
        if (validateEntry is not null && validateEntry(response))
        {
            _localCacheValues.Add((memberName, key), response);
        }
        return response;
    }

    public async Task<TResponse> GetDistributedOnly<TResponse>(
        object key,
        Func<CancellationToken, Task<TResponse>> getObject,
        CancellationToken cancellationToken = default,
        [CallerMemberName] string memberName = "")
        where TResponse : class
    {
        if (_cache is not null)
        {
            var distCachedValue = await _cache.GetOrSetAsync<TResponse>(
                GrpcResponseCacheHelpers.CreateCacheKey(memberName, key),
                getObject,
                token: cancellationToken);

            if (distCachedValue is not null)
            {
                logPayload(distCachedValue, key, LoggerExtensions.CacheTypes.Distributed, memberName);
                return distCachedValue;
            }
        }

        return await getObject(cancellationToken);
    }

    public async Task<TResponse> GetLocalOnly<TResponse>(
        object key,
        Func<CancellationToken, Task<TResponse>> getObject,
        CancellationToken cancellationToken,
        [CallerMemberName] string memberName = "")
        where TResponse : class
    {
        if (_localCacheValues.TryGetValue((memberName, key), out var cachedValue))
        {
            logPayload(cachedValue, key, LoggerExtensions.CacheTypes.Local, memberName);
            return (TResponse)cachedValue;
        }
        else
        {
            var response = await getObject(cancellationToken);
            _localCacheValues.Add((memberName, key), response);
            return response;
        }
    }

    public async Task InvalidateEntry(object key, string methodName, CancellationToken cancellationToken = default)
    {
        _localCacheValues.Remove((methodName, key));
        await _cache.RemoveAsync(GrpcResponseCacheHelpers.CreateCacheKey(methodName, key), token: cancellationToken);
    }

    public void InvalidateLocalEntries()
    {
        _localCacheValues.Clear();
    }

    private void logPayload(in object cachedValue, [NotNull] in object key, LoggerExtensions.CacheTypes cacheType, in string memberName)
    {
        // it is pointless to serialize payload when log level prohibits logging of this event
        if (_logger.IsEnabled(LogLevel.Debug))
        {
            using (_logger.BeginScope(new Dictionary<string, object>
            {
                { "Payload", System.Text.Json.JsonSerializer.Serialize(cachedValue) }
            }))
            {
                _logger.UsingCacheInsteadOfRpc(cacheType, key.ToString()!, memberName);
            }
        }
    }

    /// <summary>
    /// Lokalni scoped uloziste pro nakesovane responses
    /// </summary>
    private readonly Dictionary<(string MethodName, object Key), object> _localCacheValues = [];
}

