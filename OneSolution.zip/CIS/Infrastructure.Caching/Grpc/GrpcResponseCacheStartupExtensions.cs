﻿using CIS.Core.Configuration;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;
using ZiggyCreatures.Caching.Fusion;
using Microsoft.Extensions.Caching.Distributed;

namespace CIS.Infrastructure.Caching.Grpc;

public static class GrpcResponseCacheStartupExtensions
{
    public static WebApplicationBuilder AddGrpcResponseCache([NotNull] this WebApplicationBuilder builder, [NotNull] ICisDistributedCacheConfiguration configuration)
    {
        if (configuration.CacheType != ICisDistributedCacheConfiguration.CacheTypes.None)
        {
            // add GRPC response cache
            builder.Services
                .AddFusionCache(Constants.GrpcResponseCacheName)
                .WithOptions(options =>
                {
                    options.DisableTagging = true;
                    options.DistributedCacheKeyModifierMode = CacheKeyModifierMode.None;
                    options.DistributedCacheCircuitBreakerDuration = TimeSpan.FromSeconds(60);
                })
                .WithDefaultEntryOptions(options =>
                {
                    options.SetSkipMemoryCache();
                    options.DistributedCacheDuration = TimeSpan.FromMinutes(30);
                    options.AllowBackgroundDistributedCacheOperations = true;
                    options.DistributedCacheSoftTimeout = TimeSpan.FromSeconds(1);
                    options.DistributedCacheHardTimeout = TimeSpan.FromSeconds(2);
                })
                .WithCacheKeyPrefix(Constants.GrpcResponseCachePrefix)
                .WithSerializer(services => configuration.SerializationType switch
                {
                    ICisDistributedCacheConfiguration.SerializationTypes.Json => new ZiggyCreatures.Caching.Fusion.Serialization.NewtonsoftJson.FusionCacheNewtonsoftJsonSerializer(),
                    ICisDistributedCacheConfiguration.SerializationTypes.Protobuf => new ZiggyCreatures.Caching.Fusion.Serialization.ProtoBufNet.FusionCacheProtoBufNetSerializer(),
                    _ => throw new Core.Exceptions.CisConfigurationNotFound("Unknown serialization type")
                })
                .WithDistributedCache(provider => provider.GetRequiredService<IDistributedCache>());
        }
        else
        {
            // add GRPC response cache
            builder.Services
                .AddFusionCache(Constants.GrpcResponseCacheName)
                .WithDefaultEntryOptions(options =>
                {
                    options.SetSkipMemoryCache();
                    options.SetSkipDistributedCache(true, true);
                });
        }

        // add grpc response cache
        builder.Services.AddScoped<IGrpcResponseCache, GrpcResponseCache>();

        return builder;
    }
}
