﻿namespace CIS.Infrastructure.CisMediatR
{
    /// <summary>
    /// MediatR custom behaviors
    /// </summary>
    internal static class AssemblyDoc { }
}
