﻿namespace CIS.Infrastructure.CisMediatR.GrpcValidation;

public enum GrpcValidationBehaviorExceptionTypes
{
    Unknown,
    CisValidationException,
    CisNotFoundException,
    CisArgumentException
}
