﻿namespace CIS.Infrastructure.CisMediatR.Rollback;

/// <summary>
/// Marker interface pro Mediatr Request, ktery ma podporovat rollback pipeline.
/// </summary>
public interface IRollbackCapable
{
}
