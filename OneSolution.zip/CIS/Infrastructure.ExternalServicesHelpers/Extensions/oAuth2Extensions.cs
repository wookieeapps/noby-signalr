﻿using CIS.Infrastructure.ExternalServicesHelpers.Configuration;
using CIS.Infrastructure.ExternalServicesHelpers.Services;
using Duende.AccessTokenManagement;
using System.Net;

namespace CIS.Infrastructure.ExternalServicesHelpers;

public static class oAuth2Extensions
{
    private const string _microsoftEntraIdHttpClientName = "MicrosoftEntraIdHttpClient";

    public static IHttpClientBuilder AddMicrosoftEntraId(this IHttpClientBuilder builder, IExternalServiceConfiguration configuration)
    {
        builder.Services
            .AddClientCredentialsTokenManagement()
            .AddClient(configuration.ServiceName!, client =>
            {
                client.TokenEndpoint = configuration.OAuthTokenEndpoint;
                client.ClientId = configuration.ClientId;
                client.ClientSecret = configuration.ClientSecret;
                client.Scope = configuration.Scopes;
                client.HttpClientName = _microsoftEntraIdHttpClientName;
            });

        builder.Services
            .AddHttpClient(_microsoftEntraIdHttpClientName)
            .UseSocketsHttpHandler((sockets, _) =>
            {
                if (!configuration.UseProxy)
                {
                    sockets.UseProxy = false;

                    return;
                }

                var proxy = configuration.Proxy!;

                sockets.UseProxy = true;
                sockets.Proxy = new WebProxy
                {
                    Address = new Uri(proxy.Address),
                    Credentials = proxy.AuthenticationType switch
                    {
                        ExternalServiceConfigurationProxy.ProxyAuthenticationTypes.Network => new NetworkCredential(
                            proxy.ProxyCredentials!.Username,
                            proxy.ProxyCredentials.Password,
                            proxy.ProxyCredentials.Domain),

                        ExternalServiceConfigurationProxy.ProxyAuthenticationTypes.Basic => new NetworkCredential(
                            proxy.ProxyCredentials!.Username,
                            proxy.ProxyCredentials.Password),

                        ExternalServiceConfigurationProxy.ProxyAuthenticationTypes.None or _ => null
                    }
                };
            });

        return builder.AddClientCredentialsTokenHandler(configuration.ServiceName!).UseSocketsHttpHandler();
    }

    public static IHttpClientBuilder AddKbPseudoOAuthAuthentication(this IHttpClientBuilder builder, IExternalServiceConfiguration configuration)
    {
        builder.Services
            .AddClientCredentialsTokenManagement()
            .AddClient(configuration.ServiceName!, client =>
            {
                client.TokenEndpoint = configuration.OAuthTokenEndpoint;
                client.ClientId = configuration.ClientId;
                client.ClientSecret = configuration.ClientSecret;
                client.Scope = configuration.Scopes;

                client.Parameters.Add("username", configuration.Username!);
                client.Parameters.Add("password", configuration.Password!);
            });

        builder.AddClientCredentialsTokenHandler(configuration.ServiceName!);

        builder.Services
            .AddHttpClient<IClientCredentialsTokenEndpointService, JsonClientCredentialsTokenEndpointService>()
            .UseSocketsHttpHandler()
            .AddHttpMessageHandler(services =>
            {
                var logger = services.GetRequiredService<ILogger<JsonClientCredentialsTokenEndpointService>>();
                return new HttpHandlers.LoggingHttpHandler(logger, configuration.LogRequestPayload, logResponsePayload: false);
            });

        return builder;
    }
}
