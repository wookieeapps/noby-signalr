﻿using CIS.Core;

namespace CIS.Infrastructure.ExternalServicesHelpers.HttpHandlers;

public sealed class KbCustomerJourneyHttpHandler
    : DelegatingHandler
{
    private string? EnvironmentName { get; init; }
    private string ProcessId { get; init; }

    public KbCustomerJourneyHttpHandler(string? environmentName, string processId)
    {
        EnvironmentName = environmentName;
        ProcessId = processId;
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        int envid;
        if (!string.IsNullOrEmpty(EnvironmentName) && _environmentMapper.TryGetValue(EnvironmentName, out envid))
        {
            request.Headers.AddIfNotExists("x-kb-customer-journey", $$"""{"processId":"{{ProcessId}}","instanceId":"{{Guid.NewGuid()}}","environmentId":"{{envid}}"}""");
        }

        return await base.SendAsync(request, cancellationToken);
    }

    private static readonly Dictionary<string, int> _environmentMapper = new()
    {
        { "DEV", 651 },
        { "FAT", 701 },
        { "SIT", 801 },
        { "UAT", 1151 },
        { "QUALITY", 1001 },
        { "PREPROD", 1001 },
        { "PROD", 901 }
    };
}
