﻿using Duende.AccessTokenManagement;
using Microsoft.Extensions.Options;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Json;
using System.Text.Json.Serialization;

namespace CIS.Infrastructure.ExternalServicesHelpers.Services;

public class JsonClientCredentialsTokenEndpointService(
    HttpClient _httpClient,
    IOptionsMonitor<ClientCredentialsClient> _options)
    : IClientCredentialsTokenEndpointService
{
    public async Task<ClientCredentialsToken> RequestToken(string clientName, TokenRequestParameters? parameters = null, CancellationToken cancellationToken = default)
    {
        var client = _options.Get(clientName);

        if (string.IsNullOrWhiteSpace(client.ClientId))
        {
            throw new InvalidOperationException($"No ClientId configured for client {clientName}");
        }
        if (string.IsNullOrWhiteSpace(client.TokenEndpoint))
        {
            throw new InvalidOperationException($"No TokenEndpoint configured for client {clientName}");
        }
        var payload = new
        {
            client_id = client.ClientId,
            client_secret = client.ClientSecret,
            grant_type = "password",
            scope = client.Scope,
            username = client.Parameters["username"].FirstOrDefault(),
            password = client.Parameters["password"].FirstOrDefault()
        };

        var response = await _httpClient.PostAsJsonAsync(client.TokenEndpoint, payload, cancellationToken);

        if (response.IsSuccessStatusCode)
        {
            var tokenResponse = await response.Content.ReadFromJsonAsync<TokenResponse>(cancellationToken);

            var handler = new JwtSecurityTokenHandler();
            var token = handler.ReadJwtToken(tokenResponse!.AccessToken);

            return new()
            {
                AccessToken = tokenResponse.AccessToken,
                AccessTokenType = tokenResponse.AccessTokenType,
                Scope = tokenResponse.Scope,
                Expiration = DateTimeOffset.FromUnixTimeSeconds(token.Payload.Expiration!.Value).AddMinutes(-5).UtcDateTime
            };
        }

        return new()
        {
            Error = await response.Content.ReadAsStringAsync(cancellationToken)
        };
    }

    private class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;

        [JsonPropertyName("token_type")]
        public string AccessTokenType { get; set; } = string.Empty;

        [JsonPropertyName("scope")]
        public string Scope { get; set; } = string.Empty;
    }
}
