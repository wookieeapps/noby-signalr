﻿namespace CIS.Infrastructure.Logging.Extensions
{
    /// <summary>
    /// ILogger extension methods
    /// </summary>
    internal static class AssemblyDoc { }
}

namespace CIS.Infrastructure.Logging
{
    /// <summary>
    /// Extension metody pro logování.
    /// </summary>
    internal static class NamespaceDoc { }
}