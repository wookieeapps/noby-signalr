﻿namespace CIS.Infrastructure.Messaging.Artemis;

public interface IArtemisCmdClient
{
    Task<Guid> Send<TMessage>(TMessage message) where TMessage : class;
    Task<Guid> Send<TMessage>(TMessage message, ArtemisEndpoint replyToEndpoint) where TMessage : class;
}
