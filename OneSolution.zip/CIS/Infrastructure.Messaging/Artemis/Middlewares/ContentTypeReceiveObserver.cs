﻿using Apache.NMS.Util;
using MassTransit;
using MassTransit.ActiveMqTransport;

namespace CIS.Infrastructure.Messaging.Artemis.Middlewares;
/// <summary>
/// SpringBoot SDK application uses as Content-Type header key contentType which is not supported by MassTransit.
/// In PreReceive event we check if this is ActiveMQ context and if yes rewrite header to allow correct deserializer choose.
/// </summary>
internal class ContentTypeReceiveObserver : IReceiveObserver
{
    private const string javaContentTypeKeyName = "contentType";
    private const string massTransitContentTypeKeyName = "Content-Type";

    public Task ConsumeFault<T>(ConsumeContext<T> context, TimeSpan duration, string consumerType, Exception exception) where T : class
        => Task.CompletedTask;

    public Task PostConsume<T>(ConsumeContext<T> context, TimeSpan duration, string consumerType) where T : class
        => Task.CompletedTask;

    public Task PostReceive(ReceiveContext context)
        => Task.CompletedTask;

    public Task PreReceive(ReceiveContext context)
    {
        if (context is ActiveMqReceiveContext activeMqContext && activeMqContext.Properties is PrimitiveMapInterceptor properties)
        {
            foreach (string key in properties.Keys)
            {

                if (string.Equals(key, javaContentTypeKeyName, StringComparison.Ordinal))
                {
                    properties.ReadOnly = false;
                    properties.SetString(massTransitContentTypeKeyName, properties[key].ToString());
                    properties.ReadOnly = true;
                }
            }

        }
        return Task.CompletedTask;
    }
    public Task ReceiveFault(ReceiveContext context, Exception exception)
        => Task.CompletedTask;
}
