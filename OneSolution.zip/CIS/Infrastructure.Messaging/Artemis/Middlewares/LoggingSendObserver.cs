﻿using CIS.Infrastructure.Messaging.Shared.Logging;
using MassTransit;
using Microsoft.Extensions.Logging;

namespace CIS.Infrastructure.Messaging.Artemis.Middlewares;

internal class LoggingSendObserver(ILogger<LoggingSendObserver> logger) : ISendObserver
{
    private readonly MessagingLogger _messagingLogger = new(logger, "Artemis");

    public Task PreSend<T>(SendContext<T> context) where T : class => Task.CompletedTask;

    public Task PostSend<T>(SendContext<T> context) where T : class
    {
        var messageSent = new MessageInformationToLogDto
        {
            MessageId = GetMessageId(context),
            TopicOrQueue = context.DestinationAddress?.ToString() ?? "",
            Headers = context.Headers.GetAll().ToDictionary(),
            Message = context.Message
        };

        _messagingLogger.MessageSent(messageSent);

        return Task.CompletedTask;
    }

    private static Guid? GetMessageId(SendContext context)
    {
        return context.CorrelationId ?? context.RequestId;
    }

    public Task SendFault<T>(SendContext<T> context, Exception exception) where T : class => Task.CompletedTask;
}
