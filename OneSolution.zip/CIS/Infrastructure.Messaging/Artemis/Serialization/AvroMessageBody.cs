﻿using Confluent.SchemaRegistry.Serdes;
using MassTransit;
using System.Runtime.Serialization;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal class AvroMessageBody<T> : AvroMessageBody
     where T : class
{
    public AvroMessageBody(SendContext<T> context, AvroSerializerConfig config, Action<object, Stream> writer, object? message = null)
    : base(message ?? context.Message, config, writer)
    {
    }
}

internal class AvroMessageBody : MessageBody
{
    private readonly AvroSerializerConfig config;
    private readonly Action<object, Stream> streamWriter;
    private readonly object message;
    private byte[]? data;

    public AvroMessageBody(object message, AvroSerializerConfig config, Action<object, Stream> streamWriter)
    {
        this.message = message ?? throw new ArgumentNullException(nameof(message));
        this.config = config ?? throw new ArgumentNullException(nameof(config));
        this.streamWriter = streamWriter ?? throw new ArgumentNullException(nameof(streamWriter));
    }

    public long? Length => data?.Length;

    public byte[] GetBytes()
    {
        if (data != null)
        {
            return data;
        }

        try
        {
            using var stream = new MemoryStream(config.BufferBytes!.Value);
            using var writer = new BinaryWriter(stream);
            streamWriter.Invoke(message, stream);
            data = stream.ToArray();
            return data;
        }
        catch (Exception ex)
        {
            throw new SerializationException("Failed to serialize message", ex);
        }
    }

    public Stream GetStream() => new MemoryStream(GetBytes());

    public string GetString()
    {
        return Convert.ToBase64String(GetBytes());
    }
}
