﻿using Avro.Generic;
using Avro.IO;
using Avro.Specific;
using Confluent.SchemaRegistry;
using MassTransit;
using MassTransit.Initializers;
using MassTransit.Initializers.TypeConverters;
using MassTransit.Serialization;
using MassTransit.Util;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal class AvroSerializerContext(
    JmsSerializer serializer, 
    JmsMessageContext messageContext, 
    MessageBody messageBody,
    int schemaId,
    ISchemaRegistryClient schemaRegistry) : SerializerContext
{
    private Guid? conversationId;
    private Guid? correlationId;
    private Uri? destinationAddress;
    private Uri? faultAddress;
    private Headers? headers;
    private Guid? initiatorId;
    private Guid? messageId;
    private Guid? requestId;
    private Uri? responseAddress;
    private Uri? sourceAddress;

    public static readonly IDictionary<Type, Avro.Schema> TypeToAvroSchemaMap = new Dictionary<Type, Avro.Schema>
        {
            { typeof(int), Avro.Schema.Parse("int") },
            { typeof(bool), Avro.Schema.Parse("boolean") },
            { typeof(double), Avro.Schema.Parse("double") },
            { typeof(string), Avro.Schema.Parse("string") },
            { typeof(float), Avro.Schema.Parse("float") },
            { typeof(long), Avro.Schema.Parse("long") },
            { typeof(byte[]), Avro.Schema.Parse("bytes") },
            { typeof(Confluent.Kafka.Null), Avro.Schema.Parse("null") }
        };

    public string[] SupportedMessageTypes => Array.Empty<string>();

    public Guid? MessageId => messageId ??= messageContext.MessageId;
    public Guid? RequestId => requestId ??= messageContext.RequestId;
    public Guid? CorrelationId => correlationId ??= messageContext.CorrelationId;
    public Guid? ConversationId => conversationId ??= messageContext.ConversationId;
    public Guid? InitiatorId => initiatorId ??= messageContext.InitiatorId;
    public DateTime? ExpirationTime => messageContext.ExpirationTime;
    public Uri? SourceAddress => sourceAddress ??= messageContext.SourceAddress;
    public Uri? DestinationAddress => destinationAddress ??= messageContext.DestinationAddress;
    public Uri? ResponseAddress => responseAddress ??= messageContext.ResponseAddress;
    public Uri? FaultAddress => faultAddress ??= messageContext.FaultAddress;
    public DateTime? SentTime => messageContext.SentTime;
    public Headers Headers => headers ??= messageContext.Headers;
    public HostInfo Host => messageContext.Host;

    public IMessageSerializer GetMessageSerializer() => serializer;

    public IMessageSerializer GetMessageSerializer<T>(MessageEnvelope envelope, T message) where T : class => serializer;

    public IMessageSerializer GetMessageSerializer(object message, string[] messageTypes) => serializer;

    public bool IsSupportedMessageType<T>() where T : class
        => IsSupportedMessageType(typeof(T));

    public bool IsSupportedMessageType(Type messageType)
    {
        return messageType.IsAssignableTo(typeof(ISpecificRecord)) || messageType.IsAssignableTo(typeof(GenericRecord));
    }

    public MessageBody SerializeObject(object? value)
    {
        return serializer.SerializeObject(value);
    }

    public Dictionary<string, object> ToDictionary<T>(T? message) where T : class
    {
        return ConvertObject.ToDictionary(message);
    }

    public bool TryGetMessage<T>(out T? message) where T : class
    {
        if (IsSupportedMessageType<T>() && TryGetMessage(typeof(T), out var messageObject))
        {
            message = messageObject as T;
            return message is not null;
        }
        message = default;
        return false;
    }

    public bool TryGetMessage(Type messageType, [NotNullWhen(true)] out object? message)
    {
        var writerSchema = schemaRegistry.GetSchemaAsync(schemaId).GetAwaiter().GetResult()
                ?? throw new SerializationException($"Could not find schema with {schemaId}");

        Func<object?> deserialize;
        if (messageType.IsAssignableTo(typeof(ISpecificRecord)))
        {
            deserialize = () =>
            {
                var schema = Avro.Schema.Parse(writerSchema.SchemaString);
                var readerSchema = ((ISpecificRecord)Activator.CreateInstance(messageType)!).Schema;
                var datumReader = new SpecificDefaultReader(schema, readerSchema);

                return datumReader.Read(default!, schema, readerSchema, new BinaryDecoder(messageBody.GetStream()));
            };
        }
        else if (messageType.IsAssignableTo(typeof(GenericRecord)))
        {
            deserialize = () =>
            {
                var schema = Avro.Schema.Parse(writerSchema.SchemaString);
                var datumReader = new GenericReader<GenericRecord>(schema, schema);
                return datumReader.Read(default!, new BinaryDecoder(messageBody.GetStream()));
            };
        }
        else if (TypeToAvroSchemaMap.TryGetValue(messageType, out var readerSchema))
        {
            deserialize = () =>
            {
                var schema = Avro.Schema.Parse(writerSchema.SchemaString);
                var datumReader = new SpecificDefaultReader(schema, readerSchema);
                return datumReader.Read(default!, schema, readerSchema, new BinaryDecoder(messageBody.GetStream()));
            };
        }
        else
        {
            throw new NotSupportedException();
        }

        message = deserialize();
        return message is not null;
    }

    public T? DeserializeObject<T>(object? value, T? defaultValue = null) where T : class
    {
        return DeserializeObjectInternal(value, defaultValue);
    }

    public T? DeserializeObject<T>(object? value, T? defaultValue = null) where T : struct
    {
        return DeserializeObjectInternal(value, defaultValue);
    }

    private static T? DeserializeObjectInternal<T>(object? value, T? defaultValue)
    {
        return value switch
        {
            null => defaultValue,
            T returnValue => returnValue,
            string text when string.IsNullOrWhiteSpace(text) => defaultValue,
            string text when TypeConverterCache.TryGetTypeConverter(out ITypeConverter<T, string>? typeConverter) && typeConverter.TryConvert(text, out var result) => result,
            _ => throw new NotSupportedException(),
        };
    }
}
