﻿using Apache.NMS;
using Confluent.SchemaRegistry;
using MassTransit;
using System.Globalization;
using System.Net.Mime;
using System.Runtime.Serialization;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal sealed class JmsAvroDeserializer(JmsSerializer _jmsSerializer, ISchemaRegistryClient schemaRegistry) 
    : JmsDeserializerBase(_jmsSerializer)
{
    private const string _schemaIdHeaderName = "JMSType";

    private readonly JmsSerializer _jmsSerializer = _jmsSerializer;

    public override ContentType ContentType => ArtemisSerializerVariables.AvroContentType;

    protected override MessageBody GetMessageBody(string text) => new Base64MessageBody(text);

    protected override SerializerContext Deserialize(MessageBody body, Headers headers, Uri? destinationAddress, IMessage? transportMessage)
    {
        try
        {
            var messageContext = new JmsMessageContext(headers, destinationAddress);

            if (transportMessage is null || !int.TryParse(transportMessage.NMSType, NumberStyles.Integer, CultureInfo.InvariantCulture, out var schemaId))
            {
                schemaId = headers.Get<int>(_schemaIdHeaderName)
                    ?? throw new InvalidOperationException($"Message dos not contain header {_schemaIdHeaderName} with SchemaId");
            }

            return new AvroSerializerContext(_jmsSerializer, messageContext, body, schemaId, schemaRegistry);

        }
        catch (InvalidOperationException)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw new SerializationException("An error occured while deserializing the message enveloper", ex);
        }
    }
}
