﻿using Apache.NMS;
using MassTransit;
using MassTransit.ActiveMqTransport;
using MassTransit.Serialization;
using System.Net.Mime;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal abstract class JmsDeserializerBase(JmsSerializer _jmsSerializer) : ISerializerFactory, IMessageDeserializer
{
    public abstract ContentType ContentType { get; }

    IMessageSerializer ISerializerFactory.CreateSerializer() => _jmsSerializer;

    IMessageDeserializer ISerializerFactory.CreateDeserializer() => this;

    ConsumeContext IMessageDeserializer.Deserialize(ReceiveContext receiveContext) => GetConsumerContext(receiveContext);

    SerializerContext IMessageDeserializer.Deserialize(MessageBody body, Headers headers, Uri? destinationAddress) 
        => Deserialize(body, headers, destinationAddress, null);

    MessageBody IMessageDeserializer.GetMessageBody(string text) => GetMessageBody(text);

    protected abstract SerializerContext Deserialize(MessageBody body, Headers headers, Uri? destinationAddress, IMessage? transportMessage);

    protected abstract MessageBody GetMessageBody(string text);

    protected ConsumeContext GetConsumerContext(ReceiveContext receiveContext)
    {
        return receiveContext switch
        {
            ActiveMqReceiveContext activeMq => new JmsBodyConsumeContext(
                activeMq,
                Deserialize(activeMq.Body, activeMq.TransportHeaders, activeMq.InputAddress, activeMq.TransportMessage)
             ),

            _ => new BodyConsumeContext(
                receiveContext,
                Deserialize(receiveContext.Body, receiveContext.TransportHeaders, receiveContext.InputAddress, null)
             )
        };
    }

    void IProbeSite.Probe(ProbeContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        context.CreateScope(GetType().Name);
    }
}