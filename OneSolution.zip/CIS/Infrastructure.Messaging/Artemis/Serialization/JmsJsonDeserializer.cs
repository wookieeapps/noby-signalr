﻿using Apache.NMS;
using MassTransit;
using MassTransit.Serialization;
using System.Collections.Concurrent;
using System.Net.Mime;
using System.Runtime.Serialization;
using System.Text.Json;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal sealed class JmsJsonDeserializer(JmsSerializer _jmsSerializer) : JmsDeserializerBase(_jmsSerializer)
{
    private static readonly ConcurrentDictionary<string, Type> _typeFullNameMap = new();

    public override ContentType ContentType => ArtemisSerializerVariables.JsonContentType;

    protected override MessageBody GetMessageBody(string text) => new StringMessageBody(text);

    protected override SerializerContext Deserialize(MessageBody body, Headers headers, Uri? destinationAddress, IMessage? transportMessage)
    {
        try
        {
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(body.GetBytes(), SystemTextJsonMessageSerializer.Options);

            var messageTypes = MessageUrnTypeHelper.GetMessageTypes(headers);

            var messageContext = new JmsMessageContext(headers, destinationAddress);

            var serializerContext = new SystemTextJsonRawSerializerContext(
                SystemTextJsonMessageSerializer.Instance,
                SystemTextJsonMessageSerializer.Options,
                new ContentType(MediaTypeNames.Application.Json),
                messageContext,
                messageTypes,
                RawSerializerOptions.Default,
                jsonElement
            );

            return serializerContext;
        }
        catch (SerializationException)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw new SerializationException("An error occured while deserializing the message enveloper", ex);
        }
    }
}
