﻿using MassTransit;
using MassTransit.Metadata;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal class JmsMessageContext : MessageContext
{
    private const string _messageJmsCorrelationHeaderName = "JMSCorrelationID";

    private static readonly DateTime unixEpoch = new DateTime(1970, 1, 1);
    private readonly Headers transportHeaders;

    private Guid? conversationId;
    private Guid? correlationId;
    private Uri? faultAddress;
    private readonly HostInfo host;
    private Guid? initiatorId;
    private Guid? messageId;
    private Guid? requestId;
    private Uri? responseAddress;
    private DateTime? sentTime;
    private Uri? sourceAddress;

    public JmsMessageContext(Headers headers, Uri? destinationAddress)
    {
        transportHeaders = headers ?? throw new ArgumentNullException(nameof(headers));
        DestinationAddress = destinationAddress;
        host = GetHostInfo();
    }
    public Guid? MessageId => messageId ??= transportHeaders.GetMessageId();

    public Guid? RequestId => requestId ??= transportHeaders.GetRequestId() ?? CorrelationId;

    public Guid? CorrelationId => correlationId ??= transportHeaders.GetCorrelationId() ?? transportHeaders.GetHeaderId(_messageJmsCorrelationHeaderName);

    public Guid? ConversationId => conversationId ??= transportHeaders.GetConversationId();

    public Guid? InitiatorId => initiatorId ??= transportHeaders.GetInitiatorId();

    public DateTime? ExpirationTime { get; }

    public Uri? SourceAddress => sourceAddress ??= transportHeaders.GetSourceAddress();

    public Uri? DestinationAddress { get; }

    public Uri? ResponseAddress => responseAddress ??= transportHeaders.GetResponseAddress();

    public Uri? FaultAddress => faultAddress ??= transportHeaders.GetFaultAddress();

    public DateTime? SentTime => sentTime ??= GetSentTime();

    public Headers Headers => transportHeaders;

    public HostInfo Host => host;

    private DateTime? GetSentTime()
    {
        try
        {
            DateTime? time = MessageId?.ToNewId().Timestamp;

            return sentTime > unixEpoch ? time : default;
        }
        catch (Exception)
        {
            return default;
        }
    }

    private HostInfo GetHostInfo()
    {
        var hostInfo = transportHeaders.Get<HostInfo>(MessageHeaders.Host.Info);
        return hostInfo ?? new BusHostInfo();
    }
}
