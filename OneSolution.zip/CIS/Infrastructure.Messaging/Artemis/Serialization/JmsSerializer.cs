﻿using Avro.Generic;
using Avro.IO;
using Avro.Specific;
using Confluent.SchemaRegistry;
using Confluent.SchemaRegistry.Serdes;
using MassTransit;
using MassTransit.Serialization;
using System.Collections.Concurrent;
using System.Net.Mime;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal class JmsSerializer(ISchemaRegistryClient _schemaRegistryClient) : IMessageSerializer
{
    protected const char _messageTypeSeparator = ';';
    protected const string _messageTypeHeaderName = "_type";
    protected const string _messageContentTypeHeaderName = "contentType";
    protected const string _messageSimpleTypeHeaderName = "messaging.messageType";
    protected const string _schemaIdHeaderName = "JMSType";

    private readonly ConcurrentDictionary<string, int> _schemaIdBySubject = new(StringComparer.OrdinalIgnoreCase);
    private readonly AvroSerializerConfig _serializerConfig = new() { BufferBytes = 1024 };

    public ContentType ContentType => ArtemisSerializerVariables.JsonContentType;

    public MessageBody GetMessageBody<T>(SendContext<T> context) where T : class
    {
        if (context.Message is ISpecificRecord)
        {
            SetDefaultHeaders(context, ArtemisSerializerVariables.AvroContentType);

            return SerializeAvro(context);
        }

        SetDefaultHeaders(context, ArtemisSerializerVariables.JsonContentType);

        return new SystemTextJsonRawMessageBody<T>(context, SystemTextJsonMessageSerializer.Options);
    }

    public MessageBody SerializeObject(object? value)
    {
        if (value == null)
        {
            return new EmptyMessageBody();
        }

        var (_, _, streamWriter) = GetSerializationInfo(value);
        return new AvroMessageBody(value, _serializerConfig, streamWriter);
    }

    private static void SetDefaultHeaders<T>(SendContext<T> context, ContentType contentType) where T : class
    {
        context.ContentType = contentType;
        context.CorrelationId ??= context.RequestId;

        context.Headers.Set(_messageTypeHeaderName, string.Join(_messageTypeSeparator, MessageTypeCache<T>.MessageTypes.Select(t => t.FullName)));
        context.Headers.Set(_messageContentTypeHeaderName, contentType.ToString());
        context.Headers.Set(_messageSimpleTypeHeaderName, "SIMPLE");
        context.Headers.Set(MessageHeaders.MessageId, Guid.NewGuid().ToString());
    }

    private AvroMessageBody<T> SerializeAvro<T>(SendContext<T> context) where T : class
    {
        var (schemaString, subject, streamWriter) = GetSerializationInfo(context.Message);

        var schemaId = _schemaIdBySubject.GetOrAdd(subject, _ =>
        {
            return _schemaRegistryClient.GetSchemaIdAsync(subject, new Schema(schemaString, SchemaType.Avro)).GetAwaiter().GetResult();
        });

        context.Headers.Set(_schemaIdHeaderName, schemaId);

        return new AvroMessageBody<T>(context, _serializerConfig, streamWriter);
    }

    private static (string schemaString, string subject, Action<object, Stream> streamWriter) GetSerializationInfo<T>(T messageData)
    {
        string schemaString;
        string subject;
        Action<object, Stream> streamWriter;
        var instance = messageData ?? Activator.CreateInstance<T>();

        if (instance is ISpecificRecord specificRecord)
        {
            subject = specificRecord.Schema.Fullname;
            schemaString = specificRecord.Schema.ToString();
            streamWriter = (data, stream) =>
            {
                var datumWriter = new SpecificWriter<T>(specificRecord.Schema);
                datumWriter.Write((T)data, new BinaryEncoder(stream));
            };
        }
        else if (messageData is GenericRecord genericRecord)
        {
            subject = genericRecord.Schema.Fullname;
            schemaString = genericRecord.Schema.ToString();
            streamWriter = (data, stream) =>
            {
                var datumWriter = new GenericWriter<GenericRecord>(genericRecord.Schema);
                datumWriter.Write((GenericRecord)data, new BinaryEncoder(stream));
            };
        }
        else
        {
            throw new NotSupportedException("The message type must be one of ISpecifiRecord, GenericRecord, int, string, double, long, float, bool, byte[]");
        }

        return (schemaString, subject, streamWriter);
    }
}
