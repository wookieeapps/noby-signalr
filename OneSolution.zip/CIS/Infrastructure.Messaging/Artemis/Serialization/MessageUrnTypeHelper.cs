﻿using MassTransit;
using System.Collections.Concurrent;

namespace CIS.Infrastructure.Messaging.Artemis.Serialization;

internal static class MessageUrnTypeHelper
{
    private const char _messageTypeSeparator = ';';
    private const string _messageTypeHeaderName = "_type";

    private static readonly ConcurrentDictionary<string, Type> _typeFullNameMap = new();

    public static string[] GetMessageTypes(Headers headers)
    {
        var messageTypes = headers.Get<string>(_messageTypeHeaderName)?.Split(_messageTypeSeparator) ?? [];

        return ConvertToUrnTypes(messageTypes);
    }

    private static string[] ConvertToUrnTypes(string[] messageTypes)
    {
        var convertedMessageTypes = new List<string>();
        foreach (var messageType in messageTypes)
        {
            if (_typeFullNameMap.TryGetValue(messageType, out var type))
            {
                convertedMessageTypes.Add(type is not null ? MessageUrn.ForTypeString(type) : messageType);
                continue;
            }

            type = GetTypeFromLoadedAssemblies(messageType);
            if (type is not null)
            {
                _typeFullNameMap.TryAdd(messageType, type);
                convertedMessageTypes.Add(type is not null ? MessageUrn.ForTypeString(type) : messageType);
            }
        }
        return [.. convertedMessageTypes];
    }

    private static Type? GetTypeFromLoadedAssemblies(string name)
    {
        return
            AppDomain.CurrentDomain.GetAssemblies()
                .Reverse()
                .Select(assembly => assembly.GetType(name))
                .FirstOrDefault(t => t != null);
    }
}
