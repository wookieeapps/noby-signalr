﻿using CIS.Infrastructure.Messaging.Artemis.Middlewares;
using CIS.Infrastructure.Messaging.Artemis.Serialization;
using CIS.Infrastructure.Messaging.Configuration;
using CIS.Infrastructure.Messaging.Shared;
using MassTransit;
using Microsoft.Extensions.DependencyInjection;

namespace CIS.Infrastructure.Messaging.Artemis;

internal static class StartupExtensions
{
    public static IServiceCollection AddArtemisRequiredService<TEndpointsConfig>(this IServiceCollection services, ArtemisConfiguration<TEndpointsConfig> config) 
        where TEndpointsConfig : class
    {
        services.AddSingleton(config.Endpoints);
        services.AddSchemaRegistryClient(config.SchemaRegistry);

        services.AddTransient<JmsSerializer>();
        services.AddTransient<JmsJsonDeserializer>();
        services.AddTransient<JmsAvroDeserializer>();

        services.AddSingleton<IKbSpeedMessagingHeadersProvider, KbSpeedMessagingHeadersProvider>();
        services.AddScoped<IArtemisCmdClient, ArtemisCmdClient>();

        return services;
    }

    public static IServiceCollection AddArtemisObservers(this IServiceCollection services)
    {
        services.AddReceiveObserver<ContentTypeReceiveObserver>();
        services.AddReceiveObserver<LoggingReceiveObserver>();
        services.AddConsumeObserver<LoggingReceiveObserver>();
        services.AddSendObserver<LoggingSendObserver>();

        return services;
    }

    public static void AddArtemisSerializers(this IBusFactoryConfigurator busFactoryConfigurator, IBusRegistrationContext context)
    {
        var jsonSerializer = context.GetRequiredService<JmsJsonDeserializer>();
        var avroSerializer = context.GetRequiredService<JmsAvroDeserializer>();

        busFactoryConfigurator.ClearSerialization();

        //One is enough, MassTransit has retarded design with factory
        busFactoryConfigurator.AddSerializer(jsonSerializer);

        busFactoryConfigurator.AddDeserializer(avroSerializer);
        busFactoryConfigurator.AddDeserializer(jsonSerializer, isDefault: true);
    }
}
