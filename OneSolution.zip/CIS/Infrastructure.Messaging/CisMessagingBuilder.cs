﻿using CIS.Infrastructure.Messaging.Artemis;
using CIS.Infrastructure.Messaging.Configuration;
using CIS.Infrastructure.Messaging.KafkaFlow;
using CIS.Infrastructure.Messaging.KafkaFlow.Configuration;
using CIS.Infrastructure.Messaging.Shared;
using KafkaFlow;
using MassTransit;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CIS.Infrastructure.Messaging;

internal sealed class CisMessagingBuilder(WebApplicationBuilder builder) : ICisMessagingBuilder
{
    internal readonly WebApplicationBuilder _appBuilder = builder;

    public ICisMessagingBuilder AddKafkaFlow(Action<IKafkaFlowMessagingConfigurator> messaging)
    {
        var settings = new KafkaFlowConfiguratorSettings(_appBuilder.Configuration);

        if (settings.Configuration.Disabled || _appBuilder.Environment.EnvironmentName.Equals("Testing", StringComparison.OrdinalIgnoreCase))
            return this;

        _appBuilder.Services.AddSchemaRegistryClient(settings.Configuration.SchemaRegistry);

        _appBuilder.Services.AddKafkaFlowHostedService(
            kafka =>
            {
                kafka.AddCluster(cluster =>
                     {
                         cluster.WithBrokers(settings.Configuration.Brokers);
                         cluster.WithSecurityInformation(securityInfo => KafkaFlowSecurityInformationHelper.SetSecurityInfo(settings.Configuration, securityInfo));

                         KafkaFlowMessagingConfigurator.Configure(settings, messaging, cluster);
                     }).UseMicrosoftLog();
            });

        return this;
    }

    public ICisMessagingBuilder AddArtemis<TEndpointsConfig>(Action<IArtemisMessagingConfigurator, TEndpointsConfig> messaging) 
        where TEndpointsConfig : class
    {
        var configuration = _appBuilder.Configuration
                                       .GetSection(ArtemisConfiguration<TEndpointsConfig>.ConfigurationPath)
                                       .Get<ArtemisConfiguration<TEndpointsConfig>>()!;

        var configurator = new ArtemisMessagingConfigurator(_appBuilder.Configuration);

        messaging(configurator, configuration.Endpoints);

        _appBuilder.Services.AddArtemisRequiredService(configuration);
        _appBuilder.Services.AddArtemisObservers();

        if (_appBuilder.Environment.EnvironmentName.Equals("Testing", StringComparison.OrdinalIgnoreCase))
            return this;

        _appBuilder.Services.AddMassTransit(x =>
        {
            configurator.Register(x);
            
            x.UsingActiveMq((context, cfg) =>
            {
                cfg.Host(configuration.Host.Address, configuration.Host.Port, cfgHost =>
                {
                    cfgHost.UseSsl(enabled: true, updatePort: false);

                    cfgHost.FailoverHosts([configuration.Host.Address, .. configuration.Host.FailoverHosts]);

                    cfgHost.Username(configuration.Host.User);
                    cfgHost.EnableAsyncSend();

                    cfgHost.TransportOptions(new Dictionary<string, string>
                    {
                        { "transport.ClientCertFilename", configuration.Host.CertificateFilename },
                        { "transport.ClientCertPassword", configuration.Host.CertificatePassword }
                    });
                });

                var kbSpeedMessagingHeadersProvider = context.GetRequiredService<IKbSpeedMessagingHeadersProvider>();

                cfg.ConfigureSend(pipe =>
                {
                    pipe.UseSendExecute(sendContext =>
                    {
                        kbSpeedMessagingHeadersProvider.SetKbHeaders(sendContext.Headers.Set);
                    });
                });

                cfg.EnableArtemisCompatibility();
                cfg.SetConsumerEndpointQueueNameFormatter(new TemporaryVirtualConsumerQueueNameFormater());

                cfg.AddArtemisSerializers(context);

                configurator.ConfigureReceiveEndpoints(context, cfg);
            });
        });

        return this;
    }
}
