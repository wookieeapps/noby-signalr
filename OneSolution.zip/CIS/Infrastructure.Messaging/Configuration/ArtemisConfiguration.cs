﻿namespace CIS.Infrastructure.Messaging.Configuration;

public class ArtemisConfiguration<TEndpointsConfig> where TEndpointsConfig : class
{
    internal static readonly string ConfigurationPath = 
        $"{Constants.MessagingConfigurationElement}{Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter}{Constants.ArtemisConfigurationElement}";

    public ArtemisHostConfiguration Host { get; set; } = null!;

    public SchemaRegistryConfiguration? SchemaRegistry { get; set; }

    public TEndpointsConfig Endpoints { get; set; } = null!;

    public class ArtemisHostConfiguration
    {
        public string Address { get; set; } = string.Empty;

        public IReadOnlyCollection<string> FailoverHosts { get; set; } = [];

        public ushort Port { get; set; }

        public string? User { get; set; }

        public string CertificateFilename { get; set; } = string.Empty;

        public string CertificatePassword { get; set; } = string.Empty;
    }
}
