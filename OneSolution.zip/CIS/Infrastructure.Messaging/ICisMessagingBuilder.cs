﻿using CIS.Infrastructure.Messaging.Artemis;
using CIS.Infrastructure.Messaging.KafkaFlow;

namespace CIS.Infrastructure.Messaging;

public interface ICisMessagingBuilder
{
    ICisMessagingBuilder AddKafkaFlow(Action<IKafkaFlowMessagingConfigurator> messaging);

    ICisMessagingBuilder AddArtemis<TEndpointsConfig>(Action<IArtemisMessagingConfigurator, TEndpointsConfig> messaging) 
        where TEndpointsConfig : class;
}
