﻿using CIS.Core.Configuration;
using CIS.Infrastructure.Messaging.Configuration;
using Microsoft.Extensions.Configuration;

namespace CIS.Infrastructure.Messaging.KafkaFlow.Configuration;

internal sealed class KafkaFlowConfiguratorSettings(IConfiguration configuration)
{
    public string GroupId { get; } = GetGroupId(configuration);

    public KafkaFlowConfiguration Configuration { get; } = configuration.GetSection(GetKafkaConfigurationPath()).Get<KafkaFlowConfiguration>()!;

    public string SqlConnectionString { get; } = configuration.GetConnectionString("default") ?? string.Empty;

    private static string GetGroupId(IConfiguration configuration)
    {
        var environmentConfiguration = configuration
                                       .GetSection(Core.CisGlobalConstants.EnvironmentConfigurationSectionName)
                                       .Get<CisEnvironmentConfiguration>()!;

        return $"NOBY.{environmentConfiguration.DefaultApplicationKey}-{environmentConfiguration.EnvironmentName}";
    }

    private static string GetKafkaConfigurationPath() =>
        $"{Constants.MessagingConfigurationElement}{ConfigurationPath.KeyDelimiter}{Constants.KafkaConfigurationElement}";
}