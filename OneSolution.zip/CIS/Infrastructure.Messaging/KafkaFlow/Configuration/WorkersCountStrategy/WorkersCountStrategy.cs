﻿namespace CIS.Infrastructure.Messaging.KafkaFlow.Configuration.WorkersCountStrategy;

public enum WorkersCountStrategy
{
    Default,
    ThreadCount
}