﻿using CIS.Infrastructure.Messaging.KafkaFlow.Configuration;
using CIS.Infrastructure.Messaging.KafkaFlow.Configuration.WorkersCountStrategy;
using CIS.Infrastructure.Messaging.KafkaFlow.Middlewares;
using Confluent.SchemaRegistry;
using Confluent.SchemaRegistry.Serdes;
using KafkaFlow;
using KafkaFlow.Configuration;
using KafkaFlow.Retry;
using KafkaFlow.Retry.SqlServer;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace CIS.Infrastructure.Messaging.KafkaFlow;

internal sealed class KafkaFlowMessagingConfigurator : IKafkaFlowMessagingConfigurator
{
    private readonly KafkaFlowConfiguratorSettings _settings;

    private Action<IClusterConfigurationBuilder> _clusterBuilder = delegate { };

    private KafkaFlowMessagingConfigurator(KafkaFlowConfiguratorSettings settings)
    {
        _settings = settings;
    }

    public static void Configure(KafkaFlowConfiguratorSettings settings, Action<IKafkaFlowMessagingConfigurator> messaging, IClusterConfigurationBuilder cluster)
    {
        var configurator = new KafkaFlowMessagingConfigurator(settings);

        messaging(configurator);

        configurator._clusterBuilder(cluster);
    }

    public IKafkaFlowMessagingConfigurator AddConsumerAvro<THandler>(string topic) where THandler : class, IMessageHandler =>
        AddConsumerAvro(topic, handlers => handlers.AddHandler<THandler>());

    public IKafkaFlowMessagingConfigurator AddConsumerAvro(string topic, Action<TypedHandlerConfigurationBuilder> handlers)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(topic, nameof(topic));

        _clusterBuilder += kafka => kafka.AddConsumer(consumer => SetupConsumer(consumer, topic, m => m.AddSchemaRegistryAvroDeserializer(), handlers));

        return this;
    }

    public IKafkaFlowMessagingConfigurator AddDurableConsumerAvro<THandler, TMessage>(string topic) where THandler : class, IMessageHandler<TMessage>
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(topic, nameof(topic));

        var connectionStringBuilder = new SqlConnectionStringBuilder(_settings.SqlConnectionString);

        _clusterBuilder += kafka =>
        {
            kafka.AddConsumer(consumer => SetupConsumer(
                consumer,
                topic,
                m => m.AddSchemaRegistryAvroDeserializer(),
                handlers => handlers.AddHandler<THandler>(),
                retryConfig: m => m.RetryDurable(cfg =>
                {
                    cfg.HandleAnyException()
                       .WithMessageType(typeof(TMessage))
                       .WithSqlServerDataProvider(connectionStringBuilder.ConnectionString, connectionStringBuilder.InitialCatalog, "msg")
                       .WithPollingJobsConfiguration(jobCfg =>
                       {
                           jobCfg.WithSchedulerId($"kafka-{typeof(TMessage).Name}-cleanup-polling");

                           jobCfg.WithRetryDurablePollingConfiguration(retryCfg =>
                           {
                               retryCfg.Enabled(false);
                           });

                           jobCfg.WithCleanupPollingConfiguration(cleanup =>
                           {
                               cleanup
                               .Enabled(true)
                               .WithCronExpression("0 0 1 * * ?")
                               .WithTimeToLiveInDays(14);
                           });
                       })
                       .WithEmbeddedRetryCluster(kafka, x => x.Enabled(false))
                       .WithRetryPlanBeforeRetryDurable(x => x.TryTimes(1).WithTimeBetweenTriesPlan(TimeSpan.FromSeconds(1)));
                }))
            );
        };

        return this;
    }

    public IKafkaFlowMessagingConfigurator AddBatchConsumerAvro<TBatchHandler>(string topic) where TBatchHandler : class, IMessageMiddleware
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(topic, nameof(topic));

        _clusterBuilder += kafka => kafka.AddConsumer(consumer =>
        {
            consumer.Topic(topic).WithAutoOffsetReset(AutoOffsetReset.Earliest)
                    .WithGroupId(_settings.GroupId).WithBufferSize(300).WithWorkersCount(1)
                    .AddMiddlewares(middlewares =>
                    {
                        middlewares.AddSchemaRegistryAvroDeserializer();

                        middlewares.AddBatching(100, TimeSpan.FromSeconds(30));

                        middlewares.Add<ActivitySourceMiddleware>(MiddlewareLifetime.Message);
                        middlewares.Add<ConsumerBatchErrorHandlingMiddleware>(MiddlewareLifetime.Message);

                        middlewares.Add<TBatchHandler>();
                    });
        });

        return this;
    }

    public IKafkaFlowMessagingConfigurator AddProducerAvro<TMessage>(string defaultTopic, SubjectNameStrategy subjectNameStrategy = SubjectNameStrategy.Record)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(defaultTopic, nameof(defaultTopic));

        _clusterBuilder += kafka => kafka.AddProducer<TMessage>(producer =>
        {
            producer.DefaultTopic(defaultTopic).WithAcks(Acks.All)
                    .AddMiddlewares(m =>
                    {
                        m.Add<DefaultKBAvroHeaderMiddleware>();

                        var avroSerializerConfig = new AvroSerializerConfig
                        {
                            SubjectNameStrategy = subjectNameStrategy,
                            AutoRegisterSchemas = false
                        };

                        m.AddSchemaRegistryAvroSerializer(avroSerializerConfig);
                    });
        });

        return this;
    }

    private void SetupConsumer(
        IConsumerConfigurationBuilder consumer, 
        string topic, 
        Action<IConsumerMiddlewareConfigurationBuilder> deserializerConfig, 
        Action<TypedHandlerConfigurationBuilder> handlers,
        Action<IConsumerMiddlewareConfigurationBuilder>? retryConfig = null)
    {
        consumer.Topic(topic);

        if (_settings.Configuration.WorkersCountStrategy.TryGetValue(topic, out WorkersCountStrategyConfiguration? workersCountConfig) && workersCountConfig.WorkersCountStrategy != WorkersCountStrategy.Default)
        {
            consumer.WithWorkersCount(WorkersCountStrategyFactory.CreateCalculator(workersCountConfig), TimeSpan.FromSeconds(workersCountConfig.EvaluationIntervalSecond));
        }
        else
        {
            consumer.WithWorkersCount(_settings.Configuration.WorkersCount);
        }

        consumer.WithAutoOffsetReset(AutoOffsetReset.Earliest)
                .WithGroupId(_settings.GroupId).WithManualMessageCompletion()
                .WithBufferSize(_settings.Configuration.BufferSize)
                .AddMiddlewares(m =>
                {
                    m.AddAtBeginning<ActivitySourceMiddleware>(MiddlewareLifetime.Message);
                    m.Add<ConsumerErrorHandlingMiddleware>(MiddlewareLifetime.Message);

                    deserializerConfig(m);

                    m.Add(resolver => new LoggingKnownMessagesMiddleware(
                              _settings.Configuration,
                              resolver.Resolve<ILogger<LoggingKnownMessagesMiddleware>>()
                          ),
                          MiddlewareLifetime.Singleton);

                    retryConfig?.Invoke(m);

                    m.AddTypedHandlers(handlers += h => h.WithHandlerLifetime(InstanceLifetime.Scoped));
                });
    }
}