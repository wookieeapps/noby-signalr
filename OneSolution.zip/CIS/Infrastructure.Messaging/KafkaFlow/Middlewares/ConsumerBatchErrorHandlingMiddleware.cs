﻿using System.Text;
using CIS.Core.Exceptions;
using KafkaFlow;
using Microsoft.Extensions.Logging;

namespace CIS.Infrastructure.Messaging.KafkaFlow.Middlewares;

public class ConsumerBatchErrorHandlingMiddleware : IMessageMiddleware
{
    private readonly ILogger<ConsumerBatchErrorHandlingMiddleware> _logger;

    public ConsumerBatchErrorHandlingMiddleware(ILogger<ConsumerBatchErrorHandlingMiddleware> logger)
    {
        _logger = logger;
    }

    public async Task Invoke(IMessageContext context, MiddlewareDelegate next)
    {
        try
        {
            await next(context);
        }
        catch (BaseCisException ex)
        {
            _logger.ConsumingMessageFailed(GetMessageId(context), context.ConsumerContext.Topic, ex);
        }
        catch (Exception ex)
        {
            var loggerData = new Dictionary<string, object>
            {
                { nameof(context.ConsumerContext.ConsumerName), context.ConsumerContext.ConsumerName }
            };

            var batch = context.GetMessagesBatch();

            if (batch.Any())
            {
                loggerData.Add(nameof(context.Message), batch.Select(b => b.Message.Value).ToList());
            }

            using (_logger.BeginScope(loggerData))
            {
                _logger.ConsumingMessageFailed(GetMessageId(context), context.ConsumerContext.Topic, ex);
            }
        }

        foreach (var messageContext in context.GetMessagesBatch())
        {
            messageContext.ConsumerContext.Complete();
        }
    }

    private static string GetMessageId(IMessageContext context)
    {
        var messageId = context.Headers.GetString("messaging.id", Encoding.UTF8) ?? Encoding.UTF8.GetString(context.Message.Key as byte[] ?? []);

        return string.IsNullOrWhiteSpace(messageId) ? "N/A" : messageId;
    }
}