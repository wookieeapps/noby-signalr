﻿using Microsoft.Extensions.Logging;

namespace CIS.Infrastructure.Messaging;

internal static class LoggerExtensions
{
    private static readonly Action<ILogger, string, string, Exception> _consumingMessageFailed =
        LoggerMessage.Define<string, string>(
            LogLevel.Error,
            new EventId(901, nameof(ConsumingMessageFailed)),
            "Failed to consume message with ID '{MessageId}' from {Topic}"
        );

    private static readonly Action<ILogger, Exception> _schemaRegistryError =
        LoggerMessage.Define(
            LogLevel.Error,
            new EventId(902, nameof(SchemaRegistryError)),
            "Schema registry error"
        );

    private static readonly Action<ILogger, string, string, string, Exception> _consumingKnownMessage =
        LoggerMessage.Define<string, string, string>(
            LogLevel.Information,
            new EventId(903, nameof(ConsumingKnownMessage)),
            "Consuming message type {MessageType} with ID '{MessageId}' from {Topic}"
        );

    private static readonly Action<ILogger, int, string, Exception> _kafkaWorkerCountSet =
        LoggerMessage.Define<int, string>(
            LogLevel.Information,
            new EventId(905, nameof(KafkaWorkerCountSet)),
            "Worker count set to {WorkerCount} for ConsumerName {ConsumerName}"
        );

    private static readonly Action<ILogger, Exception> _artemisMessageReceived =
        LoggerMessage.Define(
            LogLevel.Information,
            new EventId(906, nameof(ArtemisMessageReceived)), 
            "Artemis message received"
        );

    private static readonly Action<ILogger, string, Exception> _artemisMessageSent =
        LoggerMessage.Define<string>(
            LogLevel.Information,
            new EventId(907, nameof(ArtemisMessageSent)),
            "Artemis sent message {MessageType}"
        );

    // public accessor
    public static void ConsumingMessageFailed(this ILogger logger, in string messageId, in string topic, Exception ex) => 
        _consumingMessageFailed(logger, messageId, topic, ex);

    public static void SchemaRegistryError(this ILogger logger, Exception ex) =>
        _schemaRegistryError(logger, ex);

    public static void ConsumingKnownMessage(this ILogger logger, in string messageType, in string messageId, in string topic) =>
        _consumingKnownMessage(logger, messageType, messageId, topic, null!);

    public static void KafkaWorkerCountSet(this ILogger logger, in int workerCount, in string consumerName) =>
        _kafkaWorkerCountSet(logger, workerCount, consumerName, null!);

    public static void ArtemisMessageReceived(this ILogger logger) =>
        _artemisMessageReceived(logger, null!);

    public static void ArtemisMessageSent(this ILogger logger, in string messageType) =>
        _artemisMessageSent(logger, messageType, null!);

}
