﻿using Microsoft.Extensions.Logging;

namespace CIS.Infrastructure.Messaging.Shared.Logging;

internal static class LoggerExtensions
{
    private static readonly Action<ILogger, string, Guid?, string, Exception> _receivedMessage =
        LoggerMessage.Define<string, Guid?, string>(
            LogLevel.Information,
            new EventId(901, nameof(MessageReceived)),
            "{MessagingProvider} message received '{MessageId}' from queue/topic {TopicOrQueue}");

    private static readonly Action<ILogger, string, Guid?, Exception> _receivedMessageDeserialized =
        LoggerMessage.Define<string, Guid?>(
            LogLevel.Information,
            new EventId(902, nameof(MessageDeserialized)),
            "{MessagingProvider} message deserialized '{MessageId}'");

    private static readonly Action<ILogger, string, Guid?, string, Exception> _sentMessage =
    LoggerMessage.Define<string, Guid?, string>(
        LogLevel.Information,
        new EventId(904, nameof(MessageSent)),
        "{MessagingProvider} message sent '{MessageId}' into queue/topic {TopicOrQueue}");

    public static void MessageReceived(this ILogger logger, in string messagingProvider, in Guid? messageId, in string topicOrQueue) =>
        _receivedMessage(logger, messagingProvider, messageId, topicOrQueue, null!);

    public static void MessageDeserialized(this ILogger logger, in string messagingProvider, in Guid? messageId) =>
        _receivedMessageDeserialized(logger, messagingProvider, messageId, null!);

    public static void MessageSent(this ILogger logger, in string messagingProvider, in Guid? messageId, in string topicOrQueue) =>
        _sentMessage(logger, messagingProvider, messageId, topicOrQueue, null!);
}
