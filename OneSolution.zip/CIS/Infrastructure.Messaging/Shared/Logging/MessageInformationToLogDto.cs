﻿namespace CIS.Infrastructure.Messaging.Shared.Logging;

internal record MessageInformationToLogDto
{
    public required Guid? MessageId { get; init; }

    public required string TopicOrQueue { get; init; }

    public required IReadOnlyDictionary<string, object> Headers { get; init; }

    public object? Message { get; init; }
}
