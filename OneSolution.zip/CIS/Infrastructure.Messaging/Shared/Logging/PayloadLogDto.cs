﻿namespace CIS.Infrastructure.Messaging.Shared.Logging;

internal record PayloadLogDto
{
    public required IReadOnlyDictionary<string, object> Headers { get; set; }

    public required object Message { get; set; }
}
