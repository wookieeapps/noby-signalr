﻿using CIS.Infrastructure.Messaging.Configuration;
using CIS.Infrastructure.Messaging.Shared.SchemaRegistry;
using Confluent.SchemaRegistry;
using KB.Speed.Messaging.Kafka.SchemaRegistry;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Polly.Extensions.Http;

namespace CIS.Infrastructure.Messaging.Shared;

internal static class MessagingStartupExtensions
{
    public static IServiceCollection AddSchemaRegistryClient(this IServiceCollection services, SchemaRegistryConfiguration? configuration)
    {
        if (configuration is null)
            return services;

        var httpClientRetryPolicy = HttpPolicyExtensions
            .HandleTransientHttpError()
            .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));

        services.AddHttpClient<IApicurioRestClient, ApicurioRestClient>()
                .ConfigureHttpClient(httpClient => httpClient.BaseAddress = new Uri(configuration.SchemaRegistryUrl))
                .AddPolicyHandler(httpClientRetryPolicy);

        services.AddScoped<ISchemaRegistryClient, ApicurioClient>();

        return services;
    }
}