﻿using System.Collections.Concurrent;
using System.Net;
using Confluent.SchemaRegistry;
using KB.Speed.Messaging.Kafka.SchemaRegistry;

namespace CIS.Infrastructure.Messaging.Shared.SchemaRegistry;

/// <summary>
/// 
/// </summary>
public class ApicurioClient : ISchemaRegistryClient
{
    /// <inheritdoc/>
    public int MaxCachedSchemas => 100;

    /// <summary>
    /// The client config
    /// </summary>
    public IEnumerable<KeyValuePair<string, string>> Config { get; } = [];

    /// <inheritdoc/>
    public IAuthenticationHeaderValueProvider AuthHeaderProvider => null!;

    /// <inheritdoc/>
    public IWebProxy Proxy => null!;

    private readonly int identityMapCapacity;
    private readonly List<SchemaReference> emptyReferencesList = [];
    private readonly IApicurioRestClient _client;
    private static readonly ConcurrentDictionary<int, Schema> concurrentDictionary = new();
    private readonly ConcurrentDictionary<int, Schema> schemaById = concurrentDictionary;

    private readonly ConcurrentDictionary<string, Dictionary<string, int>> idBySchemaBySubject = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, Dictionary<int, RegisteredSchema>> schemaByVersionBySubject = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, List<int>> subjectVersions = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="schemaRegistryConfig"></param>
    /// <param name="client"></param>
    public ApicurioClient(IApicurioRestClient client) => _client = client;

    /// <inheritdoc/>
    [Obsolete("SubjectNameStrategy should now be specified via serializer configuration. This method will be removed in a future release.")]
#nullable disable //interface implementation
    public string ConstructKeySubjectName(string topic, string recordType = null)
    {
        throw new NotSupportedException();
    }

    /// <inheritdoc/>
    [Obsolete("SubjectNameStrategy should now be specified via serializer configuration. This method will be removed in a future release.")]
    public string ConstructValueSubjectName(string topic, string recordType = null)
    {
        throw new NotSupportedException();
    }
#nullable restore

    /// <inheritdoc/>
    public Task<List<string>> GetAllSubjectsAsync()
    {
        throw new NotSupportedException();
    }

    /// <inheritdoc/>
    public Task<RegisteredSchema> GetLatestSchemaAsync(string subject)
    {
        throw new NotSupportedException();
    }

    /// <inheritdoc/>
    public async Task<RegisteredSchema> GetRegisteredSchemaAsync(string subject, int version, bool ignoreDeletedSchemas = true)
    {
        CleanCacheIfFull();
        var schemaByVersion = schemaByVersionBySubject.GetOrAdd(subject, new Dictionary<int, RegisteredSchema>());

        if (!schemaByVersion.TryGetValue(version, out RegisteredSchema? schema))
        {
            schema = await _client.GetSchemaAsync(subject, version).ConfigureAwait(continueOnCapturedContext: false);
            schemaByVersion[version] = schema;
            schemaById.TryAdd(schema.Id, schema.Schema);
        }
        return schema;
    }

    /// <inheritdoc/>
#nullable disable //interface implementation/// 
    public async Task<Schema> GetSchemaAsync(int id, string format = null)
#nullable restore
    {
        if (!schemaById.TryGetValue(id, out Schema? schema) || !CheckSchemaMatchesFormat(format, schema.SchemaString))
        {
            CleanCacheIfFull();
            schema = await _client.GetSchemaAsync(id).ConfigureAwait(continueOnCapturedContext: false); 
            schemaById.TryAdd(id, schema);
        }
        return schema;
    }

    /// <inheritdoc/>
    [Obsolete("Superseded by GetRegisteredSchemaAsync(string subject, int version). This method will be removed in a future release.")]
    public async Task<string> GetSchemaAsync(string subject, int version)
        => (await GetRegisteredSchemaAsync(subject, version)).SchemaString;

    /// <inheritdoc/>
    public Task<int> GetSchemaIdAsync(string subject, string avroSchema)
        => GetSchemaIdAsync(subject, new Schema(avroSchema, emptyReferencesList, SchemaType.Avro));

    /// <inheritdoc/>
    public async Task<int> GetSchemaIdAsync(string subject, Schema schema)
    {
        _ = schema ?? throw new ArgumentNullException(nameof(schema));

        var idBySchema = idBySchemaBySubject.GetOrAdd(subject, new Dictionary<string, int>());

        if (!idBySchema.TryGetValue(schema.SchemaString, out int schemaId))
        {
            CleanCacheIfFull();
            var registeredSchema = await _client.LookupSchemaAsync(subject, schema).ConfigureAwait(continueOnCapturedContext: false);
            idBySchema[schema.SchemaString] = registeredSchema.Id;
            schemaById.TryAdd(registeredSchema.Id, registeredSchema.Schema);
            schemaId = registeredSchema.Id;
        }

        return schemaId;
    }

    /// <inheritdoc/>
    public Task<List<int>> GetSubjectVersionsAsync(string subject)
    {
        if (string.IsNullOrEmpty(subject))
        {
            throw new ArgumentNullException(nameof(subject));
        }

        return GetSubjectVersionsAsyncInternalAsync(subject);
    }

    private async Task<List<int>> GetSubjectVersionsAsyncInternalAsync(string subject)
    {
        if (subjectVersions.TryGetValue(subject, out var versionsBySubject))
        {
            return versionsBySubject;
        }

        var versions = await _client.GetAvailableVersionsAsync(subject);
        CleanCacheIfFull();
        subjectVersions.TryAdd(subject, versions);
        return versions;
    }

    /// <inheritdoc/>
    public Task<bool> IsCompatibleAsync(string subject, string avroSchema)
        => IsCompatibleAsync(subject, new Schema(avroSchema, emptyReferencesList, SchemaType.Avro));

    /// <inheritdoc/>
    public Task<bool> IsCompatibleAsync(string subject, Schema schema)
    {
        throw new NotSupportedException();
    }

    /// <inheritdoc/>
    public Task<int> RegisterSchemaAsync(string subject, string avroSchema, bool normalize = false)
        => RegisterSchemaAsync(subject, new Schema(avroSchema, emptyReferencesList, SchemaType.Avro));

    /// <inheritdoc/>
    public Task<int> RegisterSchemaAsync(string subject, Schema schema, bool normalize = false)
    {
        throw new NotSupportedException();
    }

    /// <inheritdoc/>
    public Task<int> GetSchemaIdAsync(string subject, string avroSchema, bool normalize = false)
        => GetSchemaIdAsync(subject, avroSchema);

    /// <inheritdoc/>
    public Task<int> GetSchemaIdAsync(string subject, Schema schema, bool normalize = false)
        => GetSchemaIdAsync(subject, schema);

    /// <inheritdoc/>
    public Task<RegisteredSchema> LookupSchemaAsync(string subject, Schema schema, bool ignoreDeletedSchemas, bool normalize = false)
    {
        throw new NotSupportedException();
    }

    /// <summary>
    /// ets the schema uniquely identified by subject and id.
    /// </summary>
    /// <param name="subject"></param>
    /// <param name="id"></param>
    /// <param name="format"></param>
    /// <returns></returns>
    /// <exception cref="NotSupportedException"></exception>
    public Task<Schema> GetSchemaBySubjectAndIdAsync(string subject, int id, string? format = null)
    {
        return GetSchemaAsync(id, format);
    }

    /// <summary>
    /// Get the latest schema with the given metadata registered against the specified subject.
    /// </summary>
    /// <param name="subject"></param>
    /// <param name="metadata"></param>
    /// <param name="ignoreDeletedSchemas"></param>
    /// <returns></returns>
    /// <exception cref="NotSupportedException"></exception>
    public Task<RegisteredSchema> GetLatestWithMetadataAsync(string subject, IDictionary<string, string> metadata, bool ignoreDeletedSchemas)
    {
        throw new NotSupportedException();
    }

    //Interface implementation
#nullable disable
    /// <inheritdoc/>
    public Task<Compatibility> GetCompatibilityAsync(string subject = null)
    {
        throw new NotSupportedException();
    }

    /// <inheritdoc/>
    public Task<Compatibility> UpdateCompatibilityAsync(Compatibility compatibility, string subject = null)
    {
        throw new NotSupportedException();
    }
#nullable restore

    /// <summary>
    /// Clears caches of latest versions
    /// </summary>
    public void ClearLatestCaches()
    {
        //Nothing to do latest versions are not cached
    }

    /// <summary>
    /// Clears all caches.
    /// </summary>
    public void ClearCaches()
    {
        idBySchemaBySubject.Clear();
        schemaByVersionBySubject.Clear();
        subjectVersions.Clear();
        schemaById.Clear();
    }

    /// <summary>
    ///     Check if the given schema string matches a given format name.
    /// </summary>
    private static bool CheckSchemaMatchesFormat(string format, string schemaString)
    {
        var buffer = new Span<byte>(new byte[schemaString.Length]);
        // if a format isn't specified, then assume text is desired.
        if (format == null)
        {

            return !Convert.TryFromBase64String(schemaString, buffer, out int _);
        }
        else
        {
            if (format != "serialized")
            {
                throw new ArgumentException("Invalid schema specified", nameof(format));
            }

            return !Convert.TryFromBase64String(schemaString, buffer, out int _);
        }
    }

    private void CleanCacheIfFull()
    {
        if (!(schemaById.Count >= MaxCachedSchemas
            || idBySchemaBySubject.Count >= MaxCachedSchemas
            || schemaByVersionBySubject.Count >= MaxCachedSchemas
            || subjectVersions.Count >= MaxCachedSchemas))
        {
            return;
        }
        subjectVersions.Clear();
        schemaById.Clear();
        idBySchemaBySubject.Clear();
        schemaByVersionBySubject.Clear();
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
    }
}
