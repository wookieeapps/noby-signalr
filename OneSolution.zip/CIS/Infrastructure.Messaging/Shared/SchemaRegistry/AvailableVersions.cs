﻿using CIS.Infrastructure.Messaging.Shared.SchemaRegistry;
using System.Text.Json.Serialization;

namespace KB.Speed.Messaging.Kafka.SchemaRegistry;

internal class AvailableVersions
{
    [JsonPropertyName("count")]
    public int Count { get; set; }

    [JsonPropertyName("versions")]
    public List<SchemaMetadata>? Versions { get; set; }
}
