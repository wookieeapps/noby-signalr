﻿namespace CIS.Infrastructure.Telemetry
{
    /// <summary>
    /// Loggování a telemetrie
    /// </summary>
    internal static class AssemblyDoc { }

    /// <summary>
    /// Loggování a telemetrie
    /// </summary>
    internal static class NamespaceDoc { }
}

namespace CIS.Infrastructure.Telemetry.Configuration
{
    /// <summary>
    /// Konfigurace logování a telemerie
    /// </summary>
    internal static class NamespaceDoc { }
}