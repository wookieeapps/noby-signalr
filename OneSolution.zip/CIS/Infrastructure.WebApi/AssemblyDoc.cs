﻿namespace CIS.Infrastructure.WebApi
{
    /// <summary>
    /// Loggování a telemetrie
    /// </summary>
    internal static class AssemblyDoc { }

    /// <summary>
    /// Loggování a telemetrie
    /// </summary>
    internal static class NamespaceDoc { }
}
