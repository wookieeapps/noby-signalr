﻿namespace CIS.Infrastructure.WebApi;

public static class CisSecurityHeaders
{
    public static IApplicationBuilder UseCisSecurityHeaders(this IApplicationBuilder app)
    {
        app.UseMiddleware<Middleware.HttpOptionsMiddleware>();

        app.UseCisWebApiCors();

        app.UseHttpsRedirection();

        // CSP
        app.Use(async (context, next) => {
            context.Response.OnStarting(() => {
                context.Response.Headers.Append("Access-Control-Expose-Headers", "trace-id, api-ver");
                context.Response.Headers.Append("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; object-src 'none'; base-uri 'self'; connect-src 'self' *.noby.cz *.mpss.cz *.kb.cz; font-src 'self' data: https://fonts.gstatic.com; form-action 'self'; frame-src 'self'; img-src 'self' data: blob:; manifest-src 'self'; media-src 'self'; worker-src 'self'");
                context.Response.Headers.Append("permissions-policy", "accelerometer 'none', ambient-light-sensor 'none', autoplay 'none', battery 'none', camera 'none', display-capture 'none', document-domain 'none', encrypted-media 'none', fullscreen 'none', geolocation 'none', gyroscope 'none', layout-animations 'none', legacy-image-formats 'none', magnetometer 'none', microphone 'none', midi 'none', oversized-images 'none', payment 'none', picture-in-picture 'none', publickey-credentials-get 'none', sync-xhr 'self' http://istio.test.fe-api-gateway.kbcloud https://deliver.kontent.ai, unoptimized-images 'none', unsized-media 'none', usb 'none', vibrate 'none', vr 'none', screen-wake-lock 'none', web-share 'none', xr-spatial-tracking 'none'");
                context.Response.Headers.Append("X-XSS-Protection", "1; mode=block");
                context.Response.Headers.Append("Referrer-Policy", "strict-origin-when-cross-origin");

                return Task.CompletedTask;
            });

            await next();
        });

        return app;
    }
}
