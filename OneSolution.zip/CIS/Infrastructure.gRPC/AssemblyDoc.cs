﻿namespace CIS.Infrastructure.gRPC
{
    /// <summary>
    /// Podpora pro vytváření gRPC služeb v systému NOBY.
    /// </summary>
    internal static class AssemblyDoc { }
}
