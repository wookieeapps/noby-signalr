﻿namespace CIS.Infrastructure.gRPC.Configuration;

public static class GrpcServiceUriSettingsConstants
{
    public const string EmptyUriAddress = "https://localhost";
}
