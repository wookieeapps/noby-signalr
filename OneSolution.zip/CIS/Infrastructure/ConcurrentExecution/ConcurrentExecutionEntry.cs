﻿using ZiggyCreatures.Caching.Fusion;

namespace CIS.Infrastructure.ConcurrentExecution;

public sealed class ConcurrentExecutionEntry(IFusionCache distributedCache, Action<string> onEntryDisposed) 
    : IAsyncDisposable
{
#pragma warning disable CA2213 // Disposable fields should be disposed
    private readonly IFusionCache _distributedCache = distributedCache;
#pragma warning restore CA2213 // Disposable fields should be disposed
    private readonly Action<string> _onEntryDisposed = onEntryDisposed;

    private string _cacheKey = "";

    internal async Task InitializeAsync(string cacheKey, object key)
    {
        _cacheKey = cacheKey;

        var cacheEntryOptions = new FusionCacheEntryOptions 
        { 
            DistributedCacheDuration = TimeSpan.FromMinutes(5),
            SkipMemoryCacheRead = true,
            SkipMemoryCacheWrite = true
        };

        await _distributedCache.SetAsync(cacheKey, key, cacheEntryOptions);
    }

    public async ValueTask DisposeAsync()
    {
        GC.SuppressFinalize(this);

        if (string.IsNullOrWhiteSpace(_cacheKey))
            return;

        await _distributedCache.RemoveAsync(_cacheKey);
        _onEntryDisposed(_cacheKey);
    }
}