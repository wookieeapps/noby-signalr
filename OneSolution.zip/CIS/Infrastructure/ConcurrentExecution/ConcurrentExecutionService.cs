﻿using System.Collections.Concurrent;
using ZiggyCreatures.Caching.Fusion;

namespace CIS.Infrastructure.ConcurrentExecution;

public sealed class ConcurrentExecutionService(IFusionCache _distributedCache)
    : IConcurrentExecutionService
{
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> _semaphores = new();

    public async Task<IAsyncDisposable> PreventConcurrentExecutionAsync<TKey>(TKey key, string callerName) where TKey : notnull
    {
        var cacheKey = $"{nameof(ConcurrentExecutionService)}:{callerName}:{key}";

        var semaphore = _semaphores.GetOrAdd(cacheKey, _ => new SemaphoreSlim(1, 1));

        await semaphore.WaitAsync();

        try
        {
            var cachedKey = await _distributedCache.GetOrDefaultAsync<TKey?>(cacheKey);

#pragma warning disable CA1508 // Avoid dead conditional code
            if (cachedKey is not null && !Equals(cachedKey, default(TKey)))
            {
                throw new ConcurrentRequestException();
            }
#pragma warning restore CA1508 // Avoid dead conditional code

            var entry = new ConcurrentExecutionEntry(_distributedCache, OnEntryDisposed);
            await entry.InitializeAsync(cacheKey, key);

            return entry;
        }
        finally
        {
            semaphore.Release();
        }
    }

    private void OnEntryDisposed(string cacheKey)
    {
        if (!_semaphores.TryGetValue(cacheKey, out var semaphore) || semaphore.CurrentCount == 0)
        {
            return;
        }

        _semaphores.Remove(cacheKey, out _);
        semaphore.Dispose();
    }
}