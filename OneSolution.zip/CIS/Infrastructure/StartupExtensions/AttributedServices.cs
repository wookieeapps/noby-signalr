﻿using CIS.Core.Attributes;

namespace CIS.Infrastructure.StartupExtensions;

public static class AttributedServices
{
    public static IServiceCollection AddAttributedServices(this IServiceCollection services, params Type[] scannableAssemblies)
    {
        // register all services
        services.Scan(selector => selector
            .FromAssembliesOf(scannableAssemblies)
            .AddClasses(x => x.WithAttribute<ScopedServiceAttribute>().WithAttribute<AsImplementedInterfacesServiceAttribute>(), false)
            .AsImplementedInterfaces()
            .WithScopedLifetime());

        services.Scan(selector => selector
            .FromAssembliesOf(scannableAssemblies)
            .AddClasses(x => x.WithAttribute<ScopedServiceAttribute>().WithAttribute<SelfServiceAttribute>(), false)
            .AsSelf()
            .WithScopedLifetime());
        
        services.Scan(selector => selector
            .FromAssembliesOf(scannableAssemblies)
            .AddClasses(x => x.WithAttribute<TransientServiceAttribute>().WithAttribute<AsImplementedInterfacesServiceAttribute>(), false)
            .AsImplementedInterfaces()
            .WithTransientLifetime());

        services.Scan(selector => selector
            .FromAssembliesOf(scannableAssemblies)
            .AddClasses(x => x.WithAttribute<TransientServiceAttribute>().WithAttribute<SelfServiceAttribute>(), false)
            .AsSelf()
            .WithTransientLifetime());

        services.Scan(selector => selector
            .FromAssembliesOf(scannableAssemblies)
            .AddClasses(x => x.WithAttribute<SingletonServiceAttribute>().WithAttribute<AsImplementedInterfacesServiceAttribute>(), false)
            .AsImplementedInterfaces()
            .WithSingletonLifetime());

        services.Scan(selector => selector
            .FromAssembliesOf(scannableAssemblies)
            .AddClasses(x => x.WithAttribute<SingletonServiceAttribute>().WithAttribute<SelfServiceAttribute>(), false)
            .AsSelf()
            .WithSingletonLifetime());

        return services;
    }
}
