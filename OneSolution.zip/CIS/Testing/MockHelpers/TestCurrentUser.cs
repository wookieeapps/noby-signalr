﻿namespace CIS.Testing.MockHelpers;

public record TestCurrentUser(int Id, string? Login)
    : CIS.Core.Security.ICurrentUser
{
}
