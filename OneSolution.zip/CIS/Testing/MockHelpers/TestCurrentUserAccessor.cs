﻿using CIS.Core.Security;
using System.Security.Claims;

namespace CIS.Testing.MockHelpers;

public class TestCurrentUserAccessor
    : CIS.Core.Security.ICurrentUserAccessor
{
    private readonly ICurrentUser _user;

    public TestCurrentUserAccessor(ICurrentUser user)
    {
        _user = user;
    }

    public IEnumerable<Claim> Claims => throw new NotImplementedException();

    public bool IsAuthenticated => true;

    public ICurrentUser? User => _user;

    public ICurrentUserDetails? UserDetails => throw new NotImplementedException();

    public Task<ICurrentUserDetails> EnsureDetails(CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<TDetails> EnsureDetails<TDetails>(CancellationToken cancellationToken = default) where TDetails : ICurrentUserDetails
    {
        throw new NotImplementedException();
    }
}
