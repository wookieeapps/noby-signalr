﻿using CIS.Infrastructure.Messaging.Artemis;
using CIS.Infrastructure.Messaging.Artemis.Serialization;
using Confluent.SchemaRegistry;
using MassTransit;
using MassTransit.Testing;
using Microsoft.Extensions.DependencyInjection;
using NSubstitute;

namespace CIS.Infrastructure.Messaging.Tests.Artemis;

public class ArtemisSerializationFixture
{
    public ArtemisSerializationFixture()
    {
        SchemaRegistryClient = Substitute.For<ISchemaRegistryClient>();
    }

    public ISchemaRegistryClient SchemaRegistryClient { get; }

    public ITestHarness CreateHarness()
    {
        var serviceCollection = new ServiceCollection();

        serviceCollection.AddTransient<JmsSerializer>();
        serviceCollection.AddTransient<JmsJsonDeserializer>();
        serviceCollection.AddTransient<JmsAvroDeserializer>();
        serviceCollection.AddSingleton(SchemaRegistryClient);

        serviceCollection.AddMassTransitTestHarness(x =>
        {
            x.UsingInMemory((context, cfg) =>
            {
                cfg.AddArtemisSerializers(context);

                cfg.ConfigureEndpoints(context);
            });
        });

        var serviceProvider = serviceCollection.BuildServiceProvider(validateScopes: true);

        return serviceProvider.GetRequiredService<ITestHarness>();

    }
}
