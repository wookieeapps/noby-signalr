﻿namespace CIS.Infrastructure.Messaging.Tests.TestData;

internal class TestMessage
{
    public long Id { get; set; }

    public string? Message { get; set; }
}
