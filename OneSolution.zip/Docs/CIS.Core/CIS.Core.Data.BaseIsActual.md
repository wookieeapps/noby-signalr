#### [CIS.Core](index.md 'index')
### [CIS.Core.Data](CIS.Core.Data.md 'CIS.Core.Data')

## BaseIsActual Class

Implementace [IIsActual](CIS.Core.Data.IIsActual.md 'CIS.Core.Data.IIsActual')

```csharp
public class BaseIsActual :
CIS.Core.Data.IIsActual
```

Inheritance [System.Object](https://docs.microsoft.com/en-us/dotnet/api/System.Object 'System.Object') &#129106; BaseIsActual

Implements [IIsActual](CIS.Core.Data.IIsActual.md 'CIS.Core.Data.IIsActual')