#### [CIS.Core](index.md 'index')
### [CIS.Core.Data](CIS.Core.Data.md 'CIS.Core.Data')

## BaseModifiedUser Class

Implementace [IModifiedUser](CIS.Core.Data.IModifiedUser.md 'CIS.Core.Data.IModifiedUser')

```csharp
public class BaseModifiedUser :
CIS.Core.Data.IModifiedUser
```

Inheritance [System.Object](https://docs.microsoft.com/en-us/dotnet/api/System.Object 'System.Object') &#129106; BaseModifiedUser

Implements [IModifiedUser](CIS.Core.Data.IModifiedUser.md 'CIS.Core.Data.IModifiedUser')