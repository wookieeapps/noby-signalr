#### [CIS.Core](index.md 'index')
### [CIS.Core.Exceptions](CIS.Core.Exceptions.md 'CIS.Core.Exceptions')

## ICisExceptionExludedFromLog Interface

Marker interface for exceptions that should not be logged.

```csharp
public interface ICisExceptionExludedFromLog
```