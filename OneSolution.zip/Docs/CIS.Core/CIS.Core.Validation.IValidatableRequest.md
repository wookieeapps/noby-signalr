#### [CIS.Core](index.md 'index')
### [CIS.Core.Validation](CIS.Core.Validation.md 'CIS.Core.Validation')

## IValidatableRequest Interface

Marker interface, který označuje request zapojený do custom validace v rámci Mediator pipeline.

```csharp
public interface IValidatableRequest
```