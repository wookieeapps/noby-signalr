#### [CIS.Infrastructure.CisMediatR](index.md 'index')
### [CIS.Infrastructure.CisMediatR.Rollback](CIS.Infrastructure.CisMediatR.Rollback.md 'CIS.Infrastructure.CisMediatR.Rollback')

## IRollbackCapable Interface

Marker interface pro Mediatr Request, ktery ma podporovat rollback pipeline.

```csharp
public interface IRollbackCapable
```