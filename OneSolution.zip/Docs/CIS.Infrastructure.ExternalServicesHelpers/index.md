#### [CIS.Infrastructure.ExternalServicesHelpers](index.md 'index')

## CIS.Infrastructure.ExternalServicesHelpers Assembly

Podpora pro konzumaci REST a SOAP služeb třetích stran.

| Namespaces | |
| :--- | :--- |
| [CIS.Infrastructure.ExternalServicesHelpers](CIS.Infrastructure.ExternalServicesHelpers.md 'CIS.Infrastructure.ExternalServicesHelpers') | |
| [CIS.Infrastructure.ExternalServicesHelpers.Configuration](CIS.Infrastructure.ExternalServicesHelpers.Configuration.md 'CIS.Infrastructure.ExternalServicesHelpers.Configuration') | Implementace konfigurace konzumované služby v appsettings.json. |
| [CIS.Infrastructure.ExternalServicesHelpers.HttpHandlers](CIS.Infrastructure.ExternalServicesHelpers.HttpHandlers.md 'CIS.Infrastructure.ExternalServicesHelpers.HttpHandlers') | Custom HttpHandlery k použití v IHttpHandlerFactory pipeline. |
