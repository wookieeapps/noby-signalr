#### [CIS.Infrastructure.MediatR](index.md 'index')

## CIS.Infrastructure.MediatR Namespace

| Classes | |
| :--- | :--- |
| [CisMediatrStartupExtensions](CIS.Infrastructure.MediatR.CisMediatrStartupExtensions.md 'CIS.Infrastructure.MediatR.CisMediatrStartupExtensions') | Extension metody do startupu aplikace pro registraci behaviors. |
