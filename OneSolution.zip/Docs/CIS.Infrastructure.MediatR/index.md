#### [CIS.Infrastructure.MediatR](index.md 'index')

## CIS.Infrastructure.MediatR Assembly

MediatR custom behaviors

| Namespaces | |
| :--- | :--- |
| [CIS.Infrastructure.MediatR](CIS.Infrastructure.MediatR.md 'CIS.Infrastructure.MediatR') | |
| [CIS.Infrastructure.MediatR.Rollback](CIS.Infrastructure.MediatR.Rollback.md 'CIS.Infrastructure.MediatR.Rollback') | |
