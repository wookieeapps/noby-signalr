#### [CIS.Infrastructure.Messaging](index.md 'index')

## CIS.Infrastructure.Messaging.Configuration Namespace

Nastavení konfigurace autentizace z appsettings.json.

| Interfaces | |
| :--- | :--- |
| [IKafkaRiderConfiguration](CIS.Infrastructure.Messaging.Configuration.IKafkaRiderConfiguration.md 'CIS.Infrastructure.Messaging.Configuration.IKafkaRiderConfiguration') | Konfigurace Kafky - zejmena z Confluent.Kafka.ClientConfig |
