#### [CIS.Infrastructure.Messaging](index.md 'index')

## CIS.Infrastructure.Messaging.Kafka Namespace

Helpery pro konzumacia produkování zpráv do Kafky

| Interfaces | |
| :--- | :--- |
| [ICisMessagingKafkaBuilder](CIS.Infrastructure.Messaging.Kafka.ICisMessagingKafkaBuilder.md 'CIS.Infrastructure.Messaging.Kafka.ICisMessagingKafkaBuilder') | |
