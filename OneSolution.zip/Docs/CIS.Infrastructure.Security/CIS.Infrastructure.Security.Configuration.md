#### [CIS.Infrastructure.Security](index.md 'index')

## CIS.Infrastructure.Security.Configuration Namespace

Nastavení konfigurace autentizace z appsettings.json.

| Classes | |
| :--- | :--- |
| [CisSecurityConfiguration](CIS.Infrastructure.Security.Configuration.CisSecurityConfiguration.md 'CIS.Infrastructure.Security.Configuration.CisSecurityConfiguration') | Sekce v appsettings.json pro nastaveni autentizace |
| [CisServiceAuthenticationConfiguration](CIS.Infrastructure.Security.Configuration.CisServiceAuthenticationConfiguration.md 'CIS.Infrastructure.Security.Configuration.CisServiceAuthenticationConfiguration') | Konfigurace autentizace doménové služby |
| [CisServiceAuthenticationConfiguration.AllowedUserConfiguration](CIS.Infrastructure.Security.Configuration.CisServiceAuthenticationConfiguration.AllowedUserConfiguration.md 'CIS.Infrastructure.Security.Configuration.CisServiceAuthenticationConfiguration.AllowedUserConfiguration') | |
