#### [CIS.Infrastructure.Security](index.md 'index')

## CIS.Infrastructure.Security Assembly

Konfigurace a helpery pro autentizaci gRPC služeb.

| Namespaces | |
| :--- | :--- |
| [CIS.Infrastructure.Security](CIS.Infrastructure.Security.md 'CIS.Infrastructure.Security') | Helpery pro autentizaci gRPC služeb. |
| [CIS.Infrastructure.Security.Configuration](CIS.Infrastructure.Security.Configuration.md 'CIS.Infrastructure.Security.Configuration') | Nastavení konfigurace autentizace z appsettings.json. |
