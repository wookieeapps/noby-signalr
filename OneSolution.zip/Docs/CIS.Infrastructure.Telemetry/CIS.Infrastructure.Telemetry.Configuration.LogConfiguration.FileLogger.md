#### [CIS.Infrastructure.Telemetry](index.md 'index')
### [CIS.Infrastructure.Telemetry.Configuration](CIS.Infrastructure.Telemetry.Configuration.md 'CIS.Infrastructure.Telemetry.Configuration').[LogConfiguration](CIS.Infrastructure.Telemetry.Configuration.LogConfiguration.md 'CIS.Infrastructure.Telemetry.Configuration.LogConfiguration')

## LogConfiguration.FileLogger Class

Nastaveni File sink dle https://github.com/serilog/serilog-sinks-file

```csharp
public sealed class LogConfiguration.FileLogger
```

Inheritance [System.Object](https://docs.microsoft.com/en-us/dotnet/api/System.Object 'System.Object') &#129106; FileLogger