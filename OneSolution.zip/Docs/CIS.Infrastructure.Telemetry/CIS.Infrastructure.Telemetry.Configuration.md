#### [CIS.Infrastructure.Telemetry](index.md 'index')

## CIS.Infrastructure.Telemetry.Configuration Namespace

Konfigurace logování a telemerie

| Classes | |
| :--- | :--- |
| [LogConfiguration](CIS.Infrastructure.Telemetry.Configuration.LogConfiguration.md 'CIS.Infrastructure.Telemetry.Configuration.LogConfiguration') | |
| [LogConfiguration.FileLogger](CIS.Infrastructure.Telemetry.Configuration.LogConfiguration.FileLogger.md 'CIS.Infrastructure.Telemetry.Configuration.LogConfiguration.FileLogger') | Nastaveni File sink dle https://github.com/serilog/serilog-sinks-file |
| [LoggingConfiguration](CIS.Infrastructure.Telemetry.Configuration.LoggingConfiguration.md 'CIS.Infrastructure.Telemetry.Configuration.LoggingConfiguration') | |
| [TracingConfiguration](CIS.Infrastructure.Telemetry.Configuration.TracingConfiguration.md 'CIS.Infrastructure.Telemetry.Configuration.TracingConfiguration') | |
