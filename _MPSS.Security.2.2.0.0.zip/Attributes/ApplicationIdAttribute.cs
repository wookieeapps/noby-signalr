﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Atribut slouzici k nastaveni ID aplikace volajici sluzby MPSS.Security.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    [System.Runtime.InteropServices.ComVisible(false)]
    public class ApplicationIdAttribute : Attribute
    {
        protected int _ApplicationId;

        /// <summary>
        /// Application ID
        /// </summary>
        public int ApplicationId
        {
            get
            {
                return this._ApplicationId;
            }
        }

        /// <summary>
        /// Inicializace atributu
        /// </summary>
        /// <param name="applicationId">ID aplikace na PMP</param>
        public ApplicationIdAttribute(int applicationId)
        {
            this._ApplicationId = applicationId;
        }
    }
}
