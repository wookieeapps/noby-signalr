﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Moznost vypnuti/zapnuti obrany proti CSRF.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    [System.Runtime.InteropServices.ComVisible(false)]
    public class CsrfCheckAttribute : Attribute
    {
        protected bool _UseCsrfCheck;

        /// <summary>
        /// Je true, pokud je obrana zapnuta.
        /// </summary>
        public bool UseCsrfCheck
        {
            get
            {
                return this._UseCsrfCheck;
            }
        }

        public CsrfCheckAttribute(bool useCsrfCheck)
        {
            this._UseCsrfCheck = useCsrfCheck;
        }
    }
}
