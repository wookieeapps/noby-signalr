﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Atribut slouzici k nastaveni app prostredi volajici sluzby MPSS.Security.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    [System.Runtime.InteropServices.ComVisible(false)]
    public class EnvironmentTypeAttribute : Attribute
    {
        protected int _EnvironmentType;

        /// <summary>
        /// Environment type
        /// </summary>
        public int EnvironmentType
        {
            get
            {
                return this._EnvironmentType;
            }
        }

        /// <summary>
        /// Inicializace atributu
        /// </summary>
        /// <param name="applicationId">ID app prostredi</param>
        public EnvironmentTypeAttribute(int environmentType)
        {
            this._EnvironmentType = environmentType;
        }
    }
}
