﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Moznost nastaveni nutnosti autentifikace pro zobrazeni stranky.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    [System.Runtime.InteropServices.ComVisible(false)]
    public class PageAuthenticationAttribute : Attribute
    {
        protected bool _RequiresAuthentication;

        /// <summary>
        /// Je true, pokud stranka vyzaduje autentikaci.
        /// </summary>
        public bool RequiresAuthentication
        {
            get
            {
                return this._RequiresAuthentication;
            }
        }

        public PageAuthenticationAttribute(bool requiresAuthentication)
        {
            this._RequiresAuthentication = requiresAuthentication;
        }
    }
}
