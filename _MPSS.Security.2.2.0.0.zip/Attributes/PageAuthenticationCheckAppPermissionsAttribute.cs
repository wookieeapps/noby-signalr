﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Moznost nastaveni nutnosti mit pravo pro soucasnou aplikaci.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    [System.Runtime.InteropServices.ComVisible(false)]
    public class PageAuthenticationCheckAppPermissionsAttribute : Attribute
    {
        protected bool _RequiresPermission;

        /// <summary>
        /// Je true, pokud stranka vyzaduje autentikaci.
        /// </summary>
        public bool RequiresPermission
        {
            get
            {
                return this._RequiresPermission;
            }
        }

        public PageAuthenticationCheckAppPermissionsAttribute(bool RequiresPermission)
        {
            this._RequiresPermission = RequiresPermission;
        }
    }
}