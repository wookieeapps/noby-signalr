﻿using System;
using System.Reflection;
using System.Security.Policy;
using System.Diagnostics;

namespace MPSS.Security
{
    /// <summary>
    /// <para>Atribut pro kontrolu, zda je metoda volana overenou assembly. Pokud ne, vyvola vyjimku.</para>
    /// <para>Kontrolu je nutno spustit metodou CheckAssembly().</para>
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true, Inherited = false)]
    internal class ValidateAssemblyLink : Attribute
    {
        private string _AssemblyUri;
        /// <summary>
        /// Uri overovane assembly
        /// </summary>
        public string AssemblyUri
        {
            get
            {
                return this._AssemblyUri;
            }
        }

        /// <summary>
        /// Validace calling assembly.
        /// </summary>
        /// <param name="requestedAssemblyUri"></param>
        public ValidateAssemblyLink(string requestedAssemblyUri)
        {
            if (string.IsNullOrEmpty(requestedAssemblyUri))
                throw new ArgumentNullException("requestedAssemblyUri in ValidateAssemblyLink attribute is missing");

            this._AssemblyUri = requestedAssemblyUri;
        }

        /// <summary>
        /// Spusteni kontroly atributovane metody.
        /// </summary>
        /// <param name="callingAssembly">Assembly, jejiz uri je nutne zkontrolovat.</param>
        public static void CheckAssembly(Assembly callingAssembly)
        {
            bool check = false;

            int acount = 0;
            StackTrace stackTrace = new StackTrace();
            foreach (ValidateAssemblyLink att in stackTrace.GetFrame(1).GetMethod().GetCustomAttributes(typeof(ValidateAssemblyLink), true))
            {
                acount++;
                UrlMembershipCondition url = new UrlMembershipCondition(att.AssemblyUri);
                Evidence ev = callingAssembly.Evidence;
                if (url.Check(ev))
                {
                    check = true;
                    break;
                }
            }

            // pokud neprosla kontrola na uri
            if (!check && acount > 0)
            {
                // volajici assembly je v jine ceste
                throw new Exception("Secured method executed from untrusted source: " + callingAssembly.FullName);
            }
        }
    }
}
