﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Kontajner pro ulozenin konfigurace aplikace.
    /// </summary>
    public class Configuration
    {
        #region AD
        /// <summary>
        /// Login pro prihlaseni do AD
        /// </summary>
        public string ADAdminLogin { get; set; }
        /// <summary>
        /// Heslo pro prihlaseni do AD
        /// </summary>
        public string ADAdminPassword { get; set; }
        /// <summary>
        /// Server AD
        /// </summary>
        public string ADServer { get; set; }
        /// <summary>
        /// Korenovy uzel v AD
        /// </summary>
        public string ADContext { get; set; }
        /// <summary>
        /// Vetev ve ktere jsou hledani uzivatele v AD
        /// </summary>
        public string ADUsersBranch { get; set; }
        #endregion

        /// <summary>
        /// Vychozi UI culture pro PageBase a HttpHandlerBase.
        /// </summary>
        public string DefaultCulture { get; set; }

        /// <summary>
        /// Druh aplikacniho prostredi.
        /// </summary>
        public int EnvironmentType { get; set; }

        /// <summary>
        /// Server number
        /// </summary>
        public int Server { get; set; }

        #region webGarant
        public string WebGarantUrl { get; set; }

        public int WebGarantAppId { get; set; }

        public string WebGarantIc { get; set; }

        public string WebGarantChannel { get; set; }
        #endregion

        #region security cookie
        /// <summary>
        /// True pokud ma byt cookie ulozena na disk, jinak se jedna o session cookie.
        /// </summary>
        public bool PersistentCookie { get; set; }

        /// <summary>
        /// Maximalni doba prihlaseni uzivatele v minutach.
        /// </summary>
        public int MaxCookieAge { get; set; }

        /// <summary>
        /// Pokud je true SecurityCookie s sifrovanymi informacemi o uzivateli se bude odesilat pouze pokud se jedna o https protokol.
        /// </summary>
        public bool CookieOnlyHttps { get; set; }

        /// <summary>
        /// Path SecurityCookie s sifrovanymi informacemi o uzivateli.
        /// </summary>
        public string CookiePath { get; set; }

        /// <summary>
        /// Nazev SecurityCookie s sifrovanymi informacemi o uzivateli.
        /// </summary>
        public string CookieName { get; set; }
        
        /// <summary>
        /// Domena SecurityCookie s sifrovanymi informacemi o uzivateli.
        /// </summary>
        public string CookieDomainName { get; set; }

        /// <summary>
        /// Expirace SecurityCookie v minutach s sifrovanymi informacemi o uzivateli.
        /// </summary>
        public int CookieExpiration { get; set; }
        #endregion

        #region kryptovani
        /// <summary>
        /// 8-mistny klic pro kryptovani SecurityCookie
        /// </summary>
        public byte[] DesCryptoKey { get; set; }

        /// <summary>
        /// 8-mistny vektor pro kryptovani SecurityCookie
        /// </summary>
        public byte[] DesCryptoVector { get; set; }

        public string RijndealPassword { get; set; }
        public byte[] RijndaelVector { get; set; }
        public int RijndaelStrength { get; set; }
        public int RijndaelPwdIterations { get; set; }
        public byte[] RijndaelSalt { get; set; }
        #endregion

        #region portal URL
        /// <summary>
        /// URL vychozi stranky pro logovani uzivatele (v portalu).
        /// </summary>
        public string PMPLoginUrl { get; set; }

        /// <summary>
        /// URL hlavni obrazovky portalu.
        /// </summary>
        public string PMPMainUrl { get; set; }

        /// <summary>
        /// URL logoutovaciho skriptu.
        /// </summary>
        public string PMPLogoutUrl { get; set; }
        #endregion

        #region mssql database
        /// <summary>
        /// ConnectionString pro databazi s uzivateli
        /// </summary>
        public string DbConnectionString { get; set; }

        /// <summary>
        /// Connection string pro logovaci db.
        /// </summary>
        public string LogConnectionString { get; set; }
        #endregion

        public int DbLogMinSeverity { get; set; }

        /// <summary>
        /// Domeny podporovane PMP. Pozadavky z jinych domen by mely byt zakazany.
        /// </summary>
        public string[] AllowedDomains;

        /// <summary>
        /// True, pokud se ma ukladat informace o odhlaseni do databaze.
        /// Pokud se tato informace uklada, kazdy dalsi pozadavek je validovan oproti seznam odhlasenych session.
        /// </summary>
        public bool SaveLogoutRequest { get; set; }

        /// <summary>
        /// True, pokud je vyzadovano https pro kazdy pozadavek.
        /// </summary>
        public bool OnlyHttps { get; set; }

        /// <summary>
        /// Algoritmus pro kryptovani security cookie.
        /// </summary>
        public CryptoProviders CryptoProvider { get; set; }
    }
}
