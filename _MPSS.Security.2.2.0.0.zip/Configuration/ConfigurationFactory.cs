﻿using System;
using System.Collections.Generic;

namespace MPSS.Security
{
    /// <summary>
    /// Trida pro spravu a ziskavani konfigurace aplikace.
    /// </summary>
    public class ConfigurationFactory
    {
        /// <summary>
        /// Instance soucasneho providera konfigurace.
        /// </summary>
        private static Dictionary<int, Configuration> _Configuration;

        /// <summary>
        /// Vychozi prostredi
        /// </summary>
        private static int DefaultEnvironmentType;

        static ConfigurationFactory()
        {
            IConfigurationProvider provider;

            // vybrat aktivni provider
#if DebugDevportal
            //provider = new StaticDevConfigurationProvider();
            provider = new FileConfigurationProvider();
#elif Testinet
            provider = new StaticTestinetConfigurationProvider();
#elif DebugProd
            provider = new FileConfigurationProvider();
            //provider = new StaticProdConfigurationProvider();
#elif DebugLocal
            //provider = new StaticLocalConfigurationProvider();
            provider = new FileConfigurationProvider();
#elif DebugTomas
            provider = new StaticTomasConfigurationProvider();
#else
            provider = new FileConfigurationProvider();
#endif

            // instance konfiguracniho providera
            _Configuration = provider.Get();
            DefaultEnvironmentType = provider.DefaultEnvironment;

            // registrace logovaci DB provideru
            Log.LoggerFactory.AddLogger(new Log.DbLogger());

            // response logger
            //Log.LoggerFactory.AddLogger(new Log.ResponseLogger());
        }

        /// <summary>
        /// Vraci objekt konfigurace aplikace.
        /// </summary>
        public static Configuration GetConfiguration()
        {
            return _Configuration[DefaultEnvironmentType];
        }

        /// <summary>
        /// Vraci objekt konfigurace aplikace.
        /// </summary>
        /// <param name="type">ID prostredi</param>
        public static Configuration GetConfiguration(int type)
        {
            if (type == 0)
            {
                return GetConfiguration();
            }
            else
            {
                if (_Configuration.ContainsKey(type))
                {
                    return _Configuration[type];
                }
                else
                {
                    throw new Exception(string.Format("Environment type '{0}' not found in configuration file", type));
                }
            }
        }
    }
}
