﻿using System;
using System.Collections.Generic;
using MPSS.Security;
using System.Text;
using System.Configuration;
using System.Xml;
using System.IO;

namespace MPSS.Security
{
    internal class FileConfigurationProvider : IConfigurationProvider
    {
        private string ConfigFilePath;

        public int DefaultEnvironment
        {
            get;
            private set;
        }
        private int Server;

        private string GV(string key, XmlNode node)
        {
            XmlNode node2 = node.SelectSingleNode(string.Format(".//add[@key=\"{0}\"]", key));
            if (node2 == null)
                throw new Exception("Can not find element in config file [" + ConfigFilePath + "]: " + key);
            return node2.Attributes["value"].Value;
        }

        /// <summary>
        /// Get all configurations in config file
        /// </summary>
        public Dictionary<int, Configuration> Get()
        {
            if (File.Exists(System.Reflection.Assembly.GetExecutingAssembly().Location + ".config"))
                ConfigFilePath = System.Reflection.Assembly.GetExecutingAssembly().Location + ".config";
            else if (File.Exists(System.Web.HttpContext.Current.Server.MapPath("~/MPSS.Security.dll.config")))
                ConfigFilePath = System.Web.HttpContext.Current.Server.MapPath("~/MPSS.Security.dll.config");
            else
            {
                string error = "Can not find config file:<br/>";
                error += System.Reflection.Assembly.GetExecutingAssembly().Location + ".config<br/>";
                error += System.Web.HttpContext.Current.Server.MapPath("~/MPSS.Security.dll.config");
                throw new Exception(error);
            }

            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(ConfigFilePath);

            // defaults node
            XmlNode defaultsNode = xmldoc.SelectSingleNode("/securityConfiguration/defaults");
            if (defaultsNode == null)
                throw new Exception("Can not find 'defaults' element in config file.");

            // read defaults
            this.DefaultEnvironment = Convert.ToInt32(GV("EnvironmentType", defaultsNode));
            this.Server = Convert.ToInt32(GV("Server", defaultsNode));

            // environments nodes
            XmlNodeList envs = xmldoc.SelectNodes("/securityConfiguration/environment");
            if (envs == null)
                throw new Exception("Can not find any 'environment' element in config file.");

            Dictionary<int, Configuration> configs = new Dictionary<int, Configuration>();

            foreach (XmlNode node in envs)
            {
                Configuration c = new Configuration();

                c.DefaultCulture = GV("DefaultCulture", node);
                c.EnvironmentType = Convert.ToInt32(node.Attributes["type"].Value);
                c.Server = this.Server;

                // webgarant
                c.WebGarantAppId = Convert.ToInt32(GV("webGarantAppId", node));
                c.WebGarantUrl = GV("webGarantUrl", node);
                c.WebGarantIc = GV("webGarantIc", node);
                c.WebGarantChannel = GV("webGarantChannel", node);

                // cookies
                c.CookieDomainName = GV("CookieDomainName", node);
                c.CookiePath = GV("CookiePath", node);
                c.PersistentCookie = GV("PersistentCookie", node) == "true";
                c.CookieExpiration = Convert.ToInt32(GV("CookieExpiration", node));
                c.CookieName = GV("CookieName", node);
                c.CookieOnlyHttps = GV("CookieOnlyHttps", node) == "true";
                c.MaxCookieAge = Convert.ToInt32(GV("MaxCookieAge", node));

                // kryptovani
                c.DesCryptoKey = ASCIIEncoding.ASCII.GetBytes(GV("DesCryptoKey", node));
                c.DesCryptoVector = ASCIIEncoding.ASCII.GetBytes(GV("DesCryptoVector", node));
                c.RijndaelPwdIterations = Convert.ToInt32(GV("RijndaelPwdIterations", node));
                c.RijndaelStrength = Convert.ToInt32(GV("RijndaelStrength", node));
                c.RijndaelVector = Encoding.ASCII.GetBytes(GV("RijndaelVector", node));
                c.RijndealPassword = GV("RijndealPassword", node);
                c.RijndaelSalt = ASCIIEncoding.UTF8.GetBytes(GV("RijndaelSalt", node));

                // PMP paths
                c.PMPLogoutUrl = GV("PMPLogoutUrl", node);
                c.PMPLoginUrl = GV("PMPLoginUrl", node);
                c.PMPMainUrl = GV("PMPMainUrl", node);

                // DB
                c.DbConnectionString = GV("DbConnectionString", node);
                c.LogConnectionString = GV("LogConnectionString", node);
                c.DbLogMinSeverity = Convert.ToInt32(GV("DbLogMinSeverity", node));

                // active directory
                c.ADAdminLogin = GV("ADAdminLogin", node);
                c.ADAdminPassword = GV("ADAdminPassword", node);
                c.ADContext = GV("ADContext", node);
                c.ADServer = GV("ADServer", node);
                c.ADUsersBranch = GV("ADUsersBranch", node);

                // povolene domeny
                c.AllowedDomains = GV("AllowedDomains", node).Split(',');
                c.OnlyHttps = GV("OnlyHttps", node) == "true";
                c.SaveLogoutRequest = GV("SaveLogoutRequest", node) == "true";

                // kryptovani
                switch (GV("CryptoProvider", node).ToUpper())
                {
                    case "DES":
                        c.CryptoProvider = CryptoProviders.DES;
                        break;
                    case "RIJNDAEL":
                        c.CryptoProvider = CryptoProviders.Rijndael;
                        break;
                }

                try
                {
                    configs.Add(c.EnvironmentType, c);
                }
                catch (Exception)
                {
                    throw new Exception("Can not add environment type to configuration, duplicate type?");
                }
            }

            return configs;
        }
    }
}
