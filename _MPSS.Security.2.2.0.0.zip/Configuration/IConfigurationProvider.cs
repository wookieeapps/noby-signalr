﻿using System;
using MPSS.Security;
using System.Collections.Generic;

namespace MPSS.Security
{
    /// <summary>
    /// Interface providera konfigurace.
    /// </summary>
    internal interface IConfigurationProvider
    {
        Dictionary<int, Configuration> Get();

        int DefaultEnvironment { get; }
    }
}
