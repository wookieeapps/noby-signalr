﻿using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Text;
using System.Web;
using System.Security.Cryptography;
using System.Security.Principal;

namespace MPSS.Security
{
    /// <summary>
    /// Trida zajistujici serializaci a deserializace objektu SecurityCookie.
    /// </summary>
    internal class SecurityCookieStringFormatter : ISecurityCookieFormatter
    {
        /// <summary>
        /// Globalni konfigurace pro soucasnou instanci tridy
        /// </summary>
        private Configuration currentConfiguration;

        public SecurityCookieStringFormatter(Configuration configuration)
        {
            this.currentConfiguration = configuration;
        }

        /// <summary>
        /// Serializace a encryptovani security cookie.
        /// </summary>
        /// <param name="identity">Instance uzivatele</param>
        /// <param name="validator">Instance cookie validatoru.</param>
        /// <returns>Vraci string zastupujici serializovany objekt SecurityCookie</returns>
        public string Encode(IIdentity identity, CookieValidator validator)
        {
            return CryptoFactory.GetCryptoProvider(this.currentConfiguration).Encrypt(SecurityCookieFactory.Get(identity, validator).ToByteArray());
        }

        /// <summary>
        /// Decryptovani a deserializace security cookie.
        /// </summary>
        /// <param name="cookieValue">String obsahujici hodnotu cookie.</param>
        /// <param name="validator">Instance validatoru security cookie.</param>
        /// <returns>Vraci instanci uzivatele. Pokud byla cookie neplatna, vraci instanci neplatneho uzivatele (IsAuthenticated=false)</returns>
        public IUser Decode(string cookieValue, CookieValidator validator)
        {
            byte[] dec;
            try
            {
                // dekryptovat retezec z cookie
                dec = CryptoFactory.GetCryptoProvider(this.currentConfiguration).Decrypt(Convert.FromBase64String(cookieValue));
            }
            catch (Exception err) // chyba pri dekodovani
            {
                // logovat mozny utok
                Log.LoggerFactory.WriteLog(err, "MPSS.Security.SecurityCookieFormatter", "Decode", 2, "SecCookie decryption: " + cookieValue, 0, this.currentConfiguration.EnvironmentType);

                return new UserBase();
            }

            // deserializace retezce
            SecurityCookie cookie;
            try
            {
                cookie = SecurityCookie.GetFromByteArray(dec);
            }
            catch (Exception err) // chyba pri deserializace
            {
                // logovat mozny utok
                Log.LoggerFactory.WriteLog(err, "MPSS.Security.SecurityCookieFormatter", "Decode", 2, "SecCookie deserialization 1: " + err.Message, 0, this.currentConfiguration.EnvironmentType);
                Log.LoggerFactory.WriteLog(err, "MPSS.Security.SecurityCookieFormatter", "Decode", 2, "SecCookie deserialization 2: " + cookieValue, 0, this.currentConfiguration.EnvironmentType);

                return new UserBase();
            }

            // pokud je cookie v poradku
            if (SecurityCookieFactory.Check(cookie, validator, this.currentConfiguration))
            {
                UserBase user = new UserBase((IdentityBase)cookie.Identity);
                return user;
            }
            else
            {
                return new UserBase();
            }
        }
    }
}
