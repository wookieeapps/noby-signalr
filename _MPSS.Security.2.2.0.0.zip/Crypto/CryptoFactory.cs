﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Vraci instanci tridy pro kryptovani podle zadanych preferenci.
    /// </summary>
    internal static class CryptoFactory
    {
        /// <summary>
        /// Vytvori instanci tridy pro kryptovani podle zadanych preferenci.
        /// </summary>
        public static ICrypto GetCryptoProvider(Configuration c)
        {
            switch (c.CryptoProvider)
            {
                case CryptoProviders.Rijndael:
                default:
                    return new RijndaelCrypto(c.EnvironmentType);
                case CryptoProviders.DES:
                    return new DesCrypto(c);
            }
        }
    }
}
