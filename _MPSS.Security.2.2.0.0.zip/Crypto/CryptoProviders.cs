﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Seznam dostupnych provideru kryptovani.
    /// </summary>
    public enum CryptoProviders
    {
        DES = 1,
        Rijndael = 2
    }
}
