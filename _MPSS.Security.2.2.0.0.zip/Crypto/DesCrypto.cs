﻿using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Collections.Generic;

namespace MPSS.Security
{
    /// <summary>
    /// Kryptovaci funkce pro symtericke sifrovani pomoci DES algoritmu.
    /// </summary>
    internal class DesCrypto : ICrypto
    {
        // nakesovany encryptor a decryptor pro vsechny prostredi
        private static Dictionary<int, ICryptoTransform> Encryptor = null;
        private static Dictionary<int, ICryptoTransform> Decryptor = null;

        // env typ pro soucasnou instanci
        private int currentEnvironmentType;

        static DesCrypto()
        {
            Encryptor = new Dictionary<int, ICryptoTransform>();
            Decryptor = new Dictionary<int, ICryptoTransform>();
        }

        public DesCrypto(Configuration config)
        {
            currentEnvironmentType = config.EnvironmentType;

            if (!Encryptor.ContainsKey(config.EnvironmentType) || !Decryptor.ContainsKey(config.EnvironmentType))
            {
#if DEBUG
                Log.LoggerFactory.WriteLog("MPSS.Security.DesCrypto", "Constructor", 5, "Create CryptoProvider", config.EnvironmentType);
#endif
                Encryptor.Add(config.EnvironmentType, CreateEncryptor(config.DesCryptoKey, config.DesCryptoVector));
                Decryptor.Add(config.EnvironmentType, CreateDecryptor(config.DesCryptoKey, config.DesCryptoVector));
            }
        }

        /// <summary>
        /// Vraci encryptor podle zadanych parametru.
        /// </summary>
        /// <param name="password">Heslo</param>
        /// <param name="vector">Vektor kryptovani</param>
        /// <returns></returns>
        public static ICryptoTransform CreateEncryptor(byte[] password, byte[] vector)
        {
            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            cryptoProvider.Key = password;
            cryptoProvider.IV = vector;
            return cryptoProvider.CreateEncryptor();
        }

        /// <summary>
        /// Vraci decryptor podle zadanych parametru.
        /// </summary>
        /// <param name="password">Heslo</param>
        /// <param name="vector">Vektor kryptovani</param>
        /// <returns></returns>
        public static ICryptoTransform CreateDecryptor(byte[] password, byte[] vector)
        {
            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            cryptoProvider.Key = password;
            cryptoProvider.IV = vector;
            return cryptoProvider.CreateDecryptor();
        }

        public static string Encrypt(string text, byte[] password, byte[] vector)
        {
            byte[] input = UTF8Encoding.UTF8.GetBytes(text);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cryptoStream = new CryptoStream(ms, CreateEncryptor(password, vector), CryptoStreamMode.Write))
                {
                    cryptoStream.Write(input, 0, text.Length);
                }
                return Convert.ToBase64String(ms.ToArray());
            }
        }

        public static string Decrypt(string text, byte[] password, byte[] vector)
        {
            try
            {
                byte[] input = Convert.FromBase64String(text);
                int r = 0;
                using (MemoryStream ms = new MemoryStream(input))
                {
                    using (CryptoStream encStream = new CryptoStream(ms, CreateDecryptor(password, vector), CryptoStreamMode.Read))
                    {
                        r = encStream.Read(input, 0, input.Length);
                    }
                }
                return UTF8Encoding.UTF8.GetString(input, 0, r);
            }
            catch (Exception)
            {
                return "";
            }
        }

        /// <summary>
        /// Kryptovani UTF8 retezce.
        /// </summary>
        /// <param name="text">Text pro zakryptovani v UTF8.</param>
        /// <returns>Kryptovany text v BASE64.</returns>
        public string Encrypt(string text)
        {
            return this.Encrypt(UTF8Encoding.UTF8.GetBytes(text));
        }

        /// <summary>
        /// Kryptovani retezce.
        /// </summary>
        /// <param name="text">Text pro zakryptovani v UTF8.</param>
        /// <returns>Kryptovany text v BASE64.</returns>
        public string Encrypt(byte[] text)
        {
            return Convert.ToBase64String(this.EncryptReturnBytes(text));
        }

        /// <summary>
        /// Kryptuje jedno bytove pole na druhe.
        /// </summary>
        /// <param name="text">Vstupni bytove pole.</param>
        /// <returns>Zakodovane pole bytu.</returns>
        public byte[] EncryptReturnBytes(byte[] text)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cryptoStream = new CryptoStream(ms, Encryptor[currentEnvironmentType], CryptoStreamMode.Write))
                {
                    cryptoStream.Write(text, 0, text.Length);
                }
                return ms.ToArray();
            }
        }

        /// <summary>
        /// Dekryptovani vstupniho pole bytu.
        /// </summary>
        /// <param name="text">Vstupni zakryptovane pole.</param>
        /// <returns>Dekryptovane pole bytu.</returns>
        public byte[] Decrypt(byte[] text)
        {
            using (MemoryStream ms = new MemoryStream(text))
            {
                using (CryptoStream encStream = new CryptoStream(ms, Decryptor[currentEnvironmentType], CryptoStreamMode.Read))
                {
                    encStream.Read(text, 0, text.Length);
                }
            }
            return text;
        }

        /// <summary>
        /// Dekryptuje vstupni pole a vraci retezec v UTF8.
        /// </summary>
        /// <param name="text">BASE64 zakryptovany retezec.</param>
        /// <returns>Dekryptovany retezec v UTF8.</returns>
        public string Decrypt(string text)
        {
            return UTF8Encoding.UTF8.GetString(Decrypt(Convert.FromBase64String(text)));
        }
    }
}
