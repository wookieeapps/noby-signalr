﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Druh loginu - zda vyzaduje ci ne icp
    /// </summary>
    public enum AdLoginTypes
    {
        WrongCPM = 0,
        RequiresOnlyCPM = 1,
        RequiresBoth = 2
    }
}
