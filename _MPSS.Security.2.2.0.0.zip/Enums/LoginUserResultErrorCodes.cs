﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Chybove stavy zobrazovane uzivateli
    /// </summary>
    public enum LoginUserResultErrorCodes
    {
        None = 0,
        NoAccess = 1,
        NoPassword = 100,
        NoCPM = 200,
        CPMWrongChars = 300,
        CPMWrongLength = 400,
        LoginNotAllowed = 500,
        NoICP = 600,
        ICPWrongChars = 700,
        ICPWrongLength = 800,
        IPisNotKB = 900,
        ADUserNotFound = 10,
        ADUserDisabled = 20,
        ADUserLocked = 30,
        ADExpiredPwd = 40,
        ADBadLogin = 50
    }
}
