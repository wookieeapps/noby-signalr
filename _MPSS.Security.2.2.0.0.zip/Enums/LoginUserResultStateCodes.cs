﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Stav uctu zobrazovany uzivateli
    /// </summary>
    public enum LoginUserResultStateCodes
    {
        None = 0,
        OnlyCPM = 1,
        Found = 2,
        NotDisabled = 3,
        NotLocked = 4,
        PwdNeverExpires = 5,
        CanNotChangePwd = 6,
        FirstLogin = 7,
        CurrentPwd = 8,
        ExpiredPwd = 9
    }
}
