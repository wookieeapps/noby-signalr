﻿using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using MPSS.Utils;

namespace MPSS.Security
{
    public class ExternalApplicationHandler
    {
        // nastaveny enkryptoru a dekryptoru pro komunikaci
        private static string Password = "heslo";
        private static int PwdIterations = 5;
        private static int Strength = 256;
        private static byte[] Salt = Encoding.ASCII.GetBytes("testovaci aplikace pro externi prihlasovani");
        private static byte[] Vector = Encoding.ASCII.GetBytes("@1B2c3D4e5F6g7H8");

        /// <summary>
        /// Druh app prostredi
        /// </summary>
        private int EnvironmentType;

        /// <summary>
        /// Kopie nekryptovaneho retezce
        /// </summary>
        public string RequestEnvelopeBeforeEncrypting;

        /// <summary>
        /// Vychozi cas v sekundach pro vyprseni pozadavku autentikaci.
        /// Hodnota se prida k soucasnemu casu na serveru MPSS a odesle na vzdaleny server. Ten porovna svuj cas s casem dodanym v pozdavku a pripadne nepovoli autentikaci.
        /// </summary>
        private static int DefaultRequestTimeout = 120;

        public ExternalApplicationHandler(int environmentType)
        {
            this.EnvironmentType = environmentType;
        }

        /// <summary>
        /// Vrati vstupni retezec zakodovany a pripraveny pro prenos k externimu partnerovi.
        /// </summary>
        /// <param name="user">Instance prihlaseneho uzivatele.</param>
        /// <param name="applicationId">ID aplikace.</param>
        /// <param name="applicationPermissions">Soucet prav pro danou aplikaci.</param>
        /// <param name="url">URL volane aplikace.</param>
        /// <returns>Zakodovany objekt pripraveny pro prenos na web treti strany.</returns>
        public string CreateRequestEnvelope(IUser user, int applicationId, int applicationPermissions, string url)
        {
            // vytvorit guid pozadavku
            string guid = Guid.NewGuid().ToString();

            // nahodny retezec vlozeny do tela pozadavku
            string[] salt = Guid.NewGuid().ToString().Split('-');

            // zapsat pozadavek do databaze
            int dbId = DbRepository.ExtAppAuthenticationRequest(user.ID, applicationId, guid);

            // vytvoreni stringu, ktery bude predan na externi web
            Uri uri = new Uri(url);
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}^{1}^", user.Name, salt[0]);
            sb.AppendFormat("{0}^{1}^", user.ID, salt[1]);
            sb.AppendFormat("{0}^", user.CPM);
            sb.AppendFormat("{0}^", user.ICP);
            sb.AppendFormat("{0}^{1}^", applicationId, salt[2]);
            sb.AppendFormat("{0}^{1}^", applicationPermissions, salt[3]);
            sb.AppendFormat("{0}^", DateTime.Now.AddSeconds(DefaultRequestTimeout).ToString(System.Globalization.CultureInfo.InvariantCulture));
            sb.AppendFormat("{0}^{1}^", guid, dbId);
            sb.AppendFormat("{0}", uri.Authority);

            RequestEnvelopeBeforeEncrypting = sb.ToString();

            // vytvorit enkryptor
            ICryptoTransform encryptor = RijndaelCrypto.CreateEncryptor(Password, PwdIterations, Strength, Vector, Salt);
            // kryptovani
            RijndaelCrypto crypto = new RijndaelCrypto(this.EnvironmentType);
            return crypto.Encrypt(sb.ToString(), encryptor);
        }

        /// <summary>
        /// Proveri pravost pozadavku a vraci zaheshovanou odpoved pro vzdaleny web.
        /// </summary>
        /// <param name="request">Bytove pole s obsahem pozadavku.</param>
        /// <param name="remoteHost">Nazev server ze ktereho byl prijat pozadavek.</param>
        /// <returns>Zakryptovanou odpoved na validacni pozadavek.</returns>
        public string CheckValidationRequest(byte[] request)
        {
            ICryptoTransform decryptor = RijndaelCrypto.CreateDecryptor(Password, PwdIterations, Strength, Vector, Salt);
            // dekryptovani
            RijndaelCrypto crypto = new RijndaelCrypto(this.EnvironmentType);
            ValidationRequest valrequest = new ValidationRequest(UTF8Encoding.UTF8.GetString(crypto.Decrypt(request, decryptor)));

            string status;
            // informace z db
            ValidationCheck check = DbRepository.ExtAppAuthenticationCheck(valrequest.Id);
#if DEBUG
            // kvuli testovani
            if (check.Guid == "TEST-DB-REPOSITORY")
                check.Guid = valrequest.OldRequestGuid;
#endif

            // pokud nesouhlasi guid nebo vyprsel cas
            string strError = "";
            if (valrequest.OldRequestGuid != check.Guid)
                strError += " GUID;";
            if (check.RequestTime.AddSeconds(DefaultRequestTimeout) < DateTime.Now)
                strError += " time validity;";
            if (strError != "")
            {
                status = string.Format("failed [{0}]", strError);
            }
            else
            {
                status = "success";
            }

            // nahodny retezec vlozeny do tela pozadavku
            string[] salt = Guid.NewGuid().ToString().Split('-');

            // vytvoreni odpovedi
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}^{1}^", status, salt[0]);
            sb.AppendFormat("{0}^{1}^", valrequest.ApplicationId, salt[1]);
            sb.AppendFormat("{0}^{1}^", DateTime.Now.AddSeconds(DefaultRequestTimeout).ToString(System.Globalization.CultureInfo.InvariantCulture), salt[2]);
            sb.AppendFormat("{0}^{1}", valrequest.NewRequestGuid, salt[3]);

            // zakryptovat odpoved
            ICryptoTransform encryptor = RijndaelCrypto.CreateEncryptor(Password, PwdIterations, Strength, Vector, Salt);
            return crypto.Encrypt(sb.ToString(), encryptor);
        }

        /// <summary>
        /// Objekt s informacemi o verifikaci pozadavku z databaze.
        /// </summary>
        internal class ValidationCheck
        {
            /// <summary>
            /// Cas prvotniho pozadavku.
            /// </summary>
            public DateTime RequestTime;

            /// <summary>
            /// Prvotni guid.
            /// </summary>
            public string Guid;
        }

        /// <summary>
        /// Objekt s informacemi o validacnim pozadavku ze vzdaleneho webu.
        /// </summary>
        private class ValidationRequest
        {
            private const int requestIdx_AppId      = 0;
            private const int requestIdx_UserId     = 2;
            private const int requestIdx_OldGuid    = 4;
            private const int requestIdx_NewGuid    = 6;
            private const int requestIdx_Id         = 8;
            private const int requestIdx_Time       = 9;

            /// <summary>
            /// Guid prvotniho pozadavku.
            /// </summary>
            public string OldRequestGuid;

            /// <summary>
            /// Guid verifikace pozadavku.
            /// </summary>
            public string NewRequestGuid;

            public int ApplicationId;
            public int UserId;

            /// <summary>
            /// Nazev serveru na kterem ma byt umistena externi aplikace.
            /// </summary>
            //public string Host;

            /// <summary>
            /// Cas vytvoreni pozadavku na validaci.
            /// </summary>
            public DateTime Time;

            /// <summary>
            /// Id pozadavku.
            /// </summary>
            public int Id;

            public ValidationRequest(string request)
            {
                string[] arr = request.Split('^');
                this.OldRequestGuid = arr[requestIdx_OldGuid];
                this.NewRequestGuid = arr[requestIdx_NewGuid];
                this.ApplicationId = Convert.ToInt32(arr[requestIdx_AppId]);
                this.UserId = Convert.ToInt32(arr[requestIdx_UserId]);
                this.Id = Convert.ToInt32(arr[requestIdx_Id]);
                this.Time = Convert.ToDateTime(arr[requestIdx_Time], System.Globalization.CultureInfo.InvariantCulture);
            }
        }
    }
}
