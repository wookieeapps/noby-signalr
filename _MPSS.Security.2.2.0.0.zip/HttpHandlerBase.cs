﻿using System;
using System.Web;
using System.Configuration;
using System.Runtime.InteropServices;

namespace MPSS.Security
{
    /// <summary>
    /// <para>Vychozi implementace HttpHandleru (pouzit pri dedeni misto Web.IHttpHandler).</para>
    /// <para>Zajistuje autentizaci uzivatele, nastaveni UI Culture, content-type, charset.</para>
    /// <para>Zpristupnuje instanci uzivatele ve vlastnosti context.User (jako IPrincipal s moznosti pretypovat na UserBase).</para>
    /// <para>Pro ziskani modu pro daneho uzivatele a aplikaci je nutne nastavit spravne ApplicationId.</para>
    /// <para>Vstupni bod pro pouzivani dedeneho HttpHandleru je prepsana metoda ContinueRequest.</para>
    /// <para>Autentizace: pokud se nepodari uzivatele prihlasit (nema platnou security cookie), je provadeni pozadavku ukonceno vypsanim "USER AUTHENTICATION FAILED".</para>
    /// <para>Toto chovani se da ovlivnit atributem PageAuthentication.</para>
    /// </summary>
    [ComVisible(false)]
    public class HttpHandlerBase : System.Web.IHttpHandler
    {
        /// <summary>
        /// true pokud je nutna autentizace uzivatele
        /// </summary>
        protected bool RequiresAuthentication
        {
            get { return this._RequiresAuthentication; }
        }
        private bool _RequiresAuthentication;

        /// <summary>
        /// true pokud musi mit uzivatel prava pro soucasnou aplikaci.
        /// </summary>
        protected bool RequiresPermission
        {
            get { return this._RequiresPermission; }
        }
        private bool _RequiresPermission;

        /// <summary>
        /// ID aplikace.
        /// </summary>
        protected int ApplicationId
        {
            get { return this._ApplicationId; }
        }
        private int _ApplicationId;

        /// <summary>
        /// Typ aplikacniho prostredi
        /// </summary>
        protected int EnvironmentType
        {
            get { return _EnvironmentType; }
        }
        private int _EnvironmentType;

        /// <summary>
        /// Konstruktor.
        /// </summary>
        public HttpHandlerBase()
        {
            // vychozi nastaveni
            this._ApplicationId = 0;
            this._EnvironmentType = 0;
            this._RequiresAuthentication = true;
        }

        /// <summary>
        /// Konstruktor s moznosti zadani application id.
        /// </summary>
        /// <param name="applicationId"></param>
        public HttpHandlerBase(int applicationId) : this()
        {
            this._ApplicationId = applicationId;
        }

        /// <summary>
        /// Nutne zdedit z IHttpHandler.
        /// </summary>
        public virtual bool IsReusable
        {
            get { return true; }
        }

        /// <summary>
        /// Instance prihlaseneho uzivatele
        /// </summary>
        public IUser User
        {
            get
            {
                return _User;
            }
        }
        private IUser _User;

        /// <summary>
        /// Aktualni instance tridy Portal
        /// </summary>
        public Portal CurrentPortal
        {
            get;
            private set;
        }

        /// <summary>
        /// Dedi z IHttpHandler - vstupni bod handleru.
        /// </summary>
        /// <param name="context"></param>
        public virtual void ProcessRequest(HttpContext context)
        {
            // nastaveni page auth ve web.config
            if (ConfigurationManager.AppSettings[PageBase.ConfigRequiresAuthentication] != null)
            {
                this._RequiresAuthentication = ConfigurationManager.AppSettings[PageBase.ConfigRequiresAuthentication] != "false";
            }
            

            #region ziskani atributu tridy
            // projit vsechny custom attributy pridane k soucasne instanci tridy
            foreach (Attribute att in this.GetType().GetCustomAttributes(true))
            {
                Type t = att.GetType();

                // nastaveni autentikace stranky
                if (t == typeof(PageAuthenticationAttribute))
                {
                    this._RequiresAuthentication = ((PageAuthenticationAttribute)att).RequiresAuthentication;
                }
                // nastaveni povinosti prav na aplikaci
                else if (t == typeof(PageAuthenticationCheckAppPermissionsAttribute))
                {
                    this._RequiresPermission = ((PageAuthenticationCheckAppPermissionsAttribute)att).RequiresPermission;
                }
                // nastaveni application id
                else if (t == typeof(ApplicationIdAttribute) && this.ApplicationId == 0)
                {
                    this._ApplicationId = ((ApplicationIdAttribute)att).ApplicationId;
                }
                // nastaveni evn type
                else if (t == typeof(EnvironmentTypeAttribute))
                {
                    this._EnvironmentType = ((EnvironmentTypeAttribute)att).EnvironmentType;
                }
            }
            #endregion

            // pokud neni nastaveno application id atributem
            if (this.ApplicationId == 0)
            {
                if (ConfigurationManager.AppSettings[PageBase.ConfigApplicationId] != null)
                {
                    this._ApplicationId = Convert.ToInt32(ConfigurationManager.AppSettings[PageBase.ConfigApplicationId]);
                }
            }
            // nastaveni environment type
            if (this.EnvironmentType == 0)
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[PageBase.ConfigEnvironmentType]))
                {
                    this._EnvironmentType = Convert.ToInt32(ConfigurationManager.AppSettings[PageBase.ConfigEnvironmentType]);
                }
            }

            // instance konfigurace
            Configuration config = ConfigurationFactory.GetConfiguration(this.EnvironmentType);
            // instance Portal tridy
            CurrentPortal = new Portal(config);

            // autentifikace
            this._User = CurrentPortal.GetCurrentUser(this._ApplicationId, !this.RequiresAuthentication);
            context.User = this._User;

            // pokud neni uzivatel autentifikovan a je vyzadovana autentifikace
            // presmerovat na login a vratit v querystringu tuhle stranku
            if ((!context.User.Identity.IsAuthenticated || (this._RequiresPermission && this._User.Permissions == 0)) && this._RequiresAuthentication)
            {
                context.Response.Write("USER AUTHENTICATION FAILED");
                return;
            }

            // nastavit culture
            System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo(config.DefaultCulture);
            System.Threading.Thread.CurrentThread.CurrentCulture = ci;
            System.Threading.Thread.CurrentThread.CurrentUICulture = ci;

            // nastaveni hlavicky / vycistit response
            context.Response.Clear();
            context.Response.Charset = "utf-8";
            context.Response.ContentEncoding = System.Text.Encoding.UTF8;
            context.Response.ContentType = "text/plain";

            // zavolat developerem prepsanou metodu
            this.ContinueRequest(context);
        }

        public virtual void ContinueRequest(HttpContext context)
        {
            // your code here (override method)
        }
    }
}
