﻿using System;
using System.Data;
using System.Data.SqlClient;
using MPSS.Utils;
using System.Collections.Generic;
using System.Diagnostics;

namespace MPSS.Security.Log
{
    /// <summary>
    /// Logovani udalosti do MSSQL databaze.
    /// </summary>
    internal class DbLogger : ILogger
    {
        private Queue<LogItem> Items;

        /// <summary>
        /// Konstruktor
        /// </summary>
        /// <param name="connectionString">Connection string na databazi, kam se maji logovat udalosti</param>
        public DbLogger()
        {
            this.Items = new Queue<LogItem>();
        }

        /// <summary>
        /// Zapsani udalosti do logu.
        /// </summary>
        /// <param name="thrownError">Vyvolana vyjimka nebo null.</param>
        /// <param name="severity">Vaznost udalosti.</param>
        /// <param name="exceptionDetails">Detaily volani.</param>
        /// <param name="customMessage">Informativni zprava.</param>
        public void LogEvent(LogItem item, Configuration config)
        {
            CData data = new CData(config.LogConnectionString);
            data.AddValue("ExceptionMessage", item.ExceptionMessage);
            data.AddValue("BaseExceptionMessage", item.BaseExceptionMessage);
            data.AddValue("ApplicationMessage", item.ApplicationMessage);
            data.AddValue("Details", item.Details);
            data.AddValue("Severity", item.Severity);
            data.AddValue("InsertTime", item.InsertTime);
            data.AddValue("EnvironmentType", config.EnvironmentType);
            data.AddValue("Server", config.Server);
            if (!string.IsNullOrEmpty(item.IP))
                data.AddValue("IP", item.IP);
            if (item.ApplicationId > 0)
                data.AddValue("ApplicationId", item.ApplicationId);
            data.ExecuteNonQuery(QueryType.Insert, "PMP.DbLogger");
        }
    }
}
