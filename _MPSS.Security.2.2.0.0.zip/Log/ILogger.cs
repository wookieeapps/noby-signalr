﻿using System;

namespace MPSS.Security.Log
{
    /// <summary>
    /// <para>Rozhrani pro providery logovani udalosti.</para>
    /// <para>severity = 0-nejzavaznejsi, 5=nejlehci</para>
    /// </summary>
    internal interface ILogger
    {
        /// <summary>
        /// Zapsat udalost do logu.
        /// </summary>
        void LogEvent(LogItem item, Configuration config);
    }
}
