﻿using System;

namespace MPSS.Security.Log
{
    internal class LogItem
    {
        public DateTime InsertTime { get; set; }
        public int Severity { get; set; }
        public string Details { get; set; }
        public string ApplicationMessage { get; set; }
        public string ExceptionMessage { get; set; }
        public string BaseExceptionMessage { get; set; }
        public string IP { get; set; }
        public int ApplicationId { get; set; }
    }
}
