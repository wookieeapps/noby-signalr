﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;

namespace MPSS.Security.Log
{
    /// <summary>
    /// Trida zajistujici logovani udalosti do zaregistrovanych provideru logovani.
    /// </summary>
    internal class LoggerFactory
    {
        /// <summary>
        /// Kolekce zaregistrovanych provideru logovani.
        /// </summary>
        private static List<ILogger> _Loggers;

        internal static int Server;

        static LoggerFactory()
        {
            _Loggers = new List<ILogger>();

            Configuration c = ConfigurationFactory.GetConfiguration();
            Server = c.Server;
        }

        /// <summary>
        /// Zapisuje udalost do vsech zaregistrovanych provideru logovani.
        /// </summary>
        /// <param name="thrownError">Instance vyjimky, pokud se jedna jen o zpravu tak je null.</param>
        /// <param name="module">Modul ve kterem nastala udalost.</param>
        /// <param name="method">Metoda ve ktere nastala udalost.</param>
        /// <param name="severity">Zavaznost chyby (1-5)</param>
        public static void WriteLog(Exception thrownError, string module, string method, int severity, int environmentType)
        {
            WriteLog(thrownError, module, method, severity, "", 0, environmentType);
        }

        /// <summary>
        /// Zapisuje udalost do vsech zaregistrovanych provideru logovani.
        /// </summary>
        /// <param name="module">Modul ve kterem nastala udalost.</param>
        /// <param name="method">Metoda ve ktere nastala udalost.</param>
        /// <param name="customMessage">Zprava k zapsani.</param>
        /// <param name="severity">Zavaznost zpravy (1-5).</param>
        public static void WriteLog(string module, string method, int severity, string customMessage, int environmentType)
        {
            WriteLog(null, module, method, severity, customMessage, 0, environmentType);
        }

        /// <summary>
        /// Zapisuje udalost do vsech zaregistrovanych provideru logovani.
        /// </summary>
        /// <param name="thrownError">Instance vyjimky, pokud se jedna jen o zpravu tak je null.</param>
        /// <param name="module">Modul ve kterem nastala udalost.</param>
        /// <param name="method">Metoda ve ktere nastala udalost.</param>
        /// <param name="severity">Zavaznost udalosti (1-5)</param>
        /// <param name="customMessage">Dalsi informace o udalosti.</param>
        public static void WriteLog(Exception thrownError, string module, string method, int severity, string customMessage, int applicationId = 0, int environmentType = 0)
        {
            Configuration config = ConfigurationFactory.GetConfiguration(environmentType);

            foreach (ILogger logger in _Loggers)
            {
                if (config.DbLogMinSeverity >= severity)
                {
                    LogItem item = new LogItem();

                    // verze DLL
                    Assembly assembly = Assembly.GetExecutingAssembly();
                    FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(assembly.Location);

                    if (thrownError != null)
                    {
                        if (thrownError.GetBaseException() != null)
                            item.BaseExceptionMessage = thrownError.GetBaseException().Message;
                    }
                    item.ApplicationMessage = customMessage;
                    item.Details = string.Format("v: {2}; Module={0}; Method={1};", module, method, fvi.FileVersion);
                    item.InsertTime = DateTime.Now;
                    item.Severity = severity;
                    item.ApplicationId = applicationId;

                    System.Web.HttpContext context = System.Web.HttpContext.Current;
                    if (context != null)
                    {
                        if (context.Request != null)
                        {
                            item.IP = context.Request.UserHostAddress;
                        }
                    }

                    logger.LogEvent(item, config);
                }
            }
        }

        /// <summary>
        /// Pridat dalsi provider logovani
        /// </summary>
        /// <param name="logger"></param>
        public static void AddLogger(ILogger logger)
        {
            _Loggers.Add(logger);
        }
    }
}
