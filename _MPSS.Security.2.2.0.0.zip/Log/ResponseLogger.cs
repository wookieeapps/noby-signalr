﻿using System;
using System.Web;

namespace MPSS.Security.Log
{
    /// <summary>
    /// Logovani udalosti do MSSQL databaze.
    /// </summary>
    internal class ResponseLogger : ILogger
    {
        /// <summary>
        /// Zapsani udalosti do logu.
        /// </summary>
        public void LogEvent(LogItem item, Configuration config)
        {
            HttpResponse response = System.Web.HttpContext.Current.Response;

            response.Write("<p><hr/>");
            response.Write(string.Format("ExceptionMessage={0}<br/>", item.ExceptionMessage));
            response.Write(string.Format("BaseExceptionMessage={0}<br/>", item.BaseExceptionMessage));
            response.Write(string.Format("ApplicationMessage={0}<br/>", item.ApplicationMessage));
            response.Write(string.Format("Details={0}<br/>", item.Details));
            response.Write(string.Format("Severity={0}<br/>", item.Severity));
            response.Write(string.Format("InsertTime={0}<br/>", item.InsertTime));
            response.Write("</p>");
        }
    }
}
