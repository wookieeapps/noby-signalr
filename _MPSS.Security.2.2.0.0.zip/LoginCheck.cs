﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.DirectoryServices;

namespace MPSS.Security
{
    /// <summary>
    /// Kontroly pri logovani uzivatele. Prvni kontrola probiha pred pokusem o autentikaci v AD - kontroluje se tvar CPM, ICP a hesla. Druha kontrola je proti AD - kontroluje se nastaveni uctu v AD, spravnost hesla atd.
    /// </summary>
    internal class LoginCheck
    {
        #region kontrola druhu loginu
        /// <summary>
        /// Vraci druh loginu - povinnost uvest icp
        /// </summary>
        /// <param name="cpm">CPM uzivatele</param>
        /// <returns>Vraci druh loginu (je potreba ICP / neni potreba ICP / neplatny login)</returns>
        public static AdLoginTypes GetAdLoginType(string cpm)
        {
            // login vyzadujici icp - agentury
            Regex regLogin2 = new Regex("^(100|110|2|3|4|882)[0-9a-zA-Z]*$");
            if (regLogin2.IsMatch(cpm))
            {
                return AdLoginTypes.RequiresBoth;
            }
            else
            {
                // login bez icp (zamestnance, norm. prodejce)
                Regex regLogin1 = new Regex("^(990|991|998|999|901|902|903|904|905|500|510|98)[0-9a-zA-Z]*$");
                if (regLogin1.IsMatch(cpm))
                {
                    return AdLoginTypes.RequiresOnlyCPM;
                }
                else
                {
                    return AdLoginTypes.WrongCPM;
                }
            }
        }
        #endregion

        #region PreADCheck
        /// <summary>
        /// Kontrola validity vlozeneho cpm a icp - spousti se pred volanim AD.
        /// V pripade, ze se jedna o cpm KB, kontrola host IP adresy.
        /// </summary>
        /// <param name="result">Instance vysledku logovani.</param>
        /// <param name="cpm">CPM prihlasovaneho uzivatele.</param>
        /// <param name="icp">ICP prihlasovaneho uzivatele.</param>
        /// <returns>Login uzivatel do AD (pokud je cpm a icp ve spravnem tvaru).</returns>
        public static string PreADCheck(ref LoginUserResult result, string cpm, string icp, string password, Configuration config)
        {
            // kontrol vyplneni cpm a hesla
            if (cpm.Length == 0)
            {
                result.ErrorCode = LoginUserResultErrorCodes.NoCPM;
                return "";
            }
            if (password.Length == 0)
            {
                result.ErrorCode = LoginUserResultErrorCodes.NoPassword;
                return "";
            }

            // zakladni kontrola na tvar cpm - nesmi se kontrolovat delka cisla, to je soucasti dalsi kontroly
            Regex regCpm = new Regex("^[0-9]*[a-z]{0,1}$");
            if (!regCpm.IsMatch(cpm))
            {
                result.ErrorCode = LoginUserResultErrorCodes.CPMWrongChars;
            }
            else
            {
                // kontrola delky cpm (7=zamestnanec, 8=cpm)
                if (cpm.Length != 8 && cpm.Length != 7)
                {
                    result.ErrorCode = LoginUserResultErrorCodes.CPMWrongLength;
                }
                else
                {
                    // zjistit zda je do loginu potreba pridat icp
                    switch (GetAdLoginType(cpm))
                    {
                        // pokud se jedna o login vyzadujici icp
                        case AdLoginTypes.RequiresBoth:
                            // pokud je icp prazdne
                            if (string.IsNullOrEmpty(icp))
                            {
                                result.ErrorCode = LoginUserResultErrorCodes.NoICP;
                            }
                            else
                            {
                                // zakladni kontrola tvaru icp - nekontroluje se delka icp, ta se kontroluje dale
                                Regex regIcp = new Regex("^[0-9]*$");
                                if (!regIcp.IsMatch(icp)) // icp nema vyhovujici tvar
                                {
                                    result.ErrorCode = LoginUserResultErrorCodes.ICPWrongChars;
                                }
                                else if (icp.Length != 9) // icp nema spravnou delku
                                {
                                    result.ErrorCode = LoginUserResultErrorCodes.ICPWrongLength;
                                }
                                else // cpm + icp vypadaji v poradku, vytvor login do AD
                                {
                                    // kontrola zda se jedna o cpm KB, pokud ano - kontroluj IP adresu
                                    if (cpm.StartsWith("1"))
                                    {
                                        IDbRepository repositoryDb = RepositoryFactory.GetDbRepository(config);
                                        if (repositoryDb.IsKBIP(System.Web.HttpContext.Current.Request.UserHostAddress))
                                            return string.Format("{0}_{1}", cpm, icp);
                                        else
                                            result.ErrorCode = LoginUserResultErrorCodes.IPisNotKB;
                                    }
                                    else // pokud neni KB
                                        return string.Format("{0}_{1}", cpm, icp);
                                }
                            }
                            break;

                        // jedna se o cpm nevyzadujici icp a vypada ze je ve spravnem tvaru
                        case AdLoginTypes.RequiresOnlyCPM:
                            result.AccountState = LoginUserResultStateCodes.OnlyCPM;
                            return cpm;

                        // pokud cpm nevyhovuje podminkam regLogin1 ani regLogin2
                        case AdLoginTypes.WrongCPM:
                            result.ErrorCode = LoginUserResultErrorCodes.LoginNotAllowed;
                            break;
                    }
                }
            }

            // nepovedlo se validovat vstupy od uzivatele (cpm a icp)
            return "";
        }
        #endregion

        #region ADCheck
        /// <summary>
        /// Kontrola uzivatele v AD - kontrola disabled, locked account, expired password...
        /// </summary>
        /// <param name="result">Instance vysledku logovani.</param>
        /// <param name="dsResult">Nalezeny uzivatel.</param>
        public static bool ADCheck(ref LoginUserResult result, SearchResult dsResult, bool isAuthenticated, int environmentType)
        {
            // userAccountControl - nastaveni uctu v AD
            int userAccountControl = 0;
            if (dsResult.Properties.Contains("userAccountControl"))
                userAccountControl = Convert.ToInt32(dsResult.Properties["userAccountControl"][0]);

#if DEBUG
Log.LoggerFactory.WriteLog("MPSS.Security.LoginCheck", "ADCheck", 5, string.Format("userAccountControl={0}", userAccountControl), environmentType);
#endif

            // kontrola, zda uzivatel nebyl disabled
            if ((userAccountControl & AdRepository.ACCOUNTDISABLE) > 0) // je disabled
            {
                result.ErrorCode = LoginUserResultErrorCodes.ADUserDisabled;
            }
            else
            {
                // zjisteni, zda uzivatel nema zamknuty ucet
                // neni-li nastavena vlastnost lockoutTime, predpoklada se odemceny ucet (lockoutTime = 0)
                long lockoutTime = 0;
                if (dsResult.Properties.Contains("lockoutTime"))
                    lockoutTime = Convert.ToInt64(dsResult.Properties["lockoutTime"][0]);

#if DEBUG
Log.LoggerFactory.WriteLog("MPSS.Security.LoginCheck", "ADCheck", 5, string.Format("lockoutTime={0};", lockoutTime), environmentType);
#endif

                if (lockoutTime != 0) // pokud je ucet zamceny
                {
                    result.AccountState = LoginUserResultStateCodes.NotDisabled;
                    result.ErrorCode = LoginUserResultErrorCodes.ADUserLocked;
                }
                else // pokud je ucet odemceny
                {
                    result.AccountState = LoginUserResultStateCodes.NotLocked;

                    // kontrola vyprseni hesla
                    result.PasswordNeverExpires = ((userAccountControl & AdRepository.DONT_EXPIRE_PASSWORD) > 0);
                    if (result.PasswordNeverExpires) // pokud heslo nemuze vyprset
                    {
                        result.AccountState = LoginUserResultStateCodes.PwdNeverExpires;
                    }
                    else // pokud muze heslo expirovat, zkontroluj dobu
                    {
                        #region zjisteni informaci o heslu (muze menit, vyprseni...)
                        // muze uzivatel menit heslo?
                        result.CanNotChangePassword = ((userAccountControl & AdRepository.PASSWD_CANT_CHANGE) > 0);

                        // datum a cas posledni zmeny hesla
                        DateTime lastPwdChange;
                        if (dsResult.Properties.Contains("pwdLastSet"))
                            lastPwdChange = AdRepository.GetDateFromTicks((long)dsResult.Properties["pwdLastSet"][0]);
                        else
                            lastPwdChange = new DateTime(1901, 1, 1);

                        // nastaveni informace o expiraci hesla
                        result.PasswordExpiration = lastPwdChange.AddDays(RepositoryFactory.MaxPasswordAge);
                        #endregion

#if DEBUG
Log.LoggerFactory.WriteLog("MPSS.Security.LoginCheck", "ADCheck", 5, string.Format("lastPwdChange={0}; PwdExp: {1};", lastPwdChange, result.PasswordExpiration), environmentType);
#endif
                        
                        // uzivatel muze menit heslo
                        if (!result.CanNotChangePassword)
                        {
                            #region uzivatel muze menit heslo
                            // jedna se o prvni prihlaseni. Uzivatel musi zmenit heslo.
                            if (result.PasswordExpiration < new DateTime(1900, 1, 1))
                            {
                                result.AccountState = LoginUserResultStateCodes.FirstLogin;
                                result.MandatoryToChangePassword = true;
                            }
                            // heslo vyexpirovalo, nutne zmenit
                            if (result.PasswordExpiration <= DateTime.Now)
                            {
                                result.AccountState = LoginUserResultStateCodes.ExpiredPwd;
                                result.MandatoryToChangePassword = true;
                            }
                            else // heslo je platne
                            {
                                result.AccountState = LoginUserResultStateCodes.CurrentPwd;
                            }
                            #endregion
                        }
                        else // uzivatel nemuze menit heslo
                        {
                            #region uzivatel nemuze menit heslo
                            if (result.PasswordExpiration <= DateTime.Now)
                            {
                                result.ErrorCode = LoginUserResultErrorCodes.ADExpiredPwd;
                                result.AccountState = LoginUserResultStateCodes.NotLocked;
                            }
                            else
                            {
                                result.AccountState = LoginUserResultStateCodes.CanNotChangePwd;
                            }
                            #endregion
                        }
                    }

                    // pokud je heslo platne stale, nebo uzivatel ma pravo na jeho zmenu nebo jeste neni vyexpirovane
                    if (result.ErrorCode == LoginUserResultErrorCodes.None)
                    {
                        // overeni hesla vuci AD
                        if (isAuthenticated || result.AccountState == LoginUserResultStateCodes.ExpiredPwd || result.AccountState == LoginUserResultStateCodes.FirstLogin)
                        {
                            return true;
                        }
                        else
                        {
                            result.ErrorCode = LoginUserResultErrorCodes.ADBadLogin;
                        }
                    } // jinak pokud je heslo vyexpirovane a uzivatel nema pravo na jeho zmenu
                }
            }

            // overeni uctu nedopadlo dobre
            return false;
        }
        #endregion
    }
}
