﻿using System;
using System.Web;

namespace MPSS.Security
{
    /// <summary>
    /// Zakladni trida pro dedeni pro vsechny MasterPages.
    /// </summary>
    public class MasterPageBase : System.Web.UI.MasterPage
    {
        public IUser User
        {
            get
            {
                return ((PageBase)this.Page).User;
            }
        }

        public MPSS.Security.Portal CurrentPortal
        {
            get
            {
                return ((PageBase)this.Page).CurrentPortal;
            }
        }
    }
}
