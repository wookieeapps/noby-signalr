﻿using System;
using System.Runtime.InteropServices;

namespace MPSS.Security
{
    /// <summary>
    /// Vysledek volani metody pro zmenu hesla.
    /// </summary>
    [ComVisible(false)]
    public class ChangePasswordResult
    {
        /// <summary>
        /// true pokud se povedlo heslo zmenit.
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// Chybova zprava, pokud se nepovedlo heslo zmenit.
        /// </summary>
        public string ErrorMessage { get; set; }

        public ChangePasswordResult()
        {
            this.Success = false;
        }
    }
}
