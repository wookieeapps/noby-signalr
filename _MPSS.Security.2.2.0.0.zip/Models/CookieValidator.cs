﻿using System;
using System.Web;

namespace MPSS.Security
{
    /// <summary>
    /// Kontajner pro informace potrebne pro validaci cookie.
    /// </summary>
    internal class CookieValidator
    {
        /// <summary>
        /// IP adresa klienta.
        /// </summary>
        public string IP;

        /// <summary>
        /// Informace o prohlizeci klienta.
        /// </summary>
        public string UserAgent;

        public CookieValidator(HttpContext context)
        {
            this.IP = context.Request.UserHostAddress;
            this.UserAgent = context.Request.UserAgent;
        }

        public CookieValidator()
        {
        }
    }
}
