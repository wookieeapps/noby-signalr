﻿using System;

namespace MPSS.Security
{
    public class GetUserPermissionsResult
    {
        public int Permissions { get; set; }
        public int Impersonate { get; set; }

        public GetUserPermissionsResult(int permissions, int impersonate)
        {
            this.Permissions = permissions;
            this.Impersonate = impersonate;
        }
    }
}
