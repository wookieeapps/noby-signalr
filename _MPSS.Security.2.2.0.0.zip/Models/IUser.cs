﻿using System;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace MPSS.Security
{
    /// <summary>
    /// Instance kontajneru s informacemi o prihlasenem uzivateli.
    /// </summary>
    [ComVisible(false)]
    public interface IUser : IPrincipal
    {
        /// <summary>
        /// CPM uzivatele
        /// </summary>
        [DispId(1)]
        string CPM { get; }

        /// <summary>
        /// ICP uzivatele
        /// </summary>
        [DispId(2)]
        string ICP { get; }

        /// <summary>
        /// Jmeno a prijmeni uzivatele
        /// </summary>
        [DispId(3)]
        string Name { get; }

        /// <summary>
        /// ID uzivatele (v33id)
        /// </summary>
        [DispId(4)]
        int ID { get; }

        /// <summary>
        /// v03id uzivatele
        /// </summary>
        [DispId(12)]
        int LegacyV03ID { get; }

        /// <summary>
        /// v11id uzivatele
        /// </summary>
        [DispId(13)]
        int LegacyV11ID { get; }

        /// <summary>
        /// s53id_log uzivatele
        /// </summary>
        [DispId(14)]
        int LegacyS53ID { get; }

        /// <summary>
        /// =true pokud je uzivatel autentifikovan
        /// </summary>
        [DispId(5)]
        bool IsAuthenticated { get; }

        /// <summary>
        /// Cas expirace soucasneho hesla.
        /// </summary>
        [DispId(6)]
        DateTime PasswordExpiration { get; }

        /// <summary>
        /// Stari hesla od posledni zmeny ve dnech
        /// </summary>
        [DispId(9)]
        int PasswordAge { get; }

        /// <summary>
        /// Prava k soucasne aplikaci
        /// </summary>
        [DispId(7)]
        int Permissions { get; }

        /// <summary>
        /// ID impersonovaneho uzivatele
        /// </summary>
        [DispId(12)]
        int Impersonate { get; }

        /// <summary>
        /// Informace o nastaveni ruznych prepinacu
        /// </summary>
        /// <param name="sw"></param>
        /// <returns>true pokud je prepinac nastaven</returns>
        [DispId(8)]
        bool IsSetSwitch(IdentityBaseSwitches sw);

        [DispId(16)]
        int m17ID { get; }

        [DispId(17)]
        long BrokerId { get; }

        [DispId(18)]
        string KbUid { get; }
    }
}
