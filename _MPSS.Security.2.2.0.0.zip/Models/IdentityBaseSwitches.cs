﻿using System;
using System.Runtime.InteropServices;

namespace MPSS.Security
{
    /// <summary>
    /// Moznosti pro IdentityBase._Switches.
    /// </summary>
    [ComVisible(true)]
    public enum IdentityBaseSwitches
    {
        MandatoryToChangePassword = 2,
        CanNotChangePassword = 4,
        PasswordNeverExpires = 8,
        PasswordTooYoungToChange = 16
    }
}
