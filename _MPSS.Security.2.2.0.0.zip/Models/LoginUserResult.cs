﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Informace o vysledku pokusu prihlasit se k AD.
    /// </summary>
    public class LoginUserResult
    {
        public LoginUserResult()
        {
            this.Success = false;
            this.ErrorCode = LoginUserResultErrorCodes.None;
            this.AccountState = LoginUserResultStateCodes.None;
            this.MandatoryToChangePassword = false;
        }

        /// <summary>
        /// Pokud je true, bylo mozne uzivatele autentifikovat.
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// Chybovy stav pro zpravu administratorovi.
        /// </summary>
        public LoginUserResultErrorCodes ErrorCode { get; set; }

        /// <summary>
        /// Stav AD pro zpravu administratorovi.
        /// </summary>
        public LoginUserResultStateCodes AccountState { get; set; }

        /// <summary>
        /// Datum a cas vyprseni soucasneho hesla.
        /// </summary>
        public DateTime PasswordExpiration { get; set; }

        /// <summary>
        /// true, pokud je nutne ihned zmenit heslo do AD.
        /// </summary>
        public bool MandatoryToChangePassword { get; set; }

        /// <summary>
        /// true poku uzivatel nemuze menit heslo.
        /// </summary>
        public bool CanNotChangePassword { get; set; }

        /// <summary>
        /// true pokud heslo nikdy nevyprsi.
        /// </summary>
        public bool PasswordNeverExpires { get; set; }

        /// <summary>
        /// Instance uzivatele pokud se povedlo prihlaseni.
        /// </summary>
        public IUser User { get; set; }
    }
}
