﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MPSS.Security
{
    public class UGposition
    {
        public int v33id;

        public string CPM;

        public string ICP;
    }
}
