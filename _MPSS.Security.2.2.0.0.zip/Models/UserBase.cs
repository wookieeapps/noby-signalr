﻿using System;
using System.Security.Principal;

namespace MPSS.Security
{
    /// <summary>
    /// Kontajner detailu uzivatele (ve vlastnosti Identity).
    /// </summary>
    internal class UserBase : IUser
    {
        #region properties fetched from Identity class
        public string KbUid
        {
            get { return ((IdentityBase)Identity).KbUid; }
        }

        public int m17ID
        {
            get { return ((IdentityBase)Identity).m17ID; }
        }

        public long BrokerId
        {
            get { return ((IdentityBase)Identity).BrokerId; }
        }

        public string CPM
        {
            get { return ((IdentityBase)Identity).CPM; }
        }

        /// <summary>
        /// ICP uzivatele (pokud existuje).
        /// </summary>
        public string ICP
        {
            get { return ((IdentityBase)Identity).ICP; }
        }

        /// <summary>
        /// Jmeno a prijmeni uzivatele.
        /// </summary>
        public string Name
        {
            get { return Identity.Name; }
        }

        /// <summary>
        /// Jednotne ID uzivatele (v33id).
        /// </summary>
        public int ID
        {
            get { return ((IdentityBase)Identity).ID; }
        }

        /// <summary>
        /// v03id uzivatele.
        /// </summary>
        public int LegacyV03ID
        {
            get { return ((IdentityBase)Identity).LegacyV03ID; }
        }

        /// <summary>
        /// v11id uzivatele.
        /// </summary>
        public int LegacyV11ID
        {
            get { return ((IdentityBase)Identity).LegacyV11ID; }
        }

        /// <summary>
        /// s53id uzivatele.
        /// </summary>
        public int LegacyS53ID
        {
            get { return ((IdentityBase)Identity).LegacyS53ID; }
        }

        /// <summary>
        /// True pokud se podarilo uzivatel autentikovat proti AD.
        /// </summary>
        public bool IsAuthenticated
        {
            get { return Identity.IsAuthenticated; }
        }

        /// <summary>
        /// Cas vyprseni platnosti hesla.
        /// </summary>
        public DateTime PasswordExpiration
        {
            get { return ((IdentityBase)Identity).PasswordExpiration; }
        }

        /// <summary>
        /// Soucet prav uzivatele pro soucasnou aplikaci (podle Application ID).
        /// </summary>
        public int Permissions
        {
            get { return ((IdentityBase)Identity).Permissions; }
        }

        /// <summary>
        /// Impersonace
        /// </summary>
        public int Impersonate
        {
            get { return ((IdentityBase)Identity).Impersonate; }
        }

        /// <summary>
        /// Vraci session id security cookie.
        /// </summary>
        internal string SessionId
        {
            get { return ((IdentityBase)Identity).SessionId; }
        }

        /// <summary>
        /// Stari hesla ve dnech. Pocita se jako rozdil casu expirace hesla a max. delky platnosti hesla (z AdRepository).
        /// </summary>
        public int PasswordAge
        {
            get
            {
                try
                {
                    DateTime d = this.PasswordExpiration.Subtract(TimeSpan.FromDays(RepositoryFactory.MaxPasswordAge));
                    TimeSpan ts = DateTime.Now - d;
                    return Convert.ToInt32(Math.Floor(ts.TotalDays));
                }
                catch (ArgumentOutOfRangeException)
                {
                    return 0;
                }
            }
        }
        #endregion

        #region constructors
        public UserBase(IdentityBase identity)
        {
            this.Identity = identity;
        }

        public UserBase()
        {
            IdentityBase identity = new IdentityBase(false);
            this.Identity = identity;
        }
        #endregion

        #region switches
        /// <summary>
        /// Nastaveni prepinace vnitrnich switchu
        /// </summary>
        /// <param name="newSwitch"></param>
        internal void SetSwitch(IdentityBaseSwitches newSwitch)
        {
            int sw = Convert.ToInt32(newSwitch);
            IdentityBase ib = (IdentityBase)this.Identity;
            if ((sw & ib._Switches) == 0)
            {
                ib._Switches += sw;
            }
        }

        /// <summary>
        /// Zjisteni, zda je nastaveny konkretni prepinac
        /// </summary>
        /// <param name="sw"></param>
        /// <returns>true, pokud je prepinac nastaveny</returns>
        public bool IsSetSwitch(IdentityBaseSwitches sw)
        {
            return ((((IdentityBase)this.Identity)._Switches & Convert.ToInt32(sw)) > 0);
        }
        #endregion

        /// <summary>
        /// Vraci true, pokud ma uzivatel prirazenou danou funkci/pravo
        /// </summary>
        /// <param name="role">Pravo - jedna se integer. Z duvodu puvodni implementace IUser musi byt jako string.</param>
        public bool IsInRole(string role)
        {
            if (role.Length == 0)
                return false;

            if ((this.Permissions & Convert.ToInt32(role)) > 0)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Kontajner s daty o uzivateli
        /// </summary>
        public IIdentity Identity
        {
            get;
            private set;
        }
    }
}
