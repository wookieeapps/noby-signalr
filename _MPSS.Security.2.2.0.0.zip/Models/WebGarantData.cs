﻿using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace MPSS.Security
{
    /// <summary>
    /// Struktura dat predavana SSO webservice WebGarant v pripade pozadavku zobrazeni konkretniho klienta po prihlaseni./
    /// </summary>
    [ComVisible(false)]
    public class WebGarantData
    {
        /// <summary>
        /// ID klienta (CPM)
        /// </summary>
        public long ID;

        /// <summary>
        /// Klient - rodne cislo
        /// </summary>
        public string RodneCislo;

        /// <summary>
        /// Klient - jmeno
        /// </summary>
        public string Jmeno;

        /// <summary>
        /// Klient - prijmeni
        /// </summary>
        public string Prijmeni;

        /// <summary>
        /// Klient - titul pred jmenem
        /// </summary>
        public string Titul;

        #region adresa
        /// <summary>
        /// Trvale bydliste - nazev ulice
        /// </summary>
        public string Ulice;

        /// <summary>
        /// Trvale bydliste - misto
        /// </summary>
        public string Mesto;

        /// <summary>
        /// Trvale bydliste - Cislo ulice popisne
        /// </summary>
        public string UliceCislo1;

        /// <summary>
        /// Trvale bydliste - Cislo ulice orientacni
        /// </summary>
        public string UliceCislo2;

        /// <summary>
        /// Trvale bydliste - PSC
        /// </summary>
        public string PSC;

        public string Zeme;
        #endregion

        #region kontakt
        /// <summary>
        /// Klient - telefonni cislo
        /// </summary>
        public string Telefon;

        /// <summary>
        /// Klient - emailova adresa
        /// </summary>
        public string Email;
        #endregion
    }
}
