﻿using System;
using System.Security.Cryptography;
using System.Web;
using System.Configuration;
using System.Text;

namespace MPSS.Security
{
    /// <summary>
    /// <para>Vychozi trida pro vytvareni noveho WebFormu (pouzit pri dedeni misto Web.Page).</para>
    /// <para>Zajistuje zakladni ochranu proti CSRF nastavenim ViewStateUserKey.</para>
    /// <para>Zajistuje autentizaci uzivatele, nastaveni UI Culture.</para>
    /// <para>Zpristupnuje instanci uzivatele ve vlastnosti User.</para>
    /// <para>Pro ziskani modu pro daneho uzivatele a aplikaci je nutne nastavit spravne ApplicationId.</para>
    /// <para>Autentizace: pokud se nepodari uzivatele prihlasit (nema platnou security cookie), bude automaticky presmerovan na logovaci stranku PMP.</para>
    /// <para>Toto chovani se da ovlivnit atributem PageAuthentication (pokud je nastaveny na false, probehne autentizace, ale v pripade neuspechu neni presmerovan na PMP.</para>
    /// </summary>
    [System.Runtime.InteropServices.ComVisible(false)]
    public class PageBase : System.Web.UI.Page
    {
        #region props
        /// <summary>
        /// Key nodu ve web.config ktery obsahuje application id
        /// </summary>
        public const string ConfigApplicationId = "PageBase.ApplicationId";

        /// <summary>
        /// Key nodu ve web.config ktery obsahuje nastaveni RequiresAuthentication
        /// </summary>
        public const string ConfigRequiresAuthentication = "PageBase.RequiresAuthentication";

        /// <summary>
        /// Key nodu ve web.config ktery obsahuje moznost vypnuti CSRF obrany
        /// </summary>
        public const string ConfigCSRFProtection = "PageBase.CSRFProtection";

        /// <summary>
        /// Key nodu ve web.config ktery obsahuje moznost nastaveni app prostredi
        /// </summary>
        public const string ConfigEnvironmentType = "EnvironmentType";

        /// <summary>
        /// Instance uzivatele
        /// </summary>
        private IUser _User;

        /// <summary>
        /// Aktualni instance tridy Portal
        /// </summary>
        public Portal CurrentPortal
        {
            get;
            private set;
        }

        /// <summary>
        /// true pokud se ma vypnout ochrana proti csrf utokum.
        /// </summary>
        protected bool DisableCsrf;
        
        /// <summary>
        /// true pokud je nutna autentizace uzivatele
        /// </summary>
        protected bool RequiresAuthentication
        {
            get { return this._RequiresAuthentication; }
        }
        private bool _RequiresAuthentication;
        
        /// <summary>
        /// true pokud musi mit uzivatel prava pro soucasnou aplikaci.
        /// </summary>
        protected bool RequiresPermission
        {
            get { return this._RequiresPermission; }
        }
        private bool _RequiresPermission;

        /// <summary>
        /// true pokud pri neplatnem prihlaseni ma byt redirect na PMP proveden pomoci JavaScriptu. Jinak se provadi pomoci Response.Redirect.
        /// </summary>
        protected bool AuthenticationRedirectWithJS { get; set; }

        /// <summary>
        /// ID aplikace
        /// </summary>
        protected int ApplicationId
        {
            get { return this._ApplicationId; }
        }
        private int _ApplicationId;

        private int EnvironmentType;

        private byte[] CsrfCookiePwd = ASCIIEncoding.ASCII.GetBytes("89skl37a");
        private byte[] CsrfCookieVct = ASCIIEncoding.ASCII.GetBytes("nmzoas83");

        private byte[] CsrfFormPwd = ASCIIEncoding.ASCII.GetBytes("m489xjkw");
        private byte[] CsrfFormVct = ASCIIEncoding.ASCII.GetBytes("3sla9m2l");
        #endregion

        /// <summary>
        /// Konstruktor
        /// </summary>
        public PageBase()
        {
            this.AuthenticationRedirectWithJS = false;
            this.DisableCsrf = true;
            // default no application
            this._ApplicationId = 0;
            // default env. type
            this.EnvironmentType = 0;
            // default true
            this._RequiresAuthentication = true;
            this._RequiresPermission = true;
        }

        /// <summary>
        /// Konstruktor s nastavenim applicationId
        /// </summary>
        /// <param name="applicationId"></param>
        public PageBase(int applicationId) : this()
        {
            this._ApplicationId = applicationId;
        }

        /// <summary>
        /// Nastaveni vychozi UI culture, zjisteni attributu
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);

            // nastaveni page auth ve web.config
            if (ConfigurationManager.AppSettings[ConfigRequiresAuthentication] != null)
            {
                this._RequiresAuthentication = ConfigurationManager.AppSettings[ConfigRequiresAuthentication] != "false";
            }
            // nastaveni csrf protection
            if (ConfigurationManager.AppSettings[ConfigCSRFProtection] != null)
            {
                this.DisableCsrf = ConfigurationManager.AppSettings[ConfigCSRFProtection] == "false";
            }

            #region ziskani atributu stranky
            // projit projit vsechny odvozene typy az narazi na PageBase - tam skoncit
            // je to kvuli tomu, aby pri vicenasobnem dedeni stale fungovali atributy tridy
            Type baset = this.GetType();
            while (baset != typeof(PageBase))
            {
                // projit vsechny custom attributy pridane k soucasne instanci tridy
                foreach (Attribute att in baset.GetCustomAttributes(true))
                {
                    Type t = att.GetType();

                    // nastaveni autentikace stranky
                    if (t == typeof(PageAuthenticationAttribute))
                    {
                        this._RequiresAuthentication = ((PageAuthenticationAttribute)att).RequiresAuthentication;
                    }
                    // nastaveni povinosti prav na aplikaci
                    else if (t == typeof(PageAuthenticationCheckAppPermissionsAttribute))
                    {
                        this._RequiresPermission = ((PageAuthenticationCheckAppPermissionsAttribute)att).RequiresPermission;
                    }
                    // nastaveni application id
                    else if (t == typeof(ApplicationIdAttribute) && this.ApplicationId == 0)
                    {
                        this._ApplicationId = ((ApplicationIdAttribute)att).ApplicationId;
                    }
                    // nastaveni env. type
                    else if (t == typeof(EnvironmentTypeAttribute))
                    {
                        this.EnvironmentType = ((EnvironmentTypeAttribute)att).EnvironmentType;
                    }
                    else if (t == typeof(CsrfCheckAttribute))
                    {
                        this.DisableCsrf = !((CsrfCheckAttribute)att).UseCsrfCheck;
                    }
                }

                baset = baset.BaseType;
            }
            #endregion

            // pokud neni nastaveno application id atributem
            if (this.ApplicationId == 0)
            {
                if (ConfigurationManager.AppSettings[ConfigApplicationId] != null)
                {
                    this._ApplicationId = Convert.ToInt32(ConfigurationManager.AppSettings[ConfigApplicationId]);
                }
            }
            // nastaveni environment type
            if (this.EnvironmentType == 0)
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[ConfigEnvironmentType]))
                {
                    this.EnvironmentType = Convert.ToInt32(ConfigurationManager.AppSettings[ConfigEnvironmentType]);
                }
            }

            // konfigurace
            Configuration config = ConfigurationFactory.GetConfiguration(this.EnvironmentType);
            // instance Portal tridy
            CurrentPortal = new Portal(config);
            
            // pokud neni zadane prostredi
            if (this.EnvironmentType == 0)
                this.EnvironmentType = config.EnvironmentType;

            // nastaveni culture
            System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo(config.DefaultCulture);
            System.Threading.Thread.CurrentThread.CurrentCulture = ci;
            System.Threading.Thread.CurrentThread.CurrentUICulture = ci;
        }

        /// <summary>
        /// Autentifikace uzivatele, pripadne presmerovani na logovaci stranku
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            // autentifikace
            this._User = this.CurrentPortal.GetCurrentUser(this._ApplicationId, !this.RequiresAuthentication);

            // pokud neni uzivatel autentifikovan a je vyzadovana autentifikace
            // presmerovat na login a vratit v querystringu tuhle stranku
            if (this._RequiresAuthentication)
            {
                if (!this._User.IsAuthenticated)
                {
                    if (this.AuthenticationRedirectWithJS)
                    {
                        Response.Write("<script type=\"text/javascript\">location.href=\"");
                        Response.Write(string.Format("{0}?auth=failed&return={1}", this.CurrentPortal.CurrentConfig.PMPLoginUrl, Server.UrlEncode(this.Request.Url.ToString())));
                        Response.Write("\";</script>");
                        Response.End();
                    }
                    else
                    {
                        this.Response.Redirect(string.Format("{0}?auth=failed&return={1}", this.CurrentPortal.CurrentConfig.PMPLoginUrl, Server.UrlEncode(this.Request.Url.ToString())), true);
                    }
                    return;
                }
                // nebo pokud uzivatel nema prava na danou aplikaci a nejedna se o PMP
                else if (this._RequiresPermission && this._User.Permissions == 0)
                {
                    this.Response.Redirect(this.CurrentPortal.CurrentConfig.PMPMainUrl, true);
                    return;
                }
            }

            #region CSRF
            // protection against csrf
            if (!this.DisableCsrf)
            {
                // kontrola predchoziho csrf tokenu
                ValidateCsrf();

                // generovat csrf token
                string token = Guid.NewGuid().ToString().Substring(0, 8);
                string key = "PAGEBASE_CSRF_" + Guid.NewGuid().ToString().Substring(0, 8);
                string tokenForm = DesCrypto.Encrypt(token, this.CsrfFormPwd, this.CsrfFormVct);
                string tokenCookie = DesCrypto.Encrypt(token, this.CsrfCookiePwd, this.CsrfCookieVct);

                // zapsat do stranky
                this.Page.ClientScript.RegisterClientScriptBlock(typeof(string), key, string.Format("<input type=\"hidden\" value=\"{0}\" name=\"{1}\" />", tokenForm, key));

                // zapsat do cookies
                HttpCookie cookie = new HttpCookie(key, tokenCookie);
                if (!string.IsNullOrEmpty(this.CurrentPortal.CurrentConfig.CookieDomainName))
                    cookie.Domain = this.CurrentPortal.CurrentConfig.CookieDomainName;
                if (!string.IsNullOrEmpty(this.CurrentPortal.CurrentConfig.CookiePath))
                    cookie.Path = this.CurrentPortal.CurrentConfig.CookiePath;
                cookie.HttpOnly = true;
                cookie.Secure = this.CurrentPortal.CurrentConfig.CookieOnlyHttps;
                if (this.CurrentPortal.CurrentConfig.PersistentCookie)
                    cookie.Expires = DateTime.Now.AddMinutes(this.CurrentPortal.CurrentConfig.CookieExpiration);
                // ulozit cookie
                this.Response.Cookies.Add(cookie);
            }
            #endregion

            // method hook
            this.AfterAuthentication();
        }

        #region CSRF
        protected void ValidateCsrf()
        {
            // odstranit vsechny csrf cookie
            string[] ck = Array.FindAll<string>(this.Request.Cookies.AllKeys, t => t.StartsWith("PAGEBASE_CSRF_"));
            foreach (string ckkey in ck)
            {
                HttpCookie cookie = new HttpCookie(ckkey, "");
                cookie.Expires = DateTime.Now.AddDays(-1);
                this.Response.Cookies.Add(cookie);
            }

            string key = Array.Find<string>(this.Request.Form.AllKeys, t => t.StartsWith("PAGEBASE_CSRF_"));
            // jestlize existuje csrf token
            if (!string.IsNullOrEmpty(key))
            {
                bool csrfOK = true;
                if (this.Request.Cookies[key] != null)
                {
                    if (DesCrypto.Decrypt(Request.Form[key], this.CsrfFormPwd, this.CsrfFormVct) != DesCrypto.Decrypt(Request.Cookies[key].Value, this.CsrfCookiePwd, this.CsrfCookieVct))
                    {
                        csrfOK = false;
                    }
                }
                else
                {
                    csrfOK = false;
                }

                if (!csrfOK)
                {
                    this.Response.Redirect(string.Format("{0}?csrf=1", this.CurrentPortal.CurrentConfig.PMPLoginUrl), true);
                }
            }
        }
        #endregion

        /// <summary>
        /// Metoda pripravena pro pretizeni, je spoustena ihned po autentizaci uzivatele.
        /// </summary>
        protected virtual void AfterAuthentication()
        {
        }
        
        /// <summary>
        /// <para>Instance uzivatele.</para>para>
        /// <para>Pokud je vlastnost IsAuthenticated nastavena na false, uzivatel nebyl autentifikovan.</para>
        /// </summary>
        public new IUser User
        {
            get
            {
                return this._User;
            }
        }
    }
}
