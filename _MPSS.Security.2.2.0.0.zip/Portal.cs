﻿using System;
using System.Web;
using System.Text;
using System.Security.Policy;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace MPSS.Security
{
    /// <summary>
    /// Trida pro praci s instanci uzivatele. Zajistuje prihlaseni uzivatele (vytvoreni autentifikacni cookie) a overeni uzivatele pomoci autentifikacni cookie.
    /// </summary>
    [ComVisible(false)]
    public class Portal
    {
        /// <summary>
        /// Verze konfigurace pro aktualni pozadavek
        /// </summary>
        public Configuration CurrentConfig
        {
            get;
            private set;
        }

        /// <summary>
        /// Konstruktor vynucujici predani instance konfigurace aktualniho pozadavku.
        /// </summary>
        public Portal(Configuration config)
        {
            CurrentConfig = config;
        }

        #region static props to remove
        /// <summary>
        /// URL adresa logovaci stranky portalu.
        /// </summary>
        public static string PMPLoginUrl
        {
            get
            {
                Configuration c = ConfigurationFactory.GetConfiguration();
                return c.PMPLoginUrl;
            }
        }

        /// <summary>
        /// URL adresa pro odhlaseni z portalu
        /// </summary>
        public static string PMPLogoutUrl
        {
            get
            {
                Configuration c = ConfigurationFactory.GetConfiguration();
                return c.PMPLogoutUrl;
            }
        }

        /// <summary>
        /// URL adresa hlavni stranky portalu.
        /// </summary>
        public static string PMPMainUrl
        {
            get
            {
                Configuration c = ConfigurationFactory.GetConfiguration();
                return c.PMPMainUrl;
            }
        }

        /// <summary>
        /// True, pokud je pozadovano pouze https.
        /// </summary>
        public static bool OnlyHttps
        {
            get
            {
                Configuration c = ConfigurationFactory.GetConfiguration();
                return c.OnlyHttps;
            }
        }
        #endregion

        #region public properties
        /// <summary>
        /// Minimalni doba nezmenitelnosti hesla v AD.
        /// </summary>
        public static int MinPasswordAge
        {
            get { return RepositoryFactory.MinPasswordAge; }
        }

        /// <summary>
        /// Pocet predchozich hesel, ktera nesmi byt stejna.
        /// </summary>
        public static int PasswordHistoryLength
        {
            get { return RepositoryFactory.PasswordHistoryLength; }
        }

        /// <summary>
        /// Minimalni delka hesla v AD.
        /// </summary>
        public static int MinPasswordLength
        {
            get { return RepositoryFactory.MinPasswordLength; }
        }

        public const int EnvironmentType_Prod = 1;
        public const int EnvironmentType_Dev = 2;
        public const int EnvironmentType_Testinet = 3;
        public const int EnvironmentType_EDU = 4;
        #endregion

        /// <summary>
        /// Kontrola, zda dane URL pochazi z podporovanych domen.
        /// </summary>
        /// <param name="url">URL kontrolovane stranky.</param>
        /// <returns>True, pokud je URL v poradku.</returns>
        public bool IsAllowedUrl(string url)
        {
            if (url.StartsWith("http"))
            {
                Uri u = new Uri(url);
                
                // pokud je povolene pouze https
                if (u.Scheme != "https" && CurrentConfig.OnlyHttps)
                {
                    return false;
                }
                else
                {
                    string host = u.Host;
                    foreach (string s in CurrentConfig.AllowedDomains)
                    {
                        if (host.EndsWith(s))
                            return true;
                    }
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Vraci seznam podrizenych pro daneho UG
        /// </summary>
        /// <param name="m04id">ID nadrizeneho uzivatele (UG)</param>
        public List<UGposition> GetUGorTHSsubtree(int m04id)
        {
            if (m04id == 0)
                return new List<UGposition>();

            IDbRepository repository = RepositoryFactory.GetLogRepository(CurrentConfig);
            return repository.GetUGorTHSsubtree(m04id);
        }

        /// <summary>
        /// Ulozeni informace o pristupu uzivatele k aplikaci
        /// </summary>
        /// <param name="user">Instance uzivatele</param>
        /// <param name="appId">ID aplikace (v07id)</param>
        /// <param name="ip">IP adresa</param>
        public void ApplicationAccessLog(IUser user, int appId, string ip)
        {
            IDbRepository repository = RepositoryFactory.GetLogRepository(CurrentConfig);
            repository.ApplicationAccessSaveLog(user, appId, ip, CurrentConfig.Server, CurrentConfig.EnvironmentType);
        }

        /// <summary>
        /// Logovani pristupu na PMP
        /// </summary>
        public void PortalAccessLog(IUser user, string ip)
        {
            IDbRepository repository = RepositoryFactory.GetLogRepository(CurrentConfig);
            repository.PortalAccessSaveLog(user, ip, CurrentConfig.EnvironmentType);
        }

        #region webGarant
        /// <summary>
        /// Vytvorit Binding element pro webgarant aplikace
        /// </summary>
        /// <param name="serviceUrl">URL webservice WebGarant</param>
        private System.ServiceModel.BasicHttpBinding WebGarantCreateBinding(string serviceUrl)
        {
            // vytvorit security context
            System.ServiceModel.BasicHttpSecurity security;
            if (serviceUrl.StartsWith("https"))
            {
                security = new System.ServiceModel.BasicHttpSecurity
                {
                    Mode = System.ServiceModel.BasicHttpSecurityMode.Transport,
                    Transport = new System.ServiceModel.HttpTransportSecurity
                    {
                        ClientCredentialType = System.ServiceModel.HttpClientCredentialType.None,
                        ProxyCredentialType = System.ServiceModel.HttpProxyCredentialType.None,
                        Realm = ""
                    },
                    Message = new System.ServiceModel.BasicHttpMessageSecurity
                    {
                        ClientCredentialType = System.ServiceModel.BasicHttpMessageCredentialType.Certificate,
                        AlgorithmSuite = System.ServiceModel.Security.SecurityAlgorithmSuite.Default
                    }
                };
            }
            else
            {
                security = new System.ServiceModel.BasicHttpSecurity
                {
                    Mode = System.ServiceModel.BasicHttpSecurityMode.None,
                    Transport = new System.ServiceModel.HttpTransportSecurity
                    {
                        ClientCredentialType = System.ServiceModel.HttpClientCredentialType.None,
                        ProxyCredentialType = System.ServiceModel.HttpProxyCredentialType.None,
                        Realm = ""
                    },
                    Message = new System.ServiceModel.BasicHttpMessageSecurity
                    {
                        ClientCredentialType = System.ServiceModel.BasicHttpMessageCredentialType.UserName,
                        AlgorithmSuite = System.ServiceModel.Security.SecurityAlgorithmSuite.Default
                    }
                };
            }

            // vytvorit binding element
            System.ServiceModel.BasicHttpBinding binding = new System.ServiceModel.BasicHttpBinding
            {
                Security = security,
                MessageEncoding = System.ServiceModel.WSMessageEncoding.Text,
                TextEncoding = System.Text.Encoding.UTF8
            };

            return binding;
        }

        /// <summary>
        /// Zadost o unikatni prihlasovaci URL pro aplikaci WebGarant
        /// </summary>
        /// <returns>URL prihlasovaci strankyk aplikace WebGarant. Prazdny string v pripade, ze uzivatel nema na aplikaci pravo nebo nastal problem pri overovani.</returns>
        public string WebGarantSSO()
        {
            // instance prihlaseneho uzivatele
            IUser user = GetCurrentUser(CurrentConfig.WebGarantAppId, true);

            // log pristupu
            ApplicationAccessLog(user, CurrentConfig.WebGarantAppId, System.Web.HttpContext.Current.Request.UserHostAddress);

            // pokracovat - uzviatel ma pravo
            if (user.IsAuthenticated)
            {
                // info o uzivateli a company
                WebGarantWS.AccessData data = new WebGarantWS.AccessData
                {
                    icCompany = CurrentConfig.WebGarantIc,
                    channel = CurrentConfig.WebGarantChannel,
                    personalNumber = user.CPM,
                    idClient = new WebGarantWS.SubjectIdentification
                    {
                        idSpecified = false
                    },
                    address = new WebGarantWS.Address()
                };

                try
                {
                    using (WebGarantWS.WebGarantAccessServiceSoapClient client = new WebGarantWS.WebGarantAccessServiceSoapClient(WebGarantCreateBinding(CurrentConfig.WebGarantUrl), new System.ServiceModel.EndpointAddress(CurrentConfig.WebGarantUrl)))
                    {
                        return client.getWebGarantAccessByData(data);
                    }
                }
                catch (Exception err)
                {
                    Log.LoggerFactory.WriteLog(err, "MPSS.Security.Portal", "WebGarantSSO", 2, err.Message, 0, CurrentConfig.EnvironmentType);

                    return "";
                }
            }
            else
            {
                return "";
            }
        }

        /// <summary>
        /// Zadost o unikatni prihlasovaci URL pro aplikaci WebGarant
        /// </summary>
        /// <param name="data">Data predavana do WG</param>
        /// <param name="environmentType">ID aplikacniho prostredi</param>
        /// <param name="login">Login prihlaseneho uzivatele</param>
        /// <returns>URL prihlasovaci strankyk aplikace WebGarant. Prazdny string v pripade, ze uzivatel nema na aplikaci pravo nebo nastal problem pri overovani.</returns>
        public string WebGarantSSO(WebGarantData data, string login = "")
        {
            // instance prihlaseneho uzivatele - pokud neni explicitne zadan login
            if (string.IsNullOrEmpty(login))
            {
                IUser user = GetCurrentUser(CurrentConfig.WebGarantAppId, true);
                // pokracovat - uzivatel ma pravo
                if (user.IsAuthenticated)
                {
                    login = user.CPM;
                }
                else
                {
                    return "";
                }
            }

            // log pristupu
            ApplicationAccessLog(new UserBase(new IdentityBase(false) { CPM = login }), CurrentConfig.WebGarantAppId, System.Web.HttpContext.Current.Request.UserHostAddress);

            // data o uzivateli a klientovi
            WebGarantWS.AccessData data2 = new WebGarantWS.AccessData
            {
                icCompany = CurrentConfig.WebGarantIc,
                channel = CurrentConfig.WebGarantChannel,
                personalNumber = login,
                    
                birthNumber = data.RodneCislo,
                firstName = data.Jmeno,
                surname = data.Prijmeni,
                title = data.Titul,

                email = data.Email,
                phoneNumber = data.Telefon,

                address = new WebGarantWS.Address
                {
                    street = data.Ulice,
                    city = data.Mesto,
                    country = string.IsNullOrEmpty(data.Zeme) ? "CZE" : data.Zeme,
                    postCode = data.PSC,
                    descNo = data.UliceCislo1,
                    orientNo = data.UliceCislo2
                }
            };

            // identifikace klienta
            if (data.ID > 0)
            {
                data2.idClient = new WebGarantWS.SubjectIdentification
                {
                    idSpecified = true,
                    id = data.ID,
                    typeId = "MPSS"
                };
            }
            else
            {
                data2.idClient = new WebGarantWS.SubjectIdentification
                {
                    idSpecified = false
                };
            }

            try
            {
                using (WebGarantWS.WebGarantAccessServiceSoapClient client = new WebGarantWS.WebGarantAccessServiceSoapClient(WebGarantCreateBinding(CurrentConfig.WebGarantUrl), new System.ServiceModel.EndpointAddress(CurrentConfig.WebGarantUrl)))
                {
                    return client.getWebGarantAccessByData(data2);
                }
            }
            catch (Exception err)
            {
                Log.LoggerFactory.WriteLog(err, "MPSS.Security.Portal", "WebGarantSSO(data,login)", 2, err.Message, CurrentConfig.EnvironmentType);

                return "";
            }
        }
        #endregion

        /// <summary>
        /// Vraci soucet prav uzivatele pro danou aplikaci.
        /// </summary>
        /// <param name="user">Instance uzivatele.</param>
        /// <param name="applicationId">ID aplikace.</param>
        /// <returns>Soucet prav uzivatele pro aplikaci + ID uzivatele v pripade impersonizace.</returns>
        public GetUserPermissionsResult GetUserPermissons(IUser user, int applicationId)
        {
            IDbRepository repository = RepositoryFactory.GetDbRepository(CurrentConfig);
            return repository.GetUserPermissions((IdentityBase)user.Identity, applicationId);
        }

        /// <summary>
        /// <para>Ziska instanci uzivatele z kolekce cookies.</para>
        /// <para>Pokud je zadano applicationID != 0, zjistuje take prava uzivatele na danou aplikaci.</para>
        /// <para>IsAuthenticated muze byt false take v pripade, ze je sice overen oproti AD, ale ma vyexpirovane heslo. V takovem pripade by mel mit pristup pouze na stranku se zmenou hesla na PMP.</para>
        /// </summary>
        /// <param name="applicationId">ID volajici aplikace</param>
        /// <param name="preserveSession">Nastaveno na true zajisti, ze session nebude smazana ani v pripade, ze uzivatel neni autentikovan.</param>
        /// <param name="environmentType">ID aplikacniho prostredi</param>
        /// <returns>Vraci instanci uzivatele. Pokud neni instance platna, je nastavena vlastnost IsAuthenticated=false.</returns>
        public IUser GetCurrentUser(int applicationId, bool preserveSession = false)
        {
            // autentikace uzivatele
            IUser user = CookieRepository.GetSession(applicationId, CurrentConfig);
            if (!user.IsAuthenticated && !preserveSession)
            {
                // pokud neni uzivatel autentifikovan, smaz SecurityCookie (bezpecnosti opatreni)
                CookieRepository.RemoveCurrentSession(null, CurrentConfig);
            }
            else
            {
                CookieRepository.WriteSession(user, new CookieValidator(HttpContext.Current), CurrentConfig);
            }
            return user;
        }

        /// <summary>
        /// OBSOLETE: legacy call
        /// </summary>
        public IUser GetCurrentUser(int applicationId, int environmentType, bool preserveSession = false)
        {
            return this.GetCurrentUser(applicationId, preserveSession);
        }

        /// <summary>
        /// Odstrani instanci prihlaseneho uzivatele z kolekce cookies - uzivatel bude odhlasen.
        /// </summary>
        public void RemoveCurrentSession(IUser user)
        {
            // remove from session state
            RegenerateSessionId.RegenerateId(System.Web.HttpContext.Current);
            
            // odstranit cookie
            if (user == null)
                CookieRepository.RemoveCurrentSession("", CurrentConfig);
            else
                CookieRepository.RemoveCurrentSession(((IdentityBase)user.Identity).SessionId, CurrentConfig);
        }

        #region dummy user
        /// <summary>
        /// Vytvori a zapise security cookie s testovacim uzivatelem definovanym v promennte dummyIdentity.
        /// </summary>
        public static IUser CreateDummyUser(string cpm, string icp, int applicationId, int permissions)
        {
            return CreateDummyUser(cpm, icp, "", 0, 0, 0, 0, applicationId, permissions, 0);
        }

        /// <summary>
        /// Vytvori a zapise security cookie s testovacim uzivatelem definovanym v promennte dummyIdentity.
        /// </summary>
        public static IUser CreateDummyUser(
            string cpm, /* CPM uzivatele */
            string icp, /* ICP uzivatele */
            string name, /* jmeno a prijmeni uzivatele */
            int id, /* v33id uzivatele */
            int s53id, /* s53id uzivatele - 0 pokud se nejedna o uzivatele z t01stat_mesic */
            int v11id, /* v11id uzivatele - 0 pokud se nejedna o zamestnance */
            int v03id, /* v03id uzivatele - 0 pokud se nejedna o agenturu */
            int applicationId, /* v11id aplikace */
            int permissions, /* soucet prav uzivatele */
            int impersonate, /* v33id uzivatele, za ktereho ma byt aktualni uzivatel impersonovan */
            bool isAuthenticated = true, /* true, pokud je uzivatel korektne prihlasen (vzdy by melo byt true) */
            int environmentType = 0 /* ID prostredi PMP */)
        {
            Configuration config = ConfigurationFactory.GetConfiguration(environmentType);

            IdentityBase dummyIdentity = new IdentityBase(isAuthenticated);

            if (id == 0)
            {
                IDbRepository repository = RepositoryFactory.GetDbRepository(config);
                repository.GetDummyUserData(cpm, icp, dummyIdentity);
            }
            else
            {
                dummyIdentity.CPM = cpm;
                dummyIdentity.ICP = icp;
                dummyIdentity.Name = name;
                dummyIdentity.ID = id;
                dummyIdentity.LegacyS53ID = s53id;
                dummyIdentity.LegacyV03ID = v03id;
                dummyIdentity.LegacyV11ID = v11id;
            }

            // vytvorit guid session
            dummyIdentity.SessionId = Guid.NewGuid().ToString();
            dummyIdentity.SetPermissionCache(applicationId, permissions, impersonate);
            dummyIdentity._Permissions = permissions;

            UserBase user = new UserBase(dummyIdentity);
            CookieRepository.WriteSession(user, new CookieValidator(HttpContext.Current), config);

            return user;
        }
        #endregion

        #region prihlaseni uzivatele na PMP, vytvoreni security cookie.
        /// <summary>
        /// <para>Overeni uzivatele v active directory.</para>
        /// <para>Prihlaseni probiha nasledovne:</para>
        /// <list type="number">
        /// <item><description>kontrola umisteni assembly, ktera vola LoginUser().</description></item>
        /// <item><description>odstraneni security cookie z kolekce (nemela by tam byt, ale pro jistotu).</description></item>
        /// <item><description>LoginCheck.PreADCheck() - kontroly cpm a icp, urcene pouze algoritmy bez pristupu do AD ci databaze. Metoda vraci login do AD pokud kontroly probehly bez problemu.</description></item>
        /// <item><description>IAdRepository.CheckUser() - kontrola uzivatele v AD (kontrola expirace hesla atd.).</description></item>
        /// <item><description>vytvoreni instance UserBase naplnenim informaci o uzivateli z db.</description></item>
        /// <item><description>zapis security cookie a vraceni LoginUserResult.Success=true</description></item>
        /// </list> 
        /// <para>Pokud pri IAdRepository.CheckUser() byl uzivatel overen, ale ma vyexpirovane heslo (a muze ho menit), je nastaveno LoginUserResult.Success=false, ale security cookie se presto ulozi.</para>
        /// </summary>
        /// <param name="cpm">CPM prihlasovaneho uzivatele</param>
        /// <param name="icp">ICP prihlasovaneho uzivatele (muze byt prazdne)</param>
        /// <param name="password">Heslo prihlasovaneho uzivatele</param>
        /// <returns>Vraci true pokud je uzivatel autentifikovan proti AD. Pokud je autentizovan, zapise se zaroven SecurityCookie do kolekce cookies.</returns>
        public LoginUserResult LoginUser(string cpm, string icp, string password)
        {
#if DEBUG
            Log.LoggerFactory.WriteLog("MPSS.Security.Portal", "LoginUser", 5, string.Format("#0 cpm:{0}; icp: {1}; heslo: {2};", cpm, icp, password), CurrentConfig.EnvironmentType);
#endif
            // ocesani loginu o prazdne znaky
            cpm = cpm.Trim();
            icp = icp.Trim();

            // vytvoreni zatim prazdneho vysledku prihlaseni
            LoginUserResult result = new LoginUserResult();

            // repository *********************************************************
            IAdRepository repository = RepositoryFactory.GetAdRepository();
            IDbRepository repositoryDb = RepositoryFactory.GetDbRepository(CurrentConfig);

            // kontrola validnosti volajici assembly
            ValidateAssemblyLink.CheckAssembly(Assembly.GetCallingAssembly());

            // odstranit SecurityCookie pokud nejaka byla (bezpecnosti opatreni)
            CookieRepository.RemoveCurrentSession(null, CurrentConfig);

            // overeni validity cpm a icp PRED volanim AD
            string adLogin;
            // pokud se jedna o specialni login, ktery nema prochazet kontrolou
            if (repositoryDb.IsSpecialLogin(cpm))
            {
                adLogin = cpm;
                result.AccountState = LoginUserResultStateCodes.OnlyCPM;
            }
            else // jinak normalni login
            {
                adLogin = LoginCheck.PreADCheck(ref result, cpm, icp, password, CurrentConfig);
            }

#if DEBUG
Log.LoggerFactory.WriteLog("MPSS.Security.Portal", "LoginUser", 5, string.Format("#1 adLogin={0}; AdRepository: {1}; DbRepository: {2};", adLogin, repository.GetType(), repositoryDb.GetType()), CurrentConfig.EnvironmentType);
#endif

            // pokud ma icp a cpm spravny tvar, pokracuj na overeni v AD
            if (!string.IsNullOrEmpty(adLogin))
            {
                // overeni oproti AD
                if (repository.CheckUser(ref result, adLogin, password, this.CurrentConfig))
                {
                    // detail uzivatele z databaze
                    IdentityBase identity = repositoryDb.GetUserDetail(cpm, icp);

                    // pokud uzivatel neni v db
                    if (identity == null)
                    {
#if DEBUG
Log.LoggerFactory.WriteLog("MPSS.Security.Portal", "LoginUser", 3, string.Format("User can not be found in database: CPM:{0}; ICP:{1};", cpm, icp), CurrentConfig.EnvironmentType);
#endif
                        result.ErrorCode = LoginUserResultErrorCodes.NoAccess;
                        result.Success = false;
                        return result;
                    }

                    // vytvorit guid session
                    identity.SessionId = Guid.NewGuid().ToString();
                    // expirace hesla
                    identity.PasswordExpiration = result.PasswordExpiration;
                  
                    UserBase user = new UserBase(identity);
#if DEBUG
                    Log.LoggerFactory.WriteLog("MPSS.Security.Portal", "LoginUser", 5, string.Format("#2 RESULT PasswordExpiration: {0}; PasswordNeverExpires: {1}; MandatoryToChangePassword: {2}; CanNotChangePassword: {3}; Error: {4}-{5}", identity.PasswordExpiration, result.PasswordNeverExpires, result.MandatoryToChangePassword, result.CanNotChangePassword, result.ErrorCode, result.AccountState), CurrentConfig.EnvironmentType);
#endif

                    if (user != null) // uzivatel nalezen v databazi
                    {
                        // pokud ma uzivatel vyexpirovane heslo
                        if (result.MandatoryToChangePassword)
                            ((IdentityBase)user.Identity).IsAuthenticated = false;

                        #region nastavenin switches
                        // nastaveni switches
                        if (result.CanNotChangePassword)
                            user.SetSwitch(IdentityBaseSwitches.CanNotChangePassword);
                        if (result.MandatoryToChangePassword)
                            user.SetSwitch(IdentityBaseSwitches.MandatoryToChangePassword);
                        if (result.PasswordNeverExpires)
                            user.SetSwitch(IdentityBaseSwitches.PasswordNeverExpires);
                        // heslo nelze menit, protoze je prilis mlade

                        if (!result.PasswordNeverExpires)
                        {
                            DateTime dPwd = result.PasswordExpiration.Subtract(TimeSpan.FromDays(RepositoryFactory.MaxPasswordAge));
                            TimeSpan tsPwd = DateTime.Now - dPwd;
                            if (Convert.ToInt32(Math.Floor(tsPwd.TotalDays)) < RepositoryFactory.MinPasswordAge)
                                user.SetSwitch(IdentityBaseSwitches.PasswordTooYoungToChange);
                        }
                        #endregion

#if DEBUG
Log.LoggerFactory.WriteLog("MPSS.Security.Portal", "LoginUser", 5, string.Format("#3 USER ID: {8};CPM: {0}; ICP: {1}; Name: {2}; PwdExp: {3}; PwdAge: {4}; IsAuth: {5}; Perm: {6}; Switches: {7};", user.CPM, user.ICP, user.Name, user.PasswordExpiration, user.PasswordAge, user.IsAuthenticated, user.Permissions, ((IdentityBase)user.Identity)._Switches, user.ID), CurrentConfig.EnvironmentType);
#endif
                        // ulozeni SecurityCookie s informacemi o uzivateli
                        CookieRepository.WriteSession(user, new CookieValidator(HttpContext.Current), CurrentConfig);

                        // totalni uspech pri prihlasovani
                        result.User = user;
                        result.Success = true;
                    }
                }
            }

            return result;
        }
        #endregion

        #region zmena hesla uzivatele v AD
        /// <summary>
        /// Zmena hesla prihlaseneho uzivatele v AD. Funguje pouze v pripade, ze je uzivatel autentikovan platnou security cookie.
        /// </summary>
        /// <param name="oldPassword">Puvodni heslo.</param>
        /// <param name="newPassword">Nove heslo.</param>
        /// <returns>Vysledek zmeny hesla v AD.</returns>
        //[ValidateAssemblyLink("file:///D:/my_documents/Visual Studio 2010/Projects/MPSS/MPSS.Applications.PMP/bin/MPSS.Applications.PMP.DLL")]
        public ChangePasswordResult ChangePassword(string oldPassword, string newPassword)
        {
            return RepositoryFactory.GetAdRepository().ChangePassword(oldPassword, newPassword, CurrentConfig);
        }
        #endregion
    }
}
