﻿using System;
using System.Runtime.InteropServices;
using System.DirectoryServices;

namespace MPSS.Security
{
    /// <summary>
    /// Repository pro Active Directory.
    /// </summary>
    internal sealed class AdRepository : IAdRepository
    {
        #region AD constants
        public const long ACCOUNTDISABLE = 2;
        public const long DONT_EXPIRE_PASSWORD = 65536;
        public const long PASSWD_CANT_CHANGE = 64;

        private const long ADS_OPTION_PASSWORD_PORTNUMBER = 6;
        private const long ADS_OPTION_PASSWORD_METHOD = 7;
        private const int ADS_PASSWORD_ENCODE_REQUIRE_SSL = 0;
        private const int ADS_PASSWORD_ENCODE_CLEAR = 1;
        #endregion

        #region static properties
        /// <summary>
        /// Pocet dni, po jejich uplinuti se musi zmenit heslo
        /// </summary>
        public static int MaxPasswordAge
        {
            get
            {
                if (_MaxPasswordAge == -1)
                    AdInit();

                return _MaxPasswordAge;
            }
        }
        private static int _MaxPasswordAge;

        /// <summary>
        /// Minimalni delka hesla
        /// </summary>
        public static int MinPasswordLength
        {
            get
            {
                if (_MinPasswordLength == -1)
                    AdInit();

                return _MinPasswordLength;
            }
        }
        private static int _MinPasswordLength;

        /// <summary>
        /// Pocet predchozich hesel, ktera nesmi byt stejna
        /// </summary>
        public static int PasswordHistoryLength
        {
            get
            {
                if (_PasswordHistoryLength == -1)
                    AdInit();

                return _PasswordHistoryLength;
            }
        }
        private static int _PasswordHistoryLength;

        /// <summary>
        /// Pocet dni, po ktere uzivatel nesmi zmenit heslo
        /// </summary>
        public static int MinPasswordAge
        {
            get
            {
                if (_MinPasswordAge == -1)
                    AdInit();

                return _MinPasswordAge;
            }
        }
        private static int _MinPasswordAge;
        #endregion

        #region inicializace
        /// <summary>
        /// Staticky konstruktor
        /// </summary>
        static AdRepository()
        {
            AdInit();
        }

        /// <summary>
        /// Inicializace statickych promenych tahanych z AD.
        /// </summary>
        private static void AdInit()
        {
            // instance konfigurace
            Configuration config = ConfigurationFactory.GetConfiguration();

            string ldapConnect = string.Format("LDAP://{0}/{1}", config.ADServer, config.ADContext);
            try
            {
                using (DirectoryEntry dirBase = new DirectoryEntry(ldapConnect, config.ADAdminLogin, config.ADAdminPassword))
                {
#if DEBUG
Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "AdInit", 5, string.Format("DirectoryEntry dirBase={0}", dirBase != null), config.EnvironmentType);
#endif
                    using (DirectorySearcher ds = new DirectorySearcher(dirBase, "(objectClass=*)", new string[] { "maxPwdAge", "minPwdAge", "minPwdLength", "pwdHistoryLength" }, SearchScope.Base))
                    {
                        SearchResult result = ds.FindOne();

#if DEBUG
                        Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "AdInit", 5, string.Format("SearchResult result={0}", result != null), config.EnvironmentType);
#endif

                        if (result != null)
                        {
                            // max pwd age
                            if (result.Properties.Contains("maxPwdAge"))
                            {
                                TimeSpan tsPassword = TimeSpan.FromTicks((long)result.Properties["maxPwdAge"][0]);
                                _MaxPasswordAge = Convert.ToInt32(Math.Abs(tsPassword.TotalDays));
                            }
                            else
                                _MaxPasswordAge = 0;

#if DEBUG
                            Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "AdInit", 5, string.Format("_MaxPasswordAge={0}", _MaxPasswordAge), config.EnvironmentType);
#endif

                            // min pwd age
                            if (result.Properties.Contains("minPwdAge"))
                            {
                                TimeSpan tsPassword2 = TimeSpan.FromTicks((long)result.Properties["minPwdAge"][0]);
                                _MinPasswordAge = Convert.ToInt32(Math.Abs(tsPassword2.TotalDays));
                            }
                            else
                                _MinPasswordAge = 0;

#if DEBUG
                            Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "AdInit", 5, string.Format("_MinPasswordAge={0}", _MinPasswordAge), config.EnvironmentType);
#endif

                            // min pwd length
                            if (result.Properties.Contains("minPwdLength"))
                                _MinPasswordLength = Convert.ToInt32(result.Properties["minPwdLength"][0]);
                            else
                                _MinPasswordLength = 0;

#if DEBUG
                            Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "AdInit", 5, string.Format("_MinPasswordLength={0}", _MinPasswordLength), config.EnvironmentType);
#endif

                            // history pwd length
                            if (result.Properties.Contains("pwdHistoryLength"))
                                _PasswordHistoryLength = Convert.ToInt32(result.Properties["pwdHistoryLength"][0]);
                            else
                                _PasswordHistoryLength = 0;

#if DEBUG
                            Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "AdInit", 5, string.Format("_PasswordHistoryLength={0}", _PasswordHistoryLength), config.EnvironmentType);
#endif
                        }
                    }
                }
            }
            catch (Exception err)
            {
                _MinPasswordLength = 0;
                _MaxPasswordAge = 0;
                _MinPasswordAge = 0;
                _PasswordHistoryLength = 0;

                // log
                Log.LoggerFactory.WriteLog(err, "MPSS.Security.AdRepository", "AdInit", 1, string.Format("connect={0}; login={1}; pass={2};", ldapConnect, config.ADAdminLogin, config.ADAdminPassword), 0, config.EnvironmentType);
            }
        }
        #endregion

        #region overeni uzivatele proti AD
        /// <summary>
        /// Funkce kontroluje, zda uzivatel s danym loginem existuje v Active Directory
        /// </summary>
        /// <param name="login">Login uzivatele do AD</param>
        /// <param name="password">Heslo uzivatele v AD</param>
        /// <returns>true, pokud se podarilo uzivatele autentifikovat</returns>
        public bool CheckUser(ref LoginUserResult result, string login, string password, Configuration config)
        {
            string ldapConnect = string.Format("LDAP://{0}/{1}{2}", config.ADServer, config.ADUsersBranch, config.ADContext);

#if DEBUG
Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "CheckUser", 5, string.Format("ldapConnect={0}", ldapConnect), config.EnvironmentType);
#endif

            try
            {
                using (DirectoryEntry dirUser = new DirectoryEntry(ldapConnect, config.ADAdminLogin, config.ADAdminPassword))
                {
                    using (DirectorySearcher ds = new DirectorySearcher(dirUser))
                    {
                        ds.PropertiesToLoad.Add("userAccountControl");
                        ds.PropertiesToLoad.Add("lockoutTime");
                        ds.PropertiesToLoad.Add("pwdLastSet");
                        ds.Filter = "(&(objectClass=user)(samAccountName=" + login + "))";

                        SearchResult dsResult = ds.FindOne();

#if DEBUG
                        Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "CheckUser", 5, string.Format("SearchResult dsResult={0}", dsResult != null), config.EnvironmentType);
#endif

                        // uzivatel byl nalezen
                        if (dsResult != null)
                        {
                            result.AccountState = LoginUserResultStateCodes.Found;

                            // kontrola spravneho vyplneni hesla oproti AD
                            #region overeni hesla uzivatele proti ad
                            bool isAuthenticated;
                            try
                            {
                                using (DirectoryEntry dirPwd = new DirectoryEntry(ldapConnect, login, password))
                                {
                                    object nativeObj = dirPwd.NativeObject;
                                    isAuthenticated = true;
                                }
                            }
                            catch (Exception err)
                            {
#if DEBUG
                                Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "CheckUser", 5, string.Format("isAuthenticated error={0}", err.Message), config.EnvironmentType);
#endif
                                isAuthenticated = false;
                            }
                            #endregion

#if DEBUG
                            Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "CheckUser", 5, string.Format("isAuthenticated={0} with login={1} and pwd={2};", isAuthenticated, login, password), config.EnvironmentType);
#endif

                            // kontrola nastaveni uctu v AD
                            if (LoginCheck.ADCheck(ref result, dsResult, isAuthenticated, config.EnvironmentType))
                            {
                                // vse v poradku
                                result.Success = true;
                                return true;
                            }
                            else
                            {
#if DEBUG
                                Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "CheckUser", 5, string.Format("LoginCheck.ADCheck failed"), config.EnvironmentType);
#endif
                                return false;
                            }
                        }
                        else // uzivatel nebyl nalezen v AD
                        {
                            result.ErrorCode = LoginUserResultErrorCodes.ADUserNotFound;
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // log
                Log.LoggerFactory.WriteLog(err, "MPSS.Security.AdRepository", "CheckUser", 1, ldapConnect, config.EnvironmentType);
            }

            // overeni se nepovedlo
            return false;
        }
        #endregion

        #region zmena hesla v AD
        /// <summary>
        /// Zmena hesla v AD
        /// </summary>
        /// <param name="oldPassword">Stare heslo</param>
        /// <param name="newPassword">Nove heslo</param>
        /// <returns></returns>
        public ChangePasswordResult ChangePassword(string oldPassword, string newPassword, Configuration config)
        {
            ChangePasswordResult result = new ChangePasswordResult();

            // ziskat instanci uzivatele
            IUser user = CookieRepository.GetSession(0, config);

            if (user != null)
            {
                AdLoginTypes loginType = LoginCheck.GetAdLoginType(user.CPM);
                string login;
                switch (loginType)
                {
                    case AdLoginTypes.RequiresBoth:
                        login = string.Format("{0}_{1}", user.CPM, user.ICP);
                        break;
                    default:
                        login = user.CPM;
                        break;
                }

#if DEBUG
                Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "ChangePassword", 5, string.Format("CPM:{0}; ICP:{1}; Login: {2};", user.CPM, user.ICP, login), config.EnvironmentType);
#endif

                // connection string na ldap
                string ldapConnect = string.Format("LDAP://{0}/{2}{1}", config.ADServer, config.ADContext, config.ADUsersBranch);

                try
                {
                    using (DirectoryEntry dirUser = new DirectoryEntry(ldapConnect, config.ADAdminLogin, config.ADAdminPassword))
                    {
                        using (DirectorySearcher ds = new DirectorySearcher(dirUser))
                        {
                            ds.PropertiesToLoad.Add("userAccountControl");
                            ds.PropertiesToLoad.Add("lockoutTime");
                            ds.Filter = "(&(objectClass=user)(samAccountName=" + login + "))";

                            SearchResult dsResult = ds.FindOne();

                            // uzivatel byl nalezen
                            if (dsResult != null)
                            {
                                // userAccountControl - nastaveni uctu v AD
                                int userAccountControl = 0;
                                if (dsResult.Properties.Contains("userAccountControl"))
                                    userAccountControl = Convert.ToInt32(dsResult.Properties["userAccountControl"][0]);

#if DEBUG
                                Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "ChangePassword", 5, string.Format("#1 userAccountControl: {0};", userAccountControl), config.EnvironmentType);
#endif

                                // uzivatel nesmi menit heslo
                                if ((userAccountControl & PASSWD_CANT_CHANGE) > 0)
                                {
                                    result.ErrorMessage = "Uživatel nemá právo měnit heslo";
                                    return result;
                                }
                                // uzamceny ucet
                                if (dsResult.Properties.Contains("lockoutTime"))
                                {
                                    if (Convert.ToInt64(dsResult.Properties["lockoutTime"][0]) != 0)
                                    {
                                        result.ErrorMessage = "Váš doménový účet je uzamčený";
                                        return result;
                                    }
                                }

                                // zmena hesla
                                try
                                {
                                    //DirectoryEntry entry = new DirectoryEntry(ldapConnect, login, oldPassword, AuthenticationTypes.Secure | AuthenticationTypes.Sealing | AuthenticationTypes.ServerBind);
                                    DirectoryEntry entry = new DirectoryEntry(ldapConnect, config.ADAdminLogin, config.ADAdminPassword, AuthenticationTypes.Secure | AuthenticationTypes.Sealing | AuthenticationTypes.ServerBind);
                                    DirectorySearcher search = new DirectorySearcher(entry);
                                    search.Filter = "(SAMAccountName=" + login + ")";

#if DEBUG
                                    Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "ChangePassword", 5, string.Format("#2 SAMA name: {0};", search.Filter), config.EnvironmentType);
#endif
                                    DirectoryEntry aduser = search.FindOne().GetDirectoryEntry();
                                    aduser.Invoke("SetOption", new object[] { ADS_OPTION_PASSWORD_PORTNUMBER, 389 });
                                    aduser.Invoke("SetOption", new object[] { ADS_OPTION_PASSWORD_METHOD, ADS_PASSWORD_ENCODE_CLEAR });
                                    aduser.Invoke("ChangePassword", new object[] { oldPassword, newPassword });
                                    aduser.CommitChanges();
                                }
                                catch (Exception err2) // nastala chyba pri zmene hesla
                                {
                                    long hresult = Math.Abs(System.Runtime.InteropServices.Marshal.GetHRForException(err2.InnerException));
#if DEBUG
                                    Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "ChangePassword", 5, string.Format("EXCEPTION hresult: {0}; Message: {1}; Base Message: {2};", hresult, err2.Message, err2.GetBaseException().Message), config.EnvironmentType);
#endif
                                    switch (hresult)
                                    {
                                        case 134246405:
                                            result.ErrorMessage = "Váš doménový účet je zamčený";
                                            return result;
                                        case 0:
                                            result.ErrorMessage = "Chybně zadané staré heslo";
                                            return result;
                                        case 2147944645:
                                            result.ErrorMessage = string.Format("Vaše nové heslo nesmí být shodné s jedním z {0} posledních hesel", AdRepository._PasswordHistoryLength);
                                            return result;
                                        case 2147016657:
                                            result.ErrorMessage = "Heslo nebylo možné změnit.";
                                            return result;
                                        default:
                                            result.ErrorMessage = string.Format("{0}: {1}", hresult, err2.Message);
                                            return result;
                                    }
                                }
                            }
                            else
                            {
                                // uzivatel nebyl podle loginu nalezen v AD
                                result.ErrorMessage = "Uživatel s tímto loginem nebyl nalezen";
                                return result;
                            }
                        }
                    }
                }
                catch (Exception err) // nepodarilo se prihlasit k AD
                {
                    Log.LoggerFactory.WriteLog(err, "MPSS.Security.AdRepository", "ChangePassword", 0, ldapConnect, config.EnvironmentType);
                    result.ErrorMessage = "Nastala neočekávaná chyba.";
                    return result;
                }
            }
            else // uzivatel nema platnou security cookie
            {
#if DEBUG
                Log.LoggerFactory.WriteLog("MPSS.Security.AdRepository", "ChangePassword", 5, "No valid security cookie has been found.", config.EnvironmentType);
#endif
                result.ErrorMessage = "Nastala neočekávaná chyba.";
                return result;
            }

            // vse probehlo bez problemu
            result.Success = true;
            return result;
        }
        #endregion

        /// <summary>
        /// Vraci datum z long hodnoty ulozene v AD
        /// </summary>
        /// <param name="ticks">Long v properties objektu v AD</param>
        /// <returns></returns>
        public static DateTime GetDateFromTicks(long ticks)
        {
            TimeZone zone = TimeZone.CurrentTimeZone;
            DateTime d = new DateTime(1601, 1, 1);
            return zone.ToLocalTime(d.Add(new TimeSpan(ticks)));
        }
    }
}
