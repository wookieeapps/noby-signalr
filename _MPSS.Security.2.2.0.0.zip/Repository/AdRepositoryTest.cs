﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Testovaci nahrada za AD
    /// </summary>
    internal class AdRepositoryTest : IAdRepository
    {
        #region static properties
        /// <summary>
        /// Pocet dni, po jejich uplinuti se musi zmenit heslo
        /// </summary>
        public int MaxPasswordAge
        {
            get
            {
                return 90;
            }
        }

        /// <summary>
        /// Minimalni delka hesla
        /// </summary>
        public int MinPasswordLength
        {
            get
            {
                return 2;
            }
        }

        /// <summary>
        /// Pocet predchozich hesel, ktera nesmi byt stejna
        /// </summary>
        public int PasswordHistoryLength
        {
            get
            {
                return 4;
            }
        }

        /// <summary>
        /// Pocet dni, po ktere uzivatel nesmi zmenit heslo
        /// </summary>
        public int MinPasswordAge
        {
            get
            {
                return 0;
            }
        }
        #endregion

        public bool CheckUser(ref LoginUserResult result, string login, string password, Configuration config)
        {
            result.PasswordExpiration = DateTime.Now.AddDays(-90);
            result.MandatoryToChangePassword = false;
            result.Success = true;
            result.ErrorCode = LoginUserResultErrorCodes.ADExpiredPwd;
            result.AccountState = LoginUserResultStateCodes.ExpiredPwd;

            return result.Success;
        }

        public ChangePasswordResult ChangePassword(string oldPassword, string newPassword, Configuration config)
        {
            return new ChangePasswordResult();
        }
    }
}
