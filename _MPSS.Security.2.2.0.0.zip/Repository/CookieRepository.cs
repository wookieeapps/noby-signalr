﻿using System;
using System.Web;
using System.Web.UI;

namespace MPSS.Security
{
    /// <summary>
    /// Repository pro praci s kolekci cookies.
    /// </summary>
    internal sealed class CookieRepository
    {
        /// <summary>
        /// Vrati spravne nastavenou cookie.
        /// </summary>
        private static HttpCookie SetupCookie(Configuration config)
        {
            HttpCookie cookie = new HttpCookie(config.CookieName);
            if (!string.IsNullOrEmpty(config.CookieDomainName))
                cookie.Domain = config.CookieDomainName;
            if (!string.IsNullOrEmpty(config.CookiePath))
                cookie.Path = config.CookiePath;
            cookie.HttpOnly = true;
            cookie.Secure = config.CookieOnlyHttps;

            return cookie;
        }

        /// <summary>
        /// Odstrani aktualne prihlaseneho uzivatel (SecurityCookie) z kolekce cookies.
        /// </summary>
        public static void RemoveCurrentSession(string sessionId, Configuration config)
        {
            HttpContext context = HttpContext.Current;

            // zapsat do logu odhlasenych sessions
            if (config.SaveLogoutRequest && !string.IsNullOrEmpty(sessionId))
            {
                RepositoryFactory.GetLogRepository(config).WriteLogoutInfo(sessionId, config);
            }

            // odstranit cookie z pocitace
            if (context.Request.Cookies[config.CookieName] != null)
            {
#if DEBUG
Log.LoggerFactory.WriteLog("CookieRepository", "RemoveCurrentSession", 5, "", config.EnvironmentType);
#endif
                // odstranit cookie z kolekce request
                context.Request.Cookies.Remove(config.CookieName);

                // odstranit cookie
                HttpCookie cookie = SetupCookie(config);
                cookie.Expires = DateTime.Now.AddDays(-1);
                context.Response.Cookies.Add(cookie);
            }
        }

        /// <summary>
        /// Ulozi instanci uzivatele do kolekce cookies. Pred ulozenim vytvori instanci SecurityCookie, ktera je nasledne ulozena do cookies.
        /// </summary>
        /// <param name="user">Instance uzivatele</param>
        public static void WriteSession(IUser user, CookieValidator validator, Configuration config)
        {
            HttpCookie cookie = GetCookieForWrite(user, validator, config);
            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        /// <summary>
        /// Vytvoreni instance HttpCookie pro zapsani do response
        /// </summary>
        /// <param name="user">Instance uzivatele (identity).</param>
        /// <param name="validator">Instance cookie validatoru.</param>
        /// <returns>Zasifrovana cookie pro ulozeni do response kolekce.</returns>
        public static HttpCookie GetCookieForWrite(IUser user, CookieValidator validator, Configuration config)
        {
            // vytvoreni cookie
            HttpCookie cookie = SetupCookie(config);
            if (config.PersistentCookie)
                cookie.Expires = DateTime.Now.AddMinutes(config.CookieExpiration);

            // zasifrovani objektu
            ISecurityCookieFormatter formatter = SecurityCookieFactory.GetFormatter(config);
            cookie.Value = formatter.Encode(user.Identity, validator);
            return cookie;
        }

        /// <summary>
        /// <para>Cte SecurityCookie soucasne prihlaseneho uzivatele.</para>
        /// <para>Zaroven overuje, zda pozadavek pochazi z povolene domeny - pokud ne, vraci prazdnou instanci uzivatele.</para>
        /// </summary>
        /// <param name="applicationId">ID volajici aplikace (0=neznama aplikace)</param>
        /// <returns>Vraci instanci uzivatele ze SecurityCookie. Pokud neni uzivatel autentifikovan, vraci IsAuthenticated=false.</returns>
        public static IUser GetSession(int applicationId, Configuration config)
        {
            HttpContext c = HttpContext.Current;
            
            // pokud cookie existuje
            if (c.Request.Cookies[config.CookieName] != null)
            {
                // vytvorit cookie validator - trida obsahujici validacni informace o pozadavku
                CookieValidator validator = new CookieValidator(c);

                // dekodovani cookie
                ISecurityCookieFormatter formatter = SecurityCookieFactory.GetFormatter(config);
                IUser user = formatter.Decode(c.Request.Cookies[config.CookieName].Value, validator);
                IdentityBase identity = (IdentityBase)user.Identity;

                // overeni ze id relace neni mezi odhlasenymi relacemi
                if (config.SaveLogoutRequest)
                {
                    // pokud je relace mezi odhlasenymi
                    if (!RepositoryFactory.GetDbRepository(config).CheckLogoutInfo(identity.SessionId))
                    {
                        Log.LoggerFactory.WriteLog(null, "MPSS.Security.Portal", "GetSession", 3, string.Format("CheckLogoutInfo() returns true for Session: {0}, User ID: {1}", identity.SessionId, identity.ID), applicationId, config.EnvironmentType);

                        return new UserBase();
                    }
                }

                // ziskani prav k aplikaci
                if (applicationId != 0)
                {
                    identity.SetPermissions(applicationId, config);
                    
                    if (identity.Permissions <= 0)
                        Log.LoggerFactory.WriteLog(null, "MPSS.Security.Portal", "GetSession", 3, string.Format("Permissions: {0}; User ID: {1}; IsAuthenticated: {2}" , identity.Permissions, identity.ID, identity.IsAuthenticated), applicationId, config.EnvironmentType);
                }

                return user;
            }
            else
            {
                Log.LoggerFactory.WriteLog(null, "MPSS.Security.Portal", "GetSession", 4, string.Format("Security Cookie not found."), applicationId, config.EnvironmentType);

                return new UserBase();
            }
        }
    }
}
