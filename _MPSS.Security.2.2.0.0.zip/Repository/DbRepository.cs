﻿using System;
using System.Data;
using System.Data.SqlClient;
using MPSS.Utils;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace MPSS.Security
{
    /// <summary>
    /// Repository pro MS SQL server
    /// </summary>
    internal sealed class DbRepository : IDbRepository
    {
        /// <summary>
        /// Pole specialnich loginu, ktere nemaji prochazet kontrolou na cpm a icp.
        /// </summary>
        private static string[] arrSpecialLogins;

        /// <summary>
        /// IP adresy ze kterych muze KB pristupovat na PMP.
        /// </summary>
        private static string[] arrKBadresses;

        private string ConnectionString;

        public DbRepository(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        /// <summary>
        /// Logovani pristupu na prihlasovaci obrazovku portalu.
        /// </summary>
        /// <param name="user"></param>
        public void PortalAccessSaveLog(IUser user, string ip, int environmentType)
        {
            DateTime d = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);

            CData data = new CData(this.ConnectionString);
            data.AddValue("v09cpm", user.CPM);
            data.AddValue("v09cp", user.ICP);
            data.AddValue("v09datum", DateTime.Now);
            data.AddValue("v09cas", Convert.ToInt32((DateTime.Now - d).TotalSeconds));
            data.AddValue("v09ip", ip);
            data.AddValue("v09environment_type", environmentType);
            if (user.LegacyS53ID > 0)
                data.AddValue("m04id", user.LegacyS53ID);
            if (user.LegacyV03ID > 0)
                data.AddValue("v03id", user.LegacyV03ID);
            if (user.LegacyV11ID > 0)
                data.AddValue("v11id", user.LegacyV11ID);

            data.ExecuteNonQuery(QueryType.Insert, "PMP.v09portal_temp");
        }

        /// <summary>
        /// Vraci seznam podrizenych pro daneho UG
        /// </summary>
        public List<UGposition> GetUGorTHSsubtree(int m04id)
        {
            CData data = new CData(this.ConnectionString);
            data.AddValue("id", m04id);
            DataTable dt = data.SelectDataSet("SELECT b.v33id, b.v33cpm, b.v33icp FROM xxvvss.dbo.REF_PROD_DOZ a INNER JOIN xxvvss.dbo.v33PMP_User b ON a.m04id=b.s53idlog WHERE a.m04idnad_ug=@id OR a.m04idnad_ths=@id").Tables[0];

            List<UGposition> model = new List<UGposition>();
            foreach (DataRow row in dt.Rows)
            {
                model.Add(new UGposition
                {
                    v33id = Convert.ToInt32(row["v33id"]),
                    CPM = row["v33cpm"].ToString(),
                    ICP = row["v33icp"].ToString()
                });
            }

            return model;
        }

        /// <summary>
        /// Naplni instanci uzivatele dle CPM a ICP
        /// </summary>
        public void GetDummyUserData(string cpm, string icp, IdentityBase identity)
        {
            CData data = new CData(this.ConnectionString);
            data.AddValue("cpm", cpm);
            data.AddValue("icp", icp);
            DataTable dt = data.SelectDataSet("SELECT * FROM xxvvss.dbo.v33PMP_User WHERE v33cpm=@cpm AND ISNULL(v33icp,'')=@icp").Tables[0];
            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];

                identity.CPM = row["v33cpm"].ToString();
                identity.ICP = row["v33icp"].ToString();
                identity.Name = row["v33prijmeni"].ToString();
                identity.ID = Convert.ToInt32(row["v33id"]);
                identity.LegacyS53ID = row.IsNull("s53idlog") ? 0 : Convert.ToInt32(row["v33id"]);
                identity.LegacyV03ID = row.IsNull("v03id") ? 0 : Convert.ToInt32(row["v03id"]);
                identity.LegacyV11ID = row.IsNull("v11id") ? 0 : Convert.ToInt32(row["v11id"]);
            }
            else
                throw new Exception("User Not Found");
        }

        /// <summary>
        /// Vraci true, pokud je dane CPM evidovane jako specialni login a neni subjektem pro kontrolu formatu CPM a ICP.
        /// <param name="cpm">Kontrolovane CPM.</param>
        /// </summary>
        public bool IsSpecialLogin(string cpm)
        {
            if (arrSpecialLogins == null)
            {
                CData data = new CData(this.ConnectionString);
                DataTable dt = data.SelectDataSet("SELECT login FROM xxvvss.dbo.PMP_SpecialLogin").Tables[0];

                arrSpecialLogins = new string[dt.Rows.Count];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    arrSpecialLogins[i] = dt.Rows[i][0].ToString();
                }
            }

            return Array.Exists<string>(arrSpecialLogins, t => t == cpm);
        }

        /// <summary>
        /// Vraci true, pokud IP adresa je adresou KB.
        /// </summary>
        /// <param name="ip">IP adresa pozadavku.</param>
        /// <returns></returns>
        public bool IsKBIP(string ip)
        {
            if (arrKBadresses == null)
            {
                CData data = new CData(this.ConnectionString);
                DataTable dt = data.SelectDataSet("SELECT ip_mask FROM xxvvss.dbo.PMP_KBIP").Tables[0];

                arrKBadresses = new string[dt.Rows.Count];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    arrKBadresses[i] = dt.Rows[i][0].ToString();
                }
            }

            // projit vsechny masky ip adres, pokud nejaka souhlasi - vrat true
            foreach (string kbip in arrKBadresses)
            {
                Regex reg = new Regex(kbip);
                if (reg.IsMatch(ip))
                    return true;
            }

            // pokud nebyla nalezena shoda
            return false;
        }

        /// <summary>
        /// Zapisuje vytvoreni pozadavku na autentikaci pro externi website.
        /// </summary>
        /// <param name="userId">ID uzivatele.</param>
        /// <param name="appId">ID volane aplikace.</param>
        /// <param name="guid">GUID pozadavku.</param>
        /// <returns>Vraci ID zapsaneho pozadavku do databaze.</returns>
        internal static int ExtAppAuthenticationRequest(int userId, int appId, string guid, int environmentType = 0)
        {
            Configuration config = ConfigurationFactory.GetConfiguration(environmentType);

            CData data = new CData(CommandType.StoredProcedure, config.DbConnectionString);
            data.AddValue("userId", userId);
            data.AddValue("applicationId", appId);
            data.AddValue("guid", guid);
            return Convert.ToInt32(data.SelectScalar("xxvvss.dbo.PMP_ExtAppAuthenticationRequest"));
        }

        /// <summary>
        /// Zjisti v databazi zda je prislusna zadost o validaci pozadavku na autentikaci pro externi website platna.
        /// </summary>
        /// <param name="id">ID pozadavku v databazi.</param>
        /// <returns>Vlastnosti pozadavku.</returns>
        internal static ExternalApplicationHandler.ValidationCheck ExtAppAuthenticationCheck(int id, int environmentType = 0)
        {
            Configuration config = ConfigurationFactory.GetConfiguration(environmentType);

            CData data = new CData(CommandType.StoredProcedure, config.DbConnectionString);
            data.AddValue("id", id);
            DataTable dt = data.SelectDataSet("xxvvss.dbo.PMP_ExtAppAuthenticationCheck").Tables[0];

            ExternalApplicationHandler.ValidationCheck v = new ExternalApplicationHandler.ValidationCheck();
            if (dt.Rows.Count == 0)
            {
                v.RequestTime = new DateTime(1900, 1, 1);
                v.Guid = "";
            }
            else
            {
                DataRow row = dt.Rows[0];
                v.Guid = row["guid"].ToString();
                v.RequestTime = Convert.ToDateTime(row["time"]);
            }
            return v;
        }

        /// <summary>
        /// Zapisuje informaci o odhlaseni uzivatele.
        /// </summary>
        /// <param name="sessionId">ID relace ze security cookie.</param>
        public void WriteLogoutInfo(string sessionId, Configuration c)
        {
            CData data = new CData(this.ConnectionString);
            data.AddValue("id", sessionId);
            data.AddValue("time", DateTime.Now);
            data.AddValue("Server", c.Server);
            data.AddValue("EnvironmentType", c.EnvironmentType);

            data.ExecuteNonQuery(QueryType.Insert, "PMP.Logout");
        }

        /// <summary>
        /// Vraci informaci zda soucasna relace neni mezi odhlasenymi relacemi.
        /// </summary>
        /// <param name="sessionId">ID relace ze security cookie.</param>
        /// <returns>true pokud je vse v poradku</returns>
        public bool CheckLogoutInfo(string sessionId)
        {
            if (!string.IsNullOrEmpty(sessionId))
            {
                CData data = new CData(CommandType.StoredProcedure, this.ConnectionString);
                data.AddValue("id", sessionId);
                return Convert.ToInt32(data.SelectScalar("xxvvss.dbo.PMP_LogoutCheck")) == 0;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Vraci informace o uzivateli vytahnute z tabulky uzivatelu na MS SQL. Pokud neni uzivatel nalezen, vraci null.
        /// </summary>
        /// <param name="cpm">CPM uzivatele</param>
        /// <param name="icp">ICP uzivatele</param>
        /// <returns>Instance uzivatele</returns>
        public IdentityBase GetUserDetail(string cpm, string icp)
        {
            AdLoginTypes logtype = LoginCheck.GetAdLoginType(cpm);

            CData data = new CData(CommandType.StoredProcedure, this.ConnectionString);
            data.AddValue("cpm", cpm);
            data.AddValue("icp", icp);
            data.AddValue("requiresIcp", logtype == AdLoginTypes.RequiresBoth);
            DataTable dt = data.SelectDataSet("xxvvss.dbo.PMP_Login").Tables[0];

            if (dt.Rows.Count == 0)
            {
                return null;
            }
            else
            {
                return CreateIdentityFromRow(dt.Rows[0]);
            }
        }

        private IdentityBase CreateIdentityFromRow(DataRow row)
        {
            IdentityBase identity = new IdentityBase(true);
            identity.CPM = row["v33cpm"].ToString();
            identity.ICP = row["v33icp"].ToString();
            identity.Name = string.Format("{1} {0}", row["v33jmeno"], row["v33prijmeni"]).Trim();
            // id's
            identity.ID = Convert.ToInt32(row["v33id"]);
            if (!row.IsNull("v03id"))
                identity.LegacyV03ID = Convert.ToInt32(row["v03id"]);
            if (!row.IsNull("v11id"))
                identity.LegacyV11ID = Convert.ToInt32(row["v11id"]);
            if (!row.IsNull("s53idlog"))
                identity.LegacyS53ID = Convert.ToInt32(row["s53idlog"]);

            return identity;
        }

        /// <summary>
        /// Vraci soucet prav pro uzivatele. Pokud se jedna o starou aplikaci, vraci mod.
        /// </summary>
        /// <param name="userId">ID uzivatele</param>
        /// <param name="applicationId">ID aplikace</param>
        /// <returns>Soucet prav nebo mod aplikace (pro stare aplikace). 0=nema prava.</returns>
        public GetUserPermissionsResult GetUserPermissions(IdentityBase user, int applicationId)
        {
            CData data = new CData(CommandType.StoredProcedure, this.ConnectionString);
            data.AddValue("v33id", user.ID);
            data.AddValue("v03id", user.LegacyV03ID);
            data.AddValue("v11id", user.LegacyV11ID);
            data.AddValue("s53id", user.LegacyS53ID);
            data.AddValue("v07id", applicationId);
            DataTable dt = data.SelectDataSet("xxvvss.dbo.PMP_Permission").Tables[0];
            DataRow row = dt.Rows[0];

            return new GetUserPermissionsResult(Convert.ToInt32(row["pravo"]), Convert.ToInt32(row["pravoJako"]));
        }

        /// <summary>
        /// Ulozeni informace o pristupu uzivatele k aplikaci
        /// </summary>
        /// <param name="user">Instance uzivatele</param>
        /// <param name="appId">ID aplikace (v07id)</param>
        /// <param name="ip">IP adresa</param>
        public void ApplicationAccessSaveLog(IUser user, int appId, string ip, int server, int environmentType)
        {
            CData data = new CData(this.ConnectionString);
            data.AddValue("v33id", user.ID);
            data.AddValue("cpm", user.CPM);
            data.AddValue("icp", user.ICP);
            data.AddValue("insert_time", DateTime.Now);
            data.AddValue("v07id", appId);
            data.AddValue("ip", ip);
            data.AddValue("EnvironmentType", environmentType);
            data.AddValue("Server", server);

            data.ExecuteNonQuery(QueryType.Insert, "PMP.AppAccess");
        }
    }
}
