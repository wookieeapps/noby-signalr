﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Interface pro AD repositorar kvuli testum
    /// </summary>
    internal interface IAdRepository
    {
        /// <summary>
        /// Kontrola prihlaseneho uzivatele
        /// </summary>
        /// <param name="result"></param>
        /// <param name="login"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        bool CheckUser(ref LoginUserResult result, string login, string password, Configuration config);

        /// <summary>
        /// Zmena hesla uzivatele v AD
        /// </summary>
        /// <param name="oldPassword">Stare heslo</param>
        /// <param name="newPassword">Novev heslo</param>
        /// <returns></returns>
        ChangePasswordResult ChangePassword(string oldPassword, string newPassword, Configuration config);
    }
}
