﻿using System;
using System.Collections.Generic;

namespace MPSS.Security
{
    /// <summary>
    /// Interface na databazovy repository
    /// </summary>
    internal interface IDbRepository
    {
        /// <summary>
        /// Vraci informace o uzivateli vytahnute z tabulky uzivatelu na MS SQL. Pokud neni uzivatel nalezen, vraci null.
        /// </summary>
        /// <param name="cpm">CPM uzivatele</param>
        /// <param name="icp">ICP uzivatele</param>
        /// <returns>Instance uzivatele</returns>
        IdentityBase GetUserDetail(string cpm, string icp);

        /// <summary>
        /// Vraci seznam podrizenych pro daneho UG
        /// </summary>
        List<UGposition> GetUGorTHSsubtree(int m04id);

        /// <summary>
        /// Naplni instanci uzivatele dle CPM a ICP
        /// </summary>
        void GetDummyUserData(string cpm, string icp, IdentityBase identity);

        /// <summary>
        /// Vraci soucet prav pro uzivatele. Pokud se jedna o starou aplikaci, vraci mod.
        /// </summary>
        /// <param name="user">Instance uzivatele</param>
        /// <param name="applicationId">ID aplikace</param>
        /// <returns>Soucet prav nebo mod aplikace</returns>
        GetUserPermissionsResult GetUserPermissions(IdentityBase user, int applicationId);

        /// <summary>
        /// Zapisuje informaci o odhlaseni uzivatele.
        /// </summary>
        /// <param name="sessionId">ID relace ze security cookie.</param>
        void WriteLogoutInfo(string sessionId, Configuration c);

        /// <summary>
        /// Vraci informaci zda soucasna relace neni mezi odhlasenymi relacemi.
        /// </summary>
        /// <param name="sessionId">ID relace ze security cookie.</param>
        /// <returns>true pokud je vse v poradku</returns>
        bool CheckLogoutInfo(string sessionId);

        /// <summary>
        /// Vraci true, pokud je dane CPM evidovane jako specialni login a neni subjektem pro kontrolu formatu CPM a ICP.
        /// <param name="cpm">Kontrolovane CPM.</param>
        /// </summary>
        bool IsSpecialLogin(string cpm);

        /// <summary>
        /// Vraci true, pokud IP adresa je adresou KB.
        /// </summary>
        /// <param name="ip">IP adresa pozadavku.</param>
        /// <returns></returns>
        bool IsKBIP(string ip);

        /// <summary>
        /// Ulozeni informace o pristupu uzivatele k aplikaci
        /// </summary>
        /// <param name="user">Instance uzivatele</param>
        /// <param name="appId">ID aplikace (v07id)</param>
        /// <param name="ip">IP adresa</param>
        void ApplicationAccessSaveLog(IUser user, int appId, string ip, int server, int environmentType);

        /// <summary>
        /// Ulozeni informace o pristupu uzivatele k aplikaci
        /// </summary>
        /// <param name="user">Instance uzivatele</param>
        /// <param name="environmentType">Typ prostredi</param>
        /// <param name="ip">IP adresa</param>
        void PortalAccessSaveLog(IUser user, string ip, int environmentType);
    }
}
