﻿using System;

namespace MPSS.Security
{
    /// <summary>
    /// Vraci aktualni implementaci repository (test/prod)
    /// </summary>
    internal static class RepositoryFactory
    {
        /// <summary>
        /// Vraci databazove repository.
        /// </summary>
        public static IDbRepository GetDbRepository(Configuration c)
        {
            return new DbRepository(c.DbConnectionString);
        }

        /// <summary>
        /// Vraci repository pro logovaci databazi
        /// </summary>
        public static IDbRepository GetLogRepository(Configuration c)
        {
            return new DbRepository(c.LogConnectionString);
        }

        /// <summary>
        /// Vraci repository pro Active Directory.
        /// </summary>
        /// <returns></returns>
        public static IAdRepository GetAdRepository()
        {
#if DebugProd
            return new AdRepository();
#elif Testinet
            return new AdRepository();
#elif DebugLocal
             return new AdRepositoryTest();
#elif DebugTomas
            return new AdRepositoryTest();
#elif DebugDevportal
            return new AdRepository();
#else
            return new AdRepository();
#endif
        }

        /// <summary>
        /// Pocet dni, po jejich uplinuti se musi zmenit heslo
        /// </summary>
        public static int MaxPasswordAge
        {
            get
            {
#if DebugProd
                return AdRepository.MaxPasswordAge;
#elif Testinet
                return AdRepository.MaxPasswordAge;
#elif DebugLocal
                return 90;
#elif DebugTomas
                return 90;
#elif DebugDevportal
                return AdRepository.MaxPasswordAge;
#else
                return AdRepository.MaxPasswordAge;
#endif
            }
        }

        /// <summary>
        /// Minimalni delka hesla
        /// </summary>
        public static int MinPasswordLength
        {
            get
            {
#if DebugProd
                return AdRepository.MinPasswordLength;
#elif Testinet
                return AdRepository.MinPasswordLength;
#elif DebugLocal
                return 4;
#elif DebugTomas
                return 4;
#elif DebugDevportal
                return AdRepository.MinPasswordLength;
#else
                return AdRepository.MinPasswordLength;
#endif
            }
        }

        /// <summary>
        /// Pocet predchozich hesel, ktera nesmi byt stejna
        /// </summary>
        public static int PasswordHistoryLength
        {
            get
            {
#if DebugProd
                return AdRepository.PasswordHistoryLength;
#elif Testinet
                return AdRepository.PasswordHistoryLength;
#elif DebugLocal
                return 4;
#elif DebugTomas
                return 4;
#elif DebugDevportal
                return AdRepository.PasswordHistoryLength;
#else
                return AdRepository.PasswordHistoryLength;
#endif
            }
        }

        /// <summary>
        /// Pocet dni, po ktere uzivatel nesmi zmenit heslo
        /// </summary>
        public static int MinPasswordAge
        {
            get
            {
#if DebugProd
                return AdRepository.MinPasswordAge;
#elif Testinet
                return AdRepository.MinPasswordAge;
#elif DebugLocal
                return 2;
#elif DebugTomas
                return 2;
#elif DebugDevportal
                return AdRepository.MinPasswordAge;
#else
                return AdRepository.MinPasswordAge;
#endif
            }
        }
    }
}
