﻿/// <summary>
/// <para>Namespace obsahujici tridy pro autentikaci uzivatele v Active Directory, jeho prihlaseni do PMP a naslednou autorizaci v jednotlivych aplikacich.</para>
/// </summary>
/// <author>Filip Tuma</author>
namespace MPSS.Security
{
}
