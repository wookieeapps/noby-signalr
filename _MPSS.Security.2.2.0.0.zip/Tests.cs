﻿using System;
using System.Web;
using System.Text;
using System.Security.Policy;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace MPSS.Security
{
    public class Tests
    {
        public static string ErrorMessage;

        public static bool TestCookieFormat(string cookieValue, Configuration config = null, int environmentType = 0)
        {
            ErrorMessage = "";
            if (config == null)
                config = ConfigurationFactory.GetConfiguration(environmentType);

            byte[] dec;
            try
            {
                byte[] b = Convert.FromBase64String(cookieValue);
                // dekryptovat retezec z cookie
                dec = CryptoFactory.GetCryptoProvider(config).Decrypt(b);
            }
            catch (Exception err) // chyba pri dekodovani
            {
                ErrorMessage += "Decryption: " + err.Message + "\n\n";
                return false;
            }

            // deserializace retezce
            SecurityCookie cookie;
            try
            {
                string s1 = System.Text.UTF8Encoding.UTF8.GetString(dec);
                ErrorMessage += s1 + "\n\n";

                cookie = SecurityCookie.GetFromString(s1);

                ErrorMessage += "LastUpdate = " + cookie.LastUpdate + "\n";
                ErrorMessage += "IP = " + cookie.IP + "\n";
                ErrorMessage += "UserAgent = " + cookie.UserAgent + "\n";
                ErrorMessage += "Identity = " + cookie.Identity + "\n";
            }
            catch (Exception err) // chyba pri deserializace
            {
                ErrorMessage += "Deserialization: " + err.Message + "\n\n";
                return false;
            }

            return true;
        }
    }
}