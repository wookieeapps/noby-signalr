var e={methods:{update(e,t){this.$emit(`input`,{...this.value,[e]:t})}}};export{e as t};
//# sourceMappingURL=MixinUpdateModel-BavNDMZw.js.map