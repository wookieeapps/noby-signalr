<template>
  <v-app>
    <layout-main-menu v-model="drawer" :items="menuItems" />
    <layout-app-bar @drawer="drawer = !drawer">
      <template #center>
        <v-autocomplete
          v-if="canSearch"
          flat
          no-filter
          hide-details
          hide-no-data
          v-model="searchTerm"
          item-text="Name"
          item-value="Id"
          return-object
          :cache-items="false"
          :search-input.sync="searchValue"
          :items="searchItems"
          :loading="searchLoading"
          placeholder="Vyhledat uživatele..."
          prepend-inner-icon="search"
          style="max-width: 350px"
          class="hidden-sm-and-down"
          @change="onSearch"
          :menu-props="{ maxHeight: 600, bottom: true }"
        >
          <template v-slot:item="{ item }">
            <v-list-item-icon>
              <v-icon v-if="item.HStatus != 0">person_add</v-icon>
            </v-list-item-icon>
            <v-list-item-content>
              <v-list-item-title v-text="item.Name"></v-list-item-title>
              <v-list-item-subtitle v-if="item.CPM">{{ item.CPM }}</v-list-item-subtitle>
            </v-list-item-content>
          </template>
        </v-autocomplete>
      </template>

      <template #userMenu>
        <v-list subheader>
          <v-subheader>ID: {{ userId }} ({{ userPerm }})</v-subheader>
          <v-divider />
          <v-list-item-group v-model="usermenu">
            <v-list-item @click="usermenuClick('Impersonate')" v-if="canImpersonate">
              <v-list-item-content>
                <v-list-item-title>Impersonizace</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
            <v-list-item @click="usermenuClick('Dashboard')">
              <v-list-item-content>
                <v-list-item-title>Odhlásit se</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
            <v-list-item href="https://intranet.mpss.cz/Aplikace/Stranky/default.aspx">
              <v-list-item-content>
                <v-list-item-title>Zpět na aplikace</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
        </v-list>
      </template>
    </layout-app-bar>
    <layout-content>
      <keep-alive :include="keepAliveComponents" :max="2">
        <router-view />
      </keep-alive>
    </layout-content>
  </v-app>
</template>

<script>
import { usersApi } from "@/code/apiServices";
import { UserWorkflowStatuses } from "@mpss/hiring-api";
import { UserRoles, UserRolesGroups, Helpers } from "@mpss/eporadce-common";
import { LayoutAppBar, LayoutContent, LayoutMainMenu } from "@mpss/eporadce-common-vue";

export default {
  name: "App",

  data() {
    return {
      usermenu: null,
      userId: 0,
      userPerm: 0,
      drawer: true,
      menuItems: [],
      // search
      searchValue: null,
      searchTerm: "",
      searchLoading: false,
      searchItems: []
    };
  },

  components: {
    LayoutAppBar,
    LayoutContent,
    LayoutMainMenu
  },

  mounted() {
    this.$router.onReady(() => {
      this.$user.get().then((t) => {
        this.userId = t.Id;
        this.userPerm = t.UserRoles;

        const routeName = this.$route.name || "";

        const items = [{ icon: "dashboard", text: "Dashboard", link: { name: "Dashboard" } }];

        // mass approve
        if (this.$user.isInRoleGroup(UserRolesGroups.Hiring))
          items.push({ icon: "thumb_up", text: "Schvalování", link: { name: "TicketsMassApproval" } });

        // seznam a vyhledavani v uzivatelich
        if (this.$user.isInRoleGroup(UserRolesGroups.CanSearchInUsers)) {
          items.push({
            icon: "supervised_user_circle",
            text: "Uživatelé",
            link: { name: "UserListWithFilter" }
          });
        } else {
          items.push({
            icon: "person",
            text: "Můj profil",
            link: {
              name: this.$user.isInRole(UserRoles.Employee) ? "EmployeeDetail" : "UserDetail",
              params: { id: this.userId }
            }
          });
        }

        // seznam smazanych uzivatelu
        if (this.$user.isInRoles([UserRoles.HiringSupervisor, UserRoles.HiringController, UserRoles.ReadOnlyUserList, UserRoles.eOlaAdmin, UserRoles.eOlaAttendeeManager, UserRoles.eOlaLector])) {
          items.push({
            icon: "person_remove",
            text: "Ukončení uživatelé",
            link: { name: "UserListDeleted" }
          });
        }

        // eOla
        if (this.$user.isInRoles([UserRoles.eOlaAdmin, UserRoles.eOlaLector, UserRoles.eOlaAttendeeManager])) {
          const eOlaMenu = {
            icon: "school",
            text: "Vzdělávání",
            model: routeName.startsWith("eOla"),
            children: []
          };

          // kurzy
          if (this.$user.isInRoles([UserRoles.eOlaAdmin])) {
            eOlaMenu.children.push({
              text: "Kurzy",
              link: { name: "eOlaCoursesTree" }
            });
          }

          // termíny
          if (this.$user.isInRoles([UserRolesGroups.eOla])) {
            eOlaMenu.children.push({
              text: "Termíny",
              link: { name: "eOlaCourseEventList" }
            });
          }

          // administrace
          if (this.$user.isInRoles([UserRolesGroups.eOla])) {
            eOlaMenu.children.push({
              text: "Číselníky",
              link: { name: "eOlaListsAdministration" }
            });
          }


          items.push(eOlaMenu);
        }

        // hiring
        if (this.$user.isInRoleGroup(UserRolesGroups.Hiring)) {
          const hiringMenu = {
            icon: "person_add",
            text: "Zasmluvnění",
            model: routeName.startsWith("Hiring"),
            children: []
          };

          // novy FP
          if (!this.$user.isInRoles([UserRoles.HiringApprovers904906, UserRoles.HiringApprovers903998])) {
            hiringMenu.children.push({
              text: "Nový poradce",
              link: { name: "HiringInitiation" }
            });
          }
          // seznam FP
          hiringMenu.children.push({
            text: "Seznam poradců",
            link: { name: "HiringUserList" }
          });

          if (this.$user.isInRole(UserRoles.HiringSupervisor)) {
            // seznam smazanych
            hiringMenu.children.push({
              text: "Smazaní FP",
              link: { name: "HiringDeletedList" }
            });
            // administrace
            hiringMenu.children.push({
              text: "Administrace",
              link: { name: "HiringAdministration" }
            });
          }

          items.push(hiringMenu);
        }

        // global admin
        if (this.$user.isInRole(UserRoles.AppAdministrator)) {
          const globadminMenu = {
            icon: "settings",
            text: "Administrace",
            model: routeName.startsWith("GlobAdmin"),
            children: [
              {
                text: "Číselníky",
                link: { name: "GlobalAdminLists" }
              },
              {
                text: "Šablony emailu",
                link: { name: "GlobalAdminEmailTemplates" }
              }
            ]
          };

          items.push(globadminMenu);
        }

        this.menuItems = items;
      });
    });
  },

  watch: {
    searchValue(val) {
      val && this.searchForUser(val);
    }
  },

  computed: {
    canImpersonate() {
      if (this.userId === 0 || !this.$user.loaded) return false;
      return process.env.VUE_APP_MODE != "production" || this.$user.isInRole(UserRoles.AppAdministrator);
    },

    keepAliveComponents() {
      return ["eOlaCoursesTree", "UserListWithFilter"];
    },

    canSearch() {
      if (this.userId === 0) return false;
      return this.$user.isInRoleGroup(UserRolesGroups.CanSearchInUsers);
    }
  },

  methods: {
    usermenuClick(route) {
      this.$router.push({ name: route });
      this.usermenu = null;
    },

    searchForUser(term) {
      this.searchLoading = true;
      Helpers.debounce((term) => {
        if (term != this.searchValue) return;
        usersApi.GetGeneralSearch(term).then((t) => {
          this.searchItems = t || [];
          this.searchLoading = false;
        });
      }, 400)(term);
    },

    onSearch(user) {
      if ((user.Roles & UserRoles.Employee) > 0) {
        // zamestnanec
        this.$router.push({ name: "EmployeeDetail", params: { id: user.Id } });
      } else if (![UserWorkflowStatuses.None, UserWorkflowStatuses.Seated].includes(user.HStatus)) {
        // zasmluvneni - uzivatel jeste neni aktivni
        this.$router.push({ name: "HiringUserDetail", params: { id: user.Id } });
      } else {
        this.$router.push({ name: "UserDetail", params: { id: user.Id } });
      }

      //TODO jeste nastavit menu?

      this.searchValue = null;
      this.searchItems = [];
      this.searchTerm = "";
    }
  }
};
</script>

<style lang="scss">
@import "@/scss/app.scss";
</style>
