<template>
  <div>
    <v-card>
      <v-card-title class="justify-space-between">
        <span>Seznam tagů souborů</span>
        <div>
          <v-btn color="primary" text tile small @click.stop="itemEdit()">Nový tag</v-btn>
        </div>
      </v-card-title>

      <app-box-loader v-if="items === null" />

      <app-box-no-entries v-else-if="items.length === 0">Nejsou uloženy žádné tagy</app-box-no-entries>

      <v-card-text class="pa-0" v-else>
        <v-simple-table>
          <template v-slot:default>
            <thead>
              <tr>
                <th class="text-left">Název tagu</th>
                <th class="text-left">Objekt</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in items" :key="item.Id">
                <td>{{ item.Name }}</td>
                <td>{{ getObjectType(item.ObjectTypeId) }}</td>
                <td class="text-right">
                  <v-btn icon class="mr-2">
                    <v-icon small @click="itemEdit(item.Id)">edit</v-icon>
                  </v-btn>
                  <v-btn icon>
                    <v-icon small @click="itemDelete(item.Id)">delete</v-icon>
                  </v-btn>
                </td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-card-text>
    </v-card>

    <v-dialog v-model="dialog" max-width="500px">
      <v-card>
        <v-card-title>
          <span class="headline">Editace tagu</span>
        </v-card-title>
        <v-card-text>
          <v-text-field label="Název tagu" v-model="model.Name" :error-messages="validateField('Name')" />
          <v-select
            label="Objekt"
            v-model="model.ObjectTypeId"
            :items="filteredObjectTypes"
            item-text="Text"
            item-value="Id"
            :error-messages="validateField('ObjectTypeId')"
          />
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="gray" text @click="dialog = false">Storno</v-btn>
          <v-btn color="green" text @click="itemSave" :loading="saveLoading">Uložit</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import { tagsApi, commonListsApi } from "@/code/apiServices";
import { ObjectTypes } from "@mpss/eporadce-common";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";

export default {
  name: "FileTagsAdmin",

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      items: null,
      dialog: false,
      model: {},
      saveLoading: false,
      objectTypes: null
    };
  },

  async mounted() {
    this.objectTypes = await commonListsApi.GetObjectTypes(0);
    this.items = await tagsApi.GetList(0);
  },

  computed: {
    filteredObjectTypes() {
      if (this.objectTypes == null) return [];
      // zatim natvrdo jen pro Uzivatel
      return this.objectTypes.filter((t) => t.Id == ObjectTypes.User);
    }
  },

  methods: {
    getObjectType(id) {
      const o = this.objectTypes.find((t) => t.Id == id);
      return o ? o.Text : "";
    },

    // Smazani sekvence
    async itemDelete(id) {
      if (
        await this.$confirm("Opravdu si přejete smazat tento tag?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        if (this.resolveSubResult(await tagsApi.Delete(id, "Tag nebylo možné smazat"))) {
          this.$delete(
            this.items,
            this.items.findIndex((t) => t.Id === id)
          );
        }
      }
    },

    // zobrazeni detailu sekvence
    async itemEdit(id) {
      this.model = id ? this.items.find((t) => t.Id == id) : tagsApi.CreateEmptyModel();

      this.dialog = true;
    },

    // ulozeni sekvence
    async itemSave() {
      this.saveLoading = true;

      const result =
        this.model.Id > 0 ? await tagsApi.Edit(this.model, this.model.Id) : await tagsApi.Create(this.model);

      if (this.resolveSubResult(result, "Tag nebylo možné uložit", "")) {
        this.dialog = false;

        // nove ID
        if (this.model.Id === 0) this.model.Id = parseInt(result);

        // index objektu v gridu
        const index = this.items.findIndex((t) => t.Id == this.model.Id);

        // updatovat grid
        if (index >= 0) this.$set(this.items, index, this.model);
        else this.items.push(this.model);

        this.$toast.success("Tag byl uložena");
      }

      this.saveLoading = false;
    }
  }
};
</script>
