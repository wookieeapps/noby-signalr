<template>
  <div>
    <email-templates :application-id="appId" />
  </div>
</template>

<script>
import { ApplicationIdTypes } from "@mpss/eporadce-common";
import EmailTemplates from "../../components/EmailTemplates.vue";

export default {
  name: "GlobalAdminEmailTemplates",

  components: { EmailTemplates },

  computed: {
    appId() {
      return ApplicationIdTypes.User;
    }
  }
};
</script>
