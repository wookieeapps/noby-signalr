<template>
  <div>
    <v-tabs background-color="transparent" class="mb-5" v-model="tab">
      <v-tab :key="0">Tagy souborů</v-tab>
    </v-tabs>

    <v-tabs-items v-model="tab" style="background-color: transparent;">
      <v-tab-item :key="0">
        <file-tags-admin />
      </v-tab-item>
    </v-tabs-items>
  </div>
</template>

<script>
import FileTagsAdmin from "../components/FileTagsAdmin.vue";

export default {
  name: "GlobalAdminLists",

  components: { FileTagsAdmin },

  data() {
    return {
      tab: null
    };
  },

  async mounted() {
    if (this.id) {
      this.tab = this.id;
    }
  }
};
</script>
