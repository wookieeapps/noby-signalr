const GlobalAdminLists = () => import(/* webpackChunkName: "GlobalAdmin" */ "../pages/GlobalAdminLists.vue");
const GlobalAdminEmailTemplates = () =>
  import(/* webpackChunkName: "GlobalAdmin" */ "../pages/GlobalAdminEmailTemplates.vue");

export default [
  {
    path: "/administration/lists",
    name: "GlobalAdminLists",
    component: GlobalAdminLists
  },
  {
    path: "/administration/email-templates",
    name: "GlobalAdminEmailTemplates",
    component: GlobalAdminEmailTemplates
  }
];
