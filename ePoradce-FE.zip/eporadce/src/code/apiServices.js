import { HttpClientFactory } from "@mpss/eporadce-common-vue";
import * as apis from "@mpss/eporadce-common-api";

// create single axios instance
const httpClient = HttpClientFactory(
  process.env.VUE_APP_API_BASE_PATH,
  process.env.VERSION,
  process.env.VUE_APP_FRONTEND_BASE_PATH + "not-authenticated"
);

export default httpClient;

// vytvoreni globalnich instanci jednotlivych API
export const userGroupsApi = new apis.UserGroupsApi(httpClient);
export const fileInfoApi = new apis.FileInfoApi(httpClient);
export const emailTemplatesApi = new apis.EmailTemplatesApi(httpClient);
export const queryBuilderApi = new apis.QueryBuilderApi(httpClient);
export const usersApi = new apis.UsersApi(httpClient);
export const usersExtendedApi = new apis.UsersExtendedApi(httpClient);
export const commonListsApi = new apis.CommonListsApi(httpClient);
export const placesApi = new apis.PlacesApi(httpClient);
export const impersonateApi = new apis.ImpersonateApi(httpClient);
export const ticketsApi = new apis.TicketsApi(httpClient);
export const pmpAppsApi = new apis.PmpAppsApi(httpClient);
export const tagsApi = new apis.TagsApi(httpClient);
export const dashboardApi = new apis.DashboardApi(httpClient);
