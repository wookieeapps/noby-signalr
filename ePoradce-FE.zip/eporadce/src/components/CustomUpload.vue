<template>
  <div>
    <div>
      <v-btn tile small @click="addFiles" :class="errorMessages ? 'red--text' : ''"
        ><v-icon small>add</v-icon>{{ buttonText }}</v-btn
      >
      <input type="file" style="display: none;" multiple id="CustomUpload_File1" @change="filesInputChange" />
    </div>

    <div v-if="errorMessages" class="red--text caption pt-2">{{ errorMessages.join("; ") }}</div>

    <v-list class="py-0">
      <v-scroll-x-transition group>
        <v-list-item v-for="(file, index) in files" :key="index">
          <v-list-item-icon class="mt-4">
            <v-icon :color="filesIconColor(file)">attachment</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>
              <a :href="getDownloadUrl(file.SystemFileName)" class="filelist-link">{{ file.OriginalFileName }}</a>
            </v-list-item-title>
          </v-list-item-content>
          <v-list-item-action v-if="!file.IsReadonly">
            <v-btn icon small @click="filesDelete(file)" v-if="filesIsDeleteVisible(file)">
              <v-icon color="error">remove_circle</v-icon>
            </v-btn>
          </v-list-item-action>
          <div style="position: absolute; top: 0; left: 16px; right: 16px;" v-if="file.State === 2">
            <v-progress-linear active indeterminate color="deep-purple accent-4" />
          </div>
        </v-list-item>
      </v-scroll-x-transition>
    </v-list>
  </div>
</template>

<script>
import { fileInfoApi } from "@/code/apiServices";
import MixinFileUpload from "@/mixins/MixinFileUpload";

export default {
  name: "CustomUpload",

  props: ["value", "objectTypeId", "objectId", "buttonText", "errorMessages", "readonly"],

  mixins: [MixinFileUpload],

  async mounted() {
    if (this.objectId) {
      const result = await fileInfoApi.GetList(this.objectTypeId, this.objectId, 0, 999);
      this.files = result.Data ?? [];

      // existujici soubory jsou pouze readonly
      if (this.readonly)
        this.files.forEach((t) => {
          t.IsReadonly = true;
        });
    }
  },

  methods: {
    /**
     * Kliknuti na tlacitko pridani souboru - jen programove klikne na hidden input file
     */
    addFiles(ev) {
      document.getElementById("CustomUpload_File1").click();
    },

    filesUpdateParent() {
      this.$emit(
        "input",
        this.files.map((t) => t.Id)
      );
    }
  }
};
</script>
