<template>
  <component
    :is="loadedComponent"
    :object-types="objectTypes"
    :application-id="applicationId"
    :id="id"
    @load="onLoad"
  />
</template>

<script>
import { emailTemplatesApi } from "@/code/apiServices";

export default {
  name: "EmailTemplates",

  props: {
    applicationId: {
      type: Number,
      default: 0
    }
  },

  data() {
    return {
      id: null,
      page: null,
      objectTypes: null
    };
  },

  async mounted() {
    this.page = "list";

    // object types
    this.objectTypes = await emailTemplatesApi.GetObjectTypes(this.applicationId);
  },

  computed: {
    loadedComponent() {
      switch (this.page) {
        case "list":
          return () => import(/* webpackChunkName: "email-templates-list" */ "./EmailTemplatesList.vue");
        case "detail":
          return () => import(/* webpackChunkName: "email-templates-detail" */ "./EmailTemplatesDetail.vue");
      }
      return null;
    }
  },

  methods: {
    onLoad(page, id) {
      this.id = id;
      this.page = page;
    }
  }
};
</script>
