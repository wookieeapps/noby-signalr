<template>
  <div>
    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-card>
        <v-card-title>
          <v-icon class="mr-2" color="grey lighten-2" v-if="model.IsReadonly">lock</v-icon>
          ÚDAJE O ŠABLONĚ
        </v-card-title>
        <v-divider />
        <v-card-text>
          <v-text-field
            label="Název šablony"
            :disabled="model.IsReadonly"
            :error-messages="validateField('Name')"
            v-model="model.Name"
          />

          <v-row v-if="!model.IsReadonly">
            <v-col cols="6">
              <v-select
                v-model="objectTypeId"
                :items="objectTypes"
                item-text="Text"
                item-value="Id"
                label="Šablona určená pro objekt typu"
                :error-messages="validateField('ObjectTypeId')"
              />
            </v-col>
            <v-col cols="6">
              <v-select
                v-model="model.EmailTemplateType"
                :items="templateTypes"
                item-text="Text"
                item-value="Id"
                :loading="templateTypesLoading"
                label="Šablona určená pro typ události"
                :error-messages="validateField('EmailTemplateType')"
              />
            </v-col>
          </v-row>

          <v-select
            v-model="model.FileTypes"
            :items="fileInfoTypes"
            item-text="Name"
            item-value="Id"
            label="Typy souborů pro šablonu"
            multiple
            hide-details=""
            chips
            :error-messages="validateField('FileTypes')"
          />
        </v-card-text>
      </v-card>

      <v-card class="mt-6">
        <v-subheader>PŘEDMĚT EMAILU</v-subheader>
        <v-card-text class="pt-0">
          <v-text-field :error-messages="validateField('Subject')" v-model="model.Subject" v-tribute />
        </v-card-text>
      </v-card>

      <v-card class="mt-6">
        <froala id="Text" :tag="'textarea'" :config="editorOptions" v-model="model.Text"></froala>
      </v-card>

      <v-card v-if="configuration" class="mt-6">
        <v-subheader>ZÁSTUPNÉ ZNAKY TEXTU EMAILU</v-subheader>
        <v-card-text class="pt-0">
          <v-row v-for="(field, index) in configuration.Fields" :key="index" class="align-center">
            <v-col cols="2" class="font-weight-bold overline pb-1 pt-0 black--text">
              <span class="primary--text">#</span>{{ field.Name }}
            </v-col>
            <v-col cols="8" class="pb-1 pt-0 caption">{{ field.Description }}</v-col>
          </v-row>
        </v-card-text>
      </v-card>
    </div>

    <div class="text-right pa-4">
      <v-btn text tile @click="$emit('load', 'list')">Zpět na seznam</v-btn>
      <v-btn tile color="success" :disabled="model == null" @click="saveTemplate" :loading="saveBtnLoading"
        >Uložit</v-btn
      >
    </div>
  </div>
</template>

<script>
import { emailTemplatesApi, fileInfoApi, commonListsApi } from "@/code/apiServices";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
// inlcude Froala editor
import "froala-editor/css/froala_editor.pkgd.min.css";
import Froala from "@/components/Froala.vue";
// include Froala plugins
import "froala-editor/js/plugins/colors.min.js";
import "froala-editor/js/plugins/link.min.js";
// include Tribute
import Tribute from "tributejs";

const tributeEditor = new Tribute({
  values: [],
  trigger: "#",
  noMatchTemplate: () => '<span style:"visibility: hidden;"></span>',
  menuItemTemplate: (item) => item.original.Description,
  selectTemplate: (item) =>
    `<span class="fr-deletable fr-tribute caption mention" contenteditable="false" data-prop="${item.original.PropertyPath}">#${item.original.Name}</span>`
});

const tributeSubject = new Tribute({
  values: [],
  trigger: "#",
  noMatchTemplate: () => '<span style:"visibility: hidden;"></span>',
  menuItemTemplate: (item) => item.original.Description,
  selectTemplate: (item) => "#" + item.original.Name
});

export default {
  name: "EmailTemplatesDetail",

  components: {
    Froala
  },

  props: ["applicationId", "id", "objectTypes"],

  mixins: [MixinResolveGeneralResult],

  directives: {
    tribute: {
      inserted: function (el) {
        tributeSubject.attach(el.querySelector("input"));
      }
    }
  },

  data() {
    return {
      model: null,
      fileInfoTypes: null,
      templateTypes: null,
      templateTypesLoading: false,
      // template/object type configuration
      configuration: null,
      // Froala options
      editorOptions: {
        events: {
          initialized: function () {
            var editor = this;
            tributeEditor.attach(editor.el);
            editor.events.on(
              "keydown",
              function (e) {
                if (e.which == 13 && tributeEditor.isActive) {
                  return false;
                }
              },
              true
            );
          }
        },
        placeholderText: "Text emailu...",
        toolbarButtons: [
          ["bold", "italic", "underline", "strikeThrough", "subscript", "superscript"],
          ["textColor", "backgroundColor"],
          ["insertLink"]
        ]
      }
    };
  },

  async mounted() {

    // ID editovane sablony
    const templateId = this.id ? Number(this.id) : 0;
    // detail sablony
    this.model = templateId > 0 ? await emailTemplatesApi.Get(templateId) : emailTemplatesApi.CreateEmptyModel();

    // file types
    this.fileInfoTypes = await fileInfoApi.GetFileInfoTypes(this.objectTypeId);

    this.configuration = this.model.Configuration;
  },

  computed: {
    objectTypeId: {
      get() {
        if (this.model === null) return null;
        return this.model.ObjectTypeId;
      },
      set(v) {
        this.model.ObjectTypeId = Number(v);
      }
    }
  },

  watch: {
    async objectTypeId(ev) {
      this.templateTypesLoading = true;
      this.templateTypes = await commonListsApi.GetEmailTemplateTypes(this.model.ObjectTypeId);
      this.templateTypesLoading = false;

      // nastaveni informaci o dostupnych polich
      if (this.model.ObjectTypeId && !this.model.Configuration) {
        this.configuration = await emailTemplatesApi.GetConfiguration(
          this.model.ObjectTypeId,
          this.model.EmailTemplateType
        );

        if (this.configuration) {
          tributeEditor.append(0, this.configuration.Fields, true);
          tributeSubject.append(0, this.configuration.Fields, true);
        }
      }
    }
  },

  methods: {
    /**
     * Ulozeni skupiny
     */
    async saveTemplate() {
      this.onBeforeSave();

      const result =
        this.model.Id > 0
          ? await emailTemplatesApi.Edit(this.model, this.model.Id)
          : await emailTemplatesApi.Create(this.model);

      if (await this.resolveGeneralResult(result, "", "Šablona emailu byla uložena", "Změny nebylo možné uložit")) {
        this.$emit("load", "list", parseInt(result));
      }
    }
  }
};
</script>
