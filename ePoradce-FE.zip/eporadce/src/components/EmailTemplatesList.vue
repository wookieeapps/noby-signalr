<template>
  <v-card>
    <v-card-title class="justify-space-between">
      <span>Seznam šablon emailů</span>
      <div v-if="objectTypes && objectTypes.length > 0">
        <v-btn color="primary" text tile small @click.stop="$emit('load', 'detail')">Nová šablona</v-btn>
      </div>
    </v-card-title>
    <v-divider />

    <app-box-loader v-if="emailTemplates === null" />

    <app-box-no-entries v-else-if="emailTemplates.length === 0">Nejsou uloženy žádné šablony</app-box-no-entries>

    <v-card-text class="pa-0" v-else>
      <v-simple-table>
        <template v-slot:default>
          <tbody>
            <tr v-for="item in emailTemplates" :key="item.Id">
              <td>
                <v-icon class="mr-2" color="grey lighten-2" v-if="item.IsReadonly" small>lock</v-icon>{{ item.Name }}
              </td>
              <td>{{ item.ObjectTypeId | objectTypeName }}</td>
              <td class="text-right">
                <v-btn icon class="mr-2" @click="$emit('load', 'detail', item.Id)">
                  <v-icon small>edit</v-icon>
                </v-btn>
                <v-btn icon @click="templatesDelete(item.Id)" v-if="!item.IsReadonly">
                  <v-icon small>delete</v-icon>
                </v-btn>
              </td>
            </tr>
          </tbody>
        </template>
      </v-simple-table>
    </v-card-text>
  </v-card>
</template>

<script>
import { emailTemplatesApi } from "@/code/apiServices";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";

export default {
  name: "EmailTemplatesList",

  props: ["applicationId", "objectTypes"],

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      emailTemplates: null
    };
  },

  async mounted() {
    await this.$lists.fetch("ObjectTypes");

    // seznam sablon
    this.emailTemplates = await emailTemplatesApi.GetList(this.applicationId);
  },

  methods: {
    // smazani sablony emailu
    async templatesDelete(id) {
      if (
        await this.$confirm("Opravdu si přejete smazat tuto šablonu?", { buttonTrueText: "ANO", buttonFalseText: "NE" })
      ) {
        if (
          await this.resolveGeneralResult(
            await emailTemplatesApi.Delete(id),
            "",
            "Šablona byla smazána",
            "Šablonu nebylo možné smazat"
          )
        ) {
          this.$delete(
            this.emailTemplates,
            this.emailTemplates.findIndex((t) => t.Id === id)
          );
        }
      }
    }
  }
};
</script>
