<template>
  <v-card>
    <v-subheader class="justify-space-between">
      UDÁLOSTI
      <div>
        <v-btn color="primary" text tile small @click="addItem">Přidat událost</v-btn>
      </div>
    </v-subheader>

    <app-box-loader v-if="items === null" />

    <app-box-no-entries v-else-if="items.length === 0">Zatím nejsou přidané žádné události</app-box-no-entries>

    <v-list dense v-else>
      <v-scroll-x-transition group>
        <v-list-item two-line v-for="(item, index) in items" :key="index">
          <v-list-item-icon class="mt-6">
            <v-icon :color="iconColor(item)">mail_outline</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-select
              class="mt-0"
              style="font-size: 13px; width: 100%;"
              height="28px"
              placeholder="Typ události"
              :items="templateTypes"
              v-model="item.TemplateType"
              item-text="Name"
              item-value="Id"
              hide-details
              dense
              @change="updateParent"
              :error-messages="validateFieldPrefix('EmailTemplates', index, 'TemplateType')"
            />
            <v-select
              class="mt-0"
              style="font-size: 13px; width: 100%;"
              height="28px"
              placeholder="Šablona události"
              :items="getTemplates(item.TemplateType)"
              v-model="item.TemplateId"
              item-text="Name"
              item-value="Id"
              hide-details
              dense
              @change="updateParent"
              :error-messages="validateFieldPrefix('EmailTemplates', index, 'TemplateId')"
            />
          </v-list-item-content>

          <v-list-item-action>
            <v-btn icon small @click="deleteItem(item)">
              <v-icon color="error">remove_circle</v-icon>
            </v-btn>
          </v-list-item-action>
        </v-list-item>
      </v-scroll-x-transition>
    </v-list>
  </v-card>
</template>

<script>
import { emailTemplatesApi } from "@/code/apiServices";
import { MixinValidateField } from "@mpss/eporadce-common-vue";

let tempId = -1;

export default {
  mixins: [MixinValidateField],

  props: ["validationErrors", "value", "objectTypeId", "objectTypeIdAlias", "objectId", "applicationId"],

  data() {
    return {
      items: null,
      templates: null,
      templateTypes: null
    };
  },

  async mounted() {
    const otId = this.objectTypeIdAlias ? this.objectTypeIdAlias : this.objectTypeId;

    // typy udalosti
    this.templateTypes = await emailTemplatesApi.GetTemplateTypes(this.applicationId, otId);

    // sablony
    this.templates = await emailTemplatesApi.GetList(this.applicationId, otId);

    // ulozene vazby
    if (Array.isArray(this.value) && this.value.length > 0) this.items = this.value;
    else {
      if (this.objectId > 0) this.items = await emailTemplatesApi.GetListForObject(this.objectTypeId, this.objectId);
      else this.items = [];

      this.updateParent();
    }
  },

  methods: {
    getTemplates(templateType) {
      return this.templates.filter((t) => t.TemplateType == templateType);
    },

    /**
     * Barva ikony nalevo: cervena=failed, zelena=nove uploadovano, jinak=cerna
     */
    iconColor(item) {
      return item.Id > 0 ? "default" : "success";
    },

    addItem() {
      if (this.items === null) this.items = [];
      this.items.unshift(emailTemplatesApi.CreateEmptyModelForObject(tempId--));
      this.updateParent();
    },

    /**
     * Smazat polozku
     */
    async deleteItem(item) {
      const idx = this.items.findIndex((t) => t.Id == item.Id);
      this.$delete(this.items, idx);
      this.updateParent();
    },

    /**
     * Vrati parent komponente informaci o aktualnich items
     */
    updateParent() {
      this.$emit(
        "input",
        this.items.map((t) => {
          return {
            Id: t.Id,
            TemplateType: t.TemplateType,
            TemplateId: t.TemplateId
          };
        })
      );
    }
  }
};
</script>
