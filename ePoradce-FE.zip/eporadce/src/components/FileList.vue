<template>
  <v-card>
    <v-subheader class="justify-space-between">
      PŘILOŽENÉ SOUBORY
      <div v-show="files !== null" v-if="!isReadonly">
        <v-btn color="primary" text tile small @click="addFiles" :disabled="showTerms && !agreeTerms"
          >Nový soubor</v-btn
        >
        <input type="file" style="display: none;" multiple id="FileList_1" @change="filesInputChange" />
      </div>
    </v-subheader>

    <div class="ml-4 mr-4" v-if="showTerms">
      <v-checkbox
        v-model="agreeTerms"
        dense
        hide-details
        class="mt-0"
        @change="agreeTermsReadonly = !agreeTermsReadonly"
        :disabled="agreeTermsReadonly"
      >
        <template #label>
          <span class="text--secondary font-weight-light caption"
            >Nahráním souboru potvrzuji, že soubor souhlasí s originálem/ověřenou kopií a je čitelný, vhodný ke
            zpracování.</span
          >
        </template>
      </v-checkbox>
    </div>

    <app-box-loader v-if="files === null" />

    <app-box-no-entries v-else-if="files.length === 0">Zatím nejsou přiložené žádné soubory</app-box-no-entries>

    <v-list dense v-else>
      <v-scroll-x-transition v-for="(item, index) in files" :key="index">
        <v-list-item two-line v-show="index < 5 || !itemsMore">
          <v-list-item-icon class="mt-4">
            <v-tooltip bottom>
              <template v-slot:activator="{ on }">
                <v-icon :color="filesIconColor(item)" v-on="on">attachment</v-icon>
              </template>
              <span>
                {{ item.InsertUser }}
                <br />
                {{ item.InsertTime | date }}
              </span>
            </v-tooltip>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>
              <a :href="getDownloadUrl(item.SystemFileName)" class="filelist-link">{{ item.OriginalFileName }}</a>
            </v-list-item-title>

            <app-static-text dense v-if="item.IsReadonly" hide-details>{{ item.TypeName }}</app-static-text>

            <v-list-item-subtitle class="red--text font-weight-light" v-else-if="item.State === 4">{{
              item.ErrorMessage
            }}</v-list-item-subtitle>

            <v-select
              v-else-if="item.State !== 4 && item.State !== 2"
              class="mt-0"
              style="font-size: 13px;"
              height="28px"
              placeholder="Druh souboru"
              :items="fileTypes"
              v-model="item.FileInfoTypeId"
              item-text="Name"
              item-value="Id"
              hide-details
              dense
              @change="filesUpdateParent"
              :error-messages="validateFieldPrefix('Files', index, 'FileInfoTypeId')"
            />
          </v-list-item-content>

          <v-list-item-action>
            <v-btn icon small @click="filesDelete(item)" v-if="filesIsDeleteVisible(item)">
              <v-icon color="error">remove_circle</v-icon>
            </v-btn>
          </v-list-item-action>

          <div style="position: absolute; top: 0; left: 16px; right: 16px;" v-if="item.State === 2">
            <v-progress-linear active indeterminate color="deep-purple accent-4" />
          </div>
        </v-list-item>
      </v-scroll-x-transition>
    </v-list>

    <!-- nahrat dalsi soubory -->
    <div class="text-center pb-3" v-show="itemsMore">
      <v-btn color="primary" x-small @click="paginationLoadMore" tile text
        ><v-icon x-small>get_app</v-icon>Zobrazit další</v-btn
      >
    </div>
  </v-card>
</template>

<script>
import { fileInfoApi } from "@/code/apiServices";
import { FileInfoStates } from "@mpss/eporadce-common-api";
import { MixinValidateField } from "@mpss/eporadce-common-vue";
import MixinFileUpload from "@/mixins/MixinFileUpload";

export default {
  mixins: [MixinValidateField, MixinFileUpload],

  props: [
    "validationErrors",
    "value",
    "objectTypeId",
    "objectTypeIdAlias",
    "objectId",
    "applicationId",
    "readonlyCondition",
    "isReadonly",
    "showTerms"
  ],

  data() {
    return {
      fileTypes: null,
      agreeTerms: false,
      agreeTermsReadonly: false,
      itemsMore: false,

      continuousPaginationFce: async (start, count) => {
        var result = await fileInfoApi.GetList(this.objectTypeId, this.objectId, start, count);

        if (this.isReadonly) result.Data.forEach((t) => (t.IsReadonly = true));
        else if (this.readonlyCondition)
          result.Data.forEach((t) => {
            if (!t.IsReadonly) t.IsReadonly = this.readonlyCondition(t);
          });

        return result;
      }
    };
  },

  async mounted() {
    const otId = this.objectTypeIdAlias ? this.objectTypeIdAlias : this.objectTypeId;
    // typy souboru
    this.fileTypes = await fileInfoApi.GetFileInfoTypes(otId);

    // soubory
    if (Array.isArray(this.value) && this.value.length > 0) this.files = this.value;
    else {
      if (this.objectId > 0) {
        this.files = (await this.continuousPaginationFce(0, 99)).Data;
      } else this.files = [];

      this.itemsMore = this.files.length > 5;
      this.filesUpdateParent();
    }
  },

  computed: {
    items: {
      get() {
        return this.files;
      },
      set(v) {
        this.files = v;
      }
    }
  },

  methods: {
    paginationLoadMore() {
      this.itemsMore = false;
    },

    /**
     * Vrati parent komponente informaci o aktualnich souborech v kolekci
     */
    filesUpdateParent() {
      this.$emit(
        "input",
        this.files.map((t) => {
          return {
            Id: t.Id,
            FileInfoTypeId: t.FileInfoTypeId,
            IsReadonly: t.IsReadonly,
            OriginalFileName: t.OriginalFileName,
            InsertUser: t.InsertUser,
            InsertTime: t.InsertTime,
            SystemFileName: t.SystemFileName
          };
        })
      );
    },

    /**
     * Kliknuti na tlacitko pridani souboru - jen programove klikne na hidden input file
     */
    addFiles(ev) {
      document.getElementById("FileList_1").click();
    }
  }
};
</script>
