<template>
  <div>
    <div v-for="(file, index) in files" :key="index" class="hidden-items">
      <v-icon small class="mr-2">attachment</v-icon>
      <a :href="getDownloadUrl(file.SystemFileName)" class="filelist-link caption" target="_blank">{{
        file.OriginalFileName
      }}</a>

      <v-btn v-if="enableDelete" x-small color="error" text tile class="ml-1 hidden-item" @click="deleteFile(file.Id)"
        >SMAZAT</v-btn
      >
    </div>
  </div>
</template>

<script>
import MixinGetDownloadUrl from "@/mixins/MixinGetDownloadUrl";
import { fileInfoApi } from "@/code/apiServices";

export default {
  name: "SimpleFileList",

  props: ["objectTypeId", "objectId", "enableDelete"],

  mixins: [MixinGetDownloadUrl],

  data() {
    return {
      files: null
    };
  },

  async mounted() {
    this.files = (await fileInfoApi.GetList(this.objectTypeId, this.objectId, 0, 999)).Data;
  },

  methods: {
    async deleteFile(id) {
      if (
        await this.$confirm("Opravdu si přejete smazat tento soubor?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        const index = this.files.findIndex((t) => t.Id === id);
        this.$delete(this.files, index);

        await fileInfoApi.Delete(id);

        this.$toast.success("Soubor byl smazán");
      }
    }
  }
};
</script>
