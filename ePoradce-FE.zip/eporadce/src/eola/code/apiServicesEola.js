import httpClient from "../../code/apiServices";
import * as apis from "@mpss/eola-api";

export const courseGroupsApi = new apis.CourseGroupsApi(httpClient);
export const coursesApi = new apis.CoursesApi(httpClient);
export const courseSequenceApi = new apis.CourseSequenceApi(httpClient);
export const courseEventsApi = new apis.CourseEventsApi(httpClient);
export const accommodationsApi = new apis.AccommodationsApi(httpClient);
export const attendeeApi = new apis.AttendeeApi(httpClient);
