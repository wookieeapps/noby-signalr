<template>
  <div>
    <v-card>
      <v-card-title class="justify-space-between">
        <span>Seznam ubytování a školících míst</span>
        <div>
          <v-btn color="primary" text tile small :to="{ name: 'eOlaAccommodationDetail' }">Nový záznam</v-btn>
        </div>
      </v-card-title>
      <v-divider />

      <app-box-loader v-if="accommodations === null"></app-box-loader>
      <app-box-no-entries v-else-if="accommodations.length === 0">Nejsou uloženy žádná ubytování</app-box-no-entries>
      <v-card-text v-else class="pa-0">
        <v-simple-table>
          <template>
            <tbody>
              <tr v-for="item in accommodations" :key="item.id">
                <td style="min-width: 150px;">{{ item.Name }}</td>
                <td v-if="hasAddress(item)">{{ addressText(item) }}</td>
                <td v-else class="text--disabled">adresa není vyplněna</td>
                <td class="pl-0 pr-0">
                  <v-tooltip v-if="item.Contact" bottom>
                    <template v-slot:activator="{ on }">
                      <v-icon v-on="on" color="purple darken-2">comment</v-icon>
                    </template>
                    <span>{{ item.Contact }}</span>
                  </v-tooltip>
                </td>
                <td class="pl-0">
                  <v-chip
                    v-for="acctype in item.AccommodationTypes"
                    :key="acctype"
                    :color="acctype | list('eola', 'accommodationTypes') | color"
                    small
                    text-color="white"
                    class="mr-1"
                  >
                    {{ acctype | list("eola", "accommodationTypes") | text }}
                  </v-chip>
                </td>
                <td class="text-right">
                  <v-btn
                    icon
                    class="mr-2"
                    :to="{
                      name: 'eOlaAccommodationDetail',
                      params: { id: item.Id }
                    }"
                  >
                    <v-icon small>edit</v-icon>
                  </v-btn>
                </td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { accommodationsApi } from "../code/apiServicesEola";
import { commonListsApi } from "@/code/apiServices";
import { async } from "q";
import MixinAccommodation from "../mixins/MixinAccommodation";

export default {
  name: "Accommodations",

  mixins: [MixinAccommodation],

  data() {
    return {
      accommodations: null
    };
  },

  async mounted() {
    await this.$store.dispatch("lists/eola/fetchAccommodationTypes");

    //nacist seznam ubytovani
    this.accommodations = await accommodationsApi.GetList();
  }
};
</script>
