<template>
  <v-dialog scrollable persistent no-click-animation v-model="value" max-width="800">
    <v-card class="pt-5">
      <v-card-text>
        <!-- sekvence -->
        <v-expansion-panels focusable>
          <v-expansion-panel v-for="sequence in model" :key="sequence.Id">
            <v-expansion-panel-header disable-icon-rotate>
              <template v-slot:default="{ open }">
                {{ sequence.Name }}
              </template>
              <template v-slot:actions>
                <v-chip v-if="showChip(sequence)" small color="warning">
                  {{ sequence.SigninCount }} / {{ sequence.CoursesCount }}
                </v-chip>
                <v-icon v-else-if="showIco(sequence)" color="success">check_circle</v-icon>
              </template>
            </v-expansion-panel-header>
            <v-expansion-panel-content>
              <!-- kurzy v sekvenci -->
              <v-list>
                <v-list-group
                  v-for="(course, index) in sequence.Courses"
                  :key="course.Id"
                  v-model="course.Active"
                  no-action
                  @click="loadCourseEvents(course, sequence)"
                  :disabled="course.Disabled"
                  active-class=""
                  :append-icon="course.Disabled ? '' : '$expand'"
                >
                  <template v-slot:activator>
                    <v-list-item-content>
                      <v-list-item-title :class="course.Disabled ? 'text--disabled' : ''">
                        {{ course.Name }}
                      </v-list-item-title>
                      <v-list-item-subtitle v-if="course.CourseEventId">
                        <small>přihlášení na datum konání</small> {{ course.TimeFrom | parseDatetime }}
                      </v-list-item-subtitle>
                    </v-list-item-content>

                    <!-- ubytovani a poznamky -->
                    <template v-if="course.CourseEventId && course.CourseEventAttendeeId == null">
                      <v-list-item-action v-if="course.AccommodationId">
                        <v-checkbox v-model="course.WithAccommodation" @click.native.stop label="ubytování" small>
                        </v-checkbox>
                      </v-list-item-action>

                      <v-dialog v-model="noteDialog[index]" width="500px">
                        <template #activator="{ on }">
                          <v-btn icon v-on="on" :color="course.SignupNote || course.PrivateNote ? 'blue darken-2' : ''">
                            <v-icon>comment</v-icon>
                          </v-btn>
                        </template>
                        <v-card>
                          <v-card-title> Poznámka k přihlášení do termínu</v-card-title>
                          <v-card-text>
                            <v-textarea v-model="course.SignupNote" placeholder="text" auto-grow rows="3"></v-textarea>
                          </v-card-text>
                          <v-card-title>
                            Jiná poznámka (<small>nezobrazuje se v prezenční listině</small>)
                          </v-card-title>
                          <v-card-text>
                            <v-textarea v-model="course.PrivateNote" placeholder="text" auto-grow rows="3"></v-textarea>
                            <v-card-actions>
                              <v-spacer></v-spacer>
                              <v-btn color="primary" text @click="closeNoteDialog(index)"> OK </v-btn>
                            </v-card-actions>
                          </v-card-text>
                        </v-card>
                      </v-dialog>
                    </template>
                  </template>

                  <!-- terminy kurzu -->
                  <v-subheader v-if="course.CourseEvents.length == 0">
                    <span v-if="loading">Nahrávám data ...</span>
                    <span v-else>Žádné termíny nenalezeny</span>
                  </v-subheader>
                  <v-list-item v-else v-for="event in course.CourseEvents" :key="event.Id" class="pl-4">
                    <v-list-item-action>
                      <v-checkbox @click="selectEvent(event, course, sequence)"></v-checkbox>
                    </v-list-item-action>
                    <v-list-item-content>
                      <div class="d-flex justify-space-between">
                        <div>{{ event.TimeFrom | parseDatetime }}</div>
                        <div>
                          <v-list-item-subtitle>
                            Ubytování:
                            <span v-if="event.Accommodation && event.Accommodation.length > 0">{{
                              event.Accommodation
                            }}</span>
                            <span v-else><i>není</i></span>
                            , Místnost:
                            <span v-if="event.TrainingRoom && event.TrainingRoom.length > 0">{{
                              event.TrainingRoom
                            }}</span>
                            <span v-else><i>není</i></span>
                          </v-list-item-subtitle>
                        </div>
                      </div>
                    </v-list-item-content>
                  </v-list-item>
                </v-list-group>
              </v-list>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
      </v-card-text>
      <v-card-actions class="pr-4 pb-3">
        <v-spacer></v-spacer>
        <v-btn text tile @click="close">Zavřít</v-btn>
        <v-btn tile @click="save" color="success" :loading="saveLoading" :disabled="saveDisabled">Uložit</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { attendeeApi, courseEventsApi } from "../code/apiServicesEola";

export default {
  name: "eOlaAttendeeRegister",

  props: ["value", "userId"],

  data() {
    return {
      model: null,
      loading: false,
      noteDialog: [],
      saveLoading: false,
      saveDisabled: false,
      snackbar: false
    };
  },

  methods: {
    showChip(item) {
      return item.SigninCount < item.CoursesCount && item.Id > 0;
    },
    showIco(item) {
      return !this.showChip(item) && item.Id > 0;
    },
    courseDisabled(course, sequence) {
      // existujici prihlaseni do budoucna tady nelze menit
      if (course.CourseEventAttendeeId && course.TimeFrom && course.TimeFrom > new Date()) return true;

      // pokud existuje predchozi kurz bez prihlaseni, nepovolovat tento
      if (course.PrevCourseId) {
        const prev = sequence.Courses.find((t) => t.Id == course.PrevCourseId);
        if (!prev.CourseEventId) return true;
      }

      return false;
    },
    async loadCourseEvents(course, sequence) {
      // najit datum prihlaseni predchoziho kurzu
      this.loading = true;
      let afterDate = null;
      if (course.PrevCourseId) {
        const prev = sequence.Courses.find((t) => t.Id == course.PrevCourseId);
        afterDate = prev.TimeFrom;
      }

      let courseEventes = await courseEventsApi.SearchEvents(course.Id, afterDate)
      let userEvents = await attendeeApi.AttendeeHistory(this.$store.state.userDetail.user.Id); 
      if (course.CourseEventAttendeeId){
        //odfiltrueme eventy, na které je již user přihlášen
        course.CourseEvents = await courseEventes.filter(function(courseEvente){
                                      return userEvents.filter(function(userEvent){
                                          return userEvent.CourseEventId == courseEvente.Id;
                                      }).length == 0
                                })
      }
      this.loading = false;
    },
    selectEvent(event, course, sequence) {
      if (!course.CourseEventAttendeeId) sequence.SigninCount++;
      course.CourseEventAttendeeId = null;
      course.CourseEventId = event.Id;
      course.TimeFrom = event.TimeFrom;
      course.AccommodationId = event.AccommodationId;
      course.Accommodation = event.Accommodation;
      course.TrainingRoom = event.TrainingRoom;
      course.WithAccommodation = false;
      course.Active = false;
      course.CourseEvents = [];
      this.saveDisabled = false;
      if (course.NextCourseId) {
        const next = sequence.Courses.find((t) => t.Id == course.NextCourseId);
        next.Disabled = false;
      }
    },
    // zavreni poznamky
    closeNoteDialog(index) {
      this.$set(this.noteDialog, index, false);
    },
    async save() {
      this.saveLoading = true;
      const arr = courseEventsApi.CreateAttendeeEventList(this.model);
      await courseEventsApi.SaveAttendeeEvents(arr, this.userId);
      this.saveLoading = false;
      this.close();
    },
    close() {
      this.$emit("input", false);
    }
  },

  watch: {
    async value(v) {
      // nacist data
      if (v) {
        this.model = await attendeeApi.AttendeeCourseSequence(this.userId);
        this.model.forEach((s) => s.Courses.forEach((c) => (c.Disabled = this.courseDisabled(c, s))));
      }
    }
  }
};
</script>
