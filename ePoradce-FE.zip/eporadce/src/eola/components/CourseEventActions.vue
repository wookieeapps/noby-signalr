<template>
  <v-menu bottom left>
    <template v-slot:activator="{ on }">
      <v-btn
        v-if="!buttonText"
        icon
        exact
        v-on="on"
        :disabled="!(canEdit || canManageAttendees || canPrint || canWriteResults)"
      >
        <v-icon>more_vert</v-icon>
      </v-btn>
      <v-btn v-else tile exact v-on="on" :disabled="!(canEdit || canManageAttendees || canPrint || canWriteResults)">
        {{ buttonText }}
        <v-icon>expand_more</v-icon>
      </v-btn>
    </template>
    <v-list dense>
      <v-list-item-group>
        <v-list-item v-if="canManageAttendees" :to="{ name: 'eOlaCourseEvent', params: { id } }">
          <v-list-item-icon>
            <v-icon>how_to_reg</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Spravovat účastníky</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item
          v-if="canWriteResults"
          :disabled="disabledWriteResults"
          :to="{ name: 'eOlaCourseEventEvaluation', params: { id } }"
        >
          <v-list-item-icon>
            <v-icon>grading</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Zapsat výsledky</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item v-if="canPrint" @click="generateDocs('prezecni-listina')">
          <v-list-item-icon>
            <v-icon>print</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Tisk prezenční listiny</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item v-if="canPrint" @click="generateDocs('karta-terminu')">
          <v-list-item-icon>
            <v-icon>print</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Tisk karty termínu</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item v-if="canEdit" :to="{ name: 'eOlaCourseEventEdit', params: { id } }">
          <v-list-item-icon>
            <v-icon>edit</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Upravit termín</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item 
          v-if="canEdit"
          :disabled="disabledDelete"
          @click="deleteEvent(id)">
          <v-list-item-icon>
            <v-icon>delete</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Odstranit</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list-item-group>
    </v-list>
  </v-menu>
</template>

<script>
import MixinCourseEventBase from "../mixins/MixinCourseEventBase";

export default {
  name: "eOlaCourseEventActions",
  mixins: [MixinCourseEventBase],
  props: {
    id: {
      type: Number
    },
    buttonText: {
      type: String | null
    },
    disabledWriteResults: {
      type: Boolean,
      default: false
    },
    disabledDelete: {
      type: Boolean,
      default: false
    }
  },

};
</script>
