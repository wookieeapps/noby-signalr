<template>
  <div>
    <v-card>
      <v-card-title class="justify-space-between">
        <span>Seznam sekvencí kurzů</span>
        <div>
          <v-btn color="primary" text tile small @click.stop="sequenceEdit()">Nová sekvence</v-btn>
        </div>
      </v-card-title>
      <v-divider />

      <app-box-loader v-if="sequences === null" />

      <app-box-no-entries v-else-if="sequences.length === 0">Nejsou uloženy žádné sekvence</app-box-no-entries>

      <v-card-text class="pa-0" v-else>
        <v-simple-table>
          <template v-slot:default>
            <tbody>
              <tr v-for="item in sequences" :key="item.Id">
                <td>{{ item.Name }}</td>
                <td class="text-right">
                  <v-btn icon class="mr-2">
                    <v-icon small @click="openReorder(item.Id)">reorder</v-icon>
                  </v-btn>
                  <v-btn icon class="mr-2">
                    <v-icon small @click="sequenceEdit(item.Id)">edit</v-icon>
                  </v-btn>
                  <v-btn icon>
                    <v-icon small @click="sequenceDelete(item.Id)">delete</v-icon>
                  </v-btn>
                </td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-card-text>
    </v-card>

    <v-dialog v-model="reorderDialog" max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">Změna pořadí kurzů v sekvenci</span>
        </v-card-title>

        <app-box-loader v-if="reorderItems === null" />

        <v-card-text v-else-if="reorderItems.length === 0">
          <app-box-no-entries>Sekvence neobsahuje žádné kurzy</app-box-no-entries>
        </v-card-text>

        <div v-else>
          <v-list dense>
            <draggable
              v-model="reorderItems"
              tag="ul"
              @start="drag = true"
              @end="drag = false"
              v-bind="dragOptions"
              class="pl-0"
            >
              <transition-group type="transition" :name="!drag ? 'flip-list' : null">
                <v-list-item tag="li" v-for="(ritem, rindex) in reorderItems" :key="ritem.Id" style="cursor: move;">
                  <v-list-item-avatar>
                    <v-avatar color="blue">
                      <span class="white--text">{{ rindex + 1 }}</span>
                    </v-avatar>
                  </v-list-item-avatar>
                  <v-list-item-content>
                    <v-list-item-title>{{ ritem.Name }}</v-list-item-title>
                    <v-list-item-subtitle class="caption">{{ ritem.GroupName }}</v-list-item-subtitle>
                  </v-list-item-content>
                </v-list-item>
              </transition-group>
            </draggable>
          </v-list>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="gray" text @click="reorderDialog = false">Storno</v-btn>
            <v-btn color="green" text @click="reorderSave">Uložit</v-btn>
          </v-card-actions>
        </div>
      </v-card>
    </v-dialog>

    <v-dialog v-model="sequenceDialog" max-width="500px">
      <v-card>
        <v-card-title>
          <span class="headline">Editace sekvence</span>
        </v-card-title>
        <v-card-text>
          <v-text-field label="Název sekvence" v-model="sequenceModel.Name" :error-messages="validateField('Name')" />
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="gray" text @click="sequenceDialog = false">Storno</v-btn>
          <v-btn color="green" text @click="sequenceSave" :loading="sequenceSaveLoading">Uložit</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import { courseSequenceApi } from "../code/apiServicesEola";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
import draggable from "vuedraggable";

export default {
  name: "CourseSequences",

  components: { draggable },

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      sequences: null,
      sequenceDialog: false,
      reorderDialog: false,
      sequenceModel: {},
      sequenceSaveLoading: false,
      reorderItems: null,
      drag: false
    };
  },

  computed: {
    dragOptions() {
      return {
        animation: 200,
        group: "description",
        disabled: false,
        ghostClass: "ghost"
      };
    }
  },

  async mounted() {
    // sekvence
    this.sequences = await courseSequenceApi.GetList();
  },

  methods: {
    // Smazani sekvence
    async sequenceDelete(id) {
      if (
        await this.$confirm("Opravdu si přejete smazat tuto sekvenci?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        if (this.resolveSubResult(await courseSequenceApi.Delete(id, "Sekvenci nebylo možné smazat"))) {
          this.$delete(
            this.sequences,
            this.sequences.findIndex((t) => t.Id === id)
          );
        }
      }
    },

    // zobrazeni detailu sekvence
    async sequenceEdit(id) {
      this.sequenceModel = id ? await courseSequenceApi.Get(id) : courseSequenceApi.CreateEmptyModel();

      this.sequenceDialog = true;
    },

    // ulozeni sekvence
    async sequenceSave() {
      this.sequenceSaveLoading = true;

      const result =
        this.sequenceModel.Id > 0
          ? await courseSequenceApi.Edit(this.sequenceModel, this.sequenceModel.Id)
          : await courseSequenceApi.Create(this.sequenceModel);

      if (this.resolveSubResult(result, "Sekvenci nebylo možné uložit", "")) {
        this.sequenceDialog = false;

        // nove ID
        if (this.sequenceModel.Id === 0) this.sequenceModel.Id = parseInt(result);

        // index objektu v gridu
        const index = this.sequences.findIndex((t) => t.Id == this.sequenceModel.Id);

        // updatovat grid
        if (index >= 0) this.$set(this.sequences, index, this.sequenceModel);
        else this.sequences.push(this.sequenceModel);

        this.$toast.success("Sekvence byla uložena");
      }

      this.sequenceSaveLoading = false;
    },

    // otevre dialog s moznosti preskupeni kurzu v sekvenci
    async openReorder(id) {
      this.reorderItems = null;
      this.reorderDialog = true;

      this.reorderItems = await courseSequenceApi.GetCourses(id);
    },

    // ulozeni zmeny poradi
    async reorderSave() {
      this.reorderDialog = false;
      this.$toast.success("Pořadí kurzů v sekvenci bylo uloženo");

      await courseSequenceApi.UpdateOrder(this.reorderItems.map((t) => t.Id));
    }
  }
};
</script>

<style scoped>
.flip-list-move {
  transition: transform 0.5s;
}
.no-move {
  transition: transform 0s;
}
.ghost {
  opacity: 0.5;
  background: #c8ebfb;
}
</style>
