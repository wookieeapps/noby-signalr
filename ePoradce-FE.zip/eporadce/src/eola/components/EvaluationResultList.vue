<template>
  <div>
    <v-chip-group v-model="checked" :multiple="multiple">
      <v-chip
        v-for="item in items"
        :key="item.Id"
        :active-class="item.Color || 'success'"
        :small="small"
        :value="item.Id"
        :disabled="disabled"
        class="mt-0 mb-0"
        >{{ item.Text }}
      </v-chip>
    </v-chip-group>
  </div>
</template>

<script>
export default {
  name: "eOlaEvaluationResultList",

  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    code: {
      type: String,
      default: ""
    },
    model: {
      type: Number,
      default: 0
    }
  },

  model: {
    prop: "model",
    event: "change"
  },

  async mounted() {
    await this.$store.dispatch("lists/eola/fetchEvaluationResults");
  },

  computed: {
    items() {
      return this.$lists.eola.evaluationResults
        ? this.$lists.eola.evaluationResults.filter((t) => t.Code == this.code)
        : [];
    },
    checked: {
      get: function () {
        if (this.multiple) {
          const finalArray = [];
          this.items.forEach((x) => {
            if ((this.model & x.Id) > 0) finalArray.push(x.Id);
          });
          return finalArray;
        }
        return this.model;
      },
      set: function (val) {
        this.$emit("change", this.multiple ? val.reduce((a, b) => a + b, null) : val);
      }
    },
    multiple() {
      return this.code == "4" || this.code == "5" || this.code == "6" || this.code == "7" || this.code == "8" || this.code == "9";
    },
    small() {
      return this.code != "2";
    }
  }
};
</script>

<style scoped>
.v-chip--disabled {
  opacity: 0.87;
}
</style>
