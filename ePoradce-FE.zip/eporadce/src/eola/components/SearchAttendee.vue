<template>
  <v-autocomplete
    v-model="searchModel"
    :items="searchResult"
    :loading="searching"
    :search-input.sync="search"
    @change="searchChange"
    flat
    no-filter
    hide-details
    hide-no-data
    item-text="DisplayName"
    item-value="Id"
    item-disabled="Disabled"
    placeholder="Najít a přidat uživatele do termínu"
    prepend-inner-icon="person_search"
    return-object
  >
    <template v-slot:item="{ item }">
      <v-list-item-icon>
        <v-icon v-if="!item.Disabled">person_add</v-icon>
        <v-icon v-else disabled>warning</v-icon>
      </v-list-item-icon>
      <v-list-item-content>
        <v-list-item-title v-text="item.DisplayName"></v-list-item-title>
        <v-list-item-subtitle>
          {{ item.Cpm }}
          <span v-if="item.Disabled" class="text-caption"> - nesplněny podmínky pro přihlášení</span>
        </v-list-item-subtitle>
      </v-list-item-content>
    </template>
  </v-autocomplete>
</template>

<script>
import { courseEventsApi } from "../code/apiServicesEola";
import { Helpers } from "@mpss/eporadce-common";

export default {
  name: "eOlaSearchAttendee",

  props: {
    courseEventId: Number
  },

  data() {
    return {
      searching: false,
      search: "",
      searchModel: "",
      searchResult: []
    };
  },

  methods: {
    searchChange(item) {
      if (item.Disabled) return;
      this.$emit("searchChange", item);
    }
  },

  watch: {
    // vyhledavani
    search(val) {
      if (val) {
        this.searching = true;
        Helpers.debounce((val) => {
          if (val != this.search) return;
          courseEventsApi.SearchAttendees(val, this.courseEventId).then((t) => {
            this.searchResult = t || [];
            this.searching = false;
          });
        }, 400)(val);
      }
    }
  }
};
</script>
