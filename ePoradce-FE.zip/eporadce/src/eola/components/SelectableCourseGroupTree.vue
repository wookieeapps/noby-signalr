<style scoped>
  .groups-tree >>> .v-treeview--dense .v-treeview-node__root {
    min-height: 28px !important;
  }
</style>

<template>
  <div v-if="groups !== null">
    <v-list class="pt-0 pb-0">
      <v-list-item class="pl-0">
        <v-list-item-content>
          <v-list-item-subtitle class="caption">Zařazení ve stromu skupin</v-list-item-subtitle>
          <v-list-item-title>{{ selectedGroupName }}</v-list-item-title>
        </v-list-item-content>
        <v-list-item-action>
          <v-btn icon color="primary" large @click="groupsTreeOpened = !groupsTreeOpened">
            <v-icon v-show="groupsTreeOpened">folder_open</v-icon>
            <v-icon v-show="!groupsTreeOpened">folder</v-icon>
          </v-btn>
        </v-list-item-action>
      </v-list-item>
    </v-list>

    <v-slide-y-reverse-transition>
      <div v-show="groupsTreeOpened" class="groups-tree caption">
        <v-treeview
          selectable
          dense
          open-on-click
          return-object
          :items="groups"
          item-key="Id"
          item-text="Name"
          item-children="Children"
          selection-type="independent"
          v-model="selectedGroup"
        />
      </div>
    </v-slide-y-reverse-transition>
  </div>
</template>

<script>
  import { courseGroupsApi } from "../code/apiServicesEola";

  export default {
    props: ["value", "rootLevelLabel", "limitToGroupId"],

    data() {
      return {
        // strom vsech skupin pro zarazeni aktualni skupiny
        groups: null,
        // zobrazit nebo skryt strom skupin
        groupsTreeOpened: false,
        // vybrana skupina do ktere bude aktualni zarazena
        selectedGroup: []
      };
    },

    async mounted() {
      // dohrat strukturu skupin
      this.groups = await courseGroupsApi.GetTree(false, this.limitToGroupId);

      // nazev nadrizene kategorie
      if (this.value) {
        let path = [];
        const g = recursiveGroup(this.groups, this.value, path);
        if (g !== null) {
          this.selectedGroup = [g];
          //this.groupsTreeOpenedPath = path;
        }
      }

      function recursiveGroup(g, id, path) {
        for (let i = 0; i < g.length; i++) {
          const group = g[i];
          if (group.Id === id) return group;
          if (group.Children) {
            let obj = recursiveGroup(group.Children, id, path);
            if (obj !== null) {
              path.push(group.Id);
              return obj;
            }
          }
        }
        return null;
      }
    },

    watch: {
      selectedGroup() {
        if (this.selectedGroup.length > 1) {
          this.selectedGroup.shift();
        } else {
          this.updateParent();
        }
      }
    },

    computed: {
      selectedGroupName() {
        return this.selectedGroup == null || this.selectedGroup.length === 0 ? this.rootLevelLabel : this.selectedGroup[0].Name;
      }
    },

    methods: {
      updateParent() {
        this.$emit("input", this.selectedGroup.length > 0 ? this.selectedGroup[0].Id : null);
      }
    }
  };
</script>
