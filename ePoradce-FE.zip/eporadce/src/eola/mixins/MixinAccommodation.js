
export default {
    methods: {
        hasAddress(item) {
            return item.Street || item.City || item.Zip;
        },
        addressText(item) {
            return new Array(item.Street, item.City, item.Zip).filter((t) => t).join(", ");
        }
    }
}