import { DateHelpers, UserRoles } from "@mpss/eporadce-common";

// TODO: na server s tim, ne?

export default {
    computed: {
        //pravo upravit kurz
        canEdit() {
            return this.$user.loaded && this.$user.isInRoles([UserRoles.eOlaAdmin, UserRoles.eOlaLector]);
        },
        //pravo spravovat prihlasene uzivatele
        canManageAttendees() {
            return (
                this.$user.loaded &&
                this.$user.isInRoles([UserRoles.eOlaAdmin, UserRoles.eOlaLector, UserRoles.eOlaAttendeeManager])
            );
        },
        //pravo zapisu vysledku
        canWriteResults() {
            return (
                this.$user.loaded &&
                this.$user.isInRoles([UserRoles.eOlaAdmin, UserRoles.eOlaLector])
            );
        },
        //pravo tisku
        canPrint() {
            return (
                this.$user.loaded &&
                this.$user.isInRoles([UserRoles.eOlaAdmin, UserRoles.eOlaLector])
            );
        },
        //pravo zapisu vysledku podle datumu (v detailu)
        canWriteDetailResults() {
            return this.model &&
                this.$user.loaded &&
                DateHelpers.parseDatetime(this.model.Timefrom) < new Date() &&
                ((Array.isArray(this.model.Lectors) && this.model.Lectors.findIndex((t) => t.Id === this.$user.Id)) >= 0 || this.$user.isInRole(UserRoles.eOlaAdmin));
        },
        //pravo pridat uzivatele podle datumu
        canAddAttendee() {
            return this.model &&
                (DateHelpers.parseDatetime(this.model.SignupDeadline) >= new Date() && this.canManageAttendees) || (this.$user.loaded && (this.$user.isInRole(UserRoles.eOlaAdmin) || this.$user.isInRole(UserRoles.eOlaLector)|| this.$user.isInRole(UserRoles.eOlaLector)));
        },
        //pravo odstranit uzivatele podle datumu
        canRemoveAttendee() {
            return this.model &&
                ((DateHelpers.parseDatetime(this.model.SignoutDeadline)  >= new Date() ) &&
                    this.canManageAttendees) || (this.$user.loaded && this.$user.isInRole(UserRoles.eOlaAdmin));
        },
        //pravo upravit ubytovani uzivatele podle datumu
        canChangeAccommodationAttendee() {
            //return this.canChangeAccommodationAttendeeM(this.model?.Timefrom);
            /* return this.model && (DateHelpers.parseDatetime(this.model.Timefrom) < new Date() && this.canManageAttendees) || (this.$user.loaded && this.$user.isInRole(UserRoles.eOlaAdmin)); */
            return this.model &&
                    ((DateHelpers.parseDatetime(this.model.SignoutDeadline) >= new Date()) &&
                        this.canManageAttendees) || (this.$user.loaded && this.$user.isInRole(UserRoles.eOlaAdmin));
        }
    },

    methods: {
        //pravo zapisu vysledku podle datumu (v gridu)
        canWriteItemResults(timefrom) {
            return DateHelpers.parseDatetime(timefrom) < new Date() && this.canWriteResults;
        },
        //pravo upravit ubytovani uzivatele podle datumu
        canChangeAccommodationAttendeeM(timefrom) {
            return ((timefrom || false) && (DateHelpers.parseDatetime(timefrom) > new Date() && this.canManageAttendees)) || (this.$user.loaded && this.$user.isInRole(UserRoles.eOlaAdmin));
        },
        // možnost smazat
        candDelete(capacity){
            return capacity.substring(0, 1) == "0" ? false : true;
          }
    }

}
