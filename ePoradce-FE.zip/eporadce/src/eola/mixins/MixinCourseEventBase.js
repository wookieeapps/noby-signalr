import { courseEventsApi } from "../code/apiServicesEola";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
import MixinCourseEvent from "../mixins/MixinCourseEvent";

export default {

    data() {
        return {
            model: null,
            saveLoading: false,
            noteDialog: [],
            contactDialog: false
        };
    },

    mixins: [MixinResolveGeneralResult, MixinCourseEvent],

    async mounted() {
        // detail udalosti
        this.model = await courseEventsApi.Get(this.id);
    },

    methods: {
        // odstraneni ze seznamu
        async deleteAttendee(item) {
            const idx = this.model.Attendees.findIndex((t) => t.UserId === item.UserId);
            if (
                await this.$confirm("Opravdu si přejete odhlásit uživatele z termínu?", {
                    buttonTrueText: "ANO",
                    buttonFalseText: "NE"
                })
            ) {
                this.$delete(this.model.Attendees, idx);
            }
        },

        // zavreni poznámky
        closeNoteDialog(index) {
            //this.noteDialog[index] = false;
            this.$set(this.noteDialog, index, false);
        },

        // tisk
        async generateDocs(docType) {
            const resultDoc = await courseEventsApi.GenerateDoc(this.model.Id, docType);
            if (await this.resolveGeneralResult(resultDoc)) {
                location.href = resultDoc;
                return true;
            }
        },

        // ulozeni ucastniku
        async saveAttendees() {
            this.onBeforeSave();
            const result = await courseEventsApi.SaveAttendees(this.model.Attendees, this.model.Id);
            await this.resolveGeneralResult(result, null, "Změny uloženy", "Změny nebylo možné uložit");
        },

        // ulozeni vysledku
        async saveEvaluations(closeEvaluation) {
            if (!closeEvaluation || (closeEvaluation &&
                await this.$confirm("Opravdu si přejete uložit a uzavřít vyhodnocení?", {
                    buttonTrueText: "ANO",
                    buttonFalseText: "NE"
                }))
            ) {
                this.onBeforeSave();
                const result = await courseEventsApi.SaveEvaluation(this.model.Attendees, closeEvaluation, this.model.Id);
                if (await this.resolveGeneralResult(result, null, "Změny uloženy", "Změny nebylo možné uložit")) {
                    this.model.EvaluationClosed = closeEvaluation;
                }
            }
        },

        // smazání eventu
        async deleteEvent(id) {
            await courseEventsApi.Delete(id);
            location.reload();
        },
    }

}