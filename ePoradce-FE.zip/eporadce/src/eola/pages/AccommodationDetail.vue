<template>
  <div>
    <app-page-toolbar
      :back-to="{ name: 'eOlaListsAdministration', params: { id: 2 } }"
      :validation-errors="validationErrors"
    >
      <template v-slot:back>Zpět na seznam</template>
      <template v-slot:actions>
        <v-btn
          color="error"
          class="mr-4"
          text
          tile
          :disabled="!isDeleteEnabled"
          :loading="deleteBtnLoading"
          @click="deleteModel"
          >Odstranit
        </v-btn>
        <v-btn color="success" tile :disabled="!isSaveEnabled" @click="saveModel" :loading="saveBtnLoading"
          >Uložit</v-btn
        >
      </template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-card>
        <v-card-title v-if="isNew">Nové ubytování/místo školení</v-card-title>
        <v-card-title v-else>Editace ubytování/místa školení</v-card-title>
        <v-divider />
        <v-card-text>
          <v-row>
            <v-col cols="12" md="6" class="pt-0 pb-0">
              <v-text-field
                v-model="model.Name"
                label="Název ubytování"
                :error-messages="validateField('Name')"
              ></v-text-field>

              <v-text-field v-model="model.Street" label="Ulice"></v-text-field>

              <div class="d-flex">
                <v-text-field v-model="model.City" label="Město"></v-text-field>

                <div style="width: 20px;"></div>

                <v-text-field v-model="model.Zip" label="Psč" style="max-width: 120px;"></v-text-field>
              </div>
            </v-col>
            <v-col cols="12" md="6" class="pt-0 pb-0">
              <v-select
                item-text="Text"
                item-value="Id"
                v-model="model.AccommodationTypes"
                :items="$lists.eola.accommodationTypes"
                label="Typ ubytování/místo školení/..."
                multiple
              >
                <template slot="selection" slot-scope="{ item }">
                  <v-chip small :color="item.Color" text-color="white" class="mr-1">{{ item.Text }}</v-chip>
                </template>
              </v-select>
              <v-textarea auto-grow rows="1" v-model="model.Contact" label="Kontakt / popis" />
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>
    </div>
  </div>
</template>

<script>
import { accommodationsApi } from "../code/apiServicesEola";
import { commonListsApi } from "@/code/apiServices";
import { async } from "q";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";

export default {
  name: "AccommodationDetail",

  mixins: [MixinResolveGeneralResult],

  props: {
    id: {
      type: Number | undefined
    }
  },

  data() {
    return {
      model: null
    };
  },

  async mounted() {
    await this.$store.dispatch("lists/eola/fetchAccommodationTypes");
    this.initModel(this.id);
  },

  methods: {
    async initModel(accommodationId) {
      if (accommodationId > 0) {
        this.model = await accommodationsApi.Get(accommodationId);
      } else {
        this.model = accommodationsApi.CreateEmptyModel();
      }
    },

    async saveModel() {
      this.onBeforeSave();

      const result =
        this.model.Id > 0
          ? await accommodationsApi.Edit(this.model, this.model.Id)
          : await accommodationsApi.Create(this.model);

      this.resolveGeneralResult(
        result,
        { name: "eOlaListsAdministration", params: { id: 2 } },
        "Ubytování uloženo",
        "Změny nebylo možné uložit"
      );
    },

    async deleteModel() {
      const confirmText = "Opravdu si přejete odtranit ubytování?";
      const res = await this.$confirm(confirmText, { buttonTrueText: "ANO", buttonFalseText: "NE" });
      if (res) {
        this.onBeforeSave();
        this.resolveGeneralResult(
          await accommodationsApi.Delete(this.model.Id),
          { name: "eOlaListsAdministration", params: { id: 2 } },
          "Ubytování odstraněno",
          "Změny nebylo možné uložit"
        );
      }
    }
  },

  computed: {
    isNew() {
      return this.model === null || this.model.Id === 0;
    },

    // true pokud lze zobrazit tlacitko SAVE
    isSaveEnabled() {
      return this.model !== null;
    },

    // true pokud lze kurz smazat
    isDeleteEnabled() {
      return !this.isNew;
    }
  }
};
</script>
