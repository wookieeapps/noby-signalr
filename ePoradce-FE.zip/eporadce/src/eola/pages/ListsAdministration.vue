<template>
  <div>
    <v-tabs background-color="transparent" class="mb-5" v-model="tab">
      <v-tab :key="0" :disabled="canEdit">Sekvence kurzů</v-tab>
      <v-tab :key="1" :disabled="canEdit">Šablony emailů</v-tab>
      <v-tab :key="2">Ubytování a místa</v-tab>
    </v-tabs>

    <v-tabs-items v-model="tab" style="background-color: transparent;">
      <v-tab-item :key="0">
        <course-sequences />
      </v-tab-item>
      <v-tab-item :key="1">
        <email-templates :application-id="appId" />
      </v-tab-item>
      <v-tab-item :key="2">
        <accommodations />
      </v-tab-item>
    </v-tabs-items>
  </div>
</template>

<script>
import { ApplicationIdTypes, UserRoles } from "@mpss/eporadce-common";
import CourseSequences from "../components/CourseSequences";
import EmailTemplates from "../../components/EmailTemplates.vue";
import Accommodations from "../components/Accommodations";

export default {
  name: "eOlaListsAdministration",

  components: { EmailTemplates, CourseSequences, Accommodations },

  props: {
    id: {
      type: Number,
      required: false
    }
  },

  data() {
    return {
      tab: null
    };
  },

  async mounted() {
    if (this.id) {
      this.tab = this.id;
    }
  },

  computed: {
    appId() {
      return ApplicationIdTypes.eOla;
    },
    canEdit() {
      return (
        !this.$user.isInRole(UserRoles.eOlaAdmin)
      );
    },
  }
  ,

};
</script>
