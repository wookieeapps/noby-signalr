<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'eOlaCourseEventList' }" :validation-errors="validationErrors">
      <template v-slot:back>Zpět na termíny</template>
      <template #actions>
        <v-btn color="success" tile :disabled="!saveEnabled" @click="saveAttendees" :loading="saveLoading" class="mr-2">
          Uložit
        </v-btn>
        <course-event-actions
          :id="id"
          :can-edit="canEdit"
          :can-print="canPrint"
          :can-write-results="canWriteResults"
          :disabled-write-results="!canWriteDetailResults"
          :disabled-delete="!canDelete"
          @generateDocs="generateDocs"
          buttonText="další"
        ></course-event-actions>
      </template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-row>
        <v-col cols="12" sm="6">
          <v-card>
            <v-card-title>{{ model.Course.Name }}</v-card-title>
            <v-divider />
            <v-card-text>
              <app-text-with-label label="Datum od" :text="model.TimeFrom | parseDatetime"></app-text-with-label>
              <app-text-with-label label="Datum do" :text="model.TimeTo | parseDatetime"></app-text-with-label>
              <app-text-with-label label="Ubytování">
                <span v-if="model.Accommodation.Name">
                  {{ model.Accommodation.Name }}
                  <span v-if="model.Accommodation.Street"><br />{{ model.Accommodation.Street }}</span>
                  <span v-if="model.Accommodation.City"><br />{{ model.Accommodation.City }}</span>
                  <span v-if="model.Accommodation.Zip"><br />{{ model.Accommodation.Zip }}</span>
                  <span v-if="model.AccommodationDescription"><br />{{ model.AccommodationDescription }}</span>
                </span>
                <span v-else>Ne</span>
              </app-text-with-label>
              <app-text-with-label v-if="model.TrainingRoom" label="Školící místnost">
                <span>
                  {{ model.TrainingRoom.Name }}
                  <span v-if="model.TrainingRoom.Street"><br />{{ model.TrainingRoom.Street }}</span>
                  <span v-if="model.TrainingRoom.City"><br />{{ model.TrainingRoom.City }}</span>
                  <span v-if="model.TrainingRoom.Zip"><br />{{ model.TrainingRoom.Zip }}</span>
                  <span v-if="model.TrainingRoomDescription"><br />{{ model.TrainingRoomDescription }}</span>
                </span>
              </app-text-with-label>
              <app-text-with-label label="Lektor">
                <span>
                  <v-chip small class="mr-1" v-for="item in model.Lectors" :key="item.Id">{{ item.Name }}</v-chip>
                </span>
              </app-text-with-label>
              <app-text-with-label label="Poznámka" :text="model.Description"></app-text-with-label>
            </v-card-text>
          </v-card>
        </v-col>
        <v-col cols="12" sm="6">
          <v-card>
            <v-card-title>
              <!-- vyhledavani uzivatelu -->
              <search-attendee v-if="canAddAttendee" @searchChange="searchChange" :course-event-id="model.Id" />
            </v-card-title>
            <v-card-text>
              <!-- zadni uzivatele -->
              <app-box-no-entries :paddingLeft="false" v-if="model.Attendees.length === 0">
                <div class="text-center">žádní přihlášení úživatelé</div>
              </app-box-no-entries>
              <!-- seznam uzivatelu -->
              <v-list v-else>
                <v-list-item dense v-if="model.Accommodation.Name">
                  <v-list-item-content />
                  <v-list-item-action />
                  <v-list-item-action class="text-caption mt-0 mb-0">ubytování</v-list-item-action>
                  <v-list-item-action v-if="canRemoveAttendee" />
                </v-list-item>
                
                <v-list-item v-for="(item, index) in model.Attendees" :key="item.UserId">
                  <v-list-item-content>
                    <v-list-item-title>
                      <router-link :to="{ name: 'UserDetail', params: { id: item.UserId } }">
                        {{ item.DisplayName }}
                      </router-link>
                      <span class="text-caption pl-1"> ({{ item.Cpm }})</span>
                    </v-list-item-title>
                    <v-list-item-subtitle class="text-caption">telefon: {{ item.Phone }}</v-list-item-subtitle>
                    <v-list-item-subtitle class="text-caption">email: <a :href="'mailto:' + item.Email" target="_blank">{{ item.Email }}</a></v-list-item-subtitle>
                    <v-list-item-subtitle class="text-caption">vložil: {{ item.InsertedBy }}</v-list-item-subtitle>
                  </v-list-item-content>
                  <v-list-item-action>
                    <v-dialog v-model="noteDialog[index]" width="500px">
                      <template #activator="{ on }">
                        <v-btn icon v-on="on" :color="item.SignupNote || item.PrivateNote ? 'blue darken-2' : ''">
                          <v-icon>comment</v-icon>
                        </v-btn>
                      </template>
                      <v-card>
                        <v-card-title> Doplňující poznámka <small>(nezobrazuje se v prezenční listině)</small></v-card-title>
                        <v-card-text>
                          <v-textarea
                            v-model="item.PrivateNote"
                            placeholder="text"
                            :readonly="!saveEnabled"
                            auto-grow
                            rows="3"
                          ></v-textarea>
                        </v-card-text>
                        <v-card-title> Poznámka k účasti na školení</v-card-title>
                        <v-card-text>
                          <v-textarea
                            v-model="item.SignupNote"
                            placeholder="text"
                            :readonly="!saveEnabled"
                            auto-grow
                            rows="3"
                          ></v-textarea>
                          <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="primary" text @click="closeNoteDialog(index)"> OK </v-btn>
                          </v-card-actions>
                        </v-card-text>
                      </v-card>
                    </v-dialog>
                  </v-list-item-action>
                  <v-list-item-action v-if="model.Accommodation.Name" class="pl-1">
                    <v-checkbox
                      v-model="item.WithAccommodation"
                      :disabled="!canChangeAccommodationAttendee"
                    ></v-checkbox>
                  </v-list-item-action>
                  <v-list-item-action v-if="canRemoveAttendee">
                    <v-btn icon @click="deleteAttendee(item)"><v-icon>delete</v-icon></v-btn>
                  </v-list-item-action>
                </v-list-item>
                <v-dialog v-model="contactDialog" width="500px">
                  <template #activator="{ on, attrs }" left>
                    <v-btn icon v-on="on" v-bind="attrs">
                      <v-icon>email</v-icon>
                    </v-btn>
                  </template>
                  <v-card>
                    <v-card-title> Emaily pro vložení do outlooku</v-card-title>
                    <v-card-text>
                      <a :href="'mailto:' + contactEmails" target="_blank">{{ contactEmails }}</a>
                      <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn color="primary" text @click="contactDialog = false"> OK </v-btn>
                      </v-card-actions>
                    </v-card-text>
                  </v-card>
                </v-dialog>
              </v-list>
            </v-card-text>
          </v-card>
        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
/* import FileList from "@/components/FileList.vue"; */
import { emailTemplatesApi } from "../../../code/apiServices";
import CourseEventActions from "../../components/CourseEventActions";
import SearchAttendee from "../../components/SearchAttendee";
import MixinCourseEventBase from "../../mixins/MixinCourseEventBase";

export default {
  components: {
    /* FileList, */
    CourseEventActions,
    SearchAttendee
  },

  mixins: [MixinCourseEventBase],

  props: {
    id: {
      type: Number
    }
  },
  methods: {
    closeNoteDialog(index) {
      //this.noteDialog[index] = false;
      this.$set(this.noteDialog, index, false);
    },

    // pridani noveho uzivatele do seznamu
    searchChange(item) {
      this.model.Attendees.unshift({
        UserId: item.Id,
        DisplayName: item.DisplayName,
        Cpm: item.Cpm,
        WithAccommodation: false,
        InsertedBy: this.$user.getSync().DisplayName
      });
    }
  },
  computed: {
    saveEnabled() {
      return this.canAddAttendee || this.canRemoveAttendee || this.canChangeAccommodationAttendee;
    },

    contactEmails(){
      let emails = '';
      for (var usr of this.model.Attendees) {
          emails = emails+usr.Email+';';
      }
      return emails
    }


  }
};
</script>
