<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'eOlaCourseEventList' }" :validation-errors="validationErrors">
      <template #back>Zpět na termíny</template>
      <template #actions>
        <v-btn
          color="error"
          class="mr-4"
          text
          tile
          :disabled="model !== null"
          :loading="deleteBtnLoading"
          @click="deleteEvent"
          >Odstranit</v-btn
        >
        <v-btn color="primary" tile @click="saveEvent(true)" :loading="saveBtnLoading">Uložit</v-btn>
        <v-btn color="primary" tile @click="saveEvent(false)" :loading="saveBtnLoading" class="ml-4"
          >Uložit a nový</v-btn
        >
      </template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-row>
        <v-col cols="12" class="pt-0">
          <v-card>
            <v-card-title>Editace termínu</v-card-title>
            <v-divider />
            <v-card-text>
              <v-row>
                <v-col cols="12" sm="6" class="pt-0 pb-0">
                  <v-select
                    label="Kurz"
                    :items="coursesFilter"
                    item-text="Name"
                    item-value="Id"
                    :value="model.CourseId"
                    @change="changeCourse"
                    :readonly="modelId != 0 && !model.IsDraft"
                    :error-messages="validateField('CourseEvent.CourseId')"
                  />
                </v-col>
                <v-col cols="12" sm="6" class="pt-0 pb-0">
                  <v-checkbox v-model="model.IsDraft" label="Draft (nelze přihlašovat účastníky)"></v-checkbox>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" sm="6" class="pt-0 pb-0">
                  <app-date-picker
                    v-model="model.TimeFrom"
                    label="Datum konání od"
                    is-datetime
                    :timePickerProps="this.timePickerProps"
                    :error-messages="validateField('CourseEvent.TimeFrom')"
                  />
                </v-col>
                <v-col cols="12" sm="6" class="pt-0 pb-0">
                  <app-date-picker
                    v-model="model.TimeTo"
                    label="Datum konání do"
                    is-datetime
                    :timePickerProps="this.timePickerProps"
                    :error-messages="validateField('CourseEvent.TimeTo')"
                  />
                </v-col>
                <v-col cols="12" sm="6" class="pt-0 pb-0">
                  <app-date-picker 
                    v-model="model.SignupDeadline" 
                    label="Uzávěrka přihlášení" 
                    is-datetime
                    :timePickerProps="this.timePickerProps"
                    :error-messages="validateField('CourseEvent.SignupDeadline')" 
                  />
                </v-col>
                <v-col cols="12" sm="6" class="pt-0 pb-0">
                  <app-date-picker 
                    v-model="model.SignoutDeadline" 
                    label="Uzávěrka odhlášení" 
                    is-datetime
                    :timePickerProps="this.timePickerProps"
                    :error-messages="validateField('CourseEvent.SignoutDeadline')" 
                  />
                </v-col>
                <v-col cols="12" md="6" class="pt-0 pb-0">
                  <v-select
                    v-model="model.EvaluationType"
                    label="Způsob vyhodnocení"
                    :items="$lists.eola.evaluationTypes"
                    :error-messages="validateField('model.EvaluationType')"
                    item-text="Text"
                    item-value="Id"
                  />
                </v-col>
                <v-col cols="12" sm="6" lg="3" class="pt-0 pb-0">
                  <v-text-field
                    v-model="model.MinAttendees"
                    label="Min. počet účastníků"
                    :error-messages="validateField('model.MinAttendees')"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" lg="3" class="pt-0 pb-0">
                  <v-text-field
                    v-model="model.MaxAttendees"
                    type="number"
                    label="Max. počet účastníků"
                    :error-messages="validateField('model.MaxAttendees')"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" class="pt-0 pb-0">
                  <v-select
                    v-model="model.CertificateType"
                    label="Certifikát"
                    :items="$lists.eola.certificateTypes"
                    :error-messages="validateField('Course.CertificateType')"
                    item-text="Text"
                    item-value="Id"
                  />
                </v-col>
                <v-col cols="12" sm="6" class="pt-0 pb-0">
                  <v-select
                    label="Lektoři"
                    :items="lectors"
                    item-text="DisplayName"
                    item-value="UserId"
                    v-model="model.Lectors"
                    :error-messages="validateField('model.Lectors')"
                    multiple
                    small-chips
                  />
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12">
          <v-card>
            <v-card-text>
              <v-row>
                <v-col cols="12" md="6" class="pt-0 pb-0">
                  <v-select
                    label="Hotel"
                    :items="accommodations"
                    item-text="Name"
                    item-value="Id"
                    v-model="model.AccommodationId"
                    v-on:change="changeAccommodation"
                    :error-messages="validateField('model.AccommodationId')"
                    clearable
                  />
                  <span v-if="accommodation && hasAddress(accommodation)">{{ addressText(accommodation) }}</span>
                </v-col>
                <v-col cols="12" md="6" class="pt-0 pb-0">
                  <v-textarea v-model="model.AccommodationDescription" auto-grow rows="1" label="Číslo rezervace" />
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12">
          <v-card>
            <v-card-text>
              <v-row>
                <v-col cols="12" md="6" class="pt-0 pb-0">
                  <v-select
                    label="Místo školení"
                    :items="rooms"
                    item-text="Name"
                    item-value="Id"
                    v-model="model.TrainingRoomId"
                    v-on:change="changeRoom"
                    :error-messages="validateField('model.TrainingRoomId')"
                    clearable
                  />
                  <span v-if="room && hasAddress(room)">{{ addressText(room) }}</span>
                </v-col>
                <v-col cols="12" md="6" class="pt-0 pb-0">
                  <v-textarea v-model="model.TrainingRoomDescription" auto-grow rows="1" label="Popis k místu" />
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12" md="6">
          <file-list
            :application-id="appId"
            :object-type-id="objTypeId"
            :object-id="modelId"
            v-model="files"
            :validation-errors="validationErrors"
            :key="filesKey"
          />
        </v-col>

        <v-col v-if="1==2" cols="12" md="6">
          <event-mail-list
            :application-id="appId"
            :object-type-id="objTypeId"
            :object-id="modelId"
            v-model="eventMails"
            :validation-errors="validationErrors"
            :key="eventMailsKey"
          />
        </v-col>

        <v-col cols="12">
          <v-card>
            <v-card-text>
              <v-textarea auto-grow rows="1" label="Poznámka" v-model="model.Description"></v-textarea>
            </v-card-text>
          </v-card>
        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
import FileList from "@/components/FileList.vue";
import EventMailList from "@/components/EventMailList.vue";
import { MixinResolveGeneralResult, AppDatePicker } from "@mpss/eporadce-common-vue";
import { Enums as Common } from "@mpss/eporadce-common-api";
import { commonListsApi, usersApi, fileInfoApi, emailTemplatesApi } from "@/code/apiServices";
import { courseEventsApi, coursesApi, accommodationsApi } from "../../code/apiServicesEola";
import MixinAccommodation from "../../mixins/MixinAccommodation";
import { ApplicationIdTypes, ObjectTypes } from "@mpss/eporadce-common";
import { AccommodationTypes as AccommodationEnum } from "@mpss/eola-api";

export default {
  components: {
    FileList,
    EventMailList
  },

  mixins: [MixinResolveGeneralResult, MixinAccommodation],

  props: {
    id: {
      type: Number | undefined
    }
  },

  data() {
    return {
      modelId: null,
      model: null,
      // seznam kurzu
      courses: [],
      // seznam lektoru
      lectors: [],
      // seznam ubytovani
      accommodations: [],
      // vybrane ubytovani
      accommodation: null,
      // seznam mistnosti
      rooms: [],
      // vybrana mistnost
      room: null,
      // list prilozenych souboru
      files: null,
      filesKey: 1,
      // list mailovych udalosti
      eventMails: null,
      eventMailsKey: 1,
      timePickerProps: { format:"24hr" }
    };
  },

  async mounted() {
    // druhy vyhodnoceni, certifikaty
    await this.$lists.fetch("eola", ["EvaluationTypes", "CertificateTypes"]);

    this.modelId = this.id || 0;

    // existujici termin
    if (this.modelId > 0) {
      this.model = await courseEventsApi.GetEdit(this.id);
    } else {
      // novy termin
      this.model = courseEventsApi.CreateEmptyModel();
    }

    // seznam kurzu
    this.courses = await coursesApi.GetList(null, this.model.CourseId);

    // seznam lektoru
    this.lectors = await usersApi.GetBaseList(this.model.Lectors ? this.model.Lectors : null, 128);

    // ubytovani a skolici mistnosti
    const acc = await accommodationsApi.GetList(
      AccommodationEnum.CourseEvent | AccommodationEnum.TrainingRoom,
      new Array(this.model.AccommodationId, this.model.TrainingRoomId).filter((t) => t)
    );
    this.accommodations = acc.filter(
      (t) => t.AccommodationTypes.indexOf(AccommodationEnum.CourseEvent) != -1 || t.Id === this.model.AccommodationId
    );
    this.rooms = acc.filter(
      (t) => t.AccommodationTypes.indexOf(AccommodationEnum.TrainingRoom) != -1 || t.Id === this.model.TrainingRoomId
    );
  },

  methods: {
    async saveEvent(redir) {
      this.onBeforeSave();

      const result =
        this.modelId > 0
          ? await courseEventsApi.Edit(
              {
                CourseEvent: this.model,
                Files: this.files,
                EmailTemplates: this.eventMails
              },
              this.id
            )
          : await courseEventsApi.Create({
              CourseEvent: this.model,
              Files: this.files,
              EmailTemplates: this.eventMails
            });

      await this.resolveGeneralResult(
        result,
        redir && "eOlaCourseEventList",
        "Termín byl uložen",
        "Změny nebylo možné uložit",
        !redir && this.clearModel
      );
    },

    async deleteEvent() {},

    async clearModel() {
      this.modelId = 0;
      this.model.TimeFrom = null;
      this.model.TimeTo = null;
      this.model.SignupDeadline = null;
      this.model.SignoutDeadline = null;
      return true;
    },

    changeAccommodation(value) {
      this.accommodation = this.accommodations.find((t) => t.Id == value);
    },

    changeRoom(value) {
      this.room = this.rooms.find((t) => t.Id == value);
    },

    async changeCourse(value) {
      if (value && this.model && this.model.CourseId != value) {
        this.model.CourseId = value;
        const course = await coursesApi.Get(value);
        this.model.EvaluationType = course.EvaluationType;
        this.model.CertificateType = course.CertificateType;
        this.model.MinAttendees = course.MinAttendees
        this.model.MaxAttendees = course.MaxAttendees


        //this.files = (await fileInfoApi.GetList(ObjectTypes.eOlaCourse, course.Id, 0, 100)).Data;
        this.filesKey++;

        this.eventMails = await emailTemplatesApi.GetListForObject(ObjectTypes.eOlaCourse, course.Id);
        this.eventMailsKey++;
      }
    }
  },

  computed: {
    appId() {
      return ApplicationIdTypes.eOla;
    },

    objTypeId() {
      return ObjectTypes.eOlaCourseEvent;
    },

    coursesFilter() {

      function compare(a, b){
        if (a.Name < b.Name) return -1;
        if (a.Name > b.Name) return 1;
        return 0
      }

      return this.courses
        ? this.courses.filter((t) => !t.IsArchived || (this.model && this.model.courseId === t.Id)).sort(compare)
        : [];
    },
  }
};
</script>
