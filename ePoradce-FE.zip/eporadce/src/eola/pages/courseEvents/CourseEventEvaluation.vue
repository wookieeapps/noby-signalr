<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'eOlaCourseEventList' }" :validation-errors="validationErrors">
      <template v-slot:back>Zpět na termíny</template>
      <template #actions>
        <v-btn
          color="success"
          tile
          :disabled="!saveEnabled"
          @click="saveEvaluations(true)"
          :loading="saveBtnLoading"
          class="mr-2"
        >
          Uložit a uzavřít hodnocení
        </v-btn>
        <v-btn
          color="success"
          tile
          :disabled="!saveEnabled"
          @click="saveEvaluations(false)"
          :loading="saveBtnLoading"
          class="mr-2"
        >
          Uložit
        </v-btn>
      </template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-card>
        <v-card-title>
          <v-row>
            <v-col cols="auto" class="mr-auto"
              >{{ model.Course.Name }}
              <span class="text-subtitle-2 ml-1">({{ model.TimeFrom | parseDatetime }})</span>
              <span class="ml-3"></span>
            </v-col>
            <v-col cols="auto">
              <v-chip small class="mr-1" v-for="item in model.Lectors" :key="item.Id">{{ item.Name }}</v-chip>
            </v-col>
          </v-row>
        </v-card-title>
        <v-divider />
        <v-card-text>
          <!-- vyhledavani uzivatelu -->
          <v-row align="center">
            <v-col cols="12" sm="2" md="1"> </v-col>
            <v-col cols="12" md="5" class="pt-0 pb-0">
              <search-attendee
                v-if="canAddAttendee && saveEnabled"
                @searchChange="searchChange"
                :course-event-id="model.Id"
                class="mb-3"
              />
            </v-col>
          </v-row>

          <app-box-no-entries :paddingLeft="false" v-if="model.Attendees.length === 0">
            <div class="text-center">žádní přihlášení úživatelé</div>
          </app-box-no-entries>

          <!-- seznam uzivatelu s vysledky -->
          <div v-else class="mt-5">
            <div v-for="(item, index) in model.Attendees" :key="item.UserId">
              <v-divider></v-divider>
              <v-row
                dense
                :class="item.EvaluationGratutade ? 'pt-1 align-center' : 'pt-1 align-center yellow lighten-5'"
              >
                <!-- ucast -->
                <v-col cols="3" sm="2" md="1" class="pt-0 pr-0">
                  <v-switch
                    v-model="item.EvaluationGratutade"
                    flat
                    dense
                    :messages="item.EvaluationGratutade ? 'absolvoval' : 'neabsolvoval'"
                    color="success"
                    :readonly="!saveEnabled"
                    class="pt-0 mt-2"
                  ></v-switch>
                </v-col>

                <!-- jmeno -->
                <v-col cols="9" sm="9" md="3">
                  <div class="text-subtitle-1">
                    <router-link :to="{ name: 'UserDetail', params: { id: item.UserId } }">
                      {{ item.DisplayName }}
                    </router-link>
                  </div>
                  <span class="text-caption pl-1">{{ item.Cpm }}</span>
                </v-col>
                <v-spacer></v-spacer>

                <!-- seznam vysledku -->
                <v-col cols="9" md="6">
                  <component
                    v-if="item.EvaluationGratutade"
                    :is="loadedComponent"
                    :code="model.EvaluationType.toString()"
                    :disabled="!saveEnabled"
                    v-model="item.EvaluationResult"
                  />
                </v-col>

                <v-col cols="3" md="2" class="d-flex justify-end">
                  <!-- body test -->
                  <v-text-field
                    v-if="item.EvaluationGratutade"
                    v-model="item.BodyTest"
                    dense
                    hide-details
                    type="number"
                    label="body test"
                    class="mr-5"
                  />

                  <!-- poznamka -->
                  <v-dialog v-model="noteDialog[index]" width="500px">
                    <template #activator="{ on }">
                      <v-btn icon v-on="on" :color="item.EvaluationNote ? 'blue darken-2' : ''">
                        <v-icon>comment</v-icon>
                      </v-btn>
                    </template>
                    <v-card>
                      <v-card-title>Poznámka k hodnocení</v-card-title>
                      <v-card-text>
                        <v-textarea
                          v-model="item.EvaluationNote"
                          placeholder="text"
                          :readonly="!saveEnabled"
                          auto-grow
                          rows="3"
                        ></v-textarea>
                        <v-card-actions>
                          <v-spacer></v-spacer>
                          <v-btn color="primary" text @click="closeNoteDialog(index)"> OK </v-btn>
                        </v-card-actions>
                      </v-card-text>
                    </v-card>
                  </v-dialog>
                </v-col>
              </v-row>
            </div>
          </div>

          <v-row>
            <v-col cols="12" sm="6"></v-col>
            <v-col cols="12" sm="6">wwww </v-col>
          </v-row>
        </v-card-text>
      </v-card>
    </div>
  </div>
</template>

<script>
import CourseEventActions from "../../components/CourseEventActions";
import SearchAttendee from "../../components/SearchAttendee";
import MixinCourseEventBase from "../../mixins/MixinCourseEventBase";
import { UserRoles } from "@mpss/eporadce-common";

export default {
  components: {
    CourseEventActions,
    SearchAttendee
  },

  mixins: [MixinCourseEventBase],

  props: {
    id: {
      type: Number
    }
  },

  methods: {
    closeNoteDialog(index) {
      this.$set(this.noteDialog, index, false);
    },

    // pridani noveho uzivatele do seznamu
    searchChange(item) {
      if (this.model.Attendees.some((t) => t.UserId == item.Id)) return;

      this.model.Attendees.unshift({
        UserId: item.Id,
        DisplayName: item.DisplayName,
        Cpm: item.Cpm,
        WithAccommodation: false,
        InsertedBy: this.$user.getSync().DisplayName,
        EvaluationGratutade: true
      });
    }
  },

  computed: {
    saveEnabled() {
      return (
        (this.canWriteResults && this.model && !this.model.EvaluationClosed) || this.$user.isInRole(UserRoles.eOlaAdmin)
      );
    },
    loadedComponent() {
      if (this.model && this.model.EvaluationType != 1) {
        return () => import(/* webpackChunkName: "evaluation-result" */ "../../components/EvaluationResultList");
      }
      return null;
    }
  }
};
</script>
