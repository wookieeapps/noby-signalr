<template>
  <v-card>
    <v-card-title class="justify-space-between">
      Termíny
      <div>
        <v-btn color="primary" text tile exact :to="{ name: 'eOlaCourseEventEdit' }">Nový termín</v-btn>
      </div>
    </v-card-title>
    <v-divider />

    <query-builder v-model="queryFilter" ident="eola-courseevent" @input="onQueryChange" />

    <v-data-table
      max-width="1424"
      :headers="headers"
      :items="items"
      :options.sync="options"
      :server-items-length="total"
      :loading="loading"
      :items-per-page="itemsPerPage"
      item-key="Id"
      :item-class="itemRowBackground"
      @update:sort-by="getData"
      @update:sort-desc="getData"
      @update:page="getData"
      :footer-props="{
        showFirstLastPage: true,
        disableItemsPerPage: true,
        itemsPerPageOptions: [itemsPerPage]
      }"
    >
      <template #loading>
        <div class="pa-12">Nahrávám data...</div>
      </template>

      <template #no-data>
        <div class="pa-12">Filtru neodpovídají žádné záznamy</div>
      </template>
      <template v-slot:item.AttendanceList="{ item }">
              <span v-if="item.AttendanceList">
                <v-icon>list</v-icon>
              </span>
              
      </template>
      <template v-slot:item.AccommodationName="{ item }">
              <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                  <span
                    v-bind="attrs"
                    v-on="on"
                  >{{ item.AccommodationName}}</span>
                </template>
                <span>{{item.AccommodationAddress}}</span>
              </v-tooltip>
      </template>
      <template v-slot:item.TrainingRoomName="{ item }">
              <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                  <span
                    v-bind="attrs"
                    v-on="on"
                  >{{ item.TrainingRoomName}}</span>
                </template>
                <span>{{item.TrainingRoomAddress}}</span>
              </v-tooltip>
      </template>

      <template v-slot:item.actions="{ item }">
        <course-event-actions
          :id="item.Id"
          :can-edit="canEdit"
          :can-manage-attendees="canManageAttendees"
          :can-print="canPrint"
          :can-write-results="canWriteResults"
          :disabled-write-results="!canWriteItemResults(item.TimeFrom)"
          :disabled-delete="candDelete(item.Capacity)"
        ></course-event-actions>
      </template>
    </v-data-table>
  </v-card>
</template>

<script>
import { QueryBuilder } from "@mpss/eporadce-common-vue";
import { usersApi } from "@/code/apiServices";
import { courseEventsApi } from "../../code/apiServicesEola";
import { DateHelpers, UserRoles } from "@mpss/eporadce-common";
import MixinCourseEvent from "../../mixins/MixinCourseEvent";
import CourseEventActions from "../../components/CourseEventActions";

export default {
  name: "CourseEventList",

  components: { QueryBuilder, CourseEventActions },

  mixins: [MixinCourseEvent],

  data() {
    return {
      // vychozi pocet zaznamu na strance gridu
      itemsPerPage: 15,
      // vychozi nastaveni filtru
      queryFilter: null,
      // celkem nalezenych radek podle zadaneho filtru
      total: 0,
      // loading state gridu
      loading: false,
      // nastaveni gridu
      options: { filters: null, sortBy: ['TimeFrom'] },
      // hlavicka gridu
      headers: [
        { text: "P", value: "AttendanceList" },
        { text: "Název", value: "Name" },
        { text: "Datum", value: "TimeFrom" },
        { text: "Obs.", value: "Capacity" },
        { text: "Přihláška do", value: "SignupDeadline" },
        { text: "Lektor", value: "Lectors" },
        { text: "Ubytování", value: "AccommodationName" },
        { text: "Místo", value: "TrainingRoomName" },
        { text: "", value: "actions", sortable: false }
      ],
      // data/radky v gridu
      items: []
    };
  },

async mounted() {
    // load default filter
    const userId = (await this.$user.get()).Id;
    this.queryFilter = await usersApi.GetMeta(userId, 2);
    if (this.queryFilter !== null) this.saveFilterToGrid();

    // initial data load
    await this.getData();
  },

  methods: {
    onQueryChange() {
      // save filter to grid options
      this.saveFilterToGrid();

      // refresh data
      this.getData().then((t) => {});

      // save current filter
      this.$user.get().then((t) => {
        usersApi.SaveMeta(t.Id, 2, this.queryFilter).then((t) => {});
      });
    },

    saveFilterToGrid() {
      this.options.filters = this.queryFilter.conditions;
      this.options.connector = this.queryFilter.conditionConnector;
    },

    itemRowBackground: function (item) {
     return item.IsDraft ? 'strikeout' : ''
    },

    // naplnit data do gridu podle zadaneho filtru
    async getData() {
      if (this.loading) return;
      this.loading = true;

      var model = await courseEventsApi.GetList(this.options);
      this.total = model.TotalRows;
      this.items = model.Data;

      this.loading = false;
    }
  }
};
</script>

<style>
.strikeout {
  background-color: rgb(154, 154, 154)
  /*text-decoration: line-through;*/
}
</style>