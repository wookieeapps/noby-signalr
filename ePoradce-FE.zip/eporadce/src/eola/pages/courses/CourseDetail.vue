<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'eOlaCoursesTree' }" :validation-errors="validationErrors">
      <template #back>Zpět na skupiny</template>
      <template #actions>
        <v-btn
          color="error"
          class="mr-4"
          text
          tile
          :disabled="!isDeleteEnabled"
          :loading="deleteBtnLoading"
          @click="deleteCourse"
        >
          {{ deleteBtnTitle }}
        </v-btn>
        <v-btn color="success" tile :disabled="!isSaveEnabled" @click="saveCourse" :loading="saveBtnLoading"
          >Uložit</v-btn
        >
      </template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-alert type="warning" v-if="model.IsArchived">Tento kurz je archivován!</v-alert>

      <v-row>
        <v-col cols="12" class="pt-0">
          <v-card>
            <v-card-title>Editace kurzu</v-card-title>
            <v-divider />
            <v-card-text>
              <v-row>
                <v-col cols="6" class="pt-0 pb-0">
                  <v-text-field
                    label="Název kurzu"
                    v-model="model.Name"
                    :error-messages="validateField('Course.Name')"
                  />

                  <v-select
                    v-model="model.Sequence"
                    label="Zařazení do sekvence"
                    :items="sequences"
                    item-text="Name"
                    item-value="Id"
                    clearable
                  />

                  <v-select
                    v-model="model.EvaluationType"
                    label="Způsob vyhodnocení"
                    :items="$lists.eola.evaluationTypes"
                    :error-messages="validateField('Course.EvaluationType')"
                    item-text="Text"
                    item-value="Id"
                  />

                  <v-select
                    v-model="model.CertificateType"
                    label="Certifikát"
                    :items="$lists.eola.certificateTypes"
                    :error-messages="validateField('Course.CertificateType')"
                    item-text="Text"
                    item-value="Id"
                  />
                </v-col>

                <v-col cols="6" class="pt-0 pb-0" style="margin-top: -12px">
                  <v-row>
                    <v-col cols="12" class="pt-0 pb-0">
                      <selectable-course-group-tree root-level-label="Nezařazen" v-model="model.CourseGroupId" />
                    </v-col>
                  </v-row>
                  <v-row>
                    <v-col cols="12" sm="6" lg="6" class="pt-0 pb-0">
                      <v-text-field
                        v-model="model.MinAttendees"
                        label="Min. počet účastníků"
                        :error-messages="validateField('Course.MinAttendees')"
                      ></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" lg="6" class="pt-0 pb-0">
                      <v-text-field
                        v-model="model.MaxAttendees"
                        type="number"
                        label="Max. počet účastníků"
                        :error-messages="validateField('Course.MaxAttendees')"
                      ></v-text-field>
                    </v-col>
                  </v-row>
                  <v-row>
                    <v-col cols="12" sm="6" class="pt-0 pb-0">
                      <v-checkbox  v-model="model.IsUserDashboard" value label="Zobrazovat uživatelům"></v-checkbox>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="6">
          <v-card>
            <v-card-text>
              <p class="caption grey--text">Poznámka ke kurzu.</p>
              <v-textarea auto-grow rows="4" label="Popis kurzu" v-model="model.Description"></v-textarea>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="6">
          <v-card>
            <v-card-text>
              <p class="caption grey--text">Interní poznámka ke kurzu.</p>
              <v-textarea auto-grow rows="4" label="Interní poznámka" v-model="model.InternalNote" />
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="6">
          <file-list
            :object-type-id="objTypeIdEvent"
            :object-id="model.Id"
            v-model="files"
            :validation-errors="validationErrors"
          />
        </v-col>

        <v-col v-if="1==2" cols="6">
          <event-mail-list
            :application-id="appId"
            :object-type-id="objTypeId"
            :object-type-id-alias="objTypeIdEvent"
            :object-id="model.Id"
            v-model="eventMails"
            :validation-errors="validationErrors"
          />
        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
import FileList from "@/components/FileList.vue";
import EventMailList from "@/components/EventMailList.vue";
import SelectableCourseGroupTree from "../../components/SelectableCourseGroupTree.vue";
import { fileInfoApi, emailTemplatesApi, commonListsApi } from "@/code/apiServices";
import { coursesApi, courseGroupsApi, courseSequenceApi } from "../../code/apiServicesEola";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
import { Enums as Common } from "@mpss/eporadce-common-api";
import { ApplicationIdTypes, ObjectTypes } from "@mpss/eporadce-common";

export default {
  name: "eOlaCourseDetail",

  components: {
    FileList,
    EventMailList,
    SelectableCourseGroupTree
  },

  props: ["id", "group"],

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      model: null,
      // list prilozenych souboru
      files: null,
      // list mailovych udalosti
      eventMails: null,
      // seznam dostupnych sekvenci
      sequences: []
    };
  },

  async mounted() {
    // druhy vyhodnoceni, certifikaty
    await this.$lists.fetch("eola", ["EvaluationTypes", "CertificateTypes"]);

    // seznam sekvenci
    this.sequences = await courseSequenceApi.GetList();

    // ID editovaneho kurzu
    const courseId = this.id ? parseInt(this.id) : 0;
    // ID kategorie, ve ktere bude tato nova kategorie zalozena
    const groupId = this.group ? parseInt(this.group) : 0;

    await this.initModel(courseId, groupId);
  },

  beforeRouteUpdate(to, from, next) {
    this.initModel(to.params.id, 0).then((t) => {
      next();
    });
  },

  computed: {
    appId() {
      return ApplicationIdTypes.eOla;
    },

    objTypeId() {
      return ObjectTypes.eOlaCourse;
    },

    objTypeIdEvent() {
      return ObjectTypes.eOlaCourseEvent;
    },

    isNewCourse() {
      return this.model === null || this.model.Id === 0;
    },

    // true pokud lze zobrazit tlacitko SAVE
    isSaveEnabled() {
      return this.model !== null;
    },

    // true pokud lze kurz smazat
    isDeleteEnabled() {
      return !this.isNewCourse;
    },

    // text tlacitka DELETE
    deleteBtnTitle() {
      return this.model !== null && this.model.IsArchived ? "Smazat" : "Archivovat";
    }
  },

  methods: {
    async initModel(courseId, groupId) {
      // existujici kurz
      if (courseId > 0) {
        this.model = await coursesApi.Get(courseId);
      } else {
        // novy kurz
        this.model = coursesApi.CreateEmptyModel(groupId);
      }
    },

    /**
     * Smazani kurzu
     */
    async deleteCourse() {
      this.deleteBtnLoading = true;

      const confirmText = this.model.IsArchived
        ? "Opravdu si přejete smazat tento kurz?"
        : "Opravdu si přejete archivovat tento kurz?";

      if (await this.$confirm(confirmText, { buttonTrueText: "ANO", buttonFalseText: "NE" })) {
        await this.resolveGeneralResult(
          await coursesApi.Delete(this.model.Id),
          "eOlaCoursesTree",
          this.model.IsArchived ? "Kurz byl smazán" : "Kurz byl archivován"
        );
      } else this.deleteBtnLoading = false;
    },

    /**
     * Ulozeni kurzu
     */
    async saveCourse() {
      this.onBeforeSave();

      const result =
        this.model.Id > 0
          ? await coursesApi.Edit(
              {
                Course: this.model,
                Files: this.files,
                EmailTemplates: this.eventMails
              },
              this.model.Id
            )
          : await coursesApi.Create({
              Course: this.model,
              Files: this.files,
              EmailTemplates: this.eventMails
            });

      await this.resolveGeneralResult(result, "eOlaCoursesTree", "Kurz byl uložen", "Změny nebylo možné uložit");

      /* for future reference
        async r => {
          // nove ID
          const id = this.model.Id === 0 ? parseInt(result) : this.model.Id;

          // ulozit soubory
          const b1 = this.resolveSubResult(
            await fileInfoApi.Update(
              Common.ObjectTypes.eOlaCourse,
              id,
              this.files
            ),
            "Chyba v přiložených souborech",
            "files"
          );

          // ulozit udalosti/sablony
          const b2 = this.resolveSubResult(
            await emailTemplatesApi.Update(
              Common.ObjectTypes.eOlaCourse,
              id,
              this.eventMails
            ),
            "Chyba v událostech",
            "eventMails"
          );

          return b1 && b2;
        }*/
    }
  }
};
</script>
