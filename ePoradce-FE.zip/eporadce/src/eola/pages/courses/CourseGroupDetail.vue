<style scoped>
.groups-tree >>> .v-treeview--dense .v-treeview-node__root {
  min-height: 28px !important;
}
</style>

<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'eOlaCoursesTree' }" :validation-errors="validationErrors">
      <template v-slot:back>Zpět na skupiny</template>
      <template v-slot:actions>
        <v-btn
          color="error"
          class="mr-4"
          text
          tile
          :disabled="!isDeleteEnabled"
          :loading="deleteBtnLoading"
          @click="deleteCategory"
          >Smazat</v-btn
        >
        <v-btn color="success" tile :disabled="!isSaveEnabled" @click="saveCategory" :loading="saveBtnLoading"
          >Uložit</v-btn
        >
      </template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-sheet v-if="!isDeleteEnabled && !isNewCategory">
        <v-alert border="left" type="warning" text
          >Kategorie nelze smazat, protože obsahuje kurzy nebo podkategorie.</v-alert
        >
      </v-sheet>

      <v-row>
        <v-col cols="6" class="pt-0">
          <v-card>
            <v-card-title>{{ !isNewCategory ? "Editace skupiny" : "Nová skupina" }}</v-card-title>
            <v-divider />
            <v-card-text>
              <v-text-field label="Název skupiny" :error-messages="validateField('Name')" v-model="model.Name" />
              {{ model.children }}
              <selectable-course-group-tree root-level-label="Hlavní úroveň" v-model="model.ParentId" />
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="6" class="pt-0" v-if="!isNewCategory">
          <v-card>
            <v-subheader>OBSAHUJE KURZY</v-subheader>

            <app-box-loader v-if="courses === null" />

            <app-box-no-entries v-else-if="courses.length === 0">Zatím nejsou založené žádné kurzy</app-box-no-entries>

            <v-list v-else dense v-for="item in courses" :key="item.Id" class="pt-0">
              <v-list-item exact :to="{ name: 'eOlaCourseDetail', params: { id: item.Id } }">
                <v-list-item-content>
                  <v-list-item-title>{{ item.Name }}</v-list-item-title> </v-list-item-content
                ><v-list-item-action>
                  <v-icon>navigate_next</v-icon>
                </v-list-item-action>
              </v-list-item>
            </v-list>
          </v-card>
        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
import { courseGroupsApi, coursesApi } from "../../code/apiServicesEola";
import SelectableCourseGroupTree from "../../components/SelectableCourseGroupTree.vue";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";

export default {
  name: "eOlaCourseGroupDetail",

  components: {
    SelectableCourseGroupTree
  },

  // id=ID editovane skupiny, parent=ID nadrizene skupiny do ktere se ma vlozit nove vytvarena skupina
  props: ["id", "parent"],

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      model: null,
      // seznam kurzu v teto skupine
      courses: null,
      courseGroups: null
    };
  },

  async mounted() {
    // ID editovane kategorie
    const courseGroupId = this.id ? parseInt(this.id) : 0;
    // ID kategorie, ve ktere bude tato nova kategorie zalozena
    const parentId = courseGroupId === 0 && this.parent ? parseInt(this.parent) : 0;

    await this.initModel(courseGroupId, parentId);
    this.courseGroups = await courseGroupsApi.GetChild(courseGroupId);
  },

  beforeRouteUpdate(to, from, next) {
    this.initModel(to.params.id, 0).then((t) => {
      next();
    });
  },

  computed: {
    isNewCategory() {
      return this.model.Id === 0;
    },

    showCourses() {
      return this.courses && this.courses.length > 0;
    },

    showGroups() {
      return this.courseGroups && this.courseGroups.length > 0;;
    },


    // true pokud lze zobrazit tlacitko SAVE
    isSaveEnabled() {
      return this.model !== null;
    },

    // true pokud lze kategorii smazat
    isDeleteEnabled() {
      if (this.model === null || this.isNewCategory ) return false;
      return !this.showCourses && !this.showGroups;
    }
  },

  methods: {
    async initModel(courseGroupId, parentId) {
      // existujici kategorie
      if (courseGroupId > 0) {
        this.model = await courseGroupsApi.Get(courseGroupId);
        if (this.model === null) {
          this.$toast.error("Skupina kurzů nebyla nalezena");
          return;
        }

        // dotahnout podrizene kurzy
        this.courses = await coursesApi.GetList(this.model.Id);
        
      } else if (parentId > 0) {
        // nova podkategorie
        this.model = courseGroupsApi.CreateEmptyModel();

        const parentModel = await courseGroupsApi.Get(parentId);
        if (parentModel !== null) {
          this.model.ParentId = parentModel.Id;
        }
      } else {
        // kdyz nelze nahrat existujici model, vytvor novy
        this.model = courseGroupsApi.CreateEmptyModel();
      }
    },

    /**
     * Smazani skupiny
     */
    async deleteCategory() {
      this.deleteBtnLoading = true;

      if (
        await this.$confirm("Opravdu si přejete smazat tuto skupinu?", { buttonTrueText: "ANO", buttonFalseText: "NE" })
      ) {
        await this.resolveGeneralResult(
          await courseGroupsApi.Delete(this.model.Id),
          "eOlaCoursesTree",
          "Skupina kurzů byla smazána"
        );
      } else this.deleteBtnLoading = false;
    },

    /**
     * Ulozeni skupiny
     */
    async saveCategory() {
      this.onBeforeSave();

      const result =
        this.model.Id > 0
          ? await courseGroupsApi.Edit(this.model, this.model.Id)
          : await courseGroupsApi.Create(this.model);

      await this.resolveGeneralResult(
        result,
        "eOlaCoursesTree",
        "Skupina kurzů byla uložena",
        "Změny nebylo možné uložit"
      );
    }
  }
};
</script>
