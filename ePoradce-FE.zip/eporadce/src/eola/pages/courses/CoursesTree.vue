<template>
  <v-card>
    <v-card-title class="justify-space-between">
      Seznam skupin kurzů
      <div>
        <v-btn color="primary" text tile exact :to="{ name: 'eOlaCourseGroupDetail' }">Nová skupina</v-btn>
      </div>
    </v-card-title>
    <v-divider />

    <v-card-text>
      <div class="pt-12 pb-12 text-center" v-if="items === null">
        <v-progress-circular indeterminate color="primary" />
      </div>

      <app-box-no-entries v-else-if="items.length === 0">Zatím nejsou založené žádné skupiny</app-box-no-entries>

      <v-treeview
        v-if="items !== null"
        dense
        :active.sync="active"
        :items="items"
        item-key="Id"
        item-children="Children"
        open-on-click
        shaped
        activatable
        @update:active="onActivate"
      >
        <template v-slot:prepend="{ item, open }">
          <v-icon class="grey--text text--lighten-2" v-if="item.Id > 0">{{ open ? "folder_open" : "folder" }}</v-icon>
        </template>

        <template v-slot:append="{ item }">
          <v-menu v-if="item.Id > 0 && item.IsSystem == false" left>
            <template v-slot:activator="{ on }">
              <v-btn text icon color="primary" v-on="on">
                <v-icon>more_vert</v-icon>
              </v-btn>
            </template>
            <v-list dense>
              <v-list-item exact :to="{ name: 'eOlaCourseDetail', params: { group: item.Id } }">
                <v-list-item-icon>
                  <v-icon color="primary">library_books</v-icon>
                </v-list-item-icon>
                <v-list-item-content>
                  <v-list-item-title class="primary--text">Nový kurz do skupiny</v-list-item-title>
                </v-list-item-content>
              </v-list-item>
              <v-divider />
              <v-list-item exact :to="{ name: 'eOlaCourseGroupDetail', params: { id: item.Id } }">
                <v-list-item-icon>
                  <v-icon color="grey">edit</v-icon>
                </v-list-item-icon>
                <v-list-item-content>
                  <v-list-item-title>Upravit skupinu</v-list-item-title>
                </v-list-item-content>
              </v-list-item>
              <v-list-item exact :to="{ name: 'eOlaCourseGroupDetail', params: { parent: item.Id } }">
                <v-list-item-icon>
                  <v-icon color="grey">add</v-icon>
                </v-list-item-icon>
                <v-list-item-content>
                  <v-list-item-title>Vytvořit podskupinu</v-list-item-title>
                </v-list-item-content>
              </v-list-item>
            </v-list>
          </v-menu>
        </template>

        <template v-slot:label="{ item }">
          <template v-if="item.Id > 0">
            <strong>{{ item.Name }}</strong>
          </template>
          <template v-else-if="item.IsArchived">
            <v-icon color="warning" small>hourglass_empty</v-icon>
            <span class="grey--text">
              {{ item.Name }}
              <span v-if="item.Desc" class="caption font-weight-light">({{ item.Desc }})</span>
            </span>
          </template>
          <template v-else>
            {{ item.Name }}
            <span v-if="item.Desc" class="caption grey--text font-weight-light">({{ item.Desc }})</span>
          </template>
        </template>
      </v-treeview>
    </v-card-text>
  </v-card>
</template>

<script>
import { courseGroupsApi } from "../../code/apiServicesEola";

export default {
  name: "eOlaCoursesTree",

  data() {
    return {
      active: [],
      items: null
    };
  },

  beforeRouteEnter(to, from, next) {
    if (to.params.refresh) {
      courseGroupsApi.GetTree(true).then((p) => {
        next((vm) => {
          vm.$data.items = p;
        });
      });
    } else next();
  },

  async mounted() {
    this.items = await courseGroupsApi.GetTree(true);
  },

  methods: {
    onActivate(ids) {
      const id = ids[0];
      this.active = [];

      if (id < 0)
        this.$router.push({
          name: "eOlaCourseDetail",
          params: { id: id * -1 }
        });
    }
  }
};
</script>
