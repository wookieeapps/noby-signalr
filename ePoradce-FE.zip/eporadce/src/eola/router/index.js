// PAGES
const CourseEventList = () => import(/* webpackChunkName: "eola_courseevents" */ "../pages/courseEvents/CourseEventList.vue");
const CourseEventEdit = () => import(/* webpackChunkName: "eola_courseevents" */ "../pages/courseEvents/CourseEventEdit.vue");
const CourseEventDetail = () => import(/* webpackChunkName: "eola_courseevents" */ "../pages/courseEvents/CourseEventDetail.vue");
const CourseEventEvaluation = () => import(/* webpackChunkName: "eola_courseevents" */ "../pages/courseEvents/CourseEventEvaluation.vue");
const CourseGroupDetail = () => import(/* webpackChunkName: "eola_courses" */ "../pages/courses/CourseGroupDetail.vue");
const CourseDetail = () => import(/* webpackChunkName: "eola_courses" */ "../pages/courses/CourseDetail.vue");
const CoursesTree = () => import(/* webpackChunkName: "eola_courses" */ "../pages/courses/CoursesTree.vue");
const ListsAdministration = () => import(/* webpackChunkName: "eola_administration" */ "../pages/ListsAdministration.vue");
const AccommodationDetail = () => import(/* webpackChunkName: "eola_administration" */ "../pages/AccommodationDetail.vue");

const idRouteFce = route => ({ ...route.params, id: Number(route.params.id) });

export default [
  {
    name: "eOlaAccommodationDetail",
    path: "/eola/lists-administration/accommodation/:id?",
    component: AccommodationDetail,
    props: true
  },
  {
    path: "/eola/lists-administration/:id?",
    name: "eOlaListsAdministration",
    component: ListsAdministration,
    props: idRouteFce
  },
  {
    name: "eOlaCoursesTree",
    path: "/eola/courses",
    component: CoursesTree
  },
  {
    name: "eOlaCourseGroupDetail",
    path: "/eola/courses/group/:id?",
    component: CourseGroupDetail,
    props: true
  },
  {
    name: "eOlaCourseDetail",
    path: "/eola/courses/edit/:id?",
    component: CourseDetail,
    props: true
  },
  {
    name: "eOlaCourseEventList",
    path: "/eola/course-events",
    component: CourseEventList
  },
  {
    name: "eOlaCourseEventEdit",
    path: "/eola/course-events/:id?/edit",
    component: CourseEventEdit,
    props: idRouteFce
  },
  {
    name: "eOlaCourseEvent",
    path: "/eola/course-events/:id",
    component: CourseEventDetail,
    props: idRouteFce
  },
  {
    name: "eOlaCourseEventEvaluation",
    path: "/eola/course-events/:id?/evaluation",
    component: CourseEventEvaluation,
    props: idRouteFce
  }
];
