import { commonListsApi } from "@/code/apiServices";

export default {
  namespaced: true,

  state: {
    evaluationTypes: null,
    accommodationTypes: null,
    certificateTypes: null,
    evaluationResults: null
  },

  actions: {
    async fetchEvaluationTypes({ state }) {
      if (state.evaluationTypes === null) {
        state.evaluationTypes = await commonListsApi.GetEvaluationTypes();
      }
    },
    async fetchAccommodationTypes({ state }) {
      if (state.accommodationTypes === null) {
        state.accommodationTypes = (await commonListsApi.GetAccommodationTypes()) || [];
      }
    },
    async fetchCertificateTypes({ state }) {
      if (state.certificateTypes === null) {
        state.certificateTypes = (await commonListsApi.GetCertificateTypes()) || [];
      }
    },
    async fetchEvaluationResults({ state }) {
      if (state.evaluationResults === null) {
        state.evaluationResults = (await commonListsApi.GetEvaluationResults()) || [];
      }
    },

    async fetch({ dispatch }, listTypes) {
      for (let list of listTypes) {
        await dispatch("fetch" + list);
      }
    },

    async fetchAll({ dispatch }) {
      await dispatch("fetchEvaluationTypes");
      await dispatch("fetchAccommodationTypes");
      await dispatch("fetchCertificateTypes");
      await dispatch("fetchEvaluationResults");
    }
  }
};
