import httpClient from "../../code/apiServices";
import * as apis from "@mpss/hiring-api";

export const onboardingApi = new apis.OnboardingApi(httpClient);
export const checkinApi = new apis.CheckinApi(httpClient);
export const toDeleteApi = new apis.ToDeleteApi(httpClient);
export const hiringGeneralApi = new apis.GeneralApi(httpClient);
export const validationApi = new apis.ValidationApi(httpClient);
export const checklistsApi = new apis.ChecklistsApi(httpClient);
export const attributesApi = new apis.AttributesApi(httpClient);
export const approvalApi = new apis.ApprovalApi(httpClient);
export const initiationApi = new apis.InitiationApi(httpClient);
export const finalCheckApi = new apis.FinalCheckApi(httpClient);
