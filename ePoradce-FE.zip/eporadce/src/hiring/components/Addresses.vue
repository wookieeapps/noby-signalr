<template>
  <v-row>
    <v-col cols="12" md="6">
      <v-card>
        <v-subheader>TRVALÉ BYDLIŠTĚ</v-subheader>
        <v-card-text class="pt-0">
          <v-text-field
            label="Ulice"
            maxlength="50"
            v-model="value.Addr1Street"
            @input="update('Addr1Street', $event)"
            :disabled="readonly"
            :error-messages="validateField('User.Addr1Street')"
          />

          <div class="d-flex">
            <v-text-field
              label="PSČ"
              v-model="value.Addr1Zip"
              @input="update('Addr1Zip', $event)"
              :disabled="readonly"
              :error-messages="validateField('User.Addr1Zip')"
              style="max-width: 100px;"
              maxlength="5"
            />
            <div style="width: 20px;"></div>
            <v-combobox
              label="Město"
              maxlength="50"
              v-model="value.Addr1City"
              @input="update('Addr1City', $event)"
              :disabled="readonly"
              :error-messages="validateField('User.Addr1City')"
              :loading="citi1loading"
              :items="city1items"
            />
          </div>
        </v-card-text>
      </v-card>
    </v-col>

    <v-col cols="12" md="6">
      <v-card>
        <v-subheader class="justify-space-between">
          <span>KORESPONDENČNÍ ADRESA</span>
          <v-switch
            dense
            :disabled="readonly"
            v-model="value.IsAddr2Same"
            @input="update('IsAddr2Same', $event)"
            class="v-input--reverse"
          >
            <template #label>
              <span class="caption">stejná jako trvalá</span>
            </template>
          </v-switch>
        </v-subheader>
        <v-card-text class="pt-0" v-show="!value.IsAddr2Same">
          <v-text-field
            label="Ulice"
            maxlength="50"
            v-model="value.Addr2Street"
            @input="update('Addr2Street', $event)"
            :disabled="readonly"
            :error-messages="validateField('User.Addr2Street')"
          />

          <div class="d-flex">
            <v-text-field
              label="PSČ"
              v-model="value.Addr2Zip"
              width="100px"
              @input="update('Addr2Zip', $event)"
              :disabled="readonly"
              :error-messages="validateField('User.Addr2Zip')"
              style="max-width: 100px;"
              maxlength="5"
            />
            <div style="width: 20px;"></div>
            <v-combobox
              label="Město"
              maxlength="50"
              v-model="value.Addr2City"
              @input="update('Addr2City', $event)"
              :disabled="readonly"
              :error-messages="validateField('User.Addr2City')"
              :loading="citi2loading"
              :items="city2items"
            />
          </div>
        </v-card-text>
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";
import { placesApi } from "../../code/apiServices";

export default {
  name: "HiringAddresses",

  mixins: [MixinHiringPagePart],

  data() {
    return {
      city1items: [],
      citi1loading: false,
      city2items: [],
      citi2loading: false
    };
  },

  watch: {
    "value.Addr1Zip": function (value) {
      value && this.getPlaces(value, 1);
    },

    "value.Addr2Zip": function (value) {
      value && this.getPlaces(value, 2);
    }
  },

  methods: {
    getPlaces(value, index) {
      if (/^\d{5}$/.test(value)) {
        this[`citi${index}loading`] = true;

        placesApi.GetPlaceByZip(value).then((t) => {
          this[`city${index}items`] = t;
          this[`citi${index}loading`] = false;
        });
      } else this[`city${index}items`] = [];
    }
  }
};
</script>
