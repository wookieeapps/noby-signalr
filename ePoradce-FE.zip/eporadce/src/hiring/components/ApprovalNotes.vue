<template>
  <div>
    <!-- poznamka -->
    <v-card class="mb-7" v-if="value.ValidationNote">
      <v-subheader>POZNÁMKA ADMINISTRÁTORA</v-subheader>
      <v-card-text class="pt-0" v-html="value.ValidationNote"> </v-card-text>
    </v-card>

    <!-- poznamka -->
    <v-card class="mb-7">
      <v-subheader>POZNÁMKA PRO ADMINISTRÁTORA</v-subheader>
      <v-card-text class="pt-0">
        <v-textarea
          label="Zde napište Váš komentář"
          auto-grow
          :value="value.ApprovalNote"
          @input="update('ApprovalNote', $event)"
          :error-messages="validateField('User.ApprovalNote')"
          :disabled="readonly"
        />
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";

export default {
  name: "HiringApprovalNotes",

  mixins: [MixinHiringPagePart]
};
</script>
