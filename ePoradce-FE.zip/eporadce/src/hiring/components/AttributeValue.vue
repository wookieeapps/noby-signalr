<template>
  <div>
    <v-text-field
      v-if="configuration.InputType == 1"
      label="Hodnota"
      dense
      filled
      single-line
      hide-details
      :value="value"
      @change="update"
      :disabled="readonly"
      :max-length="configuration.MaxLength"
    />

    <app-date-picker
      v-else-if="configuration.InputType == 3"
      label="Hodnota"
      dense
      single-line
      filled
      hide-details
      :datetime="value"
      @input="update"
      :disabled="readonly"
    />

    <v-checkbox
      v-else-if="configuration.InputType == 4"
      class="mt-0"
      label="ANO"
      dense
      single-line
      hide-details
      :input-value="value"
      @change="update"
      :disabled="readonly"
    />

    <v-select
      v-else-if="configuration.InputType == 5"
      :multiple="configuration.Multiple"
      label="Hodnota"
      dense
      filled
      single-line
      hide-details
      :value="valueOrArray"
      @input="update"
      :disabled="readonly"
      :items="configuration.Items"
    />

    <v-select
      v-else-if="configuration.InputType == 6"
      :multiple="configuration.Multiple"
      label="Hodnota"
      dense
      filled
      single-line
      hide-details
      :value="valueOrArray"
      @input="update"
      :disabled="readonly"
      :items="configuration.Items"
    >
      <template v-slot:selection="{ item, selected }" v-if="configuration.Multiple">
        <v-chip :input-value="selected">
          <span v-text="item.value"></span>
        </v-chip>
      </template>
    </v-select>
  </div>
</template>

<script>
export default {
  name: "HiringAttributeValue",

  props: ["value", "configuration", "readonly"],

  computed: {
    valueOrArray() {
      // zkontrolovat zda je to array
      if (Array.isArray(this.value)) return this.value;
      return this.value && this.value.startsWith("[") && this.value.endsWith("]") ? JSON.parse(this.value) : this.value;
    }
  },

  methods: {
    update(value) {
      this.$emit("input", value);
    }
  }
};
</script>
