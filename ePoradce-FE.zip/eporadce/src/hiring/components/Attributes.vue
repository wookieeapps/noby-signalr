<template>
  <div>
    <v-card>
      <v-card-text class="pt-1">
        <v-simple-table>
          <template v-slot:default>
            <thead>
              <tr>
                <th class="text-left">Atribut</th>
                <th>Hodnota</th>
                <th class="text-center">Platnost od</th>
                <th class="text-center">Platnost do</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in $hiring.attributes" :key="item.Id">
                <td v-html="attributeName(item)"></td>
                <td>
                  <hiring-attribute-value
                    v-model="item.Value"
                    :readonly="readonly"
                    :configuration="item.Configuration"
                    @input="updateParent"
                  />
                </td>
                <td align="center">
                  <app-date-picker
                    style="max-width: 170px;"
                    v-if="item.Configuration.IsDateFromEditable"
                    label="Datum od"
                    dense
                    single-line
                    filled
                    hide-details
                    v-model="item.DateFrom"
                    @input="updateParent"
                    :disabled="readonly"
                  />
                </td>
                <td align="center">
                  <app-date-picker
                    style="max-width: 170px;"
                    v-if="item.Configuration.IsDateToEditable"
                    label="Datum do"
                    dense
                    single-line
                    filled
                    hide-details
                    v-model="item.DateTo"
                    @input="updateParent"
                    :disabled="readonly"
                  />
                </td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-card-text>
      <v-card-actions v-if="!readonly">
        <v-btn tile text color="primary" @click="showAttributesP2"
          ><v-icon class="mr-2">launch</v-icon>Uložit a zobrazit atributy tak, jak budou odeslány na P2</v-btn
        >
      </v-card-actions>
    </v-card>

    <v-dialog scrollable v-model="p2attributesDialog" max-width="500">
      <v-card class="pt-1">
        <v-card-text class="px-0">
          <app-box-loader v-show="p2attributes === null" />
          <v-simple-table dense v-show="p2attributes !== null">
            <template v-slot:default>
              <thead>
                <tr>
                  <th class="text-left">Atribut</th>
                  <th>Hodnota</th>
                  <th class="text-center">Platnost od</th>
                  <th class="text-center">Platnost do</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="attr in p2attributes" :key="attr.Id">
                  <td>
                    <strong>{{ attr.Code }}</strong>
                  </td>
                  <td>{{ attr.Value }}</td>
                  <td>{{ attr.DateFrom | date }}</td>
                  <td>{{ attr.DateTo | date }}</td>
                </tr>
              </tbody>
            </template>
          </v-simple-table>
        </v-card-text>
        <v-card-actions class="pr-4 pb-3">
          <v-spacer></v-spacer>
          <v-btn text @click="hideAttributesP2" :loading="p2btnLoading" :disabled="p2btnLoading">Zavřít</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import { attributesApi } from "../code/apiServicesHiring";
import HiringAttributeValue from "./AttributeValue";

export default {
  name: "HiringAttributes",

  components: { HiringAttributeValue },

  props: ["validationErrors", "userId", "save", "readonly"],

  data() {
    return {
      p2attributesDialog: false,
      p2btnLoading: false,
      p2attributes: null
    };
  },

  methods: {
    attributeName(item) {
      if (item.Name) return `${item.Name} <strong>(${item.Code})</strong>`;
      else return `<strong>${item.Code}</strong>`;
    },

    updateParent() {
      this.$emit("change");
    },

    async showAttributesP2() {
      this.p2attributes = null;
      this.p2attributesDialog = true;

      await this.save();
      this.p2attributes = await attributesApi.GetOverview(this.userId);
    },

    hideAttributesP2() {
      this.p2attributesDialog = false;
      this.p2attributes = null;
    }
  }
};
</script>
