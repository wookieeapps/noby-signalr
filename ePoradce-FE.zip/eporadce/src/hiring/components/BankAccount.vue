<template>
  <v-card class="h-100">
    <v-subheader>BANKOVNÍ ÚČET</v-subheader>
    <v-card-text class="pt-0">
      <div class="d-flex">
        <v-text-field
          label="Číslo účtu"
          maxlength="17"
          :disabled="readonly"
          :value="value.AccountNo"
          @input="update('AccountNo', $event)"
          :error-messages="validateField('User.AccountNo')"
        />
        <div style="width: 10px;"></div>
        <v-select
          label="Banka"
          clearable
          :disabled="readonly"
          :value="value.BankCode"
          item-text="Code"
          item-value="Code"
          :items="$lists.shared.banks || []"
          @input="update('BankCode', $event)"
          :error-messages="validateField('User.BankCode')"
          style="max-width: 110px;"
        >
          <template v-slot:item="{ item }">{{ item.Code }} - {{ item.Text }}</template>
        </v-select>
      </div>

      <v-text-field
        label="Specifický symbol"
        maxlength="12"
        :disabled="readonly"
        :value="value.SpecificSymbol"
        @input="update('SpecificSymbol', $event)"
        :error-messages="validateField('User.SpecificSymbol')"
      />
    </v-card-text>
  </v-card>
</template>

<script>
import { commonListsApi } from "../../code/apiServices";
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";

export default {
  name: "HiringBankAccount",

  mixins: [MixinHiringPagePart],

  async created() {
    await this.$lists.fetch("Banks");
  }
};
</script>
