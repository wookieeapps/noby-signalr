<template>
  <div>
    <v-card class="mb-7" v-if="model.OnboardingNote">
      <v-subheader>POZNÁMKA EDITORA</v-subheader>
      <v-card-text class="pt-0" v-html="model.OnboardingNote"> </v-card-text>
    </v-card>

    <!-- zakladni udaje -->
    <v-card class="mb-7">
      <v-card-text>
        <hiring-personal-data v-model="model" :readonly="true" />
      </v-card-text>
    </v-card>

    <!-- info o pozici -->
    <v-card class="mb-4">
      <v-card-text>
        <hiring-position-info v-model="model" :readonly="true" />
      </v-card-text>
    </v-card>

    <v-row class="mb-1">
      <!-- adresy -->
      <v-col cols="12" md="6">
        <v-card>
          <v-subheader>TRVALÉ BYDLIŠTĚ</v-subheader>
          <v-card-text class="pt-0">
            <v-text-field label="Ulice" :value="model.Addr1Street" disabled />

            <div class="d-flex">
              <v-text-field label="PSČ" :value="model.Addr1Zip" disabled style="max-width: 100px" />
              <div style="width: 10px"></div>
              <v-text-field label="Město" :value="model.Addr1City" disabled />
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <!-- kontakty -->
      <v-col cols="12" md="6">
        <v-card>
          <v-subheader>KONTAKTY</v-subheader>
          <v-card-text class="pt-0">
            <v-text-field label="Email soukromý" prepend-icon="mail" disabled :value="model.EmailPersonal" />

            <v-text-field label="Mobil" prepend-icon="phone_iphone" disabled :value="model.Mobil" prefix="+420" />
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>

<script>
import HiringPersonalData from "../components/PersonalData.vue";
import HiringPositionInfo from "../components/PositionInfo.vue";

export default {
  name: "HiringCheckinBody",

  props: ["model"],

  components: { HiringPersonalData, HiringPositionInfo }
};
</script>
