<template>
  <v-card class="mt-4">
    <v-subheader>POZNÁMKA PRO ADMINISTRÁTORA</v-subheader>
    <v-card-text class="pt-0">
      <v-textarea
        label="Zde napište Váš komentář"
        auto-grow
        :value="value.CheckinNote"
        @input="update('CheckinNote', $event)"
        :error-messages="validateField('User.CheckinNote')"
        :disabled="readonly"
      />
    </v-card-text>
  </v-card>
</template>

<script>
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";

export default {
  name: "HiringCheckinNotes",

  mixins: [MixinHiringPagePart]
};
</script>
