<template>
  <div v-if="$lists.hiring.checklistStatuses !== null && checklistSource !== null">
    <v-expansion-panels popout>
      <v-expansion-panel v-for="item in checklistSource" :key="item.Id">
        <v-expansion-panel-header>
          <template v-slot:default="{ open }">
            <hiring-checklist-closed-bar :open="open" :item="item" :user-id="userId" :source="source" />
          </template>
        </v-expansion-panel-header>
        <v-expansion-panel-content>
          <v-row>
            <v-col cols="8" class="pt-0">
              <p v-if="item.Help" class="caption text--secondary" v-html="item.Help"></p>

              <v-row no-gutters>
                <v-col cols="2" class="d-flex align-center">Status:</v-col>
                <v-col cols="10">
                  <v-btn-toggle
                    v-model="item.Status"
                    mandatory
                    dense
                    tile
                    borderless
                    class="w-100"
                    @change="updateParent"
                  >
                    <v-btn
                      text
                      style="flex: 1"
                      :disabled="readonly"
                      :value="sts.Id"
                      v-for="sts in $lists.hiring.checklistStatuses"
                      :key="sts.Id"
                      :color="item.Status === sts.Id ? sts.Color : ''"
                      >{{ sts.Text }}</v-btn
                    >
                  </v-btn-toggle>
                </v-col>
              </v-row>

              <v-row no-gutters class="mt-3" v-if="!item.Configuration.HideNote">
                <v-col cols="2" class="d-flex align-center">Poznámka:</v-col>
                <v-col cols="10">
                  <v-textarea
                    rows="1"
                    auto-grow
                    dense
                    filled
                    hide-details
                    v-model="item.Note"
                    :disabled="readonly"
                    @change="updateParent"
                  />
                </v-col>
              </v-row>

              <hiring-checklist-attribute :id="item.Id" :readonly="readonly" :source="source" />

              <v-row no-gutters class="mt-3" v-if="!readonly || item.HasRequest">
                <v-col cols="2" class="d-flex align-center">Dožádání:</v-col>
                <v-col cols="10">
                  <v-btn small tile v-show="!item.HasRequest" @click="hasRequestClick(item.Id, true)"
                    >Aktivovat dožádání</v-btn
                  >
                  <div v-show="item.HasRequest">
                    <v-textarea
                      rows="1"
                      auto-grow
                      dense
                      filled
                      hide-details
                      :disabled="readonly"
                      :readonly="item.RequestNoteReadonly"
                      v-model="item.RequestNote"
                      @change="updateParent"
                    />
                    <v-btn
                      color="red"
                      small
                      text
                      tile
                      class="mt-1"
                      v-if="!readonly"
                      @click="hasRequestClick(item.Id, false)"
                      >Zrušit dožádání</v-btn
                    >
                    <span v-if="item.RequestSentDate" class="text--disabled font-italic caption float-right pt-1"
                      >Dožádání bylo odesláno {{ item.RequestSentDate | date }}</span
                    >
                    <span v-else class="text--disabled font-italic caption float-right pt-1"
                      >Dožádání bude odesláno při uložení</span
                    >
                  </div>
                </v-col>
              </v-row>
            </v-col>

            <v-col cols="4" class="pt-0">
              <hiring-checklist-files
                :files="
                  filesCollection.filter(
                    (t) =>
                      item.Configuration.FileInfoTypes && item.Configuration.FileInfoTypes.includes(t.FileInfoTypeId)
                  )
                "
              />
            </v-col>
          </v-row>
        </v-expansion-panel-content>
      </v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>

<script>
import HiringChecklistClosedBar from "./ChecklistClosedBar.vue";
import HiringChecklistFiles from "./ChecklistFiles.vue";
import HiringChecklistAttribute from "./ChecklistAttribute.vue";

export default {
  name: "HiringChecklist",

  components: { HiringChecklistAttribute, HiringChecklistFiles, HiringChecklistClosedBar },

  props: ["validationErrors", "readonly", "userId", "files", "source"],

  async mounted() {
    await this.$lists.fetch("hiring", "ChecklistStatuses");
  },

  computed: {
    filesCollection() {
      return this.files || [];
    },

    checklistSource() {
      if (this.source && this.source == "userDetail") return this.$store.state.userDetail.checklists;
      else return this.$hiring.checklists;
    }
  },

  methods: {
    hasRequestClick(id, activate) {
      const item = this.checklistSource.find((t) => t.Id === id);

      item.HasRequest = activate;
      item.RequestNoteReadonly = false;
      item.RequestNote = "";
      item.RequestSentDate = null;

      this.updateParent();
    },

    updateParent() {
      this.$emit("change");
    }
  }
};
</script>
