<template>
  <v-row no-gutters class="mt-3" v-if="attribute">
    <v-col cols="2" class="d-flex align-center">Atribut:</v-col>
    <v-col :cols="columns">
      <hiring-attribute-value
        :readonly="readonly"
        v-model="attribute.Value"
        :configuration="attribute.Configuration"
        @input="update"
      />
    </v-col>
    <v-col cols="3" v-if="attribute.Configuration.IsDateFromEditable">
      <app-date-picker
        style="max-width: 170px;"
        label="Datum od"
        dense
        single-line
        filled
        hide-details
        :disabled="readonly"
        v-model="attribute.DateFrom"
        @input="update"
      />
    </v-col>
    <v-col cols="3" v-if="attribute.Configuration.IsDateToEditable">
      <app-date-picker
        style="max-width: 170px;"
        label="Datum do"
        dense
        single-line
        filled
        hide-details
        :disabled="readonly"
        v-model="attribute.DateTo"
        @input="update"
      />
    </v-col>
  </v-row>
</template>

<script>
import HiringAttributeValue from "./AttributeValue";

export default {
  name: "HiringChecklistAttribute",

  components: { HiringAttributeValue },

  props: ["id", "readonly", "source"],

  computed: {
    attribute() {
      if (this.source && this.source == "userDetail")
        return this.$store.state.userDetail.attributes.find((t) => t.ChecklistId == this.id);
      else return this.$hiring.attributes.find((t) => t.ChecklistId == this.id);
    },

    columns() {
      let c = 4;
      if (!this.attribute.Configuration.IsDateFromEditable) c += 3;
      if (!this.attribute.Configuration.IsDateToEditable) c += 3;
      return c;
    }
  },

  methods: {
    update() {
      this.$emit("change");
    }
  }
};
</script>
