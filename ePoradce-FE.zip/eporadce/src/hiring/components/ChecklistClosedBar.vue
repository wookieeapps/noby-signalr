<template>
  <div class="d-flex align-center justify-space-between pr-4">
    <strong>{{ item.Name }}</strong>
    <v-fade-transition hide-on-leave>
      <div class="text-right" v-show="!open">
        <v-chip small pill outlined class="ml-2" v-if="item.Note">P</v-chip>
        <v-chip small pill color="accent" class="ml-2" v-if="item.HasRequest">DOŽÁDÁNÍ</v-chip>
        <v-chip
          v-if="item.Status == 0"
          small
          pill
          :color="item.Status | list('hiring', 'checklistStatuses') | color"
          class="ml-2 text-uppercase"
          >{{ item.Status | list("hiring", "checklistStatuses") | text }}</v-chip
        >
        <v-tooltip top v-else>
          <template v-slot:activator="{ on }">
            <v-chip
              small
              pill
              v-on="on"
              :color="item.Status | list('hiring', 'checklistStatuses') | color"
              class="ml-2 text-uppercase"
              >{{ item.Status | list("hiring", "checklistStatuses") | text }}</v-chip
            >
          </template>
          <span>{{ item.InsertUser }}, {{ item.InsertTime | datetime }}</span>
        </v-tooltip>
      </div>
    </v-fade-transition>
    <v-fade-transition hide-on-leave>
      <v-btn
        v-if="item.User2ChecklistId"
        v-show="open"
        tile
        small
        text
        color="grey"
        @click.stop="dialogHistoryId = item.Id"
      >
        <v-icon class="mr-2">history</v-icon>
        {{ item.InsertUser }}, {{ item.InsertTime | datetime }}
      </v-btn>
    </v-fade-transition>

    <hiring-checklist-history :user-id="userId" v-model="dialogHistoryId" :source="source" />
  </div>
</template>

<script>
import HiringChecklistHistory from "./ChecklistHistory.vue";

export default {
  name: "HiringChecklistClosedBar",

  components: { HiringChecklistHistory },

  props: ["item", "open", "userId", "source"],

  data() {
    return {
      // history dialog
      dialogHistoryId: null
    };
  }
};
</script>
