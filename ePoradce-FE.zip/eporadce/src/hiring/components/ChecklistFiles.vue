<template>
  <v-list dense subheader>
    <v-list-item
      :href="getDownloadUrl(file.SystemFileName)"
      target="_blank"
      v-for="file in files"
      :key="file.Id"
      class="pl-0 pr-0"
    >
      <v-list-item-avatar class="mt-1 mb-1 mr-2">
        <v-icon>attachment</v-icon>
      </v-list-item-avatar>
      <v-list-item-content>
        <v-list-item-title>{{ file.OriginalFileName }}</v-list-item-title>
        <v-list-item-subtitle>{{ file.InsertUser }}, {{ file.InsertTime | date }}</v-list-item-subtitle>
      </v-list-item-content>
    </v-list-item>
  </v-list>
</template>

<script>
import { fileInfoApi } from "@/code/apiServices";

export default {
  name: "HiringChecklistFiles",

  props: ["files"],

  methods: {
    getDownloadUrl(guid) {
      return process.env.VUE_APP_API_BASE_PATH + fileInfoApi.GetDownloadUrl(guid);
    }
  }
};
</script>
