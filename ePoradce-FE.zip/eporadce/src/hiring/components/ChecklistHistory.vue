<template>
  <v-dialog v-model="show" max-width="1024">
    <v-card>
      <v-card-title class="headline">Historie - {{ title }}</v-card-title>
      <app-box-loader v-show="items === null" />

      <v-timeline dense class="pt-0">
        <v-timeline-item
          fill-dot
          small
          :color="historyItem.Status | list('hiring', 'checklistStatuses') | color"
          v-for="historyItem in items"
          :key="historyItem.Id"
        >
          <template v-slot:icon>
            <v-avatar color="white">
              <v-img
                :src="getUserImg(historyItem.InsertUserId)"
                lazy-src="../../assets/account_circle_black_36dp.png"
                width="40"
              />
            </v-avatar>
          </template>
          <div class="pb-4 pr-6">
            <div class="d-flex align-center">
              <v-chip
                small
                pill
                :color="historyItem.Status | list('hiring', 'checklistStatuses') | color"
                class="mr-4 text-uppercase"
              >
                {{ historyItem.Status | list("hiring", "checklistStatuses") | text }}
              </v-chip>
              <span class="font-weight-bold"
                >{{ historyItem.InsertUser }}, {{ historyItem.InsertTime | datetime }}</span
              >
            </div>
            <div v-if="historyItem.Note" class="grey--text body-2 mt-2" v-text="historyItem.Note"></div>
            <div class="accent--text body-2 mt-2" v-if="historyItem.HasRequest">
              <strong>Dožádání:</strong>
              {{ historyItem.RequestNote }}
            </div>
          </div>
        </v-timeline-item>
      </v-timeline>

      <v-card-actions class="pr-4 pb-3">
        <v-spacer></v-spacer>
        <v-btn text @click="show = false">Zavřít historii</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { usersApi } from "../../code/apiServices";
import { checklistsApi } from "../code/apiServicesHiring";

export default {
  name: "HiringChecklistHistory",

  props: ["value", "userId", "source"],

  data() {
    return {
      items: null,
      show: false
    };
  },

  computed: {
    title() {
      if (this.value) {
        return (this.source && this.source == "userDetail"
          ? this.$store.state.userDetail.checklists
          : this.$hiring.checklists
        ).find((t) => t.Id == this.value).Name;
      } else return "";
    }
  },

  watch: {
    show(v) {
      if (!v) this.$emit("input", null);
    },

    value(v) {
      this.items = null;
      this.show = v != null && v > 0;

      if (this.show) {
        checklistsApi.GetHistory(this.userId, this.value).then((t) => {
          this.items = t;
        });
      }
    }
  },

  methods: {
    getUserImg(id) {
      return usersApi.GetUserImageUrl(id);
    }
  }
};
</script>
