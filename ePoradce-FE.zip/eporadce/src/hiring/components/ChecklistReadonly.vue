<template>
  <div>
    <v-card v-if="$lists.hiring.checklistStatuses === null || $hiring.checklists === null">
      <app-box-loader />
    </v-card>

    <v-card v-else-if="$hiring.checklists.length === 0">
      <v-card-text class="pt-12 pb-12">
        Tento FP nemá žádné dožádání nebo rizikové checklisty.
      </v-card-text>
    </v-card>

    <v-expansion-panels popout v-else>
      <v-expansion-panel v-for="item in $hiring.checklists" :key="item.Id">
        <v-expansion-panel-header>
          <template v-slot:default="{ open }">
            <hiring-checklist-closed-bar :open="open" :item="item" :user-id="userId" />
          </template>
        </v-expansion-panel-header>
        <v-expansion-panel-content>
          <v-row>
            <v-col cols="8" class="pt-0 pb-0">
              <p v-if="item.Help" class="caption text--secondary" v-html="item.Help"></p>

              <v-row no-gutters>
                <v-col cols="2" class="d-flex align-center">Status:</v-col>
                <v-col cols="10" class="text-uppercase">
                  <strong :class="color(item.Status)">{{
                    item.Status | list("hiring", "checklistStatuses") | text
                  }}</strong>
                </v-col>
              </v-row>

              <v-row no-gutters class="mt-3" v-if="item.Note">
                <v-col cols="2" class="d-flex align-center">Poznámka:</v-col>
                <v-col cols="10" class="subtitle-2">{{ item.Note }}</v-col>
              </v-row>

              <v-row no-gutters class="mt-3" v-if="item.HasRequest">
                <v-col cols="2">Dožádání:</v-col>
                <v-col cols="10">
                  <div class="subtitle-2">{{ item.RequestNote }}</div>
                  <div class="text--disabled font-italic caption pt-1">
                    Dožádání bylo odesláno {{ item.RequestSentDate | date }}
                  </div>
                </v-col>
              </v-row>
            </v-col>

            <v-col cols="4" class="pt-0 pb-0">
              <hiring-checklist-files
                :files="
                  filesCollection.filter(
                    (t) =>
                      item.Configuration.FileInfoTypes && item.Configuration.FileInfoTypes.includes(t.FileInfoTypeId)
                  )
                "
              />
            </v-col>
          </v-row>
        </v-expansion-panel-content>
      </v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>

<script>
import { checklistsApi } from "../code/apiServicesHiring";
import HiringChecklistClosedBar from "./ChecklistClosedBar.vue";
import HiringChecklistFiles from "./ChecklistFiles.vue";

export default {
  name: "HiringChecklistReadonly",

  components: { HiringChecklistFiles, HiringChecklistClosedBar },

  props: ["validationErrors", "userId", "files"],

  async mounted() {
    await this.$lists.fetch("hiring", "ChecklistStatuses");
  },

  computed: {
    filesCollection() {
      return this.files ? this.files.Data || [] : [];
    }
  },

  methods: {
    color(value) {
      return this.$options.filters.color(this.$options.filters.list(value, "hiring", "checklistStatuses")) + "--text";
    }
  }
};
</script>
