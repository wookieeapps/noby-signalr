<template>
  <v-card>
    <v-subheader>KONTAKTNÍ ÚDAJE</v-subheader>
    <v-card-text class="pt-0">
      <v-text-field
        label="Email soukromý"
        maxlength="50"
        prepend-icon="mail"
        :disabled="readonly"
        :value="value.EmailPersonal"
        @input="update('EmailPersonal', $event)"
        :error-messages="validateField('User.EmailPersonal')"
      />

      <v-text-field
        label="Mobil"
        maxlength="9"
        prepend-icon="phone_iphone"
        :disabled="readonly"
        :value="value.Mobil"
        prefix="+420"
        @input="update('Mobil', $event)"
        :error-messages="validateField('User.Mobil')"
      />
    </v-card-text>
  </v-card>
</template>

<script>
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";

export default {
  name: "HiringContactData",

  mixins: [MixinHiringPagePart]
};
</script>
