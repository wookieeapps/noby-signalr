<template>
  <fragment v-if="model !== null">
    <!-- general numbers -->
    <general-numbers-widget :data="model" />

    <!-- dozadani -->
    <requests-to-deal-with-widget :items="model.OpenedRequests" @update="$emit('update')" />
  </fragment>
</template>

<script>
import { Fragment } from "vue-fragment";
import { hiringGeneralApi } from "../code/apiServicesHiring";

import GeneralNumbersWidget from "./dashboard/GeneralNumbersWidget.vue";
import RequestsToDealWithWidget from "./dashboard/RequestsToDealWithWidget.vue";

export default {
  name: "HiringDashboard",

  components: { Fragment, GeneralNumbersWidget, RequestsToDealWithWidget },

  data() {
    return {
      model: null
    };
  },

  async mounted() {
    this.model = await hiringGeneralApi.Dashboard();

    this.$emit("update");
  }
};
</script>
