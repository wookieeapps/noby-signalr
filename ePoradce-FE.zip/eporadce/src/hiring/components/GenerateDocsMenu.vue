<template>
  <v-menu top offset-y>
    <template v-slot:activator="{ on }">
      <v-btn v-on="on" tile class="mr-4">
        Tisk dokumentů
        <v-icon>expand_more</v-icon>
      </v-btn>
    </template>
    <v-list>
      <v-list-item @click="generateDocs('spfp')">
        <v-list-item-icon>
          <v-icon :color="spfp ? 'success' : 'grey lighten-2'">get_app</v-icon>
        </v-list-item-icon>
        <v-list-item-title>Generovat SOS</v-list-item-title>
      </v-list-item>
      <v-list-item @click="generateDocs('seju')">
        <v-list-item-icon>
          <v-icon :color="seju ? 'success' : 'grey lighten-2'">get_app</v-icon>
        </v-list-item-icon>
        <v-list-item-title>Generovat SeJu</v-list-item-title>
      </v-list-item>
      <v-list-item @click="generateDocs('krycilist')">
        <v-list-item-icon>
          <v-icon :color="krycilist ? 'success' : 'grey lighten-2'">get_app</v-icon>
        </v-list-item-icon>
        <v-list-item-title>Generovat Krycí list</v-list-item-title>
      </v-list-item>
      <v-list-item @click="generateDocs('povExtSecialisty')">
        <v-list-item-icon>
          <v-icon :color="povExtSecialisty ? 'success' : 'grey lighten-2'">get_app</v-icon>
        </v-list-item-icon>
        <v-list-item-title>Generovat Povinosti Externího Secialisty</v-list-item-title>
      </v-list-item>
    </v-list>
  </v-menu>
</template>

<script>
export default {
  name: "HiringGenerateDocsMenu",

  props: ["createFce"],

  data() {
    return {
      spfp: false,
      seju: false,
      krycilist: false,
      povExtSecialisty: false
    };
  },

  methods: {
    generateDocs(docType) {
      this.createFce(docType).then((t) => {
        if (t) this[docType] = true;
      });
    }
  }
};
</script>
