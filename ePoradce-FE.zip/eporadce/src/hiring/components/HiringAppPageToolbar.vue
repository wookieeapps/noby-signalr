<template>
  <app-page-toolbar
    :back-to="{ name: 'HiringUserList' }"
    :validation-errors="validationErrors"
    @validationChanged="$emit('validationChanged', $event)"
  >
    <template v-slot:back>Zpět na seznam</template>
    <template v-slot:actions>
      <v-btn
        v-if="isDeleteVisible"
        color="error"
        class="mr-4"
        text
        tile
        :disabled="!isDeleteEnabled"
        :loading="deleteBtnLoading"
        @click="$emit('deleteUser')"
        >Smazat</v-btn
      >

      <v-btn v-if="readonly" color="success" tile @click="$emit('saveUpload')" :loading="saveBtnLoading"
        >Uložit soubory</v-btn
      >

      <v-btn
        v-else-if="isSaveVisible"
        color="success"
        tile
        :disabled="!isSaveEnabled"
        @click="$emit('saveUser')"
        :loading="saveBtnLoading"
        >Uložit</v-btn
      >
    </template>
  </app-page-toolbar>
</template>

<script>
export default {
  name: "HiringAppPageToolbar",

  props: [
    "validationErrors",
    "deleteBtnLoading",
    "isDeleteEnabled",
    "isDeleteVisible",
    "isSaveVisible",
    "isSaveEnabled",
    "saveBtnLoading",
    "readonly"
  ]
};
</script>
