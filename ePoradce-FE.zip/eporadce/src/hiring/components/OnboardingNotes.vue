<template>
  <v-card class="mt-4">
    <v-subheader>POZNÁMKA PRO KONTROLORA</v-subheader>
    <v-card-text class="pt-0">
      <v-textarea
        label="Zde napište Váš komentář"
        auto-grow
        :value="value.OnboardingNote"
        @input="update('OnboardingNote', $event)"
        :error-messages="validateField('User.OnboardingNote')"
        :disabled="readonly"
      />
    </v-card-text>
  </v-card>
</template>

<script>
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";

export default {
  name: "HiringOnboardingNotes",

  mixins: [MixinHiringPagePart]
};
</script>
