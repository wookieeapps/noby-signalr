<template>
  <div>
    <!-- POCE 1 -->
    <v-autocomplete
      label="PoCe působnost K1"
      item-value="Id"
      item-text="Street"
      no-filter
      :cache-items="false"
      clearable
      :disabled="readonly"
      :search-input.sync="poce1search"
      :items="poce1items"
      :loading="poce1loading"
      :value="value.Poce1Id"
      @input="update('Poce1Id', $event)"
      :error-messages="validateField('User.Poce1Id')"
    >
      <template v-slot:no-data>
        <v-list-item>
          <v-list-item-title>Název ulice, město...</v-list-item-title>
        </v-list-item>
      </template>
      <template v-slot:item="{ item }">
        <v-list-item-content>
          <v-list-item-title v-text="item.Street"></v-list-item-title>
          <v-list-item-subtitle>{{ item.City }} {{ item.Zip }}</v-list-item-subtitle>
        </v-list-item-content>
      </template>
    </v-autocomplete>

    <!-- POCE 2 -->
    <v-autocomplete
      label="PoCe působnost K2"
      item-value="Id"
      item-text="Street"
      no-filter
      :cache-items="false"
      clearable
      :disabled="readonly"
      :search-input.sync="poce2search"
      :items="poce2items"
      :loading="poce2loading"
      :value="value.Poce2Id"
      @input="update('Poce2Id', $event)"
      :error-messages="validateField('User.Poce2Id')"
    >
      <template v-slot:no-data>
        <v-list-item>
          <v-list-item-title>Název ulice, město...</v-list-item-title>
        </v-list-item>
      </template>
      <template v-slot:item="{ item }">
        <v-list-item-content>
          <v-list-item-title v-text="item.Street"></v-list-item-title>
          <v-list-item-subtitle>{{ item.City }} {{ item.Zip }}</v-list-item-subtitle>
        </v-list-item-content>
      </template>
    </v-autocomplete>

    <!-- pracovni zarazeni -->
    <v-select
      v-if="value.UserGroupType == '998'"
      label="Předchozí zaměstnání - pracovní zařazení"
      item-text="Text"
      item-value="Id"
      clearable
      :disabled="readonly"
      :items="$lists.hiring.jobClassifications || []"
      :value="value.JobClassificationId"
      @input="update('JobClassificationId', $event)"
      :error-messages="validateField('User.JobClassificationId')"
    />

    <!-- oblast cinnosti -->
    <v-select
      v-if="value.UserGroupType == '998'"
      label="Předchozí zaměstnání - oblast činnosti"
      item-text="Text"
      item-value="Id"
      clearable
      :disabled="readonly"
      :items="$lists.hiring.jobActivities || []"
      :value="value.JobActivityId"
      @input="update('JobActivityId', $event)"
      :error-messages="validateField('User.JobActivityId')"
    />

    <!-- zdroj naboru -->
    <v-select
      v-if="value.UserGroupType == '998' || value.UserGroupType == '904'"
      label="Nábor - zdroj"
      item-text="Text"
      item-value="Id"
      clearable
      :disabled="readonly"
      :items="$lists.hiring.recruitmentSources || []"
      :value="value.RecruitmentSourceId"
      @input="update('RecruitmentSourceId', $event)"
      :error-messages="validateField('User.RecruitmentSourceId')"
    />

    <v-scroll-x-transition>
      <v-text-field
        v-show="showRecruitmentNote"
        label="Nábor - poznámka"
        :disabled="readonly"
        :value="value.RecruitmentNote"
        @input="update('RecruitmentNote', $event)"
        :error-messages="validateField('User.RecruitmentNote')"
      />
    </v-scroll-x-transition>

    <!-- exekuce -->
    <v-select
      label="Exekuce nyní a v posledních 3 letech"
      :disabled="pepDisabled"
      :value="value.Execution"
      @input="update('Execution', $event)"
      :error-messages="validateField('User.Execution')"
      :items="yesNoItems"
      clearable
    />

    <!-- PEP -->
    <v-select
      label="PEP nebo k ní osoba blízká"
      :disabled="pepDisabled"
      :value="value.PEP"
      @input="update('PEP', $event)"
      :error-messages="validateField('User.PEP')"
      :items="yesNoItems"
      clearable
    />

    <v-scroll-x-transition>
      <v-text-field
        v-show="value.PEP"
        label="Vztah k PEP"
        :disabled="pepDisabled"
        :value="value.PEPNote"
        @input="update('PEPNote', $event)"
        :error-messages="validateField('User.PEPNote')"
      />
    </v-scroll-x-transition>
    <!-- PublicOfficial -->
    <v-select
      label="Veřejný činitel nebo k ní osoba blízká"
      :disabled="poDisabled"
      :value="value.PublicOfficial"
      @input="update('PublicOfficial', $event)"
      :error-messages="validateField('User.PublicOfficial')"
      :items="yesNoItems"
      clearable
    />

    <v-scroll-x-transition>
      <v-text-field
        v-show="value.PublicOfficial"
        label="Vztah k Veřejnému činiteli"
        :disabled="poDisabled"
        :value="value.PublicOfficialNote"
        @input="update('PublicOfficialNote', $event)"
        :error-messages="validateField('User.PublicOfficialNote')"
      />
    </v-scroll-x-transition>

    <!-- BankAccountIsMy -->
    <v-select
      label="Účet pro zasílání provizí veden na mou osobu"
      :disabled="pepDisabled"
      :value="value.BankAccountIsMy"
      @input="update('BankAccountIsMy', $event)"
      :error-messages="validateField('User.BankAccountIsMy')"
      :items="yesNoItems"
      clearable
    />

  </div>
</template>

<script>
import { UserWorkflowStatuses } from "@mpss/hiring-api";
import { Helpers } from "@mpss/eporadce-common";
import { placesApi } from "../../code/apiServices";
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";

export default {
  name: "HiringOtherData",

  mixins: [MixinHiringPagePart],

  data() {
    return {
      poce1search: null,
      poce2search: null,
      poce1loading: false,
      poce2loading: false,
      poce1items: [],
      poce2items: [],
      yesNoItems: [
        { value: true, text: "ANO" },
        { value: false, text: "NE" }
      ]
    };
  },

  async created() {
    await this.$lists.fetch("hiring", ["JobClassifications", "JobActivities", "RecruitmentSources"]);

    if (this.value.Poce1Id) {
      const poce1 = await placesApi.GetPoCeById(this.value.Poce1Id);
      this.poce1items = [poce1];
    }
    if (this.value.Poce2Id) {
      const poce2 = await placesApi.GetPoCeById(this.value.Poce2Id);
      this.poce2items = [poce2];
    }
  },

  computed: {
    showRecruitmentNote() {
      return [1, 2, 5, 9, 10, 11].includes(this.value.RecruitmentSourceId);
    },

    pepDisabled() {
      return this.readonly || this.value.WorkflowStatus != UserWorkflowStatuses.Onboarding;
    },

    poDisabled() {
      return this.readonly || this.value.WorkflowStatus != UserWorkflowStatuses.Onboarding;
    }
  },

  watch: {
    poce1search(val) {
      val && this.searchPoce(1, val);
    },

    poce2search(val) {
      val && this.searchPoce(2, val);
    }
  },

  methods: {
    searchPoce(index, term) {
      this[`poce${index}loading`] = true;

      Helpers.debounce((term) => {
        if (term != this[`poce${index}search`]) return;

        placesApi.GetPoCeByTerm(term).then((t) => {
          this[`poce${index}items`] = t;
          this[`poce${index}loading`] = false;
        });
      }, 400)(term);
    }
  }
};
</script>
