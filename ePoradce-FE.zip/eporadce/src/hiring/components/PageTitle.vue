<template>
  <v-card-title class="justify-space-between">
    <span
      >{{ user.WorkflowStatus | list("hiring", "workflowStatuses") | text }}
      <v-icon color="grey lighten-2" class="ml-2" v-if="user.IsReadonly">lock</v-icon></span
    >
    <hiring-workflow-menu
      v-if="user.WorkflowStatus != 1"
      :statuses="user.Workflow"
      :current-status="user.WorkflowStatusName"
    />
  </v-card-title>
</template>

<script>
import HiringWorkflowMenu from "./WorkflowMenu.vue";

export default {
  name: "HiringPageTitle",

  props: ["user"],

  components: { HiringWorkflowMenu }
};
</script>
