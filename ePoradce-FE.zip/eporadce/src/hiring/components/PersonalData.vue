<template>
  <v-row :class="{ 'pt-1': readonly }">
    <v-col cols="12" md="6">
      <v-row v-if="!statusValidation && !statusFinalCheck">
        <v-col cols="6">
          <v-text-field label="Rodné číslo" disabled :value="value.PersonalId" />
        </v-col>
        <v-col cols="6">
          <v-text-field label="Typ prodejce" disabled :value="value.UserGroupType" />
        </v-col>
      </v-row>

      <div class="d-flex" v-if="show(value.Salutation)">
        <v-select
          v-if="show(value.Salutation)"
          label="Oslovení"
          item-text="Text"
          item-value="Id"
          :items="$lists.shared.userSalutations || []"
          :disabled="readonly"
          :value="value.Salutation"
          @input="update('Salutation', $event)"
          :error-messages="validateField('User.Salutation')"
          style="max-width: 120px"
        />
        <div style="width: 20px" v-if="show(value.Title)"></div>
        <v-combobox
          v-if="show(value.Title)"
          clearable
          label="Titul"
          item-text="Text"
          item-value="Text"
          :return-object="false"
          :items="$lists.shared.titles || []"
          :disabled="readonly"
          :value="value.Title"
          @input="update('Title', $event)"
          :error-messages="validateField('User.Title')"
        />
        <div style="width: 20px" v-if="show(value.Title2)"></div>
        <v-combobox
          v-if="show(value.Title2)"
          clearable
          label="Titul za"
          item-text="Text"
          item-value="Text"
          :return-object="false"
          :items="$lists.shared.titles2 || []"
          :disabled="readonly"
          :value="value.Title2"
          @input="update('Title2', $event)"
          :error-messages="validateField('User.Title2')"
        />
      </div>

      <v-text-field
        label="Jméno"
        maxlength="40"
        :disabled="readonly"
        :value="value.Firstname"
        @input="update('Firstname', $event)"
        :error-messages="validateField('User.Firstname')"
      />

      <v-text-field
        label="Příjmení"
        maxlength="40"
        :disabled="readonly"
        :value="value.Surname"
        @input="update('Surname', $event)"
        :error-messages="validateField('User.Surname')"
      />

      <v-text-field
        label="Rodné příjmení"
        maxlength="40"
        :disabled="readonly"
        :value="value.BirthSurname"
        @input="update('BirthSurname', $event)"
        :error-messages="validateField('User.BirthSurname')"
      />

      <div class="d-flex" v-if="show(value.IC)">
        <v-text-field
          label="IČ"
          maxlength="10"
          :disabled="readonly"
          :value="value.IC"
          @input="update('IC', $event)"
          :error-messages="validateField('User.IC')"
        />
        <div style="width: 20px"></div>
        <v-checkbox
          label="Plátce DPH"
          :disabled="readonly"
          :input-value="value.IsVatRegistered"
          @change="update('IsVatRegistered', $event)"
          :error-messages="validateField('User.IsVatRegistered')"
        />
      </div>
    </v-col>

    <!-- navrh data zasmluvneni -->
    <v-col cols="12" md="6">
      <v-radio-group
        class="pb-1"
        :value="value.Gender"
        row
        label="Pohlaví: "
        :disabled="readonly"
        @change="update('Gender', $event)"
        :error-messages="validateField('User.Gender')"
      >
        <v-radio label="muž" :value="1"></v-radio>
        <v-radio label="žena" :value="2"></v-radio>
      </v-radio-group>

      <v-autocomplete
        clearable
        :value="value.NationalityCode"
        :disabled="readonly"
        :items="$lists.shared.countries || []"
        item-text="Name"
        item-value="Code"
        label="Státní příslušnost"
        @change="update('NationalityCode', $event)"
        :error-messages="validateField('User.NationalityCode')"
      />

      <v-autocomplete
        clearable
        :value="value.BirthCountryCode"
        :disabled="readonly"
        :items="$lists.shared.countries || []"
        item-text="Name"
        item-value="Code"
        label="Stát narození"
        @change="update('BirthCountryCode', $event)"
        :error-messages="validateField('User.BirthCountryCode')"
      />

      <v-text-field
        label="Místo narození"
        maxlength="150"
        :disabled="readonly"
        :value="value.BirthPlace"
        @input="update('BirthPlace', $event)"
        :error-messages="validateField('User.BirthPlace')"
      />

      <v-autocomplete
        clearable
        :value="value.WorkInGroup"
        :disabled="readonly"
        :items="$lists.hiring.workInGroupTypes || []"
        item-text="Text"
        item-value="Id"
        label="Pracoval jste někdy v KB/MP?"
        @change="update('WorkInGroup', $event)"
        :error-messages="validateField('User.WorkInGroup')"
      />

      <v-autocomplete
        clearable
        :value="value.TaxResidenceCode"
        :disabled="readonly"
        :items="$lists.shared.countries || []"
        item-text="Name"
        item-value="Code"
        label="Daňová rezidence"
        @change="update('TaxResidenceCode', $event)"
        :error-messages="validateField('User.TaxResidenceCode')"
      />
    </v-col>
  </v-row>
</template>

<script>
import { UserWorkflowStatuses } from "@mpss/hiring-api";
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";

export default {
  name: "HiringPersonalData",

  mixins: [MixinHiringPagePart],

  async created() {
    await this.$lists.fetch(["Titles", "Titles2", "UserSalutations", "Countries"]);
    await this.$lists.fetch("hiring", "WorkInGroupTypes");
  },

  computed: {
    statusValidation() {
      return this.value.WorkflowStatus === UserWorkflowStatuses.Validation;
    },

    statusFinalCheck() {
      return this.value.WorkflowStatus === UserWorkflowStatuses.FinalCheck;
    }
  }
};
</script>
