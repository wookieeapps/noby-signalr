<template>
  <v-card v-if="poce1 || poce2">
    <v-subheader v-if="poce1">POCE 1</v-subheader>
    <v-card-text v-if="poce1" class="pt-0">
      {{ poce1.Street }}
      <br />
      {{ poce1.Zip }} {{ poce1.City }}
    </v-card-text>
    <v-subheader v-if="poce2">POCE 2</v-subheader>
    <v-card-text v-if="poce2" class="pt-0">
      {{ poce2.Street }}
      <br />
      {{ poce2.Zip }} {{ poce2.City }}
    </v-card-text>
  </v-card>
</template>

<script>
import { placesApi } from "../../code/apiServices";

export default {
  name: "HiringPoceReadonly",

  props: ["model"],

  data() {
    return {
      poce1: null,
      poce2: null
    };
  },

  async mounted() {
    if (this.model.Poce1Id) {
      this.poce1 = await placesApi.GetPoCeById(this.model.Poce1Id);
    }
    if (this.model.Poce2Id) {
      this.poce2 = await placesApi.GetPoCeById(this.model.Poce2Id);
    }
  }
};
</script>
