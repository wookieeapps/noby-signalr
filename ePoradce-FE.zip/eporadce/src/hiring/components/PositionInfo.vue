<template>
  <v-row :class="{ 'pt-4': readonly }">
    <v-col cols="12" md="6">
      <!-- pozice FP -->
      <v-select
        label="Pozice"
        item-text="Name"
        item-value="Code"
        clearable
        :disabled="readonly || value.UserGroupType == '906'"
        :items="positions"
        :value="value.PositionCode"
        @input="update('PositionCode', $event)"
        :error-messages="validateField('User.PositionCode')"
      />

      <v-scroll-x-transition>
        <v-select
          v-show="expTypes"
          label="Typ FP"
          item-text="Text"
          item-value="Id"
          clearable
          :disabled="readonly"
          :items="$lists.hiring.experienceTypes || []"
          :value="value.ExperienceType"
          @input="update('ExperienceType', $event)"
          :error-messages="validateField('User.ExperienceType')"
        />
      </v-scroll-x-transition>
    </v-col>

    <v-col cols="12" md="6">
      <v-select
        v-if="!statusValidation && !statusFinalCheck && !readonly"
        label="Návrh data zasmluvnění"
        v-model="value.DraftContractDate"
        :items="draftDateItems"
        :disabled="readonly"
        :error-messages="validateField('User.DraftContractDate')"
        @change="update('DraftContractDate', $event)"
      />
      <app-static-text v-else-if="!statusValidation && !statusFinalCheck && readonly" label="Návrh data zasmluvnění">{{
        draftDate
      }}</app-static-text>

      <!-- uzemni zarazeni -->
      <div class="d-flex">
        <v-scroll-x-transition hide-on-leave>
          <v-autocomplete
            v-show="!value.IsUserGroupMissing"
            label="Územní zařazení"
            item-value="Id"
            item-text="Name"
            no-filter
            :cache-items="false"
            clearable
            :disabled="readonly || value.UserGroupType == '906'"
            :search-input.sync="userGroupSearch"
            :items="userGroupItems"
            :loading="userGroupLoading"
            :value="value.UserGroupId"
            @input="update('UserGroupId', $event)"
            :error-messages="validateField('User.UserGroupId')"
          >
            <template #no-data>
              <v-list-item>
                <v-list-item-title>Název území...</v-list-item-title>
              </v-list-item>
            </template>

            <template #selection="{ item }">
              <div class="text-no-wrap d-inline-block text-truncate">{{ item.Code }} {{ item.Name }}</div>
            </template>

            <template #item="{ item }">
              <v-list-item-content>{{ item.Code }} {{ item.Name }}</v-list-item-content>
            </template>
          </v-autocomplete>
        </v-scroll-x-transition>

        <!-- uz. zarazeni rucne - pouze pro 904 -->
        <v-scroll-x-reverse-transition hide-on-leave>
          <v-text-field
            v-show="value.IsUserGroupMissing"
            label="Územní zařazení - ručně"
            maxlength="50"
            :disabled="readonly"
            :value="value.UserGroupNote"
            @input="update('UserGroupNote', $event)"
            :error-messages="validateField('User.UserGroupNote')"
          />
        </v-scroll-x-reverse-transition>
        <div style="width: 20px" v-if="value.UserGroupType == '904'"></div>
        <v-checkbox
          v-if="value.UserGroupType == '904'"
          hide-details
          v-show="!readonly || value.IsUserGroupMissing"
          label="Neexistuje"
          :disabled="readonly"
          :input-value="value.IsUserGroupMissing"
          @change="update('IsUserGroupMissing', $event)"
          :error-messages="validateField('User.IsUserGroupMissing')"
        />
      </div>
    </v-col>
  </v-row>
</template>

<script>
import { UserWorkflowStatuses } from "@mpss/hiring-api";
import { ApplicationIdTypes, Helpers } from "@mpss/eporadce-common";
import { userGroupsApi } from "../../code/apiServices";
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";

export default {
  name: "HiringPositionInfo",

  mixins: [MixinHiringPagePart],

  data() {
    return {
      draftDateItems: [],
      userGroupSearch: null,
      userGroupLoading: false,
      userGroupItems: [],
      userGroupLastText: "" // zasranej workaround aby se nespoustelo hledani pri nacteni stranky. fuck vuetify
    };
  },

  async created() {
    await this.$lists.fetch("hiring", ["Positions", "ExperienceTypes"]);

    if (this.value.UserGroupId) {
      const grp = await userGroupsApi.Get(this.value.UserGroupId);
      this.userGroupItems = [grp];
      this.userGroupLastText = grp.Name;
    } else {
      this.userGroupItems = await userGroupsApi.Search("", ApplicationIdTypes.Hiring);
    }

    // draft dates
    const draftDates = [
      {
        value: "",
        text: "co nejdříve"
      }
    ];
    for (let i = 1; i <= 3; i++) {
      const d = this.$dates.startOfMonth(this.$dates.addMonths(new Date(), i));
      draftDates.push({
        value: d,
        text: this.$dates.format(d)
      });
    }

    this.draftDateItems = draftDates;
  },

  computed: {
    statusValidation() {
      return this.value.WorkflowStatus === UserWorkflowStatuses.Validation;
    },

    statusFinalCheck() {
      return this.value.WorkflowStatus === UserWorkflowStatuses.FinalCheck;
    },

    expTypes() {
      return this.value.UserGroupType == "904";
    },

    positions() {
      if (this.$lists.hiring.positions === null) return [];
      return this.$lists.hiring.positions.filter((t) => t.UserGroupType === this.value.UserGroupType) || [];
    },

    draftDate() {
      if (this.value.DraftContractDate) return this.$dates.format(this.value.DraftContractDate);
      else return "Co nejdříve";
    }
  },

  watch: {
    userGroupSearch(val) {
      val && this.searchUserGroup(val);
    }
  },

  methods: {
    searchUserGroup(term) {
      this.userGroupLoading = true;

      Helpers.debounce((term) => {
        if (term != this.userGroupSearch) return;
        userGroupsApi.Search(term, ApplicationIdTypes.Hiring).then((t) => {
          this.userGroupLoading = false;
          this.userGroupItems = t;
        });
      }, 400)(term);
    }
  }
};
</script>
