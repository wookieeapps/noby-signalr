<template>
  <div>
    <v-row>
      <v-col cols="6" md="3">
        <v-text-field label="ČPM" :value="value.CPM" disabled />

        <v-text-field label="Rodné číslo" disabled :value="value.PersonalId" hide-details />
      </v-col>
      <v-col cols="6" md="3">
        <v-text-field label="IČP" :value="value.ICP" disabled />

        <v-text-field label="Typ prodejce" disabled :value="value.UserGroupType" hide-details />
      </v-col>
      <v-col cols="6" md="3">
        <v-text-field label="Návrh data zasmluvnění" :value="draftDate" disabled />

        <v-select
          v-if="showContractInfo"
          label="Verze smlouvy"
          :items="contractItems"
          :value="value.ContractVersion"
          :disabled="readonly"
          @input="update('ContractVersion', $event)"
          :error-messages="validateField('User.ContractVersion')"
        />
      </v-col>
      <v-col cols="6" md="3">
        <app-date-picker
          v-if="showContractInfo"
          label="Datum nástupu"
          :datetime="value.ContractDateFrom"
          :disabled="readonly"
          @input="update('ContractDateFrom', $event)"
          :error-messages="validateField('User.ContractDateFrom')"
        />
      </v-col>
    </v-row>
  </div>
</template>

<script>
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";
import { UserRoles } from "@mpss/eporadce-common";

export default {
  name: "HiringValidationCpmIcp",

  mixins: [MixinHiringPagePart],

  props: ["readonly"],

  data() {
    return {
      contractItems: [
        { value: "16", text: "SPFP16" },
        { value: "17", text: "SPFP17" },
        { value: "18", text: "SPFP18" },
        { value: "S01", text: "SOS001" }
        ]
    };
  },

  computed: {
    showContractInfo() {
      return this.$user.isInRole(UserRoles.HiringSupervisor);
    },

    draftDate() {
      if (this.value.DraftContractDate) return this.$dates.format(this.value.DraftContractDate);
      else return "Co nejdříve";
    }
  }
};
</script>
