<template>
  <v-card class="mt-6">
    <v-subheader>Manuální kategorizace FP</v-subheader>
    <v-card-text class="pt-0">
      <v-select
        label="Kategorie"
        hide-details
        item-text="Text"
        item-value="Id"
        class="mb-8"
        :items="$lists.hiring.riskTypes || []"
        :value="value.RiskType"
        @input="update('RiskType', $event)"
        :disabled="readonly"
        :error-messages="validateField('User.RiskType')"
      />

      <v-textarea
        label="Poznámka Administrátora"
        auto-grow
        hide-details
        :value="value.ValidationNote"
        @input="update('ValidationNote', $event)"
        :disabled="readonly"
        :error-messages="validateField('User.ValidationNote')"
      />

      <v-textarea
        v-if="value.ApprovalNote"
        label="Poznámka Schvalovatele"
        auto-grow
        hide-details
        :value="value.ApprovalNote"
        :disabled="true"
      />
    </v-card-text>
  </v-card>
</template>

<script>
import MixinHiringPagePart from "../mixins/MixinHiringPagePart";

export default {
  name: "HiringValidationNotes",

  mixins: [MixinHiringPagePart]
};
</script>
