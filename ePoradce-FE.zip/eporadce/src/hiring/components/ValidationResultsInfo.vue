<template>
  <div>
    <v-alert type="error" v-if="isUnwanted">FP je nežádoucí, smažte ho.</v-alert>
    <v-alert type="warning" v-if="isRenewal">OBNOVA</v-alert>
    <v-alert type="info" v-if="isExPa">PORADCE ExPa {{ model.FormerCPM }} a {{ model.FormerICP }}</v-alert>
    <v-alert type="info" v-if="isRenumbering">PŘEČÍSLOVÁNÍ {{ model.FormerCPM }} a {{ model.FormerICP }}</v-alert>
  </div>
</template>

<script>
import { UserValidationResults } from "@mpss/hiring-api";

export default {
  name: "HiringValidationResultsInfo",

  props: ["model"],

  computed: {
    isUnwanted() {
      return this.model && (this.model.ValidationResults & UserValidationResults.Unwanted) > 0;
    },

    isRenewal() {
      return this.model && (this.model.ValidationResults & UserValidationResults.Renewal) > 0;
    },

    isRenumbering() {
      return this.model && (this.model.ValidationResults & UserValidationResults.Renumbering) > 0;
    },

    isExPa() {
      return this.model && (this.model.ValidationResults & UserValidationResults.IsExPa) > 0;
    }
  }
};
</script>
