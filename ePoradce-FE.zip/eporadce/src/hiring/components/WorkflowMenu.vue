<template>
  <v-menu
    v-if="$lists.hiring.workflowStatuses != null"
    v-model="opened"
    :close-on-content-click="false"
    offset-y
    bottom
    left
  >
    <template v-slot:activator="{ on }">
      <v-btn v-on="on" text>
        <span class="grey--text overline pr-1">status:</span>
        {{ currentStatus }}
        <v-icon>expand_more</v-icon>
      </v-btn>
    </template>

    <v-card style="width: 500px;">
      <v-card-text>
        <v-timeline>
          <div v-for="(status, index) in statuses" :key="index">
            <!-- info o statusu -->
            <v-timeline-item :color="color(status.Status)" small fill-dot right>
              <strong
                :class="`subtitle-1 font-weight-bold text-uppercase text-no-wrap ${color(status.Status)}--text`"
                >{{ status.Status | list("hiring", "workflowStatuses") | text }}</strong
              >
            </v-timeline-item>

            <!-- info o uzivateli -->
            <v-timeline-item color="grey" small fill-dot right>
              <template v-slot:opposite>
                <span>{{ status.InsertTime | datetime }}</span>
              </template>
              <template v-slot:icon>
                <v-avatar color="white">
                  <v-img
                    :src="getUserImg(status.InsertUserId)"
                    lazy-src="../../assets/account_circle_black_36dp.png"
                    width="40"
                  />
                </v-avatar>
              </template>
              <span class="text-no-wrap">{{ status.DisplayName }}</span>
            </v-timeline-item>
          </div>
        </v-timeline>
      </v-card-text>
    </v-card>
  </v-menu>
</template>

<script>
import { usersApi } from "@/code/apiServices";

export default {
  name: "HiringWorkflowMenu",

  props: ["statuses", "currentStatus"],

  data() {
    return {
      opened: false
    };
  },

  async mounted() {
    await this.$lists.fetch("hiring", "WorkflowStatuses");
  },

  methods: {
    getUserImg(id) {
      return usersApi.GetUserImageUrl(id);
    },

    color(value) {
      return this.$options.filters.color(this.$options.filters.list(value, "hiring", "workflowStatuses"));
    }
  }
};
</script>
