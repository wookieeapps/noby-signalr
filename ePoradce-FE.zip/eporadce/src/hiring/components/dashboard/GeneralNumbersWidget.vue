<template>
  <div v-if="data != null && (data.ToApprove > 0 || data.ToDelete > 0)" class="masonry-grid-item col-12 col-md-6">
    <v-card tile>
      <v-card-title><v-icon class="mr-2">person_add</v-icon>Zasmluvnění</v-card-title>
      <v-list>
        <!-- to approve -->
        <v-list-item v-if="data.ToApprove > 0">
          <v-list-item-content>
            <v-list-item-subtitle
              >Máte <strong class="black--text">{{ data.ToApprove }}</strong> nových FP ke
              schválení.</v-list-item-subtitle
            >
          </v-list-item-content>
          <v-list-item-action
            ><v-btn icon :to="{ name: 'HiringUserList' }"
              ><v-icon color="primary">send</v-icon></v-btn
            ></v-list-item-action
          >
        </v-list-item>

        <!-- to delete -->
        <v-list-item v-if="data.ToDelete > 0">
          <v-list-item-content>
            <v-list-item-subtitle
              >Máte <strong class="black--text">{{ data.ToDelete }}</strong> FP ke smazání</v-list-item-subtitle
            >
          </v-list-item-content>
          <v-list-item-action
            ><v-btn icon :to="{ name: 'HiringUserList' }"
              ><v-icon color="primary">send</v-icon></v-btn
            ></v-list-item-action
          >
        </v-list-item>
      </v-list>
    </v-card>
  </div>
</template>

<script>
export default {
  props: ["data"]
};
</script>
