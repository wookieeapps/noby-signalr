<template>
  <div v-if="items && items.length > 0" class="masonry-grid-item col-12 col-md-6">
    <v-card tile>
      <v-card-title>Aktivní dožádání</v-card-title>
      <v-list>
        <v-list-item v-for="req in items" :key="req.Id" v-show="showAll || !isHidden(false)">
          <v-list-item-content>
            <v-list-item-title>{{ req.DisplayName }}</v-list-item-title>
            <v-list-item-subtitle
              ><span class="font-weight-light">Území:</span> {{ req.UserGroup }}</v-list-item-subtitle
            >
            <v-list-item-subtitle>{{ req.Date | date }} {{ req.Name }}</v-list-item-subtitle>
            <v-list-item-subtitle v-if="req.Note">{{ req.Note }}</v-list-item-subtitle>
          </v-list-item-content>
          <v-list-item-action>
            <v-btn icon :to="redirect(req)"><v-icon color="primary">send</v-icon></v-btn>
          </v-list-item-action>
        </v-list-item>
      </v-list>

      <!-- zobrazit dalsi soubory -->
      <div class="text-center pb-3" v-if="showButton">
        <v-btn color="primary" x-small @click="showAll = true" tile text
          ><v-icon x-small>get_app</v-icon>Zobrazit vše ({{ count }})</v-btn
        >
      </div>
    </v-card>
  </div>
</template>

<script>
import MixinDashboardShowMore from "../../../mixins/MixinDashboardShowMore";

export default {
  mixins: [MixinDashboardShowMore],

  methods: {
    redirect(req) {
      if (req.IsInHiring) return { name: "HiringUserDetail", params: { id: req.UserId } };
      else return { name: "UserDetail", params: { id: req.UserId } };
    }
  }
};
</script>
