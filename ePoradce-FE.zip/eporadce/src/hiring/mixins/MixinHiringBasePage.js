import { UserRoles, ObjectTypes, Helpers } from "@mpss/eporadce-common";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
import { hiringGeneralApi } from "../code/apiServicesHiring";
import FileList from "../../components/FileList.vue";

export default {
  components: {
    FileList
  },

  props: ["user"],

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      // instance API sluzby pro dany status
      apiInstance: null,
      // instance editovaneho FP
      model: this.user,
      // list prilozenych souboru
      files: null,
      bottomValidation: false,
      bottomValidationMessages: null
    };
  },

  async mounted() {
    await this.$lists.fetch("hiring", "WorkflowStatuses");
  },

  computed: {
    objectTypeId() {
      return ObjectTypes.HiringUser;
    },

    // true pokud lze zobrazit tlacitko SAVE
    isSaveEnabled() {
      return this.model !== null;
    },

    // true pokud lze kurz smazat
    isDeleteEnabled() {
      return this.model !== null && this.model.Id > 0;
    }
  },

  methods: {
    validationChanged(messages) {
      this.bottomValidation = messages !== null && messages !== "";
      this.bottomValidationMessages = messages;
    },

    /**
     * Smazani uzivatele
     */
    async deleteUser() {
      this.deleteBtnLoading = true;

      if (
        await this.$confirm("Opravdu si přejete smazat tohoto poradce?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        await this.resolveGeneralResult(
          await this.apiInstance.Delete(this.model.Id),
          "HiringUserList",
          "Poradce byl smazán"
        );
      } else this.deleteBtnLoading = false;
    },

    /**
     * Ulozeni uzivatele
     */
    async saveUser() {
      Helpers.debounce(async () => {
        await this.resolveGeneralResult(
          await this._save(),
          "HiringUserList",
          "Poradce byl uložen",
          "Změny nebylo možné uložit"
        );
      }, 50)();
    },

    /**
     * Odeslat uzivatele do dalsiho statuus (a pred tim ho ulozit)
     */
    async proceedUser() {
      if (
        await this.$confirm("Opravdu si přejete odeslat poradce do dalšího statusu?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        const result = await this._save();

        this.onBeforeSave();

        if (
          await this.resolveGeneralResult(
            result,
            null,
            null,
            "Poradce nebylo možné uložit, odeslání do dalšího statusu bylo stornováno"
          )
        ) {
          this.onBeforeSave();

          if (!(this.model.Id > 0)) this.model.Id = parseInt(result);
          const sendResult = await this.apiInstance.Proceed({ User: this.model, Files: this.files }, this.model.Id);

          await this.resolveGeneralResult(
            sendResult,
            "HiringUserList",
            "Poradce byl odeslán do dalšího statusu",
            "Poradce nebylo možné odeslat do dalšího statusu"
          );
        }
      }
    },

    /**
     * ulozeni pouze souboru
     */
    async saveUpload() {
      this.onBeforeSave();

      const result = await hiringGeneralApi.Upload({ Files: this.files }, this.model.Id);
      await this.resolveGeneralResult(result, "HiringUserList", "Soubory byly uloženy", "Změny nebylo možné uložit");
    },

    /**
     * interni metoda pro ulozeni uzivatele
     */
    async _save() {
      this.onBeforeSave();

      return await this.apiInstance.Edit({ User: this.model, Files: this.files }, this.model.Id);
    },

    /**
     * Tisk generovanych dokumentu do PDF
     * @param {string} docType druh dokumentu
     */
    async generateDocs(docType) {
      // nejdriv uzivatele ulozit
      if (this.model.IsReadonly) {
        this.generateDocsInner(docType);
      } else if (
        await this.resolveGeneralResult(await this._save(), "", "Poradce byl uložen", "Změny nebylo možné uložit")
      ) {
        this.generateDocsInner(docType);
      }
      return false;
    },

    async generateDocsInner(docType) {
      const resultDoc = await hiringGeneralApi.GenerateDoc(this.model.Id, docType);
      if (await this.resolveGeneralResult(resultDoc)) {
        location.href = resultDoc;
        return true;
      }
    },

    // soubor muze editovat jen admin nebo kontrolor nebo manazer, ale jen kdyz je to jeho soubor
    fileReadonlyCondition(file) {
      return !this.$root.$user.isInRole(UserRoles.HiringSupervisor);
    }
  }
};
