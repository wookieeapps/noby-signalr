import HiringGenerateDocsMenu from "../components/GenerateDocsMenu.vue";
import HiringOtherData from "../components/OtherData.vue";
import HiringContactData from "../components/ContactData.vue";
import HiringPersonalData from "../components/PersonalData.vue";
import HiringPositionInfo from "../components/PositionInfo.vue";
import HiringPageTitle from "../components/PageTitle.vue";
import HiringAppPageToolbar from "../components/HiringAppPageToolbar.vue";
import HiringAddresses from "../components/Addresses.vue";
import HiringBankAccount from "../components/BankAccount.vue";
import HiringValidationResultsInfo from "../components/ValidationResultsInfo.vue";

import MixinHiringBasePage from "../mixins/MixinHiringBasePage";

export default {
  components: {
    HiringPersonalData,
    HiringPositionInfo,
    HiringPageTitle,
    HiringOtherData,
    HiringContactData,
    HiringAddresses,
    HiringGenerateDocsMenu,
    HiringAppPageToolbar,
    HiringValidationResultsInfo,
    HiringBankAccount
  },

  mixins: [MixinHiringBasePage]
};
