import { MixinValidateField, MixinUpdateModel } from "@mpss/eporadce-common-vue";

export default {
  mixins: [MixinValidateField, MixinUpdateModel],

  props: ["value", "validationErrors", "readonly"],

  methods: {
    show(value) {
      return !(this.readonly && !value);
    }
  }
};
