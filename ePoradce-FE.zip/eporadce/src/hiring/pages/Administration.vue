<template>
  <div>
    <v-tabs background-color="transparent" class="mb-5" v-model="tab">
      <v-tab :key="0">Šablony emailů</v-tab>
    </v-tabs>

    <v-tabs-items v-model="tab" style="background-color: transparent;">
      <v-tab-item :key="0">
        <email-templates :application-id="appId" />
      </v-tab-item>
    </v-tabs-items>
  </div>
</template>

<script>
import { ApplicationIdTypes } from "@mpss/eporadce-common";
import EmailTemplates from "../../components/EmailTemplates.vue";

export default {
  name: "HiringAdministration",

  components: { EmailTemplates },

  props: {
    id: {
      type: Number,
      required: false
    }
  },

  data() {
    return {
      tab: null
    };
  },

  async mounted() {
    if (this.id) {
      this.tab = this.id;
    }
  },

  computed: {
    appId() {
      return ApplicationIdTypes.Hiring;
    }
  }
};
</script>
