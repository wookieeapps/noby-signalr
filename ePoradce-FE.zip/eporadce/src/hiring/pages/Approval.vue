<template>
  <div>
    <app-page-toolbar
      :back-to="{ name: 'HiringUserList' }"
      :validation-errors="validationErrors"
      @validationChanged="validationChanged"
    >
      <template v-slot:back>Zpět na seznam</template>
      <template v-slot:actions v-if="!model.IsReadonly">
        <v-btn color="red" dark text-color="white" class="mr-4" tile @click="disapprove" :loading="saveBtnLoading"
          >Zamítnout</v-btn
        >
        <v-btn color="success" tile @click="approve" :loading="saveBtnLoading">Schválit</v-btn>
      </template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <hiring-validation-results-info :model="model" />

      <!-- zakladni info o FP -->
      <v-card class="mb-7">
        <hiring-page-title :user="model" />
        <v-divider />
        <v-card-text>
          <v-row>
            <v-col cols="12" md="6" class="pt-0 pb-0">
              <app-static-text label="Jméno">{{ model.Firstname }}</app-static-text>

              <app-static-text label="Příjmení">{{ model.Surname }}</app-static-text>
            </v-col>
            <v-col cols="6" md="3" class="pt-0 pb-0">
              <app-static-text label="ČPM">{{ model.CPM }}</app-static-text>

              <app-static-text label="Kategorie" :style="{ color: riskTypeColor }">{{ riskType }}</app-static-text>

              <app-static-text label="Datum nástupu">{{ model.ContractDateFrom | date }}</app-static-text>
            </v-col>
            <v-col cols="6" md="3" class="pt-0 pb-0">
              <app-static-text label="IČP">{{ model.ICP }}</app-static-text>

              <app-static-text label="Atribut CRMC">{{ crmc }}</app-static-text>
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>

      <!-- position info -->
      <v-card class="mb-7">
        <v-card-text>
          <hiring-position-info v-model="model" :readonly="true" />
        </v-card-text>
      </v-card>

      <!-- poznamky -->
      <notes v-model="model" :validation-errors="validationErrors" :readonly="model.IsReadonly" />

      <!-- checklist -->
      <hiring-checklist-readonly :user-id="model.Id" :files="files" />
    </div>
  </div>
</template>

<script>
import { UserRoles, ObjectTypes } from "@mpss/eporadce-common";
import { fileInfoApi, userGroupsApi } from "@/code/apiServices";
import { approvalApi, attributesApi } from "../code/apiServicesHiring";
import HiringChecklistReadonly from "../components/ChecklistReadonly.vue";
import HiringPageTitle from "../components/PageTitle.vue";
import MixinHiringBasePage from "../mixins/MixinHiringBasePage";
import HiringValidationResultsInfo from "../components/ValidationResultsInfo.vue";
import HiringPositionInfo from "../components/PositionInfo.vue";
import Notes from "../components/ApprovalNotes.vue";

export default {
  name: "HiringApproval",

  components: {
    HiringPageTitle,
    HiringChecklistReadonly,
    HiringPositionInfo,
    HiringValidationResultsInfo,
    Notes
  },

  mixins: [MixinHiringBasePage],

  data() {
    return {
      apiInstance: approvalApi,
      pozice: null,
      riskType: null,
      riskTypeColor: null,
      files: null,
      crmc: "",
      userGroupName: ""
    };
  },

  async mounted() {
    // ciselniky
    await this.$lists.fetch("hiring", ["Positions", "RiskTypes"]);
    // get checklists
    await this.$store.dispatch("hiring/initApproval", this.model.Id);

    // nazev usergroup
    if (this.model.UserGroupType == "904" && this.model.IsUserGroupMissing) {
      this.userGroupName = this.model.UserGroupNote;
    } else if (this.model.UserGroupId) {
      const ug = await userGroupsApi.Get(this.model.UserGroupId);
      this.userGroupName = `${ug.Code} ${ug.Name}`;
    }

    // seznam souboru pro checklist
    this.files = await fileInfoApi.GetList(ObjectTypes.HiringUser, this.model.Id, 0, 99);

    // hodnoty poli z ciselniku
    const rt = this.$lists.hiring.riskTypes.find((t) => t.Id === this.model.RiskType);
    this.riskType = rt ? rt.Text : "nezadáno";
    this.riskTypeColor = rt ? rt.Color : "orange";
    this.pozice = this.$lists.hiring.positions.find((t) => t.Code == this.model.PositionCode).Name;

    // hodnota atributu CRMC
    const attrs = await attributesApi.GetOverview(this.model.Id);
    if (attrs !== null) {
      const crmcAttrs = attrs.filter((t) => t.Code === "CRMC");
      if (crmcAttrs.length > 0) this.crmc = crmcAttrs.map((t) => t.Value).join(",");
    }
  },

  methods: {
    async approve() {
      if (
        await this.$confirm("Opravdu si přejete schválit tohoto poradce?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        this.onBeforeSave();

        const result = await approvalApi.Approve({ ApprovalNote: this.model.ApprovalNote }, this.model.Id);
        await this.resolveGeneralResult(
          result,
          "HiringUserList",
          "Poradce byl schválen",
          "Poradce nebylo možné schválit"
        );
      }
    },

    async disapprove() {
      if (
        await this.$confirm("Opravdu si přejete zamítnout tohoto poradce?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        this.onBeforeSave();

        const result = await approvalApi.Disapprove({ ApprovalNote: this.model.ApprovalNote }, this.model.Id);
        await this.resolveGeneralResult(
          result,
          "HiringUserList",
          "Poradce byl zamítnut",
          "Poradce nebylo možné zamítnout"
        );
      }
    }
  }
};
</script>
