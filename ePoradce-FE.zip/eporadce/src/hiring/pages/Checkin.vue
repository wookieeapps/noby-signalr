<template>
  <div>
    <hiring-app-page-toolbar
      :validationErrors="validationErrors"
      :deleteBtnLoading="deleteBtnLoading"
      :isDeleteEnabled="isDeleteEnabled"
      :isDeleteVisible="isDeleteVisible"
      :isSaveVisible="isSaveVisible"
      :saveBtnLoading="saveBtnLoading"
      :isSaveEnabled="true"
      :readonly="model !== null && model.IsReadonly"
      @validationChanged="validationChanged"
      @deleteUser="deleteUser"
      @saveUser="saveUser"
      @saveUpload="saveUpload"
    />

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <hiring-validation-results-info :model="model" />

      <!-- CPM a ICP -->
      <v-card class="mb-7">
        <hiring-page-title :user="model" />
        <v-divider />
        <v-card-text>
          <v-row v-if="isSaveVisible">
            <v-col cols="12" :md="getColsCount">
              <div class>
                <v-text-field
                  label="ČPM"
                  v-model="model.CPM"
                  maxlength="8"
                  :loading="getFreeLoading"
                  :disabled="model.IsReadonly || isRenewal"
                  :error-messages="validateField('User.CPM')"
                />
              </div>
            </v-col>
            <v-col cols="12" :md="getColsCount">
              <v-text-field
                label="IČP"
                v-model="model.ICP"
                maxlength="9"
                :loading="getFreeLoading"
                :disabled="model.IsReadonly || isRenewal"
                :error-messages="validateField('User.ICP')"
              />
            </v-col>
            <v-col cols="12" :md="getColsCount" class="text-right" v-if="isGetFreeVisible">
              <v-btn tile width="100%" :loading="getFreeLoading" @click="getFreeClick" class="mt-3"
                >Vygenerovat nové</v-btn
              >
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>

      <hiring-checkin-body :model="model" />

      <v-row>
        <!-- POCE -->
        <v-col cols="12" md="6">
          <hiring-poce-readonly v-if="model" :model="model" />
        </v-col>
        <v-col cols="12" md="6">
          <!-- soubory -->
          <file-list
            :object-type-id="objectTypeId"
            :object-id="model.Id"
            v-model="files"
            show-terms="true"
            :readonly-condition="fileReadonlyCondition"
            :validation-errors="validationErrors"
          />
        </v-col>
      </v-row>

      <!-- poznamka -->
      <notes v-model="model" :validation-errors="validationErrors" :readonly="model.IsReadonly" />

      <!-- zobrazeni chyb -->
      <v-alert dense outlined class="mt-6" color="red" v-show="bottomValidation" v-if="isProceedBoxVisible">
        <div class="caption" v-html="bottomValidationMessages"></div>
      </v-alert>

      <!-- buttony -->
      <div class="text-right mt-7" v-if="isProceedBoxVisible">
        <hiring-generate-docs-menu :create-fce="generateDocs" />

        <v-btn color="primary" tile :disabled="!isSaveEnabled" :loading="saveBtnLoading" @click="proceedUser"
          >Odeslat ke kontrole</v-btn
        >
      </div>
    </div>
  </div>
</template>

<script>
import { checkinApi } from "../code/apiServicesHiring";
import { UserValidationResults } from "@mpss/hiring-api";
import MixinHiringDeps from "../mixins/MixinHiringDeps";
import HiringCheckinBody from "../components/CheckinBody.vue";
import HiringPoceReadonly from "../components/PoceReadonly.vue";
import Notes from "../components/CheckinNotes.vue";

export default {
  name: "HiringCheckin",

  mixins: [MixinHiringDeps],

  components: { HiringCheckinBody, HiringPoceReadonly, Notes },

  data() {
    return {
      apiInstance: checkinApi,
      getFreeLoading: false
    };
  },

  computed: {
    getColsCount() {
      return this.isGetFreeVisible ? 4 : 6;
    },

    isGetFreeVisible() {
      return (
        this.model && !this.model.IsReadonly && (this.model.ValidationResults & UserValidationResults.Renewal) == 0
      );
    },

    isDeleteVisible() {
      return this.model === null ? false : !this.model.IsReadonly;
    },

    isSaveVisible() {
      return !this.isUnwanted;
    },

    isProceedBoxVisible() {
      return this.model === null || (!this.model.IsReadonly && !this.isUnwanted);
    },

    isRenewal() {
      return this.model && (this.model.ValidationResults & UserValidationResults.Renewal) > 0;
    }
  },

  methods: {
    // vygenerovani noveho CPM a ICP
    async getFreeClick() {
      this.getFreeLoading = true;

      // zjistit nove
      const result = await this.apiInstance.GetFreeCPM(this.model.Id);
      // ulozit do modelu
      this.model.CPM = result.CPM;
      this.model.ICP = result.ICP;

      this.getFreeLoading = false;

      this.$toast.success("ČPM a IČP bylo vygenerováno");
    }
  }
};
</script>
