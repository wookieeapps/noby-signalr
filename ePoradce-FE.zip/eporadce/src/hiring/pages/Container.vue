<template>
  <component v-if="user !== null" :is="loadedComponent" :user="user"></component>
</template>

<script>
import { hiringGeneralApi } from "../code/apiServicesHiring";

export default {
  name: "HiringContainer",

  props: ["id"],

  data() {
    return {
      user: null
    };
  },

  computed: {
    loadedComponent() {
      switch (this.user.RouteName) {
        case "Onboarding":
          return () => import(/* webpackChunkName: "hiring-recruiter" */ "./Onboarding.vue");
        case "Checkin":
          return () => import(/* webpackChunkName: "hiring-controller" */ "./Checkin.vue");
        case "ToDelete":
          return () => import(/* webpackChunkName: "hiring-admin" */ "./ToDelete.vue");
        case "Validation":
          return () => import(/* webpackChunkName: "hiring-admin" */ "./Validation.vue");
        case "Approval":
          return () => import(/* webpackChunkName: "hiring-approval" */ "./Approval.vue");
        case "Editor":
          return () => import(/* webpackChunkName: "hiring-recruiter" */ "./Editor.vue");
        case "Controller":
          return () => import(/* webpackChunkName: "hiring-controller" */ "./Controller.vue");
        case "FailedSeating":
          return () => import(/* webpackChunkName: "hiring-failedseating" */ "./FailedSeating.vue");
      }
      return null;
    }
  },

  async mounted() {
    this.user = await hiringGeneralApi.Get(Number(this.id));
    if (this.user === null) this.$router.push({ name: "NotPermitted" });
  }
};
</script>
