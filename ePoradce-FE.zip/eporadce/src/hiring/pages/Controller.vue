<template>
  <div>
    <hiring-app-page-toolbar
      :validationErrors="validationErrors"
      :isDeleteVisible="false"
      :isSaveVisible="false"
      :readonly="true"
      @saveUpload="saveUpload"
    />

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-card class="mb-7">
        <hiring-page-title :user="model" />
        <v-divider />
        <v-card-text>
          <v-row>
            <v-col cols="12" md="6" class="pt-0 pb-0">
              <div class>
                <v-text-field label="ČPM" v-model="model.CPM" maxlength="8" :disabled="true" />
              </div>
            </v-col>
            <v-col cols="12" md="6" class="pt-0 pb-0">
              <v-text-field label="IČP" v-model="model.ICP" maxlength="9" :disabled="true" />
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>

      <v-tabs class="mb-4" background-color="transparent" v-model="tab" grow>
        <v-tab>Zobrazit základní data o FP</v-tab>
        <v-tab>
          Checklist
          <v-badge color="red" v-show="checklistBadgeCount > 0" :content="checklistBadgeCount" offset-x="-5"></v-badge>
        </v-tab>
      </v-tabs>

      <v-tabs-items v-model="tab" style="background-color: transparent">
        <v-tab-item :key="1">
          <hiring-checkin-body :model="model" />

          <v-row>
            <v-col cols="12" md="6">
              <hiring-poce-readonly v-if="model" :model="model" />
            </v-col>
            <v-col cols="12" md="6">
              <file-list
                show-terms="true"
                :object-type-id="objectTypeId"
                :object-id="model.Id"
                v-model="files"
                :readonly-condition="(t) => true"
              />
            </v-col>
          </v-row>
        </v-tab-item>
        <v-tab-item :key="2">
          <hiring-checklist-readonly :user-id="model.Id" :files="files" />
        </v-tab-item>
      </v-tabs-items>
    </div>
  </div>
</template>

<script>
import { checkinApi } from "../code/apiServicesHiring";
import { UserValidationResults } from "@mpss/hiring-api";
import MixinHiringDeps from "../mixins/MixinHiringDeps";
import HiringChecklistReadonly from "../components/ChecklistReadonly.vue";
import HiringCheckinBody from "../components/CheckinBody.vue";
import HiringPoceReadonly from "../components/PoceReadonly.vue";

export default {
  name: "HiringController",

  mixins: [MixinHiringDeps],

  components: { HiringChecklistReadonly, HiringCheckinBody, HiringPoceReadonly },

  data() {
    return {
      tab: null
    };
  },

  computed: {
    checklistBadgeCount() {
      return this.$hiring.checklists === null ? 0 : this.$hiring.checklists.length;
    }
  },

  async mounted() {
    await this.$store.dispatch("hiring/initApproval", this.model.Id);
  }
};
</script>
