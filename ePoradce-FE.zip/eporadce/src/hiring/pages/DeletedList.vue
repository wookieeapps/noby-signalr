<template>
  <v-card>
    <v-card-title class="justify-space-between">Seznam smazaných poradců</v-card-title>
    <v-divider />

    <v-data-table
      :headers="headers"
      :items="items"
      :loading="loading"
      item-key="Id"
      hide-default-footer
      disable-pagination
      disable-filtering
    >
      <template v-slot:loading>
        <div class="pa-12">Nahrávám data...</div>
      </template>
      <template v-slot:no-data>
        <div class="pa-12">Neexistují žádní smazaní poradci</div>
      </template>
      <template v-slot:item.RecruitmentSourceId="{ item }">{{ recruitment(item.RecruitmentSourceId) }}</template>
      <template v-slot:item.UpdateTime="{ item }">{{ item.UpdateTime | date }}</template>
    </v-data-table>
  </v-card>
</template>

<script>
import { toDeleteApi } from "../code/apiServicesHiring";

export default {
  name: "HiringDeletedlist",

  data() {
    return {
      // loading state gridu
      loading: true,

      // hlavicka gridu
      headers: [
        { text: "Příjmení, jméno", value: "DisplayName" },
        { text: "Pozice", value: "Position" },
        { text: "Nábor zdroj", value: "RecruitmentSourceId" },
        { text: "Vložil", value: "InsertUserName" },
        { text: "Smazáno", value: "UpdateTime" }
      ],

      // data/radky v gridu
      items: []
    };
  },

  async mounted() {
    await this.$lists.fetch("hiring", "RecruitmentSources");

    this.items = await toDeleteApi.GetList();

    this.loading = false;
  },

  methods: {
    recruitment(id) {
      if (id) return this.$lists.hiring.recruitmentSources.find((t) => t.Id == id).Text;
      return "";
    }
  }
};
</script>
