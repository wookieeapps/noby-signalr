<template>
  <div>
    <hiring-app-page-toolbar
      :validationErrors="validationErrors"
      :isDeleteVisible="false"
      :isSaveVisible="true"
      :isSaveEnabled="isSaveEnabled"
      :saveBtnLoading="saveBtnLoading"
      :readonly="true"
      @saveUpload="saveUpload"
    />

    <!-- page loader -->
    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <!-- info o vysledku validace -->
      <hiring-validation-results-info :model="model" />

      <!-- zakladni udaje -->
      <v-card class="mb-7">
        <hiring-page-title :user="model" />
        <v-divider />
        <v-card-text>
          <hiring-personal-data v-model="model" :readonly="model.IsReadonly" />
        </v-card-text>
      </v-card>

      <!-- info o pozici -->
      <v-card class="mb-6">
        <v-card-text>
          <hiring-position-info v-model="model" :readonly="model.IsReadonly" />
        </v-card-text>
      </v-card>

      <!-- taby -->
      <v-tabs class="mb-4" background-color="transparent" v-model="tab" grow>
        <v-tab>Zobrazit základní data o FP</v-tab>
        <v-tab>
          Checklist
          <v-badge color="red" v-show="checklistBadgeCount > 0" :content="checklistBadgeCount" offset-x="-5"></v-badge>
        </v-tab>
      </v-tabs>

      <v-tabs-items v-model="tab" style="background-color: transparent;">
        <v-tab-item :key="1">
          <!-- adresy -->
          <hiring-addresses v-model="model" class="mb-1" :readonly="model.IsReadonly" />

          <!-- kontakty a banka -->
          <v-row>
            <v-col cols="12" md="6">
              <hiring-contact-data class="mb-1" v-model="model" :readonly="model.IsReadonly" />
            </v-col>
            <v-col cols="12" md="6">
              <hiring-bank-account class="mb-1" v-model="model" :readonly="model.IsReadonly" />
            </v-col>
          </v-row>

          <!-- ostatni udaje a soubory -->
          <v-row>
            <v-col cols="12" md="6">
              <v-card>
                <v-subheader>OSTATNÍ ÚDAJE</v-subheader>
                <v-card-text class="pt-0">
                  <hiring-other-data v-model="model" :readonly="model.IsReadonly" />
                </v-card-text>
              </v-card>
            </v-col>

            <v-col cols="12" md="6">
              <file-list
                :object-type-id="objectTypeId"
                :object-id="model.Id"
                v-model="files"
                show-terms="true"
                :readonly-condition="(t) => true"
              />
            </v-col>
          </v-row>

          <!-- poznamka -->
          <v-card class="mt-4">
            <v-subheader>POZNÁMKA PRO KONTROLORA</v-subheader>
            <v-card-text class="pt-0" v-html="model.OnboardingNote" />
          </v-card>
        </v-tab-item>

        <!-- checklist -->
        <v-tab-item :key="2">
          <hiring-checklist-readonly :user-id="model.Id" :files="files" />
        </v-tab-item>
      </v-tabs-items>

      <!-- buttony -->
      <div class="text-right mt-7">
        <hiring-generate-docs-menu :create-fce="generateDocs" />
      </div>
    </div>
  </div>
</template>

<script>
import { onboardingApi } from "../code/apiServicesHiring";
import { UserRoles } from "@mpss/eporadce-common";
import { UserWorkflowStatuses } from "@mpss/hiring-api";
import MixinHiringDeps from "../mixins/MixinHiringDeps";
import HiringChecklistReadonly from "../components/ChecklistReadonly.vue";

export default {
  name: "HiringEditor",

  components: { HiringChecklistReadonly },

  mixins: [MixinHiringDeps],

  data() {
    return {
      tab: null,
      apiInstance: onboardingApi
    };
  },

  computed: {
    checklistBadgeCount() {
      return this.$hiring.checklists === null ? 0 : this.$hiring.checklists.length;
    }
  },

  async mounted() {
    await this.$store.dispatch("hiring/initApproval", this.model.Id);
  }
};
</script>
