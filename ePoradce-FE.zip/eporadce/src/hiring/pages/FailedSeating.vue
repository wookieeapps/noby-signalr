<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'HiringUserList' }" :validation-errors="validationErrors">
      <template v-slot:back>Zpět na seznam</template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-card class="mb-4">
        <hiring-page-title :user="model" />
        <v-divider />
        <v-card-text>
          <v-row>
            <v-col cols="12" md="6" class="pt-0 pb-0">
              <app-static-text label="ČPM">{{ model.CPM }}</app-static-text>
            </v-col>
            <v-col cols="12" md="6" class="pt-0 pb-0">
              <app-static-text label="IČP">{{ model.ICP }}</app-static-text>
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>

      <v-card class="mb-4">
        <v-divider />
        <v-card-text>
          <hiring-personal-data v-model="model" :readonly="true" />
        </v-card-text>
      </v-card>

      <!-- info o pozici -->
      <v-card class="mb-4">
        <v-card-text>
          <hiring-position-info v-model="model" :readonly="true" />
        </v-card-text>
      </v-card>

      <!-- poznamka schvalovatele -->
      <v-card v-if="model.ApprovalNote">
        <v-subheader>DŮVOD NEÚSPĚŠNÉHO PŘENOSU</v-subheader>
        <v-card-text class="pt-0" v-html="value.ApprovalNote"> </v-card-text>
      </v-card>
    </div>
  </div>
</template>

<script>
import { toDeleteApi } from "../code/apiServicesHiring";
import HiringPersonalData from "../components/PersonalData.vue";
import MixinHiringBasePage from "../mixins/MixinHiringBasePage";
import HiringPageTitle from "../components/PageTitle.vue";
import HiringPositionInfo from "../components/PositionInfo.vue";

export default {
  name: "HiringToDelete",

  components: { HiringPersonalData, HiringPageTitle, HiringPositionInfo },

  mixins: [MixinHiringBasePage],

  data() {
    return {
      apiInstance: toDeleteApi,
      returnBtnLoading: false
    };
  }
};
</script>
