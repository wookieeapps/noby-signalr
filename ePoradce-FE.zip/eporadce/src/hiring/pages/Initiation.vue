<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'HiringUserList' }" :validation-errors="validationErrors">
      <template v-slot:back>Zpět na seznam</template>
      <template v-slot:actions>
        <v-btn color="success" tile @click="saveUser" :loading="saveBtnLoading">Založit nového poradce</v-btn>
      </template>
    </app-page-toolbar>

    <div>
      <v-card class="mb-4">
        <v-card-title>Založení nového poradce</v-card-title>
        <v-divider />
        <v-card-text>
          <v-row>
            <v-col cols="12" md="6">
              <v-text-field
                label="Rodné číslo"
                v-model="personalId"
                maxlength="10"
                :error-messages="validateField('PersonalId')"
              />

              <v-select
                v-show="$lists.shared.userGroupTypes"
                label="Typ prodejce"
                item-text="Text"
                item-value="Code"
                :items="$lists.shared.userGroupTypes || []"
                v-model="userGroupType"
                :error-messages="validateField('UserGroupType')"
              />
            </v-col>
            <v-col cols="12" md="6">
              <v-text-field
                label="Jméno"
                maxlength="40"
                v-model="firstname"
                :error-messages="validateField('Firstname')"
              />

              <v-text-field
                label="Příjmení"
                maxlength="40"
                v-model="surname"
                :error-messages="validateField('Surname')"
              />
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>
    </div>
  </div>
</template>

<script>
import { initiationApi } from "../code/apiServicesHiring";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";

export default {
  name: "HiringInitiation",

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      personalId: null,
      userGroupType: null,
      firstname: "",
      surname: ""
    };
  },

  async mounted() {
    await this.$lists.fetch("UserGroupTypes");
  },

  methods: {
    /**
     * Zalozeni noveho uzivatele
     */
    async saveUser() {
      this.onBeforeSave();

      const result = await initiationApi.Create({
        PersonalId: this.personalId,
        UserGroupType: this.userGroupType,
        Firstname: this.firstname,
        Surname: this.surname
      });

      if (await this.resolveGeneralResult(result, "", "Poradce byl založen", "Poradce nebylo možné založit"))
        this.$router.push({
          name: "HiringUserDetail",
          params: { id: Number(result), refresh: true }
        });
    }
  }
};
</script>
