<template>
  <div>
    <hiring-app-page-toolbar
      :validationErrors="validationErrors"
      :deleteBtnLoading="deleteBtnLoading"
      :isDeleteEnabled="isDeleteEnabled"
      :isDeleteVisible="!model.IsReadonly"
      :isSaveVisible="true"
      :isSaveEnabled="isSaveEnabled"
      :saveBtnLoading="saveBtnLoading"
      :readonly="model !== null && model.IsReadonly"
      @validationChanged="validationChanged"
      @deleteUser="deleteUser"
      @saveUser="saveUser"
      @saveUpload="saveUpload"
    />

    <!-- page loader -->
    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <hiring-validation-results-info :model="model" />

      <!-- zakladni udaje -->
      <v-card class="mb-7">
        <hiring-page-title :user="model" />
        <v-divider />
        <v-card-text>
          <hiring-personal-data v-model="model" :validation-errors="validationErrors" :readonly="model.IsReadonly" />
        </v-card-text>
      </v-card>

      <!-- position info -->
      <v-card class="mb-4">
        <v-card-text>
          <hiring-position-info v-model="model" :validation-errors="validationErrors" :readonly="model.IsReadonly" />
        </v-card-text>
      </v-card>

      <!-- adresy -->
      <hiring-addresses
        v-model="model"
        :validation-errors="validationErrors"
        class="mb-1"
        :readonly="model.IsReadonly"
      />

      <!-- kontakty, banka -->
      <v-row>
        <v-col cols="12" md="6">
          <hiring-contact-data
            class="mb-1"
            v-model="model"
            :validation-errors="validationErrors"
            :readonly="model.IsReadonly"
          />
        </v-col>
        <v-col cols="12" md="6">
          <hiring-bank-account
            class="mb-1"
            v-model="model"
            :validation-errors="validationErrors"
            :readonly="model.IsReadonly"
          />
        </v-col>
      </v-row>

      <v-row>
        <!-- ostatni udaje -->
        <v-col cols="12" md="6">
          <v-card>
            <v-subheader>OSTATNÍ ÚDAJE</v-subheader>
            <v-card-text class="pt-0">
              <hiring-other-data v-model="model" :validation-errors="validationErrors" :readonly="model.IsReadonly" />
            </v-card-text>
          </v-card>
        </v-col>

        <!-- soubory -->
        <v-col cols="12" md="6">
          <file-list
            :object-type-id="objectTypeId"
            :object-id="model.Id"
            v-model="files"
            show-terms="true"
            :readonly-condition="fileReadonlyCondition"
            :validation-errors="validationErrors"
          />
        </v-col>
      </v-row>

      <!-- poznamka -->
      <notes v-model="model" :validation-errors="validationErrors" :readonly="model.IsReadonly" />

      <!-- vypis chyb -->
      <v-alert dense outlined class="mt-6" color="red" v-show="bottomValidation">
        <div class="caption" v-html="bottomValidationMessages"></div>
      </v-alert>

      <!-- buttony -->
      <div class="text-right mt-7">
        <hiring-generate-docs-menu :create-fce="generateDocs" />

        <v-btn
          v-if="!model.IsReadonly"
          color="primary"
          tile
          :disabled="!isSaveEnabled"
          :loading="saveBtnLoading"
          @click="proceedUser"
          >Odeslat ke schválení</v-btn
        >
      </div>
    </div>
  </div>
</template>

<script>
import { onboardingApi } from "../code/apiServicesHiring";
import { UserRoles } from "@mpss/eporadce-common";
import { UserWorkflowStatuses } from "@mpss/hiring-api";
import MixinHiringDeps from "../mixins/MixinHiringDeps";
import Notes from "../components/OnboardingNotes.vue";
import { MixinUpdateModel } from "@mpss/eporadce-common-vue";

export default {
  name: "HiringOnboarding",

  mixins: [MixinHiringDeps, MixinUpdateModel],

  components: {
    Notes
  },

  data() {
    return {
      apiInstance: onboardingApi
    };
  },

  methods: {
    // soubor muze editovat jen admin nebo kontrolor nebo manazer, ale jen kdyz je to jeho soubor
    fileReadonlyCondition(file) {
      return (
        !this.$root.$user.isInRole(UserRoles.HiringSupervisor) &&
        this.model.WorkflowStatus != UserWorkflowStatuses.Onboarding
      );
    }
  }
};
</script>
