<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'HiringUserList' }" :validation-errors="validationErrors">
      <template v-slot:back>Zpět na seznam</template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <v-card class="mb-4">
        <hiring-page-title :user="model" />
        <v-divider />
        <v-card-text>
          <v-row>
            <v-col cols="12" md="6" class="pb-0">
              <app-static-text label="ČPM">{{ model.CPM }}</app-static-text>
            </v-col>
            <v-col cols="12" md="6" class="pb-0">
              <app-static-text label="IČP">{{ model.ICP }}</app-static-text>
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>

      <v-card class="mb-4">
        <v-divider />
        <v-card-text>
          <hiring-personal-data v-model="model" :readonly="true" />
        </v-card-text>
      </v-card>

      <!-- info o pozici -->
      <v-card class="mb-4">
        <v-card-text>
          <hiring-position-info v-model="model" :readonly="true" />
        </v-card-text>
      </v-card>

      <!-- poznamka schvalovatele -->
      <v-card v-if="model.ApprovalNote">
        <v-subheader>POZNÁMKA SCHVALOVATELE</v-subheader>
        <v-card-text class="pt-0" v-html="model.ApprovalNote"> </v-card-text>
      </v-card>

      <div class="text-right mt-4">
        <v-btn tile @click="returnBack" :loading="returnBtnLoading" class="mr-4">Vrátit do předchozího statusu</v-btn>

        <v-btn color="error" tile :loading="deleteBtnLoading" @click="deleteUser">Smazat FP</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
import { toDeleteApi } from "../code/apiServicesHiring";
import HiringPersonalData from "../components/PersonalData.vue";
import MixinHiringBasePage from "../mixins/MixinHiringBasePage";
import HiringPageTitle from "../components/PageTitle.vue";
import HiringPositionInfo from "../components/PositionInfo.vue";

export default {
  name: "HiringToDelete",

  components: { HiringPersonalData, HiringPageTitle, HiringPositionInfo },

  mixins: [MixinHiringBasePage],

  data() {
    return {
      apiInstance: toDeleteApi,
      returnBtnLoading: false
    };
  },

  methods: {
    // navrat do predchoziho statusu
    async returnBack() {
      this.returnBtnLoading = true;

      if (
        await this.$confirm("Opravdu si přejete vrátit tohoto poradce do předchozího statusu?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        await this.resolveGeneralResult(
          await toDeleteApi.ReturnToLastStatus(this.model.Id),
          "HiringUserList",
          "Poradce byl vrácen do předchozího statusu",
          "Změny nebylo možné uložit"
        );
      } else this.returnBtnLoading = false;
    }
  }
};
</script>
