<template>
  <v-card>
    <v-card-title class="justify-space-between">Seznam poradců</v-card-title>
    <v-divider />

    <v-data-table
      :headers="headers"
      :items="items"
      :loading="loading"
      item-key="Id"
      hide-default-footer
      disable-pagination
      disable-filtering
    >
      <template v-slot:loading>
        <div class="pa-12">Nahrávám data...</div>
      </template>
      <template v-slot:no-data>
        <div class="pa-12">Nemáte žádné nové poradce ke zpracování</div>
      </template>
      <template v-slot:item.Status="{ item }">
        <v-tooltip top>
          <template v-slot:activator="{ on }">
            <v-chip
              text-color="white"
              small
              v-on="on"
              :color="item.Status | list('hiring', 'workflowStatuses') | color"
              >{{ item.Status | list("hiring", "workflowStatuses") | code }}</v-chip
            >
          </template>
          {{ item.Status | list("hiring", "workflowStatuses") | text }}
        </v-tooltip>
      </template>
      <template v-slot:item.InsertTime="{ item }">{{ item.InsertTime | date }}</template>
      <template v-slot:item.DraftDate="{ item }">{{ getDraftDate(item.DraftDate) }}</template>
      <template v-slot:item.Requests="{ item }">
        <v-avatar color="accent" size="26" v-if="item.Requests > 0" class="ml-2">
          <span class="white--text">{{ item.Requests }}</span>
        </v-avatar>
      </template>
      <template v-slot:item.actions="{ item }">
        <v-btn icon exact :to="{ name: 'HiringUserDetail', params: { id: item.Id } }">
          <v-icon small>edit</v-icon>
        </v-btn>
      </template>
    </v-data-table>
  </v-card>
</template>

<script>
import { hiringGeneralApi } from "../code/apiServicesHiring";
import { UserWorkflowStatuses } from "@mpss/hiring-api";

export default {
  name: "HiringUserList",

  data() {
    return {
      // loading state gridu
      loading: true,

      // hlavicka gridu
      headers: [
        { text: "ČPM", value: "CPM" },
        { text: "Příjmení, jméno", value: "Name" },
        { text: "Stav", value: "Status" },
        { text: "Dožádání", value: "Requests" },
        { text: "Území", value: "UserGroup" },
        { text: "Vložil", value: "InsertedBy" },
        { text: "Vloženo", value: "InsertTime" },
        { text: "Návrh data", value: "DraftDate" },
        { text: "", value: "actions", sortable: false, align: "end" }
      ],

      // data/radky v gridu
      items: []
    };
  },

  async mounted() {
    await this.$lists.fetch("hiring", "WorkflowStatuses");

    this.items = await hiringGeneralApi.GetList();

    this.loading = false;
  },

  methods: {
    getDraftDate(d) {
      if (d) return this.$dates.format(d);
      else return "Co nejdříve";
    }
  }
};
</script>
