<template>
  <div>
    <hiring-app-page-toolbar
      :validationErrors="validationErrors"
      :deleteBtnLoading="deleteBtnLoading"
      :isDeleteEnabled="isDeleteEnabled"
      :isDeleteVisible="isDeleteVisible"
      :isSaveVisible="true"
      :saveBtnLoading="saveBtnLoading"
      :isSaveEnabled="true"
      :readonly="model !== null && model.IsReadonly"
      @validationChanged="validationChanged"
      @deleteUser="deleteUser"
      @saveUser="saveUser"
      @saveUpload="saveUpload"
    />

    <v-card v-if="model === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <div v-else>
      <hiring-validation-results-info :model="model" />

      <v-card class="mb-7">
        <hiring-page-title :user="model" />
        <v-divider />
        <v-card-text>
          <hiring-validation-cpm-icp
            v-model="model"
            :readonly="model.IsReadonly"
            :validation-errors="validationErrors"
          />
        </v-card-text>
      </v-card>

      <!-- taby -->
      <v-tabs class="mb-4" background-color="transparent" v-model="tab" grow>
        <v-tab>Zobrazit základní data o FP</v-tab>
        <v-tab>
          Zobrazit checklist kontrol
          <v-badge color="red" v-show="checklistBadgeCount > 0" :content="checklistBadgeCount" offset-x="-5"></v-badge>
        </v-tab>
        <v-tab>
          Zobrazit atributy
        </v-tab>
      </v-tabs>

      <v-tabs-items v-model="tab" style="background-color: transparent;">
        <!-- zakladni informace o FP -->
        <v-tab-item :key="1">
          <v-card class="mb-7">
            <v-divider />
            <v-card-text>
              <hiring-personal-data
                v-model="model"
                :readonly="model.IsReadonly"
                :validation-errors="validationErrors"
              />
            </v-card-text>
          </v-card>

          <!-- position info -->
          <v-card class="mb-4">
            <v-card-text>
              <hiring-position-info
                v-model="model"
                :validation-errors="validationErrors"
                :readonly="model.IsReadonly"
              />
            </v-card-text>
          </v-card>

          <!-- adresy -->
          <hiring-addresses
            class="mb-1"
            v-model="model"
            :validation-errors="validationErrors"
            :readonly="model.IsReadonly"
          />

          <!-- kontakty a banka -->
          <v-row>
            <v-col cols="12" md="6">
              <hiring-contact-data
                class="mb-1"
                v-model="model"
                :validation-errors="validationErrors"
                :readonly="model.IsReadonly"
              />
            </v-col>
            <v-col cols="12" md="6">
              <hiring-bank-account class="mb-1" v-model="model" :readonly="true" />
            </v-col>
          </v-row>

          <v-row>
            <!-- ostatni udaje -->
            <v-col cols="12" md="6">
              <v-card>
                <v-subheader>OSTATNÍ ÚDAJE</v-subheader>
                <v-card-text class="pt-0">
                  <hiring-other-data
                    v-model="model"
                    :validation-errors="validationErrors"
                    :readonly="model.IsReadonly"
                  />
                </v-card-text>
              </v-card>
            </v-col>

            <!-- soubory -->
            <v-col cols="12" md="6">
              <file-list
                :object-type-id="objectTypeId"
                :object-id="model.Id"
                v-model="files"
                show-terms="true"
                :readonly-condition="fileReadonlyCondition"
                :validation-errors="validationErrors"
              />
            </v-col>
          </v-row>

          <v-card class="mt-4 mb-7" v-if="model.OnboardingNote">
            <v-subheader>POZNÁMKA EDITORA</v-subheader>
            <v-card-text class="pt-0" v-html="model.OnboardingNote"> </v-card-text>
          </v-card>

          <v-card class="mb-7" v-if="model.CheckinNote">
            <v-subheader>POZNÁMKA KONTROLORA</v-subheader>
            <v-card-text class="pt-0" v-html="model.CheckinNote"> </v-card-text>
          </v-card>
        </v-tab-item>

        <v-tab-item :key="2" eager>
          <app-box-loader v-if="$hiring.checklists === null" />

          <hiring-checklist
            :user-id="model.Id"
            :files="files"
            :readonly="model.IsReadonly"
            :validation-errors="validationErrors"
            @change="checklistsOnChange"
          />

          <notes v-model="model" :validation-errors="validationErrors" :readonly="model.IsReadonly" />
        </v-tab-item>

        <v-tab-item :key="3" eager>
          <hiring-attributes
            :readonly="model.IsReadonly"
            :save="_save2"
            :validation-errors="validationErrors"
            :user-id="model.Id"
          />
        </v-tab-item>
      </v-tabs-items>

      <v-alert dense outlined class="mt-6" color="red" v-show="bottomValidation" v-if="!model.IsReadonly">
        <div class="caption" v-html="bottomValidationMessages"></div>
      </v-alert>

      <div class="text-right mt-7" v-if="!model.IsReadonly">
        <hiring-generate-docs-menu :create-fce="generateDocs" />

        <v-btn color="primary" tile :disabled="!isSaveEnabled" :loading="saveBtnLoading" @click="proceedUser">{{
          proceedBtnText
        }}</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
import { UserRoles } from "@mpss/eporadce-common";
import { validationApi, finalCheckApi } from "../code/apiServicesHiring";
import { ChecklistStatuses, UserWorkflowStatuses } from "@mpss/hiring-api";
import MixinHiringDeps from "../mixins/MixinHiringDeps";
import HiringChecklist from "../components/Checklist.vue";
import HiringAttributes from "../components/Attributes.vue";
import HiringValidationCpmIcp from "../components/ValidationCpmIcp.vue";
import Notes from "../components/ValidationNotes.vue";

export default {
  name: "HiringValidation",

  components: {
    HiringValidationCpmIcp,
    HiringChecklist,
    HiringAttributes,
    Notes
  },

  mixins: [MixinHiringDeps],

  data() {
    return {
      apiInstance: null,
      // vybrana zalozka basic vs checklist vs atributy
      tab: null,
      checklistBadgeCount: 0
    };
  },

  async mounted() {
    await this.$store.dispatch("hiring/initValidation", this.model.Id);
    await this.$lists.fetch("hiring", "RiskTypes");

    this.apiInstance = this.user.WorkflowStatus === UserWorkflowStatuses.FinalCheck ? finalCheckApi : validationApi;

    this.checklistsOnChange();
  },

  computed: {
    isDeleteVisible() {
      return this.model == null ? false : !this.model.IsReadonly;
    },

    proceedBtnText() {
      return this.model.WorkflowStatus === UserWorkflowStatuses.FinalCheck ? "Odeslat do CMP" : "Odeslat ke schválení";
    }
  },

  methods: {
    checklistsOnChange() {
      this.checklistBadgeCount = this.$hiring.checklists.filter((t) => t.Status === ChecklistStatuses.None).length;
    },

    // custom funkce na ulozeni - je potreba tam pridat checklist a atributy
    async _save() {
      this.onBeforeSave();

      return await this._save2();
    },

    async _save2() {
      return await validationApi.Edit(
        {
          User: this.model,
          Files: this.files,
          Checklists: this.$hiring.checklists.map((t) => {
            return {
              Id: t.Id,
              Status: t.Status,
              Note: t.Note,
              HasRequest: t.HasRequest,
              RequestNote: t.RequestNote
            };
          }),
          Attributes: this.$hiring.attributes.map((t) => {
            return {
              Id: t.Id,
              Value: t.Value,
              DateFrom: t.DateFrom,
              DateTo: t.DateTo
            };
          })
        },
        this.model.Id
      );
    }
  }
};
</script>
