const Initiation = () => import(/* webpackChunkName: "hiring" */ "../pages/Initiation.vue");
const UserList = () => import(/* webpackChunkName: "hiring" */ "../pages/UserList.vue");
const DeletedList = () => import(/* webpackChunkName: "hiring" */ "../pages/DeletedList.vue");
const Container = () => import(/* webpackChunkName: "hiring" */ "../pages/Container.vue");
const Administration = () => import(/* webpackChunkName: "hiring_administration" */ "../pages/Administration.vue");

export default [
  {
    path: "/hiring/initiation",
    name: "HiringInitiation",
    component: Initiation
  },
  {
    path: "/hiring/list",
    name: "HiringUserList",
    component: UserList
  },
  {
    path: "/hiring/deleted-list",
    name: "HiringDeletedList",
    component: DeletedList
  },
  {
    path: "/hiring/administration",
    name: "HiringAdministration",
    component: Administration
  },
  {
    path: "/hiring/user/:id",
    name: "HiringUserDetail",
    component: Container,
    props: true
  }
];
