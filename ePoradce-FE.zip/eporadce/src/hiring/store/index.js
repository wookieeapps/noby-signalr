import { attributesApi, checklistsApi } from "../code/apiServicesHiring";

export default {
  namespaced: true,

  state: {
    attributes: null,
    checklists: null
  },

  actions: {
    async initValidation({ state, dispatch }, userId) {
      dispatch("clean");

      // atributy
      state.attributes = await attributesApi.GetList(userId);

      // checklisty
      const list = await checklistsApi.GetList(userId);
      list.forEach((t) => {
        if (t.HasRequest) t.RequestNoteReadonly = true;
      });
      state.checklists = list;
    },

    async initApproval({ state, dispatch }, userId) {
      dispatch("clean");

      // checklisty
      state.checklists = await checklistsApi.GetList(userId);
    },

    clean({ state }) {
      state.attributes = null;
      state.checklists = null;
    }
  }
};
