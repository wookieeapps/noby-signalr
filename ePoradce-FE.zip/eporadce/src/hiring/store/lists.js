import { commonListsApi } from "@/code/apiServices";

export default {
  namespaced: true,

  state: {
    riskTypes: null,
    workInGroupTypes: null,
    workflowStatuses: null,
    experienceTypes: null,
    recruitmentSources: null,
    jobClassifications: null,
    jobActivities: null,
    positions: null,
    checklistStatuses: null
  },

  actions: {
    async fetchChecklistStatuses({ state }) {
      if (state.checklistStatuses === null) {
        state.checklistStatuses = (await commonListsApi.GetHiringChecklistStatuses()) || [];
      }
    },
    async fetchRiskTypes({ state }) {
      if (state.riskTypes === null) {
        state.riskTypes = (await commonListsApi.GetHiringRiskTypes()) || [];
      }
    },
    async fetchWorkInGroupTypes({ state }) {
      if (state.workInGroupTypes === null) {
        state.workInGroupTypes = (await commonListsApi.GetWorkInGroupTypes()) || [];
      }
    },
    async fetchWorkflowStatuses({ state }) {
      if (state.workflowStatuses === null) {
        state.workflowStatuses = (await commonListsApi.GetHiringWorkflowStatuses()) || [];
      }
    },
    async fetchExperienceTypes({ state }) {
      if (state.experienceTypes === null) {
        state.experienceTypes = (await commonListsApi.GetHiringExperienceTypes()) || [];
      }
    },
    async fetchRecruitmentSources({ state }) {
      if (state.recruitmentSources === null) {
        state.recruitmentSources = (await commonListsApi.GetHiringRecruitmentSources()) || [];
      }
    },
    async fetchJobClassifications({ state }) {
      if (state.jobClassifications === null) {
        state.jobClassifications = (await commonListsApi.GetHiringJobClassifications()) || [];
      }
    },
    async fetchJobActivities({ state }) {
      if (state.jobActivities === null) {
        state.jobActivities = (await commonListsApi.GetHiringJobActivities()) || [];
      }
    },
    async fetchPositions({ state }) {
      if (state.positions === null) {
        state.positions = (await commonListsApi.GetHiringPositions()) || [];
      }
    },

    async fetch({ dispatch }, listTypes) {
      for (let list of listTypes) {
        await dispatch("fetch" + list);
      }
    },

    async fetchAll({ dispatch }) {
      await dispatch("fetchRiskTypes");
      await dispatch("fetchWorkInGroupTypes")
      await dispatch("fetchWorkflowStatuses");
      await dispatch("fetchExperienceTypes");
      await dispatch("fetchRecruitmentSources");
      await dispatch("fetchRecruitmentSources");
      await dispatch("fetchJobClassifications");
      await dispatch("fetchJobActivities");
      await dispatch("fetchPositions");
    }
  }
};
