import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import vuetify from "./plugins/vuetify";
import AsyncComputed from "vue-async-computed";
import commonVuePlugin from "@mpss/eporadce-common-vue";
import httpClient from "./code/apiServices";
import store from "./store";
import listsPlugin from "./plugins/listsPlugin";

Vue.config.productionTip = false;

// registrace eporadce-common-vue
const commonVueOptions = {
  httpClient,
  appVersion: process.env.VERSION,
  applicationId: process.env.VUE_APP_APPLICATION_ID
};
Vue.use(commonVuePlugin, commonVueOptions);

// lists plugin
Vue.use(listsPlugin, store);

Vue.use(AsyncComputed);

new Vue({
  router,
  store,
  vuetify,
  render: (h) => h(App)
}).$mount("#app");
