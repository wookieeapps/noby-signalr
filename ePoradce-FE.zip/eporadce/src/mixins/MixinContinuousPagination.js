export default {
  props: ["itemsPerPage"],

  data() {
    return {
      //items: null, - musi byt v konzumujici komponente
      itemsPageSize: this.itemsPerPage || 5,
      itemsStart: null,
      itemsEnd: null,
      itemsMore: false,
      itemsMoreLoading: false,

      continuousPaginationFce: null
    };
  },

  methods: {
    // dohrat dalsi
    async paginationLoadMore(start, count, replace) {
      this.itemsMoreLoading = true;

      let pageSize = this.itemsPageSize;
      if (start != undefined && start != null && count) {
        this.itemsStart = start;
        this.itemsEnd = count;
        pageSize = count;
      } else if (this.itemsStart === null) {
        this.itemsStart = 0;
        this.itemsEnd = this.itemsPageSize;
      } else {
        this.itemsStart = this.itemsEnd;
        this.itemsEnd = this.itemsStart + this.itemsPageSize;
      }

      const model = await this.continuousPaginationFce(this.itemsStart, pageSize);

      this.items = Array.isArray(this.items) && !replace ? this.items.concat(model.Data) : model.Data;
      this.itemsMore = model.HasMore;
      this.itemsMoreLoading = false;
    }
  }
};
