let isHiddenCounter = 0;
const maxToShow = 4;

export default {
  props: ["items"],

  data() {
    return {
      showAll: this.count <= maxToShow
    };
  },

  created() {
    isHiddenCounter = 0;
  },

  watch: {
    showAll() {
      this.$emit("update");
    }
  },

  computed: {
    count() {
      return this.items.length;
    },

    showButton() {
      return !this.showAll && this.count > maxToShow;
    }
  },

  methods: {
    isHidden(isGroup) {
      if (!isGroup) isHiddenCounter++;
      return isHiddenCounter > maxToShow;
    }
  }
};
