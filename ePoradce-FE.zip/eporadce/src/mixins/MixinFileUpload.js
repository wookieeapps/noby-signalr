import { fileInfoApi } from "@/code/apiServices";
import { FileInfoStates } from "@mpss/eporadce-common-api";
import MixinGetDownloadUrl from "@/mixins/MixinGetDownloadUrl";

export default {
  mixins: [MixinGetDownloadUrl],

  data() {
    return {
      files: null
    };
  },

  methods: {
    filesIsDeleteVisible(item) {
      if (item.IsReadonly) return false;
      return !item.State || item.State === FileInfoStates.Existing || item.State === FileInfoStates.Uploaded;
    },

    /**
     * Barva ikony nalevo: cervena=failed, zelena=nove uploadovano, jinak=cerna
     */
    filesIconColor(item) {
      if (item.State === FileInfoStates.Uploaded) return "success";
      else if (item.State === FileInfoStates.UploadFailed) return "error";
      else return "default";
    },

    /**
     * Smazat soubor
     */
    async filesDelete(item) {
      const idx = this.files.findIndex((t) => t.Id === item.Id && t.OriginalFileName === item.OriginalFileName);
      if (
        await this.$confirm("Opravdu si přejete smazat tento dokument?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        this.$delete(this.files, idx);
        this.filesUpdateParent();
      }
    },

    /**
     * Uzivatel vybral nejake soubory - upload na server.
     */
    async filesInputChange(ev) {
      if (!this.files) this.files = [];

      for (let file of ev.target.files) {
        // append to vue data
        let viewFile = fileInfoApi.CreateEmptyModel(file.name, file.size, this.$user.getSync().DisplayName);

        this.files.unshift(viewFile);

        const result = await fileInfoApi.Create(file, this.objectTypeId);

        if (result.errors) {
          viewFile.State = FileInfoStates.UploadFailed;
          viewFile.ErrorMessage = result.errors.file[0];
        } else {
          viewFile.State = FileInfoStates.Uploaded;
          viewFile.Id = result.Id;
          if (this.fileTypes && this.fileTypes.length === 1) {
            viewFile.FileInfoTypeId = this.fileTypes[0].Id;
          }
          viewFile.SystemFileName = result.SystemFileName;
        }
      }

      ev.target.value = null;

      this.filesUpdateParent();
    },

    // virtual function to be replaced in parent component
    filesUpdateParent() {}
  }
};
