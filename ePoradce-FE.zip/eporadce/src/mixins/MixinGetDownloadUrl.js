import { fileInfoApi } from "@/code/apiServices";

export default {
  methods: {
    getDownloadUrl(guid) {
      return process.env.VUE_APP_API_BASE_PATH + fileInfoApi.GetDownloadUrl(guid);
    }
  }
};
