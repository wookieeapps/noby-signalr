<template>
  <div>
    <app-box-loader v-if="generalModel === null" />

    <div v-else class="masonry-grid row" id="dvDashboard">
      <div class="masonry-grid-sizer col-md-6 col-12"></div>

      <!-- zobrazit vlastni profil -->
      <user-widget />

      <!-- tickety ke schvaleni -->
      <tickets-to-approve-widget :items="generalModel.TicketsToApprove" @update="updateMasonry" />

      <disapproved-tickets-for-manager :items="generalModel.DisapprovedTicketsAsManager" @update="updateMasonry" />

      <!-- zamitnute tickety pro aktualniho FP -->
      <active-tickets-for-user-widget :items="generalModel.DisapprovedTickets" @update="updateMasonry" />

      <!-- dozadani pro tohoto FP -->
      <requests-for-user-widget :items="generalModel.OpenedRequests" />

      <!-- HIRING -->
      <hiring-dashboard v-if="isHiring" @update="updateMasonry" />
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import Masonry from "masonry-layout";
import { UserRoles, UserRolesGroups } from "@mpss/eporadce-common";
import { dashboardApi } from "@/code/apiServices";
import HiringDashboard from "@/hiring/components/Dashboard.vue";

import DisapprovedTicketsForManager from "./dashboard/DisapprovedTicketsForManager.vue";
import UserWidget from "./dashboard/UserWidget.vue";
import TicketsToApproveWidget from "./dashboard/TicketsToApproveWidget.vue";
import RequestsForUserWidget from "./dashboard/RequestsForUserWidget.vue";
import ActiveTicketsForUserWidget from "./dashboard/ActiveTicketsForUserWidget.vue";

// masonry related
let masonry = null;

export default {
  name: "Dashboard",

  components: {
    HiringDashboard,
    UserWidget,
    RequestsForUserWidget,
    TicketsToApproveWidget,
    ActiveTicketsForUserWidget,
    DisapprovedTicketsForManager
  },

  data() {
    return {
      generalModel: null
    };
  },

  async mounted() {
    await this.$user.get();

    this.generalModel = await dashboardApi.Get();

    Vue.nextTick(function () {
      masonry = new Masonry("#dvDashboard", {
        gutter: 0,
        columnWidth: ".masonry-grid-sizer",
        itemSelector: ".masonry-grid-item",
        percentPosition: true
      });
    });
  },

  computed: {
    isHiring() {
      return this.$user.loaded ? this.$user.isInRoleGroup(UserRolesGroups.Hiring) : false;
    }
  },

  methods: {
    updateMasonry() {
      Vue.nextTick(function () {
        masonry.reloadItems();
        masonry.layout();
      });
    }
  }
};
</script>
