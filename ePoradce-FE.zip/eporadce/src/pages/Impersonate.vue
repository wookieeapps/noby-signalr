<template>
  <div>
    <app-page-toolbar :validation-errors="validationErrors">
      <template v-slot:actions>
        <v-btn color="success" tile @click="loginUser" :loading="saveBtnLoading">Přihlásit se</v-btn>
      </template>
    </app-page-toolbar>

    <v-card v-if="allRoles === null">
      <v-card-text>
        <app-box-loader />
      </v-card-text>
    </v-card>

    <v-card v-else>
      <v-card-title>Přihlášení jako jiný uživatel</v-card-title>
      <v-card-text>
        <v-row>
          <v-col md="4">
            <v-text-field maxlength="8" label="ČPM/login" v-model="login" :error-messages="validateField('Login')" />
          </v-col>
          <v-col md="2"></v-col>
          <v-col md="6">
            <v-checkbox
              v-for="item in allRoles"
              :key="item.Id"
              :value="item.Id"
              v-model="userRoles"
              hide-details
              class="mt-0"
              :error-messages="validateField('UserRoles')"
            >
              <template v-slot:label>
                <span class="text--disabled mr-2">({{ item.Code }})</span> {{ item.Text }}
              </template>
            </v-checkbox>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { impersonateApi } from "../code/apiServices";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";

export default {
  name: "Impersonate",

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      userRoles: [],
      allRoles: null,
      login: ""
    };
  },

  async mounted() {
    this.allRoles = await impersonateApi.GetUserRoles();
    this.login = this.$user.getSync().CPM;
  },

  methods: {
    async loginUser() {
      this.onBeforeSave();

      const result = await impersonateApi.Save({ Login: this.login, UserRoles: this.userRoles });

      if (await this.resolveGeneralResult(result, "", "", "Uživatele nebylo možné přihlásit"))
        location.href = process.env.VUE_APP_FRONTEND_BASE_PATH;
    }
  }
};
</script>
