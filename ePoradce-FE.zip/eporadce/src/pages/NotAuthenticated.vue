<template>
  <div class="pt-5">
    <v-alert class="text-5" type="error"
      >Nejste přihlášen/a do Portálu Modré pyramidy! Klikněte na tlačítko níže - po přihlášení budete automaticky
      přesměrováni na původně požadovanou stránku.</v-alert
    >
    <div class="mt-7"><v-btn large color="primary" :href="url">Přihlásit se do Portálu</v-btn></div>
  </div>
</template>

<script>
export default {
  name: "NotFound",

  computed: {
    url() {
      var url = new URL(location.href);
      var returnUrl = url.searchParams.get("url");
      return process.env.VUE_APP_PMP_LOGIN + "?auth=failed&return=" + encodeURIComponent(returnUrl);
    }
  }
};
</script>
