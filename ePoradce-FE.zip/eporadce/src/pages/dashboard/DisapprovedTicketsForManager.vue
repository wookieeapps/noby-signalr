<template>
  <div v-if="items && items.length > 0" class="masonry-grid-item col-12 col-md-6">
    <v-card tile>
      <v-card-title>Zamítnuté tickety sítě za posledních 30 dní</v-card-title>
      <v-list>
        <v-list-item v-for="ticket in items" :key="ticket.Id" v-show="showAll || !isHidden(false)">
          <v-list-item-avatar>#{{ ticket.Id }}</v-list-item-avatar>
          <v-list-item-content>
            <v-list-item-title>{{ ticket.Name }}</v-list-item-title>
            <v-list-item-subtitle>{{ ticket.TicketTypeName }}</v-list-item-subtitle>
            <v-list-item-subtitle>{{ ticket.Date | datetime }}</v-list-item-subtitle>
          </v-list-item-content>
          <v-list-item-action
            ><v-btn icon :to="{ name: 'UserDetail', params: { id: ticket.UserId } }"
              ><v-icon color="primary">send</v-icon></v-btn
            ></v-list-item-action
          >
        </v-list-item>
      </v-list>

      <!-- zobrazit dalsi soubory -->
      <div class="text-center pb-3" v-if="showButton">
        <v-btn color="primary" x-small @click="showAll = true" tile text
          ><v-icon x-small>get_app</v-icon>Zobrazit vše ({{ count }})</v-btn
        >
      </div>
    </v-card>
  </div>
</template>

<script>
import MixinDashboardShowMore from "../../mixins/MixinDashboardShowMore";

export default {
  name: "DisapprovedTicketsForManager",

  mixins: [MixinDashboardShowMore]
};
</script>
