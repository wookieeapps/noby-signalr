<template>
  <div v-if="items.length > 0" class="masonry-grid-item col-12 col-md-6">
    <v-card tile>
      <v-card-title><v-icon color="error" class="mr-2">assignment_late</v-icon> Má aktivní dožádání</v-card-title>
      <v-list>
        <v-list-item v-for="req in items" :key="req.Id">
          <v-list-item-content>
            <v-list-item-title>{{ req.Name }}</v-list-item-title>
            <v-list-item-subtitle v-if="req.Note">{{ req.Note }}</v-list-item-subtitle>
          </v-list-item-content>
          <v-list-item-action>
            <v-list-item-action-text>{{ req.Date | date }}</v-list-item-action-text>
            <v-list-item-action-text>{{ req.InsertedBy }}</v-list-item-action-text>
          </v-list-item-action>
        </v-list-item>
      </v-list>
    </v-card>
  </div>
</template>

<script>
export default {
  props: ["items"]
};
</script>
