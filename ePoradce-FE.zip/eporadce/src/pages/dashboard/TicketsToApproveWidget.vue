<template>
  <div v-if="items.length > 0" class="masonry-grid-item col-12 col-md-6">
    <v-card tile>
      <v-card-title class="d-flex justify-space-between"
        ><span>Tickety ke schválení</span>
        <v-btn small color="primary" outlined :to="{ name: 'TicketsMassApproval' }"
          >Rychlé schvalování</v-btn
        ></v-card-title
      >
      <v-list>
        <div v-for="(group, index) in items" :key="index">
          <v-subheader v-if="items.length > 1" v-show="showAll || !isHidden(true)"
            ><span class="pl-4 black--text caption">{{ group.GroupName }}</span></v-subheader
          >
          <v-list-item v-for="ticket in group.Tickets" :key="ticket.Id" v-show="showAll || !isHidden(false)">
            <v-list-item-avatar>#{{ ticket.Id }}</v-list-item-avatar>
            <v-list-item-content>
              <v-list-item-subtitle
                ><strong>{{ ticket.Name }}</strong></v-list-item-subtitle
              >
              <v-list-item-subtitle>{{ ticket.TicketTypeName }}</v-list-item-subtitle>
            </v-list-item-content>
            <v-list-item-action
              ><v-btn icon :to="{ name: 'UserDetail', params: { id: ticket.UserId } }"
                ><v-icon color="primary">send</v-icon></v-btn
              ></v-list-item-action
            >
          </v-list-item>
        </div>
      </v-list>

      <!-- zobrazit dalsi soubory -->
      <div class="text-center pb-3" v-if="showButton">
        <v-btn color="primary" x-small @click="showAll = true" tile text
          ><v-icon x-small>get_app</v-icon>Zobrazit vše ({{ count }})</v-btn
        >
      </div>
    </v-card>
  </div>
</template>

<script>
import MixinDashboardShowMore from "../../mixins/MixinDashboardShowMore";

export default {
  name: "TicketsToApproveWidget",

  mixins: [MixinDashboardShowMore],

  computed: {
    count() {
      let c = 0;
      this.items.forEach((t) => {
        c += t.Tickets.length;
      });
      return c;
    }
  }
};
</script>
