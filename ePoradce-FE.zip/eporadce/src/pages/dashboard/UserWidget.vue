<template>
  <div v-if="$user.loaded" class="masonry-grid-item col-md-6 col-12">
    <v-card tile>
      <v-card-title>{{ $user.getSync().DisplayName }}</v-card-title>
      <v-card-text class="py-8">
        <v-btn
          color="primary"
          :to="{
            name: $user.isInRole(16384) ? 'EmployeeDetail' : 'UserDetail',
            params: { id: $user.getSync().Id }
          }"
          >Zobrazit vlastní profil</v-btn
        >
      </v-card-text>
    </v-card>
  </div>
</template>
