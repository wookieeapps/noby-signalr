const install = function (Vue, store) {
  // get list item
  Vue.filter("list", function (value, module, collection) {
    // shared module
    if (!collection) {
      collection = module;
      module = "shared";
    }

    if (store.state.lists[module][collection]) return store.state.lists[module][collection].find((t) => t.Id == value);
    else return null;
  });

  // get Color
  Vue.filter("color", function (value, suffix) {
    let v = value ? value.Color : "";
    return suffix ? v + suffix : v;
  });

  // get Text
  Vue.filter("text", function (value) {
    return value ? value.Text : "";
  });

  // get Code
  Vue.filter("code", function (value) {
    return value ? value.Code : "";
  });

  // nazev ObjectTypeId
  Vue.filter("objectTypeName", function (value) {
    return store.state.lists["shared"]["objectTypes"].find((t) => t.Id == value).Text;
  });
};

export default {
  install
};
