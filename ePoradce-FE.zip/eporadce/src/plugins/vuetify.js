import Vue from "vue";
import Vuetify, { VSnackbar } from "vuetify/lib";
import VuetifyConfirm from "vuetify-confirm";
import VuetifyToast from "vuetify-toast-snackbar";
import cs from "vuetify/es5/locale/cs";

Vue.use(Vuetify, {
  components: {
    VSnackbar
  }
});

// konfigurace Vuetify
const config = {
  silent: process.env.VUE_APP_MODE == "production",
  icons: {
    iconfont: "md"
  },
  lang: {
    locales: { cs },
    current: "cs"
  }
};

const vuetify = new Vuetify(config);

Vue.use(VuetifyToast, {
  $vuetify: vuetify.framework
});
Vue.use(VuetifyConfirm, { vuetify });

export default vuetify;
