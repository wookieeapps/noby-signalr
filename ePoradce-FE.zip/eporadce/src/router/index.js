import Vue from "vue";
import VueRouter from "vue-router";

// APPS
import eOla from "../eola/router";
import Hiring from "../hiring/router";
import User from "../user/router";
import Administration from "../administration/router";

// VIEWS
import Dashboard from "../pages/Dashboard.vue";
import NotAuthenticated from "../pages/NotAuthenticated.vue";
import NotFound from "../pages/NotFound.vue";
const Impersonate = () => import(/* webpackChunkName: "Impersonate" */ "../pages/Impersonate.vue");

Vue.use(VueRouter);

const router = new VueRouter({
  mode: "history",
  base: process.env.VUE_APP_FRONTEND_BASE_PATH,
  routes: [
    {
      path: "/",
      name: "Dashboard",
      component: Dashboard
    },
    {
      path: "/impersonate",
      name: "Impersonate",
      component: Impersonate
    },
    {
      path: "/not-authenticated",
      name: "NotAuthenticated",
      component: NotAuthenticated
    },
    ...User,
    ...eOla,
    ...Hiring,
    ...Administration,
    // catch all route
    {
      path: "*",
      component: NotFound
    }
  ]
});

export default router;
