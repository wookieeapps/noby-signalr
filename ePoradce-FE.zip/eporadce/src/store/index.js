import Vue from "vue";
import Vuex from "vuex";

import storeLists from "./lists";
import hiring from "../hiring/store";
import userDetail from "../user/store";

Vue.use(Vuex);

const store = new Vuex.Store({
  modules: {
    lists: storeLists,
    hiring,
    userDetail
  }
});

// create shortcut to lists stores
Vue.prototype.$lists = store.state.lists;
Vue.prototype.$lists.fetch = async (module, lists) => {
  if (!lists) {
    lists = module;
    module = "shared";
  }
  await store.dispatch(`lists/${module}/fetch`, Array.isArray(lists) ? lists : [lists]);
};

// create shortcut to hiring store
Vue.prototype.$hiring = store.state.hiring;
// create shortcut to eOla store
Vue.prototype.$eola = store.state.eola;

export default store;
