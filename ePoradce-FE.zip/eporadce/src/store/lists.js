import hiringStore from "../hiring/store/lists";
import eolaStore from "../eola/store/lists";
import sharedStore from "./sharedLists";
import ticketingStore from "./ticketingLists";

export default {
  namespaced: true,

  modules: {
    ticketing: ticketingStore,
    shared: sharedStore,
    hiring: hiringStore,
    eola: eolaStore
  }
};
