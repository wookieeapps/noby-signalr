import { commonListsApi } from "../code/apiServices";
import { ApplicationIdTypes } from "@mpss/eporadce-common";

export default {
  namespaced: true,

  state: {
    objectTypes: null,
    titles: null,
    titles2: null,
    banks: null,
    userSalutations: null,
    userGroupTypes: null,
    ticketStatuses: null,
    countries: null,
    allPositions: null,
    healthInsurances: null
  },

  actions: {
    async fetchTicketStatuses({ state }) {
      if (state.ticketStatuses === null) {
        state.ticketStatuses = (await commonListsApi.GetTicketStatuses()) || [];
      }
    },
    async fetchTitles({ state }) {
      if (state.titles === null) {
        state.titles = (await commonListsApi.GetTitles()) || [];
      }
    },
    async fetchTitles2({ state }) {
      if (state.titles2 === null) {
        state.titles2 = (await commonListsApi.GetTitles2()) || [];
      }
    },
    async fetchAllPositions({ state }) {
      if (state.allPositions === null) {
        state.allPositions = (await commonListsApi.GetAllPositions()) || [];
      }
    },
    async fetchObjectTypes({ state }) {
      if (state.objectTypes === null) {
        state.objectTypes = await commonListsApi.GetObjectTypes(ApplicationIdTypes.None);
      }
    },
    async fetchBanks({ state }) {
      if (state.banks === null) {
        state.banks = await commonListsApi.GetBanks();
      }
    },
    async fetchUserSalutations({ state }) {
      if (state.userSalutations === null) {
        state.userSalutations = (await commonListsApi.GetUserSalutations()) || [];
      }
    },
    async fetchUserGroupTypes({ state }) {
      if (state.userGroupTypes === null) {
        state.userGroupTypes = (await commonListsApi.GetUserGroupTypes()) || [];
      }
    },
    async fetchCountries({ state }) {
      if (state.countries === null) {
        state.countries = (await commonListsApi.GetCountries()) || [];
      }
    },
    async fetchHealthInsurances({ state }) {
      if (state.healthInsurances === null) {
        state.healthInsurances = (await commonListsApi.GetHealthInsurances()) || [];
      }
    },

    async fetch({ dispatch }, listTypes) {
      for (let list of listTypes) {
        await dispatch("fetch" + list);
      }
    },

    async fetchAll({ dispatch }) {
      await dispatch("fetchTicketStatuses");
      await dispatch("fetchTitles");
      await dispatch("fetchTitles2");
      await dispatch("fetchObjectTypes");
      await dispatch("fetchBanks");
      await dispatch("fetchUserSalutations");
      await dispatch("fetchUserGroupTypes");
      await dispatch("fetchCountries");
      await dispatch("fetchAllPositions");
      await dispatch("fetchHealthInsurances");
    }
  }
};
