import { commonListsApi } from "../code/apiServices";

export default {
  namespaced: true,

  state: {
    terminationReasons: null
  },

  actions: {
    async fetchTerminationReasons({ state }) {
      if (state.terminationReasons === null) {
        state.terminationReasons = (await commonListsApi.GetTicketingTerminationReasons()) || [];
      }
    },

    async fetch({ dispatch }, listTypes) {
      for (let list of listTypes) {
        await dispatch("fetch" + list);
      }
    },

    async fetchAll({ dispatch }) {
      await dispatch("fetchTerminationReasons");
    }
  }
};
