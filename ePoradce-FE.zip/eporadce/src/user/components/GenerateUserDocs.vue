<template>
  <v-menu bottom offset-y v-if="isHiring">
    <template v-slot:activator="{ on }">
      <v-btn v-on="on" tile text>
        Tisk dokumentů
        <v-icon>expand_more</v-icon>
      </v-btn>
    </template>
    <v-list>
      <v-list-item @click="generateDocs('spfp')">
        <v-list-item-icon>
          <v-icon color="grey lighten-2">get_app</v-icon>
        </v-list-item-icon>
        <v-list-item-title>Generovat SOS</v-list-item-title>
      </v-list-item>
      <v-list-item @click="generateDocs('seju')">
        <v-list-item-icon>
          <v-icon color="grey lighten-2">get_app</v-icon>
        </v-list-item-icon>
        <v-list-item-title>Generovat SeJu</v-list-item-title>
      </v-list-item>
      <v-list-item @click="generateDocs('povExtSecialisty')">
        <v-list-item-icon>
          <v-icon color="grey lighten-2">get_app</v-icon>
        </v-list-item-icon>
        <v-list-item-title>Generovat Povinosti Externího Secialisty</v-list-item-title>
      </v-list-item>
    </v-list>
  </v-menu>
</template>

<script>
import { hiringGeneralApi } from "../../hiring/code/apiServicesHiring";
import { UserRolesGroups } from "@mpss/eporadce-common";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";

export default {
  name: "GenerateUserDocs",

  props: ["userId"],

  mixins: [MixinResolveGeneralResult],

  computed: {
    isHiring() {
      return this.$user.loaded ? this.$user.isInRoleGroup(UserRolesGroups.Hiring) : false;
    }
  },

  methods: {
    async generateDocs(docType) {
      const resultDoc = await hiringGeneralApi.GenerateDoc(this.userId, docType);
      if (await this.resolveGeneralResult(resultDoc)) {
        location.href = resultDoc;
      }
    }
  }
};
</script>