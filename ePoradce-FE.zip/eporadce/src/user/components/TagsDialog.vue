<template>
  <v-dialog v-model="value" max-width="500">
    <v-card>
      <v-card-title class="text-truncate">Tagy pro {{ tagsDialogTitle }}</v-card-title>

      <v-card-text>
        <v-chip-group column active-class="primary--text" v-model="tagsSelection" multiple>
          <v-chip v-for="tag in tags" :key="tag.Id" :value="tag.Id">
            {{ tag.Name }}
          </v-chip>
        </v-chip-group>
      </v-card-text>

      <v-card-actions class="pr-5 pb-4">
        <v-spacer></v-spacer>
        <v-btn text tile @click="$emit('input', false)">Zavřít</v-btn>
        <v-btn color="success" @click="saveTagsDialog" :loading="tagsDialogLoading">Uložit změny</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { tagsApi } from "@/code/apiServices";
import { ObjectTypes } from "@mpss/eporadce-common";

export default {
  name: "UserTagsDialog",

  props: ["value", "item", "save"],

  data() {
    return {
      tags: null,
      tagsDialogLoading: false,
      tagsSelection: []
    };
  },

  async mounted() {
    this.tags = await tagsApi.GetList(ObjectTypes.User);
  },

  computed: {
    // nadpis dialogu s vyberem tagu
    tagsDialogTitle() {
      return this.item == null ? "" : this.item.OriginalFileName;
    }
  },

  watch: {
    value(v) {
      if (v) this.tagsSelection = this.item.Tags == null ? [] : [...this.item.Tags];
    }
  },

  methods: {
    // ulozeni zmeny tagu u souboru
    async saveTagsDialog() {
      this.tagsDialogLoading = true;

      if (this.save) {
        await tagsApi.SaveFileBinding(ObjectTypes.User, this.item.Id, this.tagsSelection);

        this.$toast.success("Tagy byly uloženy");
      }

      this.item.Tags = [...this.tagsSelection];

      this.tagsDialogLoading = false;
      this.$emit("input", false);
    }
  }
};
</script>
