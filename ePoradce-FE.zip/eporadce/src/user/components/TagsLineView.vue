<template>
  <div>
    <v-chip small outlined text-color="primary" @click="$emit('dialog', file.Id)" class="mr-2">
      <v-icon small>bookmarks</v-icon>
    </v-chip>

    <v-chip small color="blue lighten-5" class="mr-2" v-for="tag in file.Tags" :key="`t${file.Id}_${tag}`">{{
      getTag(tag)
    }}</v-chip>
  </div>
</template>

<script>
export default {
  name: "",

  props: ["file", "tags"],

  methods: {
    // vraci nazev tagu podle ID
    getTag(id) {
      return this.tags.find((t) => t.Id == id).Name;
    }
  }
};
</script>
