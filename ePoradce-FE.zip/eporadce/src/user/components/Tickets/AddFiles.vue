<template>
  <div>
    <v-checkbox
      v-show="!hasParent"
      label="Čestně prohlašuji, že jsem pořídil scan z originálu dokladu a doklad je čitelný a vhodný ke zpracování"
      v-model="value.AgreeToTerms"
      hide-details
      @input="update('AgreeToTerms', $event)"
      :error-messages="validateField('Model.AgreeToTerms')"
    />

    <custom-upload
      class="mt-2 mb-8"
      button-text="Přiložit dokumenty"
      :object-type-id="objTypeTicket"
      :object-id="value.ParentId"
      v-model="value.Files"
      :error-messages="validateField('Model.Files')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import CustomUpload from "@/components/CustomUpload";

export default {
  name: "TicketDetailAddFiles",

  components: { CustomUpload },

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.value.AgreeToTerms = false;
      this.value.Files = [];
    }
  }
};
</script>
