<template>
  <div>
    <v-slide-y-reverse-transition hide-on-leave>
      <div v-show="!agree">
        <v-alert type="warning"
          >Pokud si nepřejete přiložit scan OP/Cestovního pasu, kontaktujte prosím svého manažera.</v-alert
        >
        <p class="text-center"><v-btn color="primary" @click="agree = true">Přiložím naskenované dokumenty</v-btn></p>
      </div>
    </v-slide-y-reverse-transition>

    <v-slide-y-transition>
      <div v-show="agree">
        <address-fields v-model="model" @input="$emit('input', model)" :validationErrors="validationErrors" />

        <custom-upload
          class="mt-2 mb-8"
          button-text="Přiložit dokumenty"
          :object-type-id="objTypeTicket"
          :object-id="value.ParentId"
          v-model="value.Files"
          :readonly="true"
          :error-messages="validateField('Model.Files')"
        />

        <personal-data-change-agreement v-model="value" :validationErrors="validationErrors" v-if="!hasParent" />

        <agreement-with-scan v-model="value" :validationErrors="validationErrors" v-if="!hasParent" />
      </div>
    </v-slide-y-transition>
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import PersonalDataChangeAgreement from "./_PersonalDataChangeAgreement.vue";
import AgreementWithScan from "./_AgreementWithScan.vue";
import CustomUpload from "@/components/CustomUpload.vue";
import AddressFields from "./_AddressFields.vue";
import { placesApi } from "@/code/apiServices";

export default {
  name: "TicketDetailAddress",

  components: { PersonalDataChangeAgreement, AddressFields, CustomUpload, AgreementWithScan },

  mixins: [MixinTicketBase],

  data() {
    return {
      agree: false,
      model: this.value
    };
  },

  created() {
    if (!this.hasParent) {
      this.model.Street = this.$store.state.userDetail.user.Addr1Street;
      this.model.Zip = this.$store.state.userDetail.user.Addr1Zip;
      this.model.City = this.$store.state.userDetail.user.Addr1City;
    } else {
      this.agree = true;
    }

    this.change();
  },

  watch: {
    agree(v) {
      this.change();
    }
  },

  methods: {
    change() {
      this.$emit("alterDialog", { successBtn: this.agree, note: this.agree });
    }
  }
};
</script>
