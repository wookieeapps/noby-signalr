<template>
  <address-fields v-model="model" @input="$emit('input', model)" :validationErrors="validationErrors" />
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import AddressFields from "./_AddressFields.vue";

export default {
  name: "TicketDetailAddressContact",

  components: { AddressFields },

  data() {
    return {
      model: this.value
    };
  },

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.model.Street = this.$store.state.userDetail.user.Addr2Street;
      this.model.Zip = this.$store.state.userDetail.user.Addr2Zip;
      this.model.City = this.$store.state.userDetail.user.Addr2City;
    }
  }
};
</script>
