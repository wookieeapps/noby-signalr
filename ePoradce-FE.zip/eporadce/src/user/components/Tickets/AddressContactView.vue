<template>
  <div>
    <app-text-with-label
      :width="20"
      label="Ulice"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.Street"
      :text-secondary="sec1"
    />
    <app-text-with-label
      :width="20"
      label="Město"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.City"
      :text-secondary="sec2"
    />
    <app-text-with-label
      :width="20"
      label="PSČ"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.Zip"
      :text-secondary="sec3"
    />
  </div>
</template>

<script>
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailAddressContactView",

  mixins: [MixinTicketViewBase],

  computed: {
    sec1() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Addr2Street : "";
    },

    sec2() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Addr2City : "";
    },

    sec3() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Addr2Zip : "";
    }
  }
};
</script>
