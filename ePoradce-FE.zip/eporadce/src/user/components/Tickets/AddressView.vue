<template>
  <div>
    <app-text-with-label
      :width="20"
      label="Ulice"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.Street"
      :text-secondary="sec1"
    />
    <app-text-with-label
      :width="20"
      label="Město"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.City"
      :text-secondary="sec2"
    />
    <app-text-with-label
      :width="20"
      label="PSČ"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.Zip"
      :text-secondary="sec3"
    />

    <simple-file-list :object-type-id="objTypeTicket" :object-id="id" :enable-delete="enableFileDelete" />
  </div>
</template>

<script>
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";
import SimpleFileList from "@/components/SimpleFileList.vue";

export default {
  name: "TicketDetailAddressView",

  components: { SimpleFileList },

  mixins: [MixinTicketViewBase],

  computed: {
    sec1() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Addr1Street : "";
    },

    sec2() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Addr1City : "";
    },

    sec3() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Addr1Zip : "";
    }
  }
};
</script>
