<template>
  <div>
    <v-text-field
      label="Číslo účtu"
      maxlength="17"
      v-model="value.AccountNo"
      @input="update('AccountNo', $event)"
      :error-messages="validateField('Model.AccountNo')"
    />

    <v-select
      label="Banka"
      clearable
      v-model="value.BankCode"
      item-text="Code"
      item-value="Code"
      :items="$lists.shared.banks"
      @input="update('BankCode', $event)"
      :error-messages="validateField('Model.BankCode')"
    >
      <template #item="{ item }">{{ item.Code }} - {{ item.Text }}</template>
    </v-select>

    <v-text-field
      label="Specifický symbol"
      maxlength="12"
      v-model="value.SpecificSymbol"
      @input="update('SpecificSymbol', $event)"
      :error-messages="validateField('Model.SpecificSymbol')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";

export default {
  name: "TicketDetailBankAccount",

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.value.AccountNo = this.$store.state.userDetail.user.AccountNo;
      this.value.BankCode = this.$store.state.userDetail.user.BankCode;
      this.value.SpecificSymbol = this.$store.state.userDetail.user.SpecificSymbol;
    }
  },

  async mounted() {
    await this.$lists.fetch(["Banks"]);
  }
};
</script>
