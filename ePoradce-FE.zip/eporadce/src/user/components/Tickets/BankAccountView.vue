<template>
  <div>
    <app-text-with-label
      :width="30"
      label="Číslo účtu"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.AccountNo"
      :text-secondary="sec1"
    />

    <app-text-with-label
      :width="30"
      label="Banka"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.BankCode"
      :text-secondary="sec2"
    />

    <app-text-with-label
      :width="30"
      label="Specifický symbol"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.SpecificSymbol"
      :text-secondary="sec3"
    />
  </div>
</template>

<script>
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailBankAccountView",

  mixins: [MixinTicketViewBase],

  computed: {
    sec1() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.AccountNo : "";
    },

    sec2() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.BankCode : "";
    },

    sec3() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.SpecificSymbol : "";
    }
  }
};
</script>
