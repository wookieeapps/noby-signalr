<template>
  <div>
    <v-btn @click="addItem" color="primary" text><v-icon left>add</v-icon> Přidat nové místo</v-btn>

    <v-list>
      <v-list-item two-line v-for="(item, index) in poceItems" :key="item.Index" class="px-0">
        <poce-address :item="item" :index="index" :validationErrors="validationErrors" />

        <v-list-item-action>
          <v-btn icon color="red">
            <v-icon @click="itemDelete(index)">delete</v-icon>
          </v-btn>
        </v-list-item-action>
      </v-list-item>
    </v-list>
  </div>
</template>

<script>
import { placesApi } from "../../../code/apiServices";
import MixinTicketBase from "../../mixins/MixinTicketBase";
import PoceAddress from "./_PoceAddress.vue";

let cIndex = 1;

export default {
  name: "TicketChangePoce",

  components: { PoceAddress },

  mixins: [MixinTicketBase],

  data() {
    return {
      poceItems: null
    };
  },

  async created() {
    if (!this.hasParent) {
      await this.$store.dispatch("userDetail/initDetail");

      const x = [...this.$store.state.userDetail.detail.PoCe];
      x.forEach((t) => (t.Index = cIndex++));
      this.poceItems = x;
    }
  },

  watch: {
    poceItems(v) {
      this.$emit("input", { ...this.value, Items: this.poceItems });
    }
  },

  methods: {
    // smazat adresu
    itemDelete(index) {
      this.$delete(this.poceItems, index);
    },

    // pridat adresu
    addItem() {
      this.poceItems.push({
        Id: 0,
        Street: "",
        City: "",
        Zip: "",
        Type: 1,
        Index: cIndex++
      });
    },

    // update uzivatele po ulozeni ticketu
    saved(result) {
      if (result !== null && !result.errors && result.SelfApproval) {
        this.$store.state.userDetail.detail.PoCe = this.poceItems;
      }
    }
  }
};
</script>
