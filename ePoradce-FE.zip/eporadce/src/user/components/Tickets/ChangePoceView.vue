<template>
  <v-list>
    <v-list-item v-for="(item, index) in model.Items" :key="index">
      <v-list-item-content>
        <v-list-item-subtitle>
          {{ (item.Type == 1 ? "POCE 1 (Příslušnost poradce k poradenskému centru)" : "POCE 2 (Poradenské centrum pro zasílání klientské dokumentace)") }}
        </v-list-item-subtitle>

        <v-list-item-title>
          {{ item.Street }}<br />
          {{ item.City }} {{ item.Zip }}
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>
  </v-list>
</template>

<script>
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketChangePoceView",

  mixins: [MixinTicketViewBase],

  methods: {
    approved() {
      this.$store.state.userDetail.detail.PoCe = this.model.Items;
    }
  }
};
</script>
