<template>
  <div>
    <v-text-field
      label="Soukromý email"
      maxlength="50"
      v-model="value.EmailPersonal"
      @input="update('EmailPersonal', $event)"
      :error-messages="validateField('Model.EmailPersonal')"
    />

    <v-text-field
      label="Mobil"
      maxlength="9"
      v-model="value.Mobil"
      @input="update('Mobil', $event)"
      :error-messages="validateField('Model.Mobil')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";

export default {
  name: "TicketDetailContacts",

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.value.EmailPersonal = this.$store.state.userDetail.user.EmailPersonal;
      this.value.Mobil = this.$store.state.userDetail.user.Mobil;
    }
  }
};
</script>
