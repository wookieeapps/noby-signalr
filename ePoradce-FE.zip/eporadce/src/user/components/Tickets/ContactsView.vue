<template>
  <div>
    <app-text-with-label
      :width="30"
      label="Soukromý email"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.EmailPersonal"
      :text-secondary="sec1"
    />

    <app-text-with-label
      :width="30"
      label="Mobil"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.Mobil"
      :text-secondary="sec2"
    />
  </div>
</template>

<script>
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailBankAccountView",

  mixins: [MixinTicketViewBase],

  computed: {
    sec1() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.EmailPersonal : "";
    },

    sec2() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Mobil : "";
    }
  }
};
</script>
