<template>
  <div>
    <v-slide-y-reverse-transition hide-on-leave>
      <div v-show="!agree">
        <v-alert type="warning"
          >Pokud si nepřejete přiložit scan OP/Cestovního pasu, kontaktujte prosím svého manažera.</v-alert
        >
        <p class="text-center"><v-btn color="primary" @click="agree = true">Přiložím naskenované dokumenty</v-btn></p>
      </div>
    </v-slide-y-reverse-transition>

    <v-slide-y-transition>
      <div v-show="agree">
        <v-row>
          <v-col cols="12" lg="6" class="pb-0">
            <v-text-field
              v-model="value.Firstname"
              @input="update('Firstname', $event)"
              maxlength="50"
              label="Jméno"
              :error-messages="validateField('Model.Firstname')"
            />
          </v-col>
          <v-col cols="12" lg="6" class="pb-0">
            <v-text-field
              v-model="value.Surname"
              @input="update('Surname', $event)"
              maxlength="50"
              label="Příjmení"
              :error-messages="validateField('Model.Surname')"
            />
          </v-col>
        </v-row>

        <v-checkbox
          label="Změna podpisového vzoru"
          v-model="value.SignatureTemplate"
          @input="update('SignatureTemplate', $event)"
          :error-messages="validateField('Model.SignatureTemplate')"
        >
          <template #label>
            <div>
              Změna podpisového vzoru <br /><span class="caption">
                Čestně prohlašuji, že se nyní budu podepisovat dle přiloženého podpisového vzoru a že podpisový vzor je
                čitelný a vhodný ke zpracování
              </span>
            </div>
          </template>
        </v-checkbox>

        <custom-upload
          class="mt-2 mb-8"
          button-text="Přiložit dokumenty"
          :object-type-id="objTypeTicket"
          :object-id="value.ParentId"
          v-model="value.Files"
          :readonly="true"
          :error-messages="validateField('Model.Files')"
        />

        <personal-data-change-agreement v-model="value" :validationErrors="validationErrors" v-if="!hasParent" />

        <agreement-with-scan v-model="value" :validationErrors="validationErrors" v-if="!hasParent" />
      </div>
    </v-slide-y-transition>
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import CustomUpload from "@/components/CustomUpload";
import PersonalDataChangeAgreement from "./_PersonalDataChangeAgreement.vue";
import AgreementWithScan from "./_AgreementWithScan.vue";

export default {
  name: "TicketDetailFirstnameSurname",

  components: { CustomUpload, PersonalDataChangeAgreement, AgreementWithScan },

  mixins: [MixinTicketBase],

  data() {
    return {
      agree: false
    };
  },

  watch: {
    agree(v) {
      this.change();
    }
  },

  created() {
    if (!this.hasParent) {
      this.value.Firstname = this.$store.state.userDetail.user.Firstname;
      this.value.Surname = this.$store.state.userDetail.user.Surname;
      this.value.AgreeToTerms = false;
      this.value.Files = [];
    } else {
      this.agree = true;
    }

    this.change();
  },

  methods: {
    change() {
      this.$emit("alterDialog", { successBtn: this.agree, note: this.agree });
    }
  }
};
</script>
