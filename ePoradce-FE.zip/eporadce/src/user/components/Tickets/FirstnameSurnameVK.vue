<template>
  <div>
    <v-row>
      <v-col cols="12" lg="6" class="py-0">
        <v-text-field
          v-model="value.Firstname"
          @input="update('Firstname', $event)"
          maxlength="50"
          label="Jméno"
          :error-messages="validateField('Model.Firstname')"
        />
      </v-col>
      <v-col cols="12" lg="6" class="py-0">
        <v-text-field
          v-model="value.Surname"
          @input="update('Surname', $event)"
          maxlength="50"
          label="Příjmení"
          :error-messages="validateField('Model.Surname')"
        />
      </v-col>
    </v-row>

    <v-checkbox
      class="mt-0"
      label="Změna podpisového vzoru"
      v-model="value.SignatureTemplate"
      @input="update('SignatureTemplate', $event)"
      :error-messages="validateField('Model.SignatureTemplate')"
    />

    <div class="caption font-weight-light" style="max-height: 150px; overflow-y: auto;">
      <strong>Poučení poradce při změně osobních údajů</strong><br />
      Komerční banka, a.s. (dále jen „KB“) Vás informuje, že za účelem změny Vašich osobních údajů
        (např. změna Vašeho příjmení nebo trvalého bydliště) můžete: <br />
        1. kontaktovat manažera distribuční sítě nebo zaměstnance útvaru KB Poradenství Network & Support pro ověření změny Vašich
        osobních údajů nebo<br />
        2. vložit scan občanského průkazu/cestovního dokladu do aplikace ePoradce, na základě kterého provede KB změny
        Vašich osobních údajů, a to na základě vyjádření Vašeho souhlasu zaškrtnutím políčka „Souhlasím“ s vložením
        scanu občanského průkazu/cestovního dokladu pro účely ověření změny osobních údajů. <br />
        V případě, že se rozhodnete využít 2. možnost, tj. vložit scan Vašeho občanského průkazu/cestovního dokladu do
        aplikace ePoradce, KB provede okamžité ověření změny Vašich osobních údajů podle vloženého scanu občanského
        průkazu/cestovního dokladu. KB scan Vašeho občanského průkazu po tomto ověření ihned vymaže z interního systému
        KB, tj. k uchovávání scanu občanského průkazu/cestovního dokladu ze strany KB nedochází. Informace o provedeném
        vymazání poskytnutého scanu občanského průkazu/cestovního dokladu bude zaslána na Váš e-mail).<br />
        Více informací Vám poskytne kbppodpora@kb.cz.
    </div>

    <v-checkbox
      label="Souhlasím"
      v-model="value.AgreeToTerms"
      @input="update('AgreeToTerms', $event)"
      :error-messages="validateField('Model.AgreeToTerms')"
    />

    <custom-upload
      button-text="Přiložit dokumenty"
      :object-type-id="objTypeTicket"
      v-model="value.Files"
      :error-messages="validateField('Model.Files')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import CustomUpload from "@/components/CustomUpload";

export default {
  name: "TicketDetailFirstnameSurname",

  components: { CustomUpload },

  mixins: [MixinTicketBase],

  created() {
    this.value.Firstname = this.$store.state.userDetail.user.Firstname;
    this.value.Surname = this.$store.state.userDetail.user.Surname;
    this.value.AgreeToTerms = false;
    this.value.Files = [];
  }
};
</script>
