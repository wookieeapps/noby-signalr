<template>
  <div>
    <app-text-with-label
      :width="30"
      label="Jméno"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.Firstname"
      :text-secondary="sec1"
    />

    <app-text-with-label
      :width="30"
      label="Příjmení"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.Surname"
      :text-secondary="sec2"
    />

    <app-text-with-label
      :width="30"
      label="Změna podp. vzoru"
      :dense="dense"
      :text="model.SignatureTemplate ? 'ANO' : 'NE'"
    />

    <simple-file-list :object-type-id="objTypeTicket" :object-id="id" :enable-delete="enableFileDelete" />
  </div>
</template>

<script>
import SimpleFileList from "@/components/SimpleFileList.vue";
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailFirstnameSurnameView",

  components: { SimpleFileList },

  mixins: [MixinTicketViewBase],

  computed: {
    sec1() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Firstname : "";
    },

    sec2() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Surname : "";
    }
  }
};
</script>
