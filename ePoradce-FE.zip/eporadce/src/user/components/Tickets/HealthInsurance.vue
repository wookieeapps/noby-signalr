<template>
  <div if="value">
    <v-combobox
      clearable
      label="Zdravotní pojišťovna"
      item-text="Text"
      item-value="Code"
      :return-object="false"
      :items="$lists.shared.healthInsurances || []"
      v-model="value.HealthInsuranceCode"
      @input="update('HealthInsuranceCode', $event)"
      :error-messages="validateField('Model.HealthInsuranceCode')"
    />

  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";

export default {
  name: "TicketDetailHealthInsurance",

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.value.HealthInsuranceCode = this.$store.state.userDetail.user.HealthInsuranceCode;
    }
  },

  async mounted() {
    await this.$lists.fetch(["HealthInsurances"]);
  }
};
</script>
