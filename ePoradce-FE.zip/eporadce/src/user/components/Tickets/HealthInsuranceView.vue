<template>
  <div>
    <app-text-with-label
      :width="20"
      label="Kód zdravotní pojišťovny"
      de:dense="dense"
      nse
      compare-text
      :hide-secondary="!showComparison"
      :text="model.HealthInsuranceCode"
      :text-secondary="sec1"
    />



  </div>
</template>

<script>

import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailHealthInsuranceView",

  mixins: [MixinTicketViewBase],

  computed: {
    sec1() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Title : "";
    },

    sec2() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Title2 : "";
    }
  }
};
</script>
