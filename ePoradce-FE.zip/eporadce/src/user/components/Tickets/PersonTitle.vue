<template>
  <div if="value">
    <v-combobox
      clearable
      label="Titul"
      item-text="Text"
      item-value="Text"
      :return-object="false"
      :items="$lists.shared.titles || []"
      v-model="value.Title"
      @input="update('Title', $event)"
      :error-messages="validateField('Model.Title')"
    />

    <v-combobox
      clearable
      label="Titul za"
      item-text="Text"
      item-value="Text"
      :return-object="false"
      :items="$lists.shared.titles2 || []"
      v-model="value.Title2"
      @input="update('Title2', $event)"
      :error-messages="validateField('Model.Title2')"
    />

    <v-alert border="left" colored-border type="info" elevation="2" class="caption mb-7" dense>
      Při více titulech před/za jménem vyberte předdefinovaný titul z nabídkovače a další titul/y doplňte.
    </v-alert>

    <v-checkbox
      v-show="!hasParent"
      label="Čestně prohlašuji, že jsem pořídil scan z originálu dokladu a doklad je čitelný a vhodný ke zpracování"
      v-model="value.AgreeToTerms"
      hide-details
      @input="update('AgreeToTerms', $event)"
      :error-messages="validateField('Model.AgreeToTerms')"
    />

    <custom-upload
      class="mt-4"
      button-text="Přiložit Doklad o dosaženém vzdělání"
      :object-type-id="objTypeTicket"
      :object-id="value.ParentId"
      v-model="value.Files"
      :readonly="true"
      :error-messages="validateField('Model.Files')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import CustomUpload from "@/components/CustomUpload";

export default {
  name: "TicketDetailPersonTitle",

  components: { CustomUpload },

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.value.Title = this.$store.state.userDetail.user.Title;
      this.value.Title2 = this.$store.state.userDetail.user.Title2;
      this.value.AgreeToTerms = false;
      this.value.Files = [];
    }
  },

  async mounted() {
    await this.$lists.fetch(["Titles", "Titles2"]);
  }
};
</script>
