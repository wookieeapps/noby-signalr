<template>
  <div>
    <app-text-with-label
      :width="20"
      label="Titul"
      de:dense="dense"
      nse
      compare-text
      :hide-secondary="!showComparison"
      :text="model.Title"
      :text-secondary="sec1"
    />

    <app-text-with-label
      :width="20"
      label="Titul za"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.Title2"
      :text-secondary="sec2"
    />

    <simple-file-list :object-type-id="objTypeTicket" :object-id="id" :enable-delete="enableFileDelete" />
  </div>
</template>

<script>
import SimpleFileList from "@/components/SimpleFileList.vue";
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailPersonTitleView",

  components: { SimpleFileList },

  mixins: [MixinTicketViewBase],

  computed: {
    sec1() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Title : "";
    },

    sec2() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.Title2 : "";
    }
  }
};
</script>
