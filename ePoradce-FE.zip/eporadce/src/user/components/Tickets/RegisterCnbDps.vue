<template>
  <div if="value">
    <v-checkbox
      v-show="!hasParent"
      v-model="value.AgreeToTermsCnb"
      hide-details
      @input="update('AgreeToTermsCnb', $event)"
      :error-messages="validateField('Model.AgreeToTermsCnb')"
    >
      <template v-slot:label>
        <div>
          Zaškrtnutím tohoto políčka žádám KB o zajištění mé registrace na ČNB jako vázaného zástupce KB pro doplňkové
          penzijní spoření a
          <a @click.stop :href="linkUrl" target="_blank">čestně prohlašuji, že jsem důvěryhodný</a>, odborně způsobilý a
          splňuji podmínky dle zákona č. 427/2011 Sb., o doplňkovém penzijním spoření a že KB evidované údaje jsou
          aktuální, pravdivé, úplné.
        </div>
      </template>
    </v-checkbox>

    <v-checkbox
      v-show="!hasParent"
      label="Čestně prohlašuji, že jsem pořídil scan z originálu dokladu a doklad je čitelný a vhodný ke zpracování"
      v-model="value.AgreeToTerms"
      hide-details
      @input="update('AgreeToTerms', $event)"
      :error-messages="validateField('Model.AgreeToTerms')"
    />

    <custom-upload
      class="mt-8"
      button-text="Přiložit dokumenty"
      :object-type-id="objTypeTicket"
      :object-id="value.ParentId"
      v-model="value.Files"
      :readonly="true"
      :error-messages="validateField('Model.Files')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import CustomUpload from "@/components/CustomUpload";

export default {
  name: "TicketDetailRegisterCnbDps",

  components: { CustomUpload },

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.value.AgreeToTermsCnb = false;
      this.value.AgreeToTerms = false;
      this.value.Files = [];
    }
  },

  computed: {
    linkUrl() {
      return process.env.VUE_APP_FRONTEND_BASE_PATH + "TicketCnbAgreement3.pdf";
    }
  }
};
</script>
