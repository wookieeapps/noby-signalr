<template>
  <div>
    <simple-file-list :object-type-id="objTypeTicket" :object-id="id" :enable-delete="enableFileDelete" />
  </div>
</template>

<script>
import SimpleFileList from "@/components/SimpleFileList.vue";
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailRegisterCnbDpsView",

  components: { SimpleFileList },

  mixins: [MixinTicketViewBase]
};
</script>
