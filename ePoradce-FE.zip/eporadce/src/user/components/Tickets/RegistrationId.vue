<template>
  <div>
    <v-text-field
      v-model="value.IC"
      @input="update('IC', $event)"
      maxlength="10"
      label="IČ"
      :error-messages="validateField('Model.IC')"
    />

    <v-checkbox
      v-show="!hasParent"
      label="Čestně prohlašuji, že jsem pořídil scan z originálu dokladu a doklad je čitelný a vhodný ke zpracování"
      v-model="value.AgreeToTerms"
      hide-details
      @input="update('AgreeToTerms', $event)"
      :error-messages="validateField('Model.AgreeToTerms')"
    />

    <custom-upload
      class="mt-4"
      button-text="Přiložit výpis z Živnostenského rejstříku"
      :object-type-id="objTypeTicket"
      :object-id="value.ParentId"
      v-model="value.Files"
      :readonly="true"
      :error-messages="validateField('Model.Files')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import CustomUpload from "@/components/CustomUpload";

export default {
  name: "TicketDetailRegistrationId",

  components: { CustomUpload },

  mixins: [MixinTicketBase],

  mounted() {
    if (!this.hasParent) {
      this.value.IC = this.$store.state.userDetail.user.IC;
      this.value.AgreeToTerms = false;
      this.value.Files = [];
    }
  }
};
</script>
