<template>
  <div>
    <app-text-with-label
      :width="20"
      label="IČ"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.IC"
      :text-secondary="sec1"
    />

    <simple-file-list :object-type-id="objTypeTicket" :object-id="id" :enable-delete="enableFileDelete" />
  </div>
</template>

<script>
import SimpleFileList from "@/components/SimpleFileList.vue";
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailRegistrationIdView",

  components: { SimpleFileList },

  mixins: [MixinTicketViewBase],

  computed: {
    sec1() {
      return this.$store.state.userDetail.user ? this.$store.state.userDetail.user.IC : "";
    }
  }
};
</script>
