<template>
  <div>
    <v-text-field
      label="Číslo Signpadu"
      maxlength="30"
      v-model="value.RegNo"
      @input="update('RegNo', $event)"
      :error-messages="validateField('Model.RegNo')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";

export default {
  name: "TicketDetailSignpadOut",

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.value.RegNo = "";
    }
  }
};
</script>
