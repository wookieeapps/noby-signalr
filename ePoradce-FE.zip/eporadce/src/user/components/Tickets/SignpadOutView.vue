<template>
  <div>
    <app-text-with-label :width="30" label="Číslo Signpadu" :dense="dense" :text="model.RegNo" />

    <div class="red--text caption mt-2">
      Potvrzuji, že jsem převzal od MP uvedené podepisovací zařízení - signpad a přebírám odpovědnost za správné
      užívání, bezpečnou úschovu a zamezení zneužití zařízení. V případě ztráty nebo odcizení jsem povinen neprodleně
      tuto skutečnost nahlásit na email operatori@mpss.cz a personalistika@mpss.cz. Pokud dojde k ukončení spolupráce s
      MP, jsem povinen zabezpečit bezodkladné vrácení podepisovacího zařízení – signpadu MP.
    </div>
  </div>
</template>

<script>
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailSignpadOutView",

  mixins: [MixinTicketViewBase]
};
</script>
