<template>
  <div>
    <v-text-field
      label="Číslo Signpadu"
      maxlength="30"
      v-model="value.RegNo"
      @input="update('RegNo', $event)"
      :error-messages="validateField('Model.RegNo')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";

export default {
  name: "TicketDetailSignpadReturn",

  mixins: [MixinTicketBase],

  async created() {
    if (!this.hasParent) {
      await this.$store.dispatch("userDetail/initDetail");

      this.value.RegNo = this.$store.state.userDetail.detail.SignpadRegNo;
      this.value.__ob__.dep.notify();
    }
  }
};
</script>
