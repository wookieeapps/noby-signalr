<template>
  <div>
    <app-text-with-label :width="30" label="Číslo Signpadu" :dense="dense" :text="model.RegNo" />
  </div>
</template>

<script>
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailSignpadReturnView",

  mixins: [MixinTicketViewBase]
};
</script>
