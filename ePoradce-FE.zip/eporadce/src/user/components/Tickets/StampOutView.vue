<template>
  <div>
    <app-text-with-label :width="30" label="Číslo razítka" :dense="dense" :text="model.RegNo" />

    <div class="red--text caption mt-2">
      Potvrzuji, že jsem převzal od MP uvedené ověřovací razítko k ověřování totožnosti a pravosti podpisů klientů a k
      ověřování listin a že přebírám odpovědnost za správné užívání, bezpečnou úschovu a zamezení zneužití razítka. V
      případě ztráty jsem povinen neprodleně tuto skutečnost nahlásit týmu Smluvní vztahy MP. V případě ukončení
      spolupráce s MP jsem povinen ho bez odkladu protokolárně vrátit MP.
    </div>
  </div>
</template>

<script>
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailStampOutView",

  mixins: [MixinTicketViewBase]
};
</script>
