<template>
  <div>
    <v-text-field
      label="Číslo ověřovacího razítka"
      maxlength="30"
      v-model="value.RegNo"
      @input="update('RegNo', $event)"
      :error-messages="validateField('Model.RegNo')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";

export default {
  name: "TicketDetailStampReturn",

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.value.RegNo = this.$store.state.userDetail.user.VerificationStamp;
      this.value.__ob__.dep.notify();
    }
  }
};
</script>
