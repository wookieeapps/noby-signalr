<template>
  <div if="value">
    <v-select
      label="Datum změny"
      :items="dates"
      v-model="value.Date"
      @input="update('Date', $event)"
      :error-messages="validateField('Model.Date')"
    />

    <v-select
      label="Pozice"
      item-text="Name"
      item-value="Code"
      clearable
      :items="positions"
      v-model="value.PositionCode"
      @input="onPositionCodeChange"
      :error-messages="validateField('Model.PositionCode')"
    />

    <!-- naseptavac uzemni zarazeni -->
    <v-list two-line class="pt-0">
      <v-list-item class="pl-0">
        <v-list-item-avatar class="text-h6">1.</v-list-item-avatar>
        <v-list-item-content class="pb-0">
          <div class="d-flex">
            <v-scroll-x-transition hide-on-leave>
              <v-autocomplete
                v-show="!isUserGroupMissing"
                label="Územní zařazení"
                item-value="Id"
                no-filter
                :cache-items="false"
                :search-input.sync="userGroupSearch"
                :items="userGroupItems"
                :loading="userGroupLoading"
                v-model="value.UserGroups[0]"
                return-object
                :error-messages="validateField('Model.UserGroups[0].Name')"
              >
                <template #no-data>
                  <v-list-item>
                    <v-list-item-title>Název území...</v-list-item-title>
                  </v-list-item>
                </template>

                <template #selection="{ item }">
                  <div class="text-no-wrap d-inline-block text-truncate">{{ item.Code }} {{ item.Name }}</div>
                </template>

                <template #item="{ item }">
                  <v-list-item-content>{{ item.Code }} {{ item.Name }}</v-list-item-content>
                </template>
              </v-autocomplete>
            </v-scroll-x-transition>
            <v-scroll-x-reverse-transition hide-on-leave>
              <v-text-field
                v-show="isUserGroupMissing"
                label="Územní zařazení - ručně"
                maxlength="50"
                v-model="missingUserGroup"
                :error-messages="validateField('Model.UserGroups[0].Name')"
              />
            </v-scroll-x-reverse-transition>
            <div style="width: 20px"></div>
            <v-checkbox hide-details label="Neexistuje" v-model="isUserGroupMissing" @change="switchUsergroupMissing" />
          </div>
        </v-list-item-content>
      </v-list-item>

      <!-- seznam dalsich usergroups -->
      <v-list-item v-for="(grp, index) in value.UserGroups" :key="index" class="pl-0" v-if="index > 0">
        <v-list-item-avatar class="text-h6">{{ index + 1 }}.</v-list-item-avatar>
        <v-list-item-content>
          <v-list-item-title v-text="grp.Name"></v-list-item-title>
          <v-list-item-subtitle v-text="grp.Code || 'Neexistující'"></v-list-item-subtitle>
        </v-list-item-content>
        <v-list-item-action>
          <v-btn fab color="red" text @click="deleteUserGroup(index)"><v-icon>delete</v-icon></v-btn>
        </v-list-item-action>
      </v-list-item>
    </v-list>

    <!-- btn pridat dalsi userGroup -->
    <div>
      <v-btn tile small @click="addUserGroup"><v-icon small>add</v-icon>Přidat další území</v-btn>
    </div>
  </div>
</template>

<script>
import { ApplicationIdTypes, Helpers, DateHelpers } from "@mpss/eporadce-common";
import { userGroupsApi, commonListsApi } from "../../../code/apiServices";
import MixinTicketBase from "../../mixins/MixinTicketBase";

const createDates = () => {
  const arr = [];
  for (let i = 1; i <= 3; i++) {
    const d = DateHelpers.startOfMonth(DateHelpers.addMonths(new Date(), i));
    arr.push(DateHelpers.format(d));
  }
  return arr;
};

export default {
  name: "TicketDetailUserGroupChange",

  mixins: [MixinTicketBase],

  data() {
    return {
      positions: [],
      userGroupSearch: null,
      userGroupLoading: false,
      userGroupItems: [],
      dates: createDates(),
      isUserGroupMissing: false,
      userGroupLastText: "" // zasranej workaround aby se nespoustelo hledani pri nacteni stranky. fuck vuetify
    };
  },

  created() {
    if (!this.hasParent) {
      this.value.PositionCode = null;
      this.value.PositionName = null;
      this.value.Date = null;
      this.value.UserGroups = [{ Id: null, Code: null, Name: null }];
    }
  },

  async mounted() {
    // dostupne pozice
    this.positions = await commonListsApi.GetPositions(this.$store.state.userDetail.user.CPM.substring(0, 3));

    // prednastavit pozici
    if (this.$store.state.userDetail.user.PositionCode) {
      this.value.PositionCode = this.$store.state.userDetail.user.PositionCode;
      this.value.PositionName = this.positions.find(
        (t) => t.Code == this.$store.state.userDetail.user.PositionCode
      ).Name;
    }

    // prednastavit uzemni prislusnost
    const grp = await userGroupsApi.Get(this.$store.state.userDetail.user.UserGroupId);
    this.userGroupItems = [grp];
    this.value.UserGroups = [{ Id: grp.Id, Code: grp.Code, Name: grp.Name }];
  },

  watch: {
    userGroupSearch(val) {
      val && this.searchUserGroup(val);
    }
  },

  computed: {
    missingUserGroup: {
      get() {
        return this.value.UserGroups[0] ? this.value.UserGroups[0].Name : "";
      },
      set(val) {
        this.value.UserGroups[0].Name = val;
        this.value.__ob__.dep.notify();
      }
    }
  },

  methods: {
    // zmena position code
    onPositionCodeChange(val) {
      const name = this.positions.find((t) => t.Code == val).Name;
      this.value.PositionName = name;

      this.update("PositionCode", val);
      this.update("PositionName", name);
    },

    // nasteptavac userGroups
    searchUserGroup(term) {
      this.userGroupLoading = true;

      Helpers.debounce((term) => {
        if (term != this.userGroupSearch) return;
        userGroupsApi.Search(term, ApplicationIdTypes.Hiring).then((t) => {
          this.userGroupLoading = false;
          this.userGroupItems = t;
        });
      }, 400)(term);
    },

    // odstranit userGroup
    deleteUserGroup(index) {
      this.$delete(this.value.UserGroups, index);
      this.value.__ob__.dep.notify();
    },

    // pridat dalsi userGroup
    addUserGroup() {
      // zkontrolovat zda je vybrany nejaky uzemni celek
      if (
        !this.value.UserGroups[0] ||
        (this.isUserGroupMissing && !this.value.UserGroups[0].Name) ||
        (!this.isUserGroupMissing && !this.value.UserGroups[0].Id)
      ) {
        this.$toast.error("Není zadaný žádný územní celek");
        return;
      }

      // zkopirovat hodnoty naseptavace do listu
      this.value.UserGroups.push({
        Code: this.value.UserGroups[0].Code,
        Name: this.value.UserGroups[0].Name,
        Id: this.value.UserGroups[0].Id
      });

      // reset naseptavace
      this.isUserGroupMissing = false;
      this.clearAutocomplete();
    },

    switchUsergroupMissing() {
      this.value.UserGroups = [
        {
          Code: "",
          Name: "",
          Id: null
        }
      ];
      this.value.__ob__.dep.notify();
      this.clearAutocomplete();
    },

    clearAutocomplete() {
      this.userGroupItems = [];
    }
  }
};
</script>
