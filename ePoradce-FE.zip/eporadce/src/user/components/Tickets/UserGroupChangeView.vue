<template>
  <div>
    <app-text-with-label label="Datum změny" :dense="dense" :text="model.Date" />

    <app-text-with-label label="Pozice" :dense="dense">
      <template>{{ model.PositionCode }} - {{ model.PositionName }}</template>
    </app-text-with-label>

    <app-text-with-label
      :label="`Územní zařazení #${index + 1}`"
      :dense="dense"
      v-for="(grp, index) in model.UserGroups"
      :key="index"
    >
      <template>{{ grp.Id ? grp.Code : "neexistuje" }} - {{ grp.Name }}</template>
    </app-text-with-label>
  </div>
</template>

<script>
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailUserGroupChangeView",

  mixins: [MixinTicketViewBase]
};
</script>
