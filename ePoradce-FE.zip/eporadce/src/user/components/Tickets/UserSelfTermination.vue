<template>
  <div if="value">
    <v-select
      label="Důvod ukončení"
      item-text="Text"
      item-value="Id"
      :return-object="false"
      :items="terminationReasons"
      v-model="value.TerminationReason"
      @input="update('TerminationReason', $event)"
      :error-messages="validateField('Model.TerminationReason')"
    />

    <app-date-picker
      label="Datum ukončení"
      :datetime="value.TerminationDate"
      @input="update('TerminationDate', $event)"
      :error-messages="validateField('Model.TerminationDate')"
    />

    <v-checkbox
      label="Odeslat notifikaci na příslušného managera"
      v-model="value.SendEmailNotification"
      hide-details
      @input="update('SendEmailNotification', $event)"
      :error-messages="validateField('Model.SendEmailNotification')"
    />

    <custom-upload
      class="mt-4"
      button-text="Přiložit podklady k ukončení"
      :object-type-id="objTypeTicket"
      :object-id="value.ParentId"
      v-model="value.Files"
      :readonly="true"
      :error-messages="validateField('Model.Files')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import CustomUpload from "@/components/CustomUpload";

export default {
  name: "TicketDetailUserSelfTermination",

  components: { CustomUpload },

  mixins: [MixinTicketBase],

  data() {
    return {
      terminationReasons: [
        { Id: 1, Text: "Odstoupení FP" },
        { Id: 2, Text: "Výpovědi FP" }
      ]
    };
  },

  created() {
    if (!this.hasParent) {
      this.value.TerminationType = null;
      this.value.TerminationReason = null;
      this.value.SendEmailNotification = true;
      this.value.Files = [];
    }
  },

  watch: {
    "value.TerminationReason": function (val) {
      if (!this.terminationReasons) return;
      const item = this.terminationReasons.find((t) => t.Id == val);
      if (item) this.update("TerminationReasonText", item.Text);
    }
  }
};
</script>
