<template>
  <div>
    <app-text-with-label label="Důvod ukončení" :dense="dense" :text="model.TerminationReasonText" />

    <app-text-with-label label="Datum ukončení" :dense="dense" :text="model.TerminationDate | parseDate" />

    <app-text-with-label
      label="Odeslat notifikaci na příslušného managera"
      :dense="dense"
      :text="model.SendEmailNotification ? 'ANO' : 'NE'"
    />

    <simple-file-list :object-type-id="objTypeTicket" :object-id="id" :enable-delete="enableFileDelete" />
  </div>
</template>

<script>
import SimpleFileList from "@/components/SimpleFileList.vue";
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailUserSelfTerminationView",

  components: { SimpleFileList },

  mixins: [MixinTicketViewBase]
};
</script>
