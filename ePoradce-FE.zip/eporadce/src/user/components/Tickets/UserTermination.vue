<template>
  <div if="value">
    <v-select
      label="Způsob ukončení"
      :items="terminationTypes"
      v-model="value.TerminationType"
      @input="update('TerminationType', $event)"
      :error-messages="validateField('Model.TerminationType')"
    />

    <v-select
      label="Důvod ukončení"
      item-text="Text"
      item-value="Id"
      :return-object="false"
      :items="$lists.ticketing.terminationReasons || []"
      v-model="value.TerminationReason"
      @input="update('TerminationReason', $event)"
      :error-messages="validateField('Model.TerminationReason')"
    />

    <custom-upload
      class="mt-4"
      button-text="Přiložit podklady k ukončení"
      :object-type-id="objTypeTicket"
      :object-id="value.ParentId"
      v-model="value.Files"
      :readonly="true"
      :error-messages="validateField('Model.Files')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import CustomUpload from "@/components/CustomUpload";

export default {
  name: "TicketDetailUserTermination",

  components: { CustomUpload },

  mixins: [MixinTicketBase],

  data() {
    return {
      terminationTypes: ["Výpověď", "Odstoupení"]
    };
  },

  created() {
    if (!this.hasParent) {
      this.value.TerminationType = null;
      this.value.TerminationReason = null;
      this.value.Files = [];
    }
  },

  async mounted() {
    await this.$lists.fetch("ticketing", ["TerminationReasons"]);
  },

  watch: {
    "value.TerminationReason": function (val) {
      if (!this.$lists.ticketing.terminationReasons) return;
      const item = this.$lists.ticketing.terminationReasons.find((t) => t.Id == val);
      if (item) this.update("TerminationReasonText", item.Text);
    }
  }
};
</script>
