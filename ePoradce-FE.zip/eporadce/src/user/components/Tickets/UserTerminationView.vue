<template>
  <div>
    <app-text-with-label label="Způsob ukončení" :dense="dense" :text="model.TerminationType" />

    <app-text-with-label label="Důvod ukončení" :dense="dense" :text="model.TerminationReasonText" />

    <simple-file-list :object-type-id="objTypeTicket" :object-id="id" :enable-delete="enableFileDelete" />
  </div>
</template>

<script>
import SimpleFileList from "@/components/SimpleFileList.vue";
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailUserTerminationView",

  components: { SimpleFileList },

  mixins: [MixinTicketViewBase]
};
</script>
