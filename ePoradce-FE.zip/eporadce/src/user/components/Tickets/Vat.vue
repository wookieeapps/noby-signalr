<template>
  <div>
    <v-radio-group
      row
      v-model="value.IsVatRegistered"
      :mandatory="true"
      :error-messages="validateField('Model.IsVatRegistered')"
    >
      <v-radio label="JSEM plátcem DPH" :value="true" />
      <v-radio label="NEJSEM plátcem DPH" :value="false" />
    </v-radio-group>

    <v-checkbox
      label="Čestně prohlašuji, že jsem pořídil scan z originálu dokladu a doklad je čitelný a vhodný ke zpracování"
      v-model="value.AgreeToTerms"
      hide-details
      @input="update('AgreeToTerms', $event)"
      :error-messages="validateField('Model.AgreeToTerms')"
    />

    <custom-upload
      class="mt-4"
      button-text="Přiložit Výpis zaevidování plátce DPH z ARES"
      :object-type-id="objTypeTicket"
      v-model="value.Files"
      :error-messages="validateField('Model.Files')"
    />
  </div>
</template>

<script>
import MixinTicketBase from "../../mixins/MixinTicketBase";
import CustomUpload from "@/components/CustomUpload";

export default {
  name: "TicketDetailVat",

  components: { CustomUpload },

  mixins: [MixinTicketBase],

  created() {
    if (!this.hasParent) {
      this.value.IsVatRegistered = this.$store.state.userDetail.user.IsVatRegistered;
      this.value.AgreeToTerms = false;
      this.value.Files = [];
    }
  }
};
</script>
