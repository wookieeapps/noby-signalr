<template>
  <div>
    <app-text-with-label
      :width="20"
      label="Plátce DPH"
      :dense="dense"
      compare-text
      :hide-secondary="!showComparison"
      :text="model.IsVatRegistered ? 'ANO' : 'NE'"
      :text-secondary="$store.state.userDetail.user.IsVatRegistered ? 'ANO' : 'NE'"
    />

    <simple-file-list :object-type-id="objTypeTicket" :object-id="id" :enable-delete="enableFileDelete" />
  </div>
</template>

<script>
import SimpleFileList from "@/components/SimpleFileList.vue";
import MixinTicketViewBase from "../../mixins/MixinTicketViewBase";

export default {
  name: "TicketDetailVatView",

  components: { SimpleFileList },

  mixins: [MixinTicketViewBase]
};
</script>
