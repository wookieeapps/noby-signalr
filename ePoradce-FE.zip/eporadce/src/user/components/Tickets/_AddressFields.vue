<template>
  <div>
    <v-text-field
      label="Ulice"
      maxlength="50"
      v-model="value.Street"
      @input="update('Street', $event)"
      :error-messages="validateField('Model.Street')"
    />

    <div class="d-flex">
      <v-text-field
        label="PSČ"
        v-model="value.Zip"
        @input="update('Zip', $event)"
        :error-messages="validateField('Model.Zip')"
        style="max-width: 100px;"
        maxlength="5"
      />
      <div style="width: 20px;"></div>
      <v-combobox
        label="Město"
        maxlength="50"
        v-model="value.City"
        @input="update('City', $event)"
        :error-messages="validateField('Model.City')"
        :loading="citiLoading"
        :items="cityItems"
      />
    </div>
  </div>
</template>

<script>
import { MixinUpdateModel, MixinValidateField } from "@mpss/eporadce-common-vue";
import { placesApi } from "@/code/apiServices";

export default {
  name: "AddressFields",

  mixins: [MixinValidateField, MixinUpdateModel],

  props: ["value", "validationErrors"],

  data() {
    return {
      cityItems: [],
      citiLoading: false
    };
  },

  watch: {
    "value.Zip": function (value) {
      value && this.getPlaces(value);
    }
  },

  methods: {
    getPlaces(value) {
      if (/^\d{5}$/.test(value)) {
        this.citiLoading = true;

        placesApi.GetPlaceByZip(value).then((t) => {
          this.cityItems = t;
          this.citiLoading = false;
        });
      } else this.cityItems = [];
    }
  }
};
</script>
