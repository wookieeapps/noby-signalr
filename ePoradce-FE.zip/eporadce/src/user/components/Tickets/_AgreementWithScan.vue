<template>
  <div>
    <v-slide-y-reverse-transition>
      <div class="caption font-weight-light mt-8" style="max-height: 130px; overflow-y: auto;" v-show="showTerms">
        KB neuchovává scan Vámi nahraného dokladu a ihned po ověření změny osobních údajů na základě nahraného scanu, KB
        vymaže tento scan z interního systému KB. Tento souhlas je vyžadován podle § 39c zákona č. 269/2021 Sb.,
        o občanských průkazech, ve znění pozdějších předpisů, resp. podle § 2 odst. 3 zákona č. 329/1999 Sb., o
        cestovních dokladech, ve znění pozdějších předpisů, a v souladu s nařízením Evropského parlamentu a Rady (EU) č.
        2016/679 ze dne 27. dubna 2016 o ochraně fyzických osob v souvislosti se zpracováním osobních údajů a o volném
        pohybu těchto údajů a o zrušení směrnice 95/46/ES (dále jen „GDPR“). Udělený souhlas můžete kdykoli odvolat.
        Souhlas můžete odvolat prostřednictvím e-mailové zprávy na: kbppodpora@kb.cz. V případě odvolání Vašeho
        souhlasu berete na vědomí, že není možné ověřit změnu Vašich osobních údajů prostřednictvím aplikace ePoradce,
        ale pro změnu Vašich osobních údajů můžete kontaktovat manažera distribuční sítě nebo zaměstnance útvaru KB Poradenství Network & Support. 
      </div>
    </v-slide-y-reverse-transition>

    <v-checkbox
      dense
      class="mt-1"
      hide-details
      label="„Souhlasím“ a nahráním scanu občanského průkazu/cestovního dokladu"
      v-model="value.AgreeToScan"
      @input="update('AgreeToScan', $event)"
      :error-messages="validateField('Model.AgreeToScan')"
    >
      <template #label>
        <div class="body-2">
          Zaškrtnutím tohoto políčka „Souhlasím“ a nahráním scanu občanského průkazu/cestovního dokladu do aplikace
          ePoradce
          <a @click.stop.prevent="showTerms = !showTerms"
            >uděluji KB výslovný souhlas s tím, že KB na základě tohoto scanu ověří změnu mých osobních údajů</a
          >.
        </div>
      </template>
    </v-checkbox>
  </div>
</template>

<script>
import { MixinUpdateModel, MixinValidateField } from "@mpss/eporadce-common-vue";

export default {
  name: "AgreementWithScan",

  mixins: [MixinValidateField, MixinUpdateModel],

  props: ["value", "validationErrors"],

  data() {
    return {
      showTerms: false
    };
  }
};
</script>
