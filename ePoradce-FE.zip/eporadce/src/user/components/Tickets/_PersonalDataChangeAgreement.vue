<template>
  <div>
    <v-slide-y-reverse-transition>
      <div class="caption font-weight-light mt-8" style="max-height: 130px; overflow-y: auto;" v-show="showTerms">
        Komerční banka, a.s. (dále jen „KB“) Vás informuje, že za účelem změny Vašich osobních údajů
        (např. změna Vašeho příjmení nebo trvalého bydliště) můžete: <br />
        1. kontaktovat manažera distribuční sítě nebo zaměstnance útvaru KB Poradenství Network & Support pro ověření změny Vašich
        osobních údajů nebo<br />
        2. vložit scan občanského průkazu/cestovního dokladu do aplikace ePoradce, na základě kterého provede KB změny
        Vašich osobních údajů, a to na základě vyjádření Vašeho souhlasu zaškrtnutím políčka „Souhlasím“ s vložením
        scanu občanského průkazu/cestovního dokladu pro účely ověření změny osobních údajů. <br />
        V případě, že se rozhodnete využít 2. možnost, tj. vložit scan Vašeho občanského průkazu/cestovního dokladu do
        aplikace ePoradce, KB provede okamžité ověření změny Vašich osobních údajů podle vloženého scanu občanského
        průkazu/cestovního dokladu. KB scan Vašeho občanského průkazu po tomto ověření ihned vymaže z interního systému
        KB, tj. k uchovávání scanu občanského průkazu/cestovního dokladu ze strany KB nedochází. Informace o provedeném
        vymazání poskytnutého scanu občanského průkazu/cestovního dokladu bude zaslána na Váš e-mail).<br />
        Více informací Vám poskytne kbppodpora@kb.cz.
      </div>
    </v-slide-y-reverse-transition>

    <v-checkbox
      dense
      class="mt-1"
      label="Souhlasím"
      hide-details
      v-model="value.AgreeToTerms"
      @input="update('AgreeToTerms', $event)"
      :error-messages="validateField('Model.AgreeToTerms')"
    >
      <template #label>
        <div class="body-2 font-weight-bold">
          Přečetl/a jsem si
          <a @click.stop.prevent="showTerms = !showTerms">Poučení poradce při změně osobních údajů</a>
        </div>
      </template>
    </v-checkbox>
  </div>
</template>

<script>
import { MixinUpdateModel, MixinValidateField } from "@mpss/eporadce-common-vue";

export default {
  name: "PersonalDataChangeAgreement",

  mixins: [MixinValidateField, MixinUpdateModel],

  props: ["value", "validationErrors"],

  data() {
    return {
      showTerms: false
    };
  }
};
</script>
