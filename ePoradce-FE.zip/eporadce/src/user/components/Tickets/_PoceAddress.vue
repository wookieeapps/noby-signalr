<template>
  <v-list-item-content>
    <v-autocomplete
      label="Adresa POCE"
      item-value="Id"
      item-text="Street"
      hide-details
      no-filter
      :cache-items="false"
      clearable
      :search-input.sync="pocesearch"
      :items="poceitems"
      :loading="poceloading"
      :value="item.Id"
      @input="placeChanged"
      return-object
      :error-messages="validateField(`Items[${index}].Id`)"
    >
      <template v-slot:no-data>
        <v-list-item>
          <v-list-item-title>Název ulice, město...</v-list-item-title>
        </v-list-item>
      </template>
      <template v-slot:item="{ item }">
        <v-list-item-content>
          <v-list-item-title v-text="item.Street"></v-list-item-title>
          <v-list-item-subtitle>{{ item.City }} {{ item.Zip }}</v-list-item-subtitle>
        </v-list-item-content>
      </template>
    </v-autocomplete>

    <!-- typ POCE -->
    <v-select
      :items="poceTypes"
      label="Typ POCE"
      :value="item.Type"
      @input="typeChanged"
      :error-messages="validateField(`Items[${index}].Type`)"
    />
  </v-list-item-content>
</template>

<script>
import { MixinValidateField } from "@mpss/eporadce-common-vue";
import { Helpers } from "@mpss/eporadce-common";
import { placesApi } from "../../../code/apiServices";

export default {
  name: "TicketPoceAddress",

  mixins: [MixinValidateField],

  props: ["item", "index", "validationErrors"],

  data() {
    return {
      poceTypes: [
        { value: 1, text: "POCE 1 (Příslušnost poradce k poradenskému centru)" },
        { value: 2, text: "POCE 2 (Poradenské centrum pro zasílání klientské dokumentace)" }
      ],
      pocesearch: null,
      poceloading: false,
      poceitems: []
    };
  },

  async created() {
    if (this.item.Id) {
      const poce = await placesApi.GetPoCeById(this.item.Id);
      this.poceitems = [poce];
    }
  },

  watch: {
    pocesearch(val) {
      val && this.searchPoce(val);
    }
  },

  methods: {
    placeChanged(newModel) {
      this.item.Id = newModel ? newModel.Id : null;
      this.item.City = newModel ? newModel.City : null;
      this.item.Zip = newModel ? newModel.Zip : null;
      this.item.Street = newModel ? newModel.Street : null;
    },

    typeChanged(newType) {
      this.item.Type = newType;
    },

    searchPoce(term) {
      this.poceloading = true;

      Helpers.debounce((term) => {
        if (term != this.pocesearch) return;

        placesApi.GetPoCeByTerm(term).then((t) => {
          this.poceitems = t;
          this.poceloading = false;
        });
      }, 400)(term);
    }
  }
};
</script>
