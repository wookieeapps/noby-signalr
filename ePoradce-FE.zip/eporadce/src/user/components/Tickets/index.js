import FirstnameSurname from "./FirstnameSurnameView.vue";
import Address from "./AddressView.vue";
import AddressContact from "./AddressContactView.vue";
import PersonTitle from "./PersonTitleView.vue";
import BankAccount from "./BankAccountView.vue";
import Contacts from "./ContactsView.vue";
import RegistrationId from "./RegistrationIdView.vue";
import Vat from "./VatView.vue";
import AddFiles from "./AddFilesView.vue";
import ChangePoce from "./ChangePoceView.vue";
import RegisterCnbSu from "./RegisterCnbSuView.vue";
import RegisterCnbDps from "./RegisterCnbDpsView.vue";
import RegisterCnbPojisteni from "./RegisterCnbPojisteniView.vue";
import RegisterCnbInvestice from "./RegisterCnbInvesticeView.vue";
import UserTermination from "./UserTerminationView.vue";
import UserSelfTermination from "./UserSelfTerminationView.vue";
import UserGroupChange from "./UserGroupChangeView.vue";
import SignpadOut from "./SignpadOutView.vue";
import SignpadReturn from "./SignpadReturnView.vue";
import StampOut from "./StampOutView.vue";
import StampReturn from "./StampReturnView.vue";
import HealthInsurance from "./HealthInsuranceView.vue";


export default {
  FirstnameSurname,
  Address,
  AddressContact,
  PersonTitle,
  UserGroupChange,
  UserTermination,
  UserSelfTermination,
  RegisterCnbInvestice,
  RegisterCnbPojisteni,
  RegisterCnbDps,
  ChangePoce,
  RegisterCnbSu,
  AddFiles,
  Vat,
  RegistrationId,
  RegistrationId,
  BankAccount,
  Contacts,
  SignpadOut,
  SignpadReturn,
  StampReturn,
  StampOut,
  HealthInsurance
};
