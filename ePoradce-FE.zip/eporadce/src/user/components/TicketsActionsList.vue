<template>
  <v-menu offset-y right v-if="show" :close-on-content-click="false" v-model="menu" :min-width="300">
    <template v-slot:activator="{ on }">
      <v-btn color="primary" dark v-on="on" tile class="ml-4"
        >Nový ticket<v-icon dark class="ml-2">arrow_drop_down</v-icon></v-btn
      >
    </template>

    <!-- multilevel menu -->
    <v-list v-if="isMultilevel">
      <v-list-group
        v-for="group in $store.state.userDetail.ticketActionsList"
        :key="group.GroupName"
        v-model="group.active"
        no-action
      >
        <template v-slot:activator>
          <v-list-item-content>
            <v-list-item-subtitle
              ><strong class="text-uppercase black--text">{{ group.GroupName }}</strong></v-list-item-subtitle
            >
          </v-list-item-content>
        </template>

        <v-list-item v-for="(item, index) in group.Tickets" :key="index" @click="createTicket(item)" class="pl-4">
          <v-list-item-content>
            <v-list-item-title>{{ item.Name }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-divider></v-divider>
      </v-list-group>
    </v-list>

    <!-- simple menu -->
    <v-list v-else>
      <v-list-item
        v-for="(item, index) in $store.state.userDetail.ticketActionsList[0].Tickets"
        :key="index"
        @click="createTicket(item)"
      >
        <v-list-item-title>{{ item.Name }}</v-list-item-title>
      </v-list-item>
    </v-list>
  </v-menu>
</template>

<script>
export default {
  name: "TicketsActionsList",

  data() {
    return {
      menu: false
    };
  },

  computed: {
    isMultilevel() {
      return this.$store.state.userDetail.ticketActionsList.length > 1;
    },

    show() {
      return (
        this.$store.state.userDetail.ticketActionsList && this.$store.state.userDetail.ticketActionsList.length > 0
      );
    }
  },

  methods: {
    createTicket(ticket) {
      this.menu = false;
      this.$store.state.userDetail.ticketActionsList.forEach((t) => {
        t.active = false;
      });
      this.$emit("action", ticket);
    }
  }
};
</script>