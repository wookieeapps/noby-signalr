<template>
  <v-dialog scrollable persistent no-click-animation v-model="value" max-width="600">
    <v-card class="pt-1">
      <v-card-title>{{ action ? action.Name : "" }}</v-card-title>

      <!-- confirm dialog po ulozeni ticketu normalnim uzivatelem -->
      <v-card-text v-if="createdMessage">
        <p v-if="createdMessage" class="pt-6 success--text">Ticket byl vytvořen a odeslán ke zpracování.</p>
      </v-card-text>

      <v-card-text v-else>
        <!-- zobrazeni timeline parent ticketu -->
        <v-sheet v-if="parentTicket" elevation="2" color="yellow lighten-5" class="pr-4 mb-4 pb-1">
          <v-timeline dense class="pt-2">
            <!-- zalozeni ticketu -->
            <flow-action :model="parentTicket" :type="1" />
            <!-- komentar zakladatele -->
            <flow-comment :type="1" :model="parentTicket" v-if="parentTicket.InsertNote" />
          </v-timeline>
        </v-sheet>

        <!-- editacni dialog ticketu -->
        <component
          v-if="model !== null"
          :is="loadedComponent"
          :validation-errors="validationErrors"
          v-model="model"
          :key="compKey"
          :action="action"
          @alterDialog="alterDialog"
          ref="ticketDetail"
        />

        <!-- poznamka -->
        <v-textarea
          v-show="config.note"
          label="Poznámka k  ticketu..."
          v-model="note"
          grow
          rows="1"
          hide-details
          class="mt-4"
        />
      </v-card-text>

      <v-card-actions class="pr-4 pb-3">
        <v-spacer></v-spacer>
        <v-btn text tile @click="$emit('input', false)">Zavřít</v-btn>
        <v-btn color="success" tile @click="create" :loading="saveLoading" v-show="action && config.successBtn">{{
          config.successBtnText
        }}</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { ticketsApi } from "@/code/apiServices";
import FlowAction from "./TicketsFlow/Action.vue";
import FlowComment from "./TicketsFlow/Comment.vue";
import { Helpers } from "@mpss/eporadce-common";

function defaultConfig() {
  return {
    note: true,
    successBtn: true,
    successBtnText: "Odeslat požadavek"
  };
}

export default {
  name: "TicketsDialog",

  props: ["value", "action", "parentId"],

  components: { FlowAction, FlowComment },

  data() {
    return {
      note: "",
      validationErrors: null,
      model: null,
      saveLoading: false,
      createdMessage: false,
      compKey: 0,
      parentTicket: null,
      config: defaultConfig()
    };
  },

  watch: {
    // v=True pokazde pri zobrazeni modalniho dialogu
    async value(v) {
      this.model = null;
      this.parentTicket = null;
      this.validationErrors = null;
      this.createdMessage = false;

      // reinit component
      if (v) {
        this.note = null;
        this.compKey++;
        this.config = defaultConfig();

        // self approve?
        const approvers = await ticketsApi.GetListOfApprovers(this.$store.state.userDetail.user.Id, this.action.Type);
        if (approvers.includes(this.$user.getSync().Id)) {
          this.config.successBtnText = "Vytvořit a schválit požadavek";
        }

        // editace ticketu - vytvoreni z rodicovskeho ticketu
        if (this.parentId) {
          this.parentTicket = (await ticketsApi.Get(this.parentId)).Ticket;
          this.model = { ParentId: this.parentId, ...this.parentTicket.Model };
        } else {
          this.model = { ParentId: null };
        }
      }
    }
  },

  computed: {
    loadedComponent() {
      if (this.action) {
        switch (this.action.Component) {
          case "FirstnameSurname":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/FirstnameSurname.vue");
          case "Address":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/Address.vue");
          case "AddressContact":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/AddressContact.vue");
          case "PersonTitle":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/PersonTitle.vue");
          case "BankAccount":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/BankAccount.vue");
          case "Contacts":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/Contacts.vue");
          case "RegistrationId":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegistrationId.vue");
          case "Vat":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/Vat.vue");
          case "AddFiles":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/AddFiles.vue");
          case "ChangePoce":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/ChangePoce.vue");
          case "RegisterCnbSu":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegisterCnbSu.vue");
          case "RegisterCnbDps":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegisterCnbDps.vue");
          case "RegisterCnbPojisteni":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegisterCnbPojisteni.vue");
          case "RegisterCnbInvestice":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegisterCnbInvestice.vue");
          case "UserTermination":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/UserTermination.vue");
          case "UserGroupChange":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/UserGroupChange.vue");
          case "UserSelfTermination":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/UserSelfTermination.vue");
          case "SignpadOut":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/SignpadOut.vue");
          case "SignpadReturn":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/SignpadReturn.vue");
          case "StampOut":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/StampOut.vue");
          case "StampReturn":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/StampReturn.vue");
          case "HealthInsurance":
            return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/HealthInsurance.vue");
        }
      }

      return null;
    }
  },

  methods: {
    // uprava zobrazeni dialogu
    alterDialog(config) {
      if (config.note !== undefined) this.config.note = config.note;
      if (config.successBtn !== undefined) this.config.successBtn = config.successBtn;
      if (config.successBtnText !== undefined) this.config.successBtnText = config.successBtnText;
    },

    // vytvorit novy ticket
    async create() {
      this.saveLoading = true;

      const result = await ticketsApi.Create(
        this.$store.state.userDetail.user.Id,
        this.action.Component.toLowerCase(),
        {
          ParentId: this.parentId,
          Model: this.model,
          Note: this.note
        }
      );

      this.saveLoading = false;

      // poslat informaci o result do komponenty
      if (this.$refs.ticketDetail.saved) this.$refs.ticketDetail.saved(result);

      if (result !== null && result.errors) {
        this.validationErrors = result.errors;
        this.$toast.error("Ticket nebylo možné vytvořit");
      } else {
        this.$emit("update:action", null);
        this.$emit("ticketCreated");

        if (result.SelfApproval) {
          // ticket byl rovnou ukoncen
          this.$toast.success("Ticket byl schválen");
          this.$emit("input", false);
          this.$emit("approved", result.TicketId);
        } else {
          // ticket odeslan na schvaleni
          this.createdMessage = true;
        }
      }
    }
  }
};
</script>
