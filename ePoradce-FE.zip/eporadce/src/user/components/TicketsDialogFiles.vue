<template>
  <v-dialog scrollable v-model="dialog" max-width="700">
    <v-card>
      <v-card-title>Ticket #{{ this.value }} - archivace souborů</v-card-title>

      <v-card-text class="pb-0">
        <app-box-loader v-if="files === null" />

        <div v-else>
          <p>Zaškrtnuté soubory budou pod vybraným druhem uloženy do archivu souborů uživatele.</p>
          <p class="red--text" v-if="deleted.length > 0">{{ deleted.length }} souborů bude smazáno.</p>
          <v-list>
            <v-list-item v-for="(item, index) in files" :key="item.Id">
              <v-list-item-action>
                <v-checkbox v-model="selected" color="primary" :value="item.Id"></v-checkbox>
              </v-list-item-action>

              <v-list-item-content>
                <v-list-item-title>
                  <a :href="getDownloadUrl(item.SystemFileName)" class="filelist-link">{{ item.OriginalFileName }}</a>
                </v-list-item-title>

                <v-select
                  class="mt-0"
                  placeholder="Druh souboru"
                  :items="fileTypes"
                  v-model="item.FileInfoTypeId"
                  item-text="Name"
                  item-value="Id"
                  hide-details
                  dense
                  :error-messages="validateFieldPrefix('Files', index, 'FileInfoTypeId')"
                />

                <tags-line-view :file="item" :tags="tags" @dialog="showTagsDialog" class="pt-2" />
              </v-list-item-content>

              <v-list-item-action>
                <v-btn icon color="red">
                  <v-icon @click="itemDelete(item.Id)">delete</v-icon>
                </v-btn>
              </v-list-item-action>
            </v-list-item>
          </v-list>
        </div>
      </v-card-text>
      <v-card-actions class="pt-1 pr-5 pb-4">
        <v-spacer></v-spacer>
        <v-btn text tile @click="close">Zavřít</v-btn>

        <v-btn tile color="success" class="ml-2" :loading="saveLoading" @click="save">Uložit změny</v-btn>
      </v-card-actions>
    </v-card>

    <!-- dialog s vyberem tagu -->
    <tags-dialog v-model="tagsDialogShow" :item="tagsCurrentItem" :save="false" />
  </v-dialog>
</template>

<script>
import { fileInfoApi, tagsApi, ticketsApi } from "@/code/apiServices";
import { ObjectTypes } from "@mpss/eporadce-common";
import { MixinValidateField } from "@mpss/eporadce-common-vue";
import MixinGetDownloadUrl from "@/mixins/MixinGetDownloadUrl";
import TagsDialog from "./TagsDialog.vue";
import TagsLineView from "./TagsLineView.vue";

export default {
  name: "TicketsDialogFiles",

  props: ["value", "userId"],

  components: { TagsDialog, TagsLineView },

  mixins: [MixinGetDownloadUrl, MixinValidateField],

  data() {
    return {
      dialog: false,
      files: null,
      fileTypes: null,
      selected: [],
      deleted: [],
      saveLoading: false,
      tags: null,
      tagsDialogShow: false,
      tagsCurrentItem: null
    };
  },

  async mounted() {
    this.tags = await tagsApi.GetList(ObjectTypes.User);

    const data = await fileInfoApi.GetList(ObjectTypes.Ticket, this.value, 0, 999);

    if (data != null && data.Data.length > 0) {
      // typy souboru
      this.fileTypes = await fileInfoApi.GetFileInfoTypes(ObjectTypes.User);

      this.selected = data.Data.map((t) => t.Id);
      this.files = data.Data;
      this.dialog = true;
    }
  },

  watch: {
    tagsDialogShow(v) {
      if (!v) {
        this.tagsCurrentItem.__ob__.dep.notify();
      }
    }
  },

  methods: {
    // otevreni dialogu s nastavenim tagu pro soubor
    showTagsDialog(id) {
      this.tagsCurrentItem = this.files.find((t) => t.Id == id);
      this.tagsDialogShow = true;
    },

    itemDelete(id) {
      this.deleted.push(id);

      const idx1 = this.files.findIndex((t) => t.Id == id);
      this.$delete(this.files, idx1);

      const idx2 = this.selected.indexOf(id);
      if (idx2 !== -1) this.$delete(this.selected, idx2);
    },

    // zavreni dialogu
    close() {
      this.dialog = false;
      this.files = null;
      this.$emit("input", null);
    },

    // ulozeni vazby
    async save() {
      this.saveLoading = true;

      const result = await fileInfoApi.Update(
        ObjectTypes.User,
        this.userId,
        this.files.filter((t) => this.selected.includes(t.Id)),
        true
      );

      if (this.deleted.length > 0) {
        await ticketsApi.DeleteAttachments(this.value, this.deleted);
      }

      this.saveLoading = false;

      if (result !== null && result.errors) {
        this.validationErrors = result.errors;
        this.$toast.error("Vyberte druh všech označených souborů");
      } else {
        this.$toast.success("Soubory byly uloženy do archivu uživatele");

        // refresh souboru v tabu Archiv
        await this.$store.dispatch("userDetail/initFiles", true);

        this.close();
      }
    }
  }
};
</script>
