<template>
  <v-dialog scrollable v-model="detailDialog" max-width="700">
    <v-card>
      <v-card-title v-if="detailModel !== null"
        >Ticket #{{ detailModel.Id }}
        <span v-if="detailModel.ParentId" class="text--disabled ml-2 font-weight-light"
          >(vytvořený z #{{ detailModel.ParentId }})</span
        >
      </v-card-title>

      <v-card-text class="pb-0">
        <app-box-loader v-if="detailModel === null" />

        <div v-else>
          <!-- zobrazeni timeline parent ticketu -->
          <v-sheet v-if="parentTicket" elevation="2" color="yellow lighten-5" class="pr-4 mb-4">
            <v-timeline dense class="pt-2">
              <!-- zalozeni ticketu -->
              <flow-action :model="parentTicket" :type="1" />
              <!-- detail ticketu -->
              <v-timeline-item hide-dot right>
                <v-alert border="left" colored-border color="primary" elevation="1" class="mb-0 pt-1 pb-1">
                  <component
                    :is="detailComponent"
                    :dense="true"
                    :model="parentTicket.Model"
                    :type="detailModel.Type"
                    :id="parentTicket.Id"
                  />
                </v-alert>
              </v-timeline-item>
              <!-- komentar zakladatele -->
              <flow-comment :type="1" :model="parentTicket" v-if="parentTicket.InsertNote" />
              <flow-status :status="5" />
            </v-timeline>
          </v-sheet>

          <v-timeline dense>
            <v-timeline-item color="orange" small right v-if="parentTicket">
              Z ticketu #{{ parentTicket.Id }} vytvořen nový ticket
            </v-timeline-item>

            <!-- zalozeni ticketu -->
            <flow-action :model="detailModel" :type="1" />
            <!-- detail ticketu -->
            <v-timeline-item hide-dot right>
              <v-alert border="left" colored-border color="primary" elevation="1" class="mb-0 pt-1 pb-1">
                <component
                  :is="detailComponent"
                  :dense="true"
                  :model="detailModel.Model"
                  :type="detailModel.Type"
                  :id="detailModel.Id"
                  show-comparison="true"
                  ref="ticketDetail"
                />
              </v-alert>
            </v-timeline-item>
            <!-- komentar zakladatele -->
            <flow-comment :type="1" :model="detailModel" v-if="detailModel.InsertNote" />
            <!-- vychozi status = tj. NEW -->
            <flow-status :status="1" />
            <!-- zobrazit approvery, pokud je ticket ve stavu NEW -->
            <flow-user-list
              :users="detailModel.Approvers"
              label="Schvalovatelé"
              v-if="detailModel.Status == 1 && !detailModel.IsEditable"
            />
            <!-- vyjadreni approvera -->
            <flow-action :model="detailModel" :type="2" v-if="detailModel.UpdateUserId" />
            <!-- komentar approvera -->
            <flow-comment :type="2" :model="detailModel" v-if="detailModel.UpdateNote" />
            <!-- konecny status -->
            <flow-status :status="detailModel.Status" v-if="detailModel.UpdateUserId" />
          </v-timeline>
        </div>
      </v-card-text>

      <!-- akce pri nahledu -->
      <template v-if="detailModel">
        <template v-if="!detailModel.IsEditable">
          <v-card-actions class="pr-5 pb-4">
            <v-spacer></v-spacer>
            <v-btn text tile @click="close">Zavřít</v-btn>
          </v-card-actions>
        </template>

        <!-- akce pro approvera -->
        <template v-else>
          <v-card-text class="pb-0 pt-1">
            <v-textarea v-model="note" label="Poznámka" rows="1" grow />
          </v-card-text>

          <v-card-actions class="pt-1 pr-5 pb-4">
            <v-spacer></v-spacer>
            <v-btn text tile @click="close">Zavřít</v-btn>

            <v-btn
              v-show="config.showEditButton"
              tile
              color="primary"
              dark
              class="ml-2"
              :loading="dialogBtnLoading"
              @click="edit"
              >Upravit</v-btn
            >
            <v-btn
              v-show="config.showDisapproveButton"
              tile
              color="red"
              dark
              class="ml-2"
              :loading="dialogBtnLoading"
              @click="disapprove"
              >Zamítnout</v-btn
            >
            <v-btn
              v-show="config.showApproveButton"
              tile
              color="success"
              class="ml-2"
              :loading="dialogBtnLoading"
              @click="approve"
              >Schválit</v-btn
            >
          </v-card-actions>
        </template>
      </template>
    </v-card>
  </v-dialog>
</template>

<script>
import { ticketsApi } from "@/code/apiServices";
// flow imports
import FlowStatus from "./TicketsFlow/Status.vue";
import FlowAction from "./TicketsFlow/Action.vue";
import FlowComment from "./TicketsFlow/Comment.vue";
import FlowUserList from "./TicketsFlow/UserList.vue";

const defaultConfig = function () {
  return {
    showEditButton: true,
    showApproveButton: true,
    showDisapproveButton: true
  };
};

export default {
  name: "TicketsDialogView",

  components: { FlowStatus, FlowComment, FlowUserList, FlowAction },

  props: ["value"],

  data() {
    return {
      note: "",

      // dialog
      dialogBtnLoading: false,
      detailDialog: false,
      detailModel: null,
      parentTicket: null,

      // dialog configuration
      config: defaultConfig()
    };
  },

  // zobrazit detail ticketu
  async mounted() {
    this.detailDialog = true;

    // nahrat ticket
    const result = await ticketsApi.Get(this.value);
    this.detailModel = result.Ticket;
    this.config = result.Config;

    // parent ticket
    if (result.Ticket.ParentId) {
      this.parentTicket = (await ticketsApi.Get(result.Ticket.ParentId)).Ticket;
    }
  },

  computed: {
    detailComponent() {
      switch (this.detailModel.Component) {
        case "FirstnameSurname":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/FirstnameSurnameView.vue");
        case "Address":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/AddressView.vue");
        case "AddressContact":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/AddressContactView.vue");
        case "PersonTitle":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/PersonTitleView.vue");
        case "BankAccount":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/BankAccountView.vue");
        case "Contacts":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/ContactsView.vue");
        case "RegistrationId":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegistrationIdView.vue");
        case "Vat":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/VatView.vue");
        case "AddFiles":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/AddFilesView.vue");
        case "ChangePoce":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/ChangePoceView.vue");
        case "RegisterCnbSu":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegisterCnbSuView.vue");
        case "RegisterCnbDps":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegisterCnbDpsView.vue");
        case "RegisterCnbPojisteni":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegisterCnbPojisteniView.vue");
        case "RegisterCnbInvestice":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/RegisterCnbInvesticeView.vue");
        case "UserTermination":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/UserTerminationView.vue");
        case "UserGroupChange":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/UserGroupChangeView.vue");
        case "UserSelfTermination":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/UserSelfTerminationView.vue");
        case "SignpadOut":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/SignpadOutView.vue");
        case "SignpadReturn":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/SignpadReturnView.vue");
        case "StampOut":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/StampOutView.vue");
        case "StampReturn":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/StampReturnView.vue");
        case "HealthInsurance":
          return () => import(/* webpackChunkName: "tickets-details" */ "./Tickets/HealthInsuranceView.vue");
      }

      return null;
    }
  },

  methods: {
    // editovat ticket
    async edit() {
      if (await this.confirm("Opravdu si přejete editovat tento ticket?")) {
        this.dialogBtnLoading = true;

        // get action (in case original action is not available for current user)
        const action = await ticketsApi.GetAction(this.detailModel.Type);
        this.$emit("editTicket", this.detailModel.Id, action);

        this.close();
      }
    },

    // schvalit ticket
    async approve() {
      if (await this.confirm("Opravdu si přejete schválit tento ticket?")) {
        this.dialogBtnLoading = true;
        const id = this.detailModel.Id;

        await ticketsApi.Approve(this.detailModel.Id, this.note);

        // poslat informaci o result do komponenty
        if (this.$refs.ticketDetail.approved) this.$refs.ticketDetail.approved();

        this.$emit("reload");
        this.close();

        this.$emit("approved", id);
      }
    },

    // zamitnout ticket
    async disapprove() {
      if (await this.confirm("Opravdu si přejete zamítnout tento ticket?")) {
        this.dialogBtnLoading = true;

        await ticketsApi.Disapprove(this.detailModel.Id, this.note);

        this.$emit("reload");
        this.close();
      }
    },

    // inner fce - konfirmacni dialog pro akci ticketu
    async confirm(text) {
      return this.$confirm(text, {
        buttonTrueText: "ANO",
        buttonFalseText: "NE"
      });
    },

    close() {
      this.parentTicket = null;
      this.dialogBtnLoading = false;
      this.detailDialog = false;
      this.detailModel = null;
      this.config = defaultConfig();

      this.$emit("input", null);
    }
  }
};
</script>
