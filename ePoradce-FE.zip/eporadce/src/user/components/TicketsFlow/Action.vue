<template>
  <v-timeline-item color="grey" fill-dot right class="pb-0">
    <template #icon>
      <app-user-avatar :user-id="userId" />
    </template>
    <v-row justify="space-between">
      <v-col cols="8">
        <span class="black--text">{{ name }}</span> {{ text }}
        <template v-if="type == 1">
          <br /><strong class="primary--text">{{ model.TypeText }}</strong>
        </template>
      </v-col>
      <v-col cols="4" class="text-right">{{ time | date }}<br />{{ time | time }}</v-col>
    </v-row>
  </v-timeline-item>
</template>

<script>
export default {
  name: "TicketsFlowAction",

  props: ["model", "type"],

  computed: {
    userId() {
      return this.type == 1 ? this.model.InsertUserId : this.model.UpdateUserId;
    },

    name() {
      return this.type == 1 ? this.model.InsertUserName : this.model.UpdateUserName;
    },

    time() {
      return this.type == 1 ? this.model.InsertTime : this.model.UpdateTime;
    },

    text() {
      return this.type == 1 ? `vytvořil ticket #${this.model.Id}` : "zpracoval";
    }
  }
};
</script>
