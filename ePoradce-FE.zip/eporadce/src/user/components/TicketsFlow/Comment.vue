<template>
  <v-timeline-item color="grey" fill-dot right>
    <template #icon>
      <app-user-avatar :user-id="userId" />
    </template>
    <v-card class="elevation-2">
      <v-card-text>{{ note }}</v-card-text>
    </v-card>
  </v-timeline-item>
</template>

<script>
export default {
  name: "TicketsFlowComment",

  props: ["model", "type"],

  computed: {
    userId() {
      return this.type == 1 ? this.model.InsertUserId : this.model.UpdateUserId;
    },

    note() {
      return this.type == 1 ? this.model.InsertNote : this.model.UpdateNote;
    }
  }
};
</script>
