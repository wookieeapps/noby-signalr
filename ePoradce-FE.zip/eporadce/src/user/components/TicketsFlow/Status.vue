<template>
  <v-timeline-item color="grey" small right>
    Přiřazen status
    <strong :class="status | list('ticketStatuses') | color('--text')">{{
      status | list("ticketStatuses") | text
    }}</strong>
  </v-timeline-item>
</template>

<script>
export default {
  name: "TicketsFlowStatus",

  props: ["status"]
};
</script>
