<template>
  <v-timeline-item color="grey" small right>
    {{ label }}
    <v-chip small class="ml-2" v-for="approver in users" :key="approver.Id">{{ approver.DisplayName }}</v-chip>
  </v-timeline-item>
</template>

<script>
export default {
  name: "TicketsFlowUserList",

  props: ["users", "label"]
};
</script>
