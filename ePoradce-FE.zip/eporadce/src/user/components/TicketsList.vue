<template>
  <div>
    <v-card>
      <v-subheader class="justify-space-between">
        <span>SEZNAM TICKETŮ</span>
        <v-switch dense v-model="onlyActive" class="v-input--reverse">
          <template #label>
            <span class="caption">pouze aktivní</span>
          </template>
        </v-switch>
      </v-subheader>

      <app-box-loader v-if="items === null" />

      <app-box-no-entries v-else-if="items.length === 0">Zatím nebyly vytvořeny žádné tickety</app-box-no-entries>

      <v-list dense two-line v-else class="pt-0">
        <v-list-item
          class="hidden-items"
          v-for="(item, index) in items"
          :key="index"
          @click="openDialog(item.Id)"
          v-show="!onlyActive || item.Status == 1"
        >
          <v-list-item-content>
            <v-list-item-subtitle class="text--primary">{{ item.TypeText }}</v-list-item-subtitle>
            <v-list-item-subtitle class="font-weight-regular">{{ item.InsertTime | datetime }}</v-list-item-subtitle>
          </v-list-item-content>
          <v-list-item-action v-if="item.IsApprover">
            <v-icon color="warning">notifications_active</v-icon>
          </v-list-item-action>
          <v-list-item-action>
            <v-list-item-action-text class="text-right">
              <v-btn
                v-if="showDeleteTicketButton"
                class="hidden-item"
                x-small
                color="error"
                text
                tile
                @click.stop="deleteTicket(item.Id)"
                >SMAZAT</v-btn
              >
              <span :class="item.Status | list('ticketStatuses') | color('--text')">{{
                item.Status | list("ticketStatuses") | text
              }}</span
              ><br />
              <span v-if="item.ParentId" class="text--disabled mr-1"
                >#{{ item.ParentId }}<v-icon x-small color="grey lighten-2">forward</v-icon></span
              >#{{ item.Id }}
            </v-list-item-action-text>
          </v-list-item-action>
        </v-list-item>
      </v-list>

      <!-- nahrat dalsi tickety -->
      <div class="text-center pb-3" v-show="itemsMore">
        <v-btn color="primary" x-small @click="paginationLoadMore" tile text :loading="itemsMoreLoading"
          ><v-icon x-small>get_app</v-icon>Zobrazit další</v-btn
        >
      </div>
    </v-card>

    <!-- dialog se zobrazenim detailu ticketu -->
    <tickets-dialog-view
      v-model="detailDialogId"
      :key="`dlgDet${detailDialogKey}`"
      @reload="reload"
      @editTicket="editTicket"
      @approved="$emit('approved', $event)"
      v-if="detailDialogId"
    />
  </div>
</template>

<script>
import { UserRoles } from "@mpss/eporadce-common";
import { ticketsApi } from "@/code/apiServices";
import TicketsDialogView from "./TicketsDialogView.vue";
import MixinContinuousPagination from "@/mixins/MixinContinuousPagination";

export default {
  name: "TicketsList",

  props: ["id"],

  mixins: [MixinContinuousPagination],

  components: { TicketsDialogView },

  data() {
    return {
      items: null,
      continuousPaginationFce: async (start, count) => {
        return await ticketsApi.GetList(this.id, start, count);
      },

      onlyActive: false,

      // ID zobrazeneho detailu ticketu
      detailDialogId: null,
      detailDialogKey: 0
    };
  },

  async mounted() {
    await this.$lists.fetch(["TicketStatuses"]);

    await this.paginationLoadMore();
  },

  computed: {
    showDeleteTicketButton() {
      return this.$user.isInRole(UserRoles.AppAdministrator);
    }
  },

  methods: {
    // smazat ticket
    async deleteTicket(id) {
      if (
        await this.$confirm("Opravdu si přejete smazat tento ticket?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        const index = this.items.findIndex((t) => t.Id === id);
        this.$delete(this.items, index);

        await ticketsApi.Delete(id);

        this.$toast.success("Ticket byl smazán");
      }
    },

    // editovat ticket
    async editTicket(id, action) {
      // poslat informaci na detail klienta, aby se spustil editacni dialog
      this.$emit("editTicket", id, action);
    },

    // nahrat seznam ticketu
    async reload(openFilesDialog) {
      await this.paginationLoadMore(0, this.itemsEnd, true);
    },

    // zobrazeni dialogu s detailem ticketu
    openDialog(id) {
      this.detailDialogKey += 1;
      this.detailDialogId = id;
    }
  }
};
</script>
