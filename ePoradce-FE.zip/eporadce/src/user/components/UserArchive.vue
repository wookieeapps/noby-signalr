<template>
  <v-card>
    <v-card-text v-if="files === null || tags === null || fileTypes === null">
      <app-box-loader />
    </v-card-text>
    <v-card-text v-else-if="files.length === 0">
      <app-box-no-entries>Zatím nejsou přiložené žádné soubory</app-box-no-entries>
    </v-card-text>

    <div v-else>
      <!-- filtrovani souboru -->
      <v-card-text>
        <v-row>
          <v-col cols="12" md="6">
            <v-select
              v-model="filter"
              :items="fileTypes"
              label="Typy..."
              multiple
              outlined
              dense
              clearable
              chips
              hide-details
              small-chips
              deletable-chips
              item-text="Name"
              item-value="Id"
            />
          </v-col>
          <v-col cols="12" md="6">
            <v-select
              v-if="tags !== null && tags.length > 0"
              v-model="filterTags"
              :items="tags"
              label="Tagy..."
              multiple
              outlined
              dense
              clearable
              chips
              hide-details
              small-chips
              deletable-chips
              item-text="Name"
              item-value="Id"
            />
          </v-col>
        </v-row>
      </v-card-text>

      <!-- info - zadny soubor neodpovida filtru -->
      <app-box-no-entries v-show="filteredFiles.length === 0">Filtru neodpovídají žádné soubory</app-box-no-entries>

      <!-- zobrazeni soubour v tabulce -->
      <v-simple-table class="user-archive-list">
        <template v-slot:default>
          <tbody v-for="file in filteredFiles" :key="file.Id">
            <tr class="uarchive-datarow">
              <td>
                <strong>{{ file.OriginalFileName }}</strong
                ><br />
                <span class="text--disabled">{{ file.FileSize | fileSize }}</span>
              </td>
              <td>{{ ftypeName(file.FileInfoTypeId) }}</td>
              <td>{{ file.InsertUser }}<br />{{ file.InsertTime | datetime }}</td>
              <td class="text-right" nowrap>
                <v-btn icon small @click="filesDelete(file)" v-if="isDeleteVisible" class="mr-3">
                  <v-icon color="error">remove_circle</v-icon>
                </v-btn>

                <v-btn target="_blank" :href="getDownloadUrl(file.SystemFileName)" icon small
                  ><v-icon>cloud_download</v-icon></v-btn
                >
              </td>
            </tr>
            <tr class="uarchive-tagrow">
              <td colspan="4" class="pb-3">
                <tags-line-view :file="file" :tags="tags" @dialog="showTagsDialog" />
              </td>
            </tr>
          </tbody>
        </template>
      </v-simple-table>

      <!-- dialog s vyberem tagu -->
      <tags-dialog v-model="tagsDialogShow" :item="tagsCurrentItem" :save="true" />
    </div>
  </v-card>
</template>

<script>
import { UserRoles } from "@mpss/eporadce-common";
import { fileInfoApi, tagsApi } from "@/code/apiServices";
import { ObjectTypes } from "@mpss/eporadce-common";
import MixinGetDownloadUrl from "@/mixins/MixinGetDownloadUrl";
import TagsDialog from "./TagsDialog.vue";
import TagsLineView from "./TagsLineView.vue";

export default {
  name: "UserArchive",

  props: ["readonly"],

  components: { TagsDialog, TagsLineView },

  mixins: [MixinGetDownloadUrl],

  data() {
    return {
      items: null,
      fileTypes: null,
      tags: null,
      filter: null,
      filterTags: null,
      tagsDialogShow: false,
      tagsCurrentItem: null
    };
  },

  async mounted() {
    // druhy souboru
    this.fileTypes = await fileInfoApi.GetFileInfoTypes(ObjectTypes.User);

    this.tags = await tagsApi.GetList(ObjectTypes.User);

    await this.$store.dispatch("userDetail/initFiles");
  },

  computed: {
    files() {
      return this.$store.state.userDetail.files;
    },

    isDeleteVisible() {
      return this.$user.isInRole(UserRoles.HiringSupervisor) && !this.readonly;
    },

    filteredFiles() {
      const types = this.filter && Array.isArray(this.filter) ? this.filter : [];
      const tags = this.filterTags && Array.isArray(this.filterTags) ? this.filterTags : [];

      if (types.length > 0 && tags.length == 0) {
        return this.files.filter((t) => types.includes(t.FileInfoTypeId));
      } else if (types.length == 0 && tags.length > 0) {
        return this.files.filter((t) => tags.some((x) => t.Tags.includes(x)));
      } else if (types.length > 0 && tags.length > 0) {
        return this.files.filter((t) => types.includes(t.FileInfoTypeId) && tags.some((x) => t.Tags.includes(x)));
      } else return this.files;
    }
  },

  methods: {
    // smazani souboru
    async filesDelete(item) {
      const idx = this.files.findIndex((t) => t.Id === item.Id && t.OriginalFileName === item.OriginalFileName);
      if (
        await this.$confirm("Opravdu si přejete smazat tento dokument?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        this.$delete(this.$store.state.userDetail.files, idx);
        await fileInfoApi.Delete(item.Id);

        this.$toast.warning("Soubor byl smazán");
      }
    },

    // otevreni dialogu s nastavenim tagu pro soubor
    showTagsDialog(id) {
      this.tagsCurrentItem = this.files.find((t) => t.Id == id);
      this.tagsDialogShow = true;
    },

    ftypeName(id) {
      if (!this.fileTypes) return "";
      const ft = this.fileTypes.find((t) => t.Id == id);
      return ft ? ft.Name : "";
    }
  }
};
</script>

<style scoped>
.user-archive-list td {
  font-size: 12px;
  line-height: 1.35em;
}
</style>
