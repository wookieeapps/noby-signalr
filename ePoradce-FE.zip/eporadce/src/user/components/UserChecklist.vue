<template>
  <div>
    <app-box-loader v-if="$store.state.userDetail.checklists === null" />

    <div v-else>
      <v-card v-if="isAdmin" class="mb-4">
        <v-card-title class="justify-space-between" v-if="!readonly">
          Nastavení checklistu
          <div>
            <v-btn tile text :loading="saveLoading" class="mr-2" @click="anulovat()">Anulovat</v-btn>
            <v-btn color="success" @click="save()" tile :loading="saveLoading">Uložit změny</v-btn>
          </div>
        </v-card-title>
        <v-card-text class="pb-1">
          <v-select
            v-if="$store.state.userDetail.detail != null"
            label="Kategorie"
            hide-details
            item-text="Text"
            item-value="Id"
            class="mb-8"
            :readonly="readonly"
            :items="$lists.hiring.riskTypes"
            v-model="$store.state.userDetail.detail.RiskType"
            :error-messages="validateField('User.RiskType')"
          />
        </v-card-text>
      </v-card>

      <hiring-checklist
        source="userDetail"
        :readonly="readonly"
        :user-id="$store.state.userDetail.user.Id"
        :files="$store.state.userDetail.files"
        :validation-errors="validationErrors"
      />
    </div>
  </div>
</template>

<script>
import { UserRoles } from "@mpss/eporadce-common";
import { checklistsApi } from "../../hiring/code/apiServicesHiring";
import HiringChecklist from "../../hiring/components/Checklist.vue";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
import { usersExtendedApi } from "../../code/apiServices";

export default {
  name: "UserChecklist",

  props: ["readonly"],

  mixins: [MixinResolveGeneralResult],

  components: { HiringChecklist },

  data() {
    return {
      validationErrors: null,
      saveLoading: false
    };
  },

  async mounted() {
    await this.$store.dispatch("userDetail/initFiles");
    await this.$store.dispatch("userDetail/initChecklist");

    // risk type
    await this.$lists.fetch("hiring", "RiskTypes");
    await this.$store.dispatch("userDetail/initDetail");
  },

  computed: {
    userId() {
      return this.$store.state.userDetail.user.Id;
    },

    isAdmin() {
      return this.$user.isInRole(UserRoles.HiringSupervisor);
    }
  },

  methods: {
    // anulovat vysledky kontrol
    async anulovat() {
      if (
        await this.$confirm("Opravdu si přejete anulovat výsledky kontrol?", {
          buttonTrueText: "ANO",
          buttonFalseText: "NE"
        })
      ) {
        await checklistsApi.ClearPeriodic(this.userId);
        // refresh checklistu
        await this.$store.dispatch("userDetail/initChecklist");
      }
    },

    async save() {
      this.saveLoading = true;

      const model = this.$store.state.userDetail.checklists.map((t) => {
        return {
          Id: t.Id,
          Status: t.Status,
          Note: t.Note,
          HasRequest: t.HasRequest,
          RequestNote: t.RequestNote
        };
      });

      // ulozit checklist
      await this.resolveGeneralResult(
        await checklistsApi.Save(model, this.userId),
        "",
        "Změny byly uloženy",
        "Změny nebylo možné uložit"
      );
      // ulozit risk type
      await usersExtendedApi.SaveRiskType(this.$store.state.userDetail.detail.RiskType, this.userId);

      this.saveLoading = false;
    }
  }
};
</script>
