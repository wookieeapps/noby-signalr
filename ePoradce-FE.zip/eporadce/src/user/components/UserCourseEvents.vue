<template>
  <v-card>
    <v-card-text>
      <!-- zadne zaznamy -->
      <app-box-no-entries :paddingLeft="false" v-if="model && model.length === 0">
        <div class="text-center">
          uživatel nebyl přihlášen do žádného kurzu

          <!-- tlacidlo prihlaseni -->
          <div class="pt-2" v-if="canManageAttendees">
            <v-btn tile small @click="registerDialog = true">
              <v-icon small class="pr-1">person_add</v-icon>
              Přihlásit do termínu
            </v-btn>
          </div>
        </div>
      </app-box-no-entries>
      <div v-else>
        <!-- tlacidlo prihlaseni -->
        <div class="pb-2" v-if="canManageAttendees">
          <v-btn tile small @click="registerDialog = true">
            <v-icon small class="pr-1">person_add</v-icon>
            Přihlásit do termínu
          </v-btn>
        </div>
        <!-- vypis terminu -->
        <div
          v-for="item in model"
          :key="item.CourseEventId"
          :class="item.EvaluationClosed ? 'grey lighten-5 pt-2 pl-2 pr-2' : 'pa-2'"
        >
          <v-row class="align-center">
            <v-col cols="4" sm="2">
              {{ item.TimeFrom | parseDate }} ({{ days(item.TimeFrom,item.TimeTo)  }})
             
            </v-col>
            <v-col cols="8" sm="10" md="3" class="align-center">
              <span class="subtitle-2">
                <router-link
                  v-if="canManageAttendees"
                  :to="{ name: 'eOlaCourseEvent', params: { id: item.CourseEventId } }"
                  target="_blank"
                >
                  {{ item.CourseName }}
                </router-link>
                <span v-else>
                  {{ item.CourseName }}
                </span>
              </span>
            </v-col>
            <v-col cols="12" md="7" v-if="item.EvaluationClosed">
              <!-- seznam vysledku -->
              <v-chip
                v-if="!item.EvaluationGratutade || item.EvaluationGratutade == 0"
                small
                color="warning"
                text-color="white"
                class="mt-0 mb-0"
                disabled
              >
                Neabsoloval
              </v-chip>
              <component
                v-else-if="item.EvaluationType !== 1"
                :is="loadedComponent"
                :code="item.EvaluationType.toString()"
                disabled
                v-model="item.EvaluationResult"
              />
            </v-col>
          </v-row>
          <!-- detail jen u jeste neuzavrenych -->
          <div v-if="!item.EvaluationClosed">
            <!-- cas -->
            <v-row class="align-center mt-0" no-gutters>
              <v-col sm="2" class="d-none d-sm-flex"></v-col>
              <v-col cols="10" class="align-center pl-1"> Čas konání: {{ time(item.TimeFrom, item.TimeTo) }} </v-col>
            </v-row>
            <!-- ubytovani -->
            <v-row v-if="item.WithAccommodation" class="align-center mt-0" no-gutters>
              <v-col sm="2" class="d-none d-sm-flex"></v-col>
              <v-col cols="10" class="align-center pl-1"> Ubytování: {{ item.Accommodation.Name }} ({{ address(item.Accommodation) }}) </v-col>
            </v-row>
            <!-- misto skoleni -->
            <v-row class="align-center mt-0" no-gutters>
              <v-col sm="2" class="d-none d-sm-flex"></v-col>
              <v-col cols="10" class="align-center pl-1"> Místo: {{ item.TrainingRoom.Name }} ({{ address(item.TrainingRoom) }}) </v-col>
            </v-row>

          </div>
          <!-- certifikat -->
            <v-row v-if="item.IsCertificate && item.EvaluationClosed" class="align-center mt-0" no-gutters>
              <v-col sm="2" class="d-none d-sm-flex"></v-col>
              <v-col cols="10" class="align-center pl-1"> Certifikát: 
                
                  <v-btn icon @click="generateDocs(item.CourseEventId, 'certifikat')" >
                    <v-icon>print</v-icon>
                  </v-btn>
              </v-col>
            </v-row>

          <v-divider class="mt-2" />
        </div>
      </div>

      <!-- prihlaseni do terminu -->
      <attendee-register v-model="registerDialog" :user-id="$store.state.userDetail.user.Id" />
    </v-card-text>
  </v-card>
</template>

<script>
import { attendeeApi, courseEventsApi } from "../../eola/code/apiServicesEola";
import { DateHelpers, UserRoles } from "@mpss/eporadce-common";
import AttendeeRegister from "../../eola/components/AttendeeRegister";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";

export default {
  name: "UserCourseEvents",

  components: { AttendeeRegister },

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      model: null,
      registerDialog: false
    };
  },

  async mounted() {
    // seznam kurzu
    this.model = await attendeeApi.AttendeeHistory(this.$store.state.userDetail.user.Id);
  },

  methods: {
    days(TimeFrom,TimeTo){
      const from = new Date(TimeFrom);
      const to = new Date(TimeTo);
      const oneDay = 1000 * 60 * 60 * 24;
      const diffInTime = to.getTime() - from.getTime();
      const diffInDays = (Math.round(diffInTime / oneDay))+1;
      if (diffInDays == 1)
      {
        return 1 + " den";
      }
      if (diffInDays >= 2 && diffInDays <= 4){
        return diffInDays +  " dny";
      }
      if (diffInDays >= 5 ){
        return diffInDays +  " dní";
      }

    },
    address(place) {
      if (place && (place.Street || place.City || place.Zip)) {
        return new Array(place.Street, place.City, place.Zip).filter((t) => t).join(", ");
      }
      return "není vyplněno";
    },
    time(dateFrom, dateTo) {
      const df = DateHelpers.parseISO(dateFrom);
      const dt = DateHelpers.parseISO(dateTo);

      if (df.getDate() === dt.getDate()) {
        return `${DateHelpers.format(df, "HH:mm")} - ${DateHelpers.format(dt, "HH:mm")}`;
      }
      return `${DateHelpers.format(df, DateHelpers.getDatetimeFormat())} - ${DateHelpers.format(
        dt,
        DateHelpers.getDatetimeFormat()
      )}`;
    },
     async generateDocs(courseEventId, docType) {
            const userId = this.$store.state.userDetail.user.Id;
            const resultDoc = await courseEventsApi.GenerateDocForUser(courseEventId,userId, docType);
            if (await this.resolveGeneralResult(resultDoc)) {
                location.href = resultDoc;
                return true;
            }
      }

  },

  watch: {
    async registerDialog(v) {
      if (!v) this.model = await attendeeApi.AttendeeHistory(this.$store.state.userDetail.user.Id);
    }
  },

  computed: {
    loadedComponent() {
      return () => import(/* webpackChunkName: "evaluation-result" */ "../../eola/components/EvaluationResultList");
    },

    //pravo spravovat prihlasene uzivatele
    canManageAttendees() {
      return (
        this.$user.loaded &&
        this.$user.isInRoles([UserRoles.eOlaAdmin, UserRoles.eOlaLector, UserRoles.eOlaAttendeeManager])
      );
    }
  }
};
</script>
