<template>
  <div>
    <v-card v-if="modelDetail === null">
      <app-box-loader />
    </v-card>

    <div v-else>
      <!-- adresy -->
      <v-card class="mt-6">
        <v-subheader>ADRESY</v-subheader>
        <v-card-text>
          <app-text-with-label label="Trv. bydliště" v-if="model.Addr1Street">
            <template>{{ model.Addr1Street }}<br />{{ model.Addr1Zip }}, {{ model.Addr1City }}</template>
          </app-text-with-label>
          <app-text-with-label label="Trv. bydliště" v-else />

          <app-text-with-label
            label="Koresp. adresa"
            v-if="(model.IsAddr2Same && model.Addr1Street) || model.Addr2Street"
          >
            <template>
              <span v-if="model.IsAddr2Same"
                >{{ model.Addr1Street }}<br />{{ model.Addr1Zip }}, {{ model.Addr1City }}</span
              >
              <span v-else>{{ model.Addr2Street }}<br />{{ model.Addr2Zip }}, {{ model.Addr2City }}</span>
            </template>
          </app-text-with-label>
          <app-text-with-label label="Koresp. adresa" v-else />

          <!-- POCE -->
          <div v-if="modelDetail.PoCe">
            <app-text-with-label
              v-for="(poce, index) in modelDetail.PoCe"
              :key="`poce_${poce.Id}_${index}`"
              :label="`POCE #${poce.Type}`"
              :label-tooltip="
                poce.Type == 1
                  ? 'Příslušnost poradce k poradenskému centru'
                  : 'Poradenské centrum pro zasílání klientské dokumentace'
              "
            >
              {{ poce.Street }}<br />{{ poce.Zip }} {{ poce.City }}
            </app-text-with-label>
          </div>
        </v-card-text>
      </v-card>

      <!-- osobni udaje -->
      <v-card class="mt-6">
        <v-subheader>OSOBNÍ ÚDAJE</v-subheader>
        <v-card-text>
          <app-text-with-label label="Rodné číslo" :text="model.PersonalId" v-if="fieldVisible('PersonalId')" />
          <app-text-with-label label="IČ">
            <template>
              {{ model.IC
              }}<span v-if="model.IC" class="ml-4"
                ><span class="text--secondary font-weight-light">Plátce DPH:</span>
                {{ model.IsVatRegistered | yesNo }}</span
              >
            </template>
          </app-text-with-label>
          <app-text-with-label
            label="VTR"
            label-tooltip="Datum vydání Výpisu z Rejstříku trestů"
            :text="getAttr('VTR', 'není')"
          />

          <app-text-with-label
            label="Mobil"
            label-tooltip="Výrobní číslo zařízení"
            :text="getAttr('MOB', 'není')"
          />
          <app-text-with-label
            label="Ntb"
            label-tooltip="Výrobní číslo zařízení"
            :text="getAttr('NTB', 'není')"
          />
          <app-text-with-label
            label="Ověřovací razítko"
            label-tooltip="Číslo vydaného ověřovacího razítka"
            :text="model.VerificationStamp"
          />
          <app-text-with-label
            v-if="modelDetail.SignpadRegNo"
            label="Číslo Signpadu"
            :text="modelDetail.SignpadRegNo"
          />
        </v-card-text>
      </v-card>

      <!-- cislo uctu -->
      <v-card class="mt-6" v-if="fieldVisible('Bank')">
        <v-subheader>BANKOVNÍ ÚČET</v-subheader>
        <v-card-text>
          <app-text-with-label label="Číslo účtu" :text="model.AccountNo" />
          <app-text-with-label label="Kód banky" :text="model.BankCode" />
          <app-text-with-label v-if="model.SpecificSymbol" label="Spec. symbol" :text="model.SpecificSymbol" />
        </v-card-text>
      </v-card>

      <!-- provizni udaje -->
      <v-card class="mt-6">
        <v-subheader>PROVIZE</v-subheader>
        <v-card-text>
          <app-text-with-label label="Datum od" :text="model.ContractDateFrom | date" />
          <app-text-with-label
            label="Datum do"
            :text="model.ContractDateTo | date"
            v-if="fieldVisible('ContractDateTo')"
          />
          <app-text-with-label label="Pozice">
            <template>
              <div>{{ model.PositionName }} ({{ model.PositionCode }})</div>
              <v-btn x-small tile @click.stop.prevent="historiePozice">Zobrazit historii pozice</v-btn>
            </template>
          </app-text-with-label>
        </v-card-text>
      </v-card>
    </div>

    <!-- dialog historie pozice -->
    <v-dialog persistent no-click-animation v-model="dialogHistoriePozice" max-width="600">
      <v-card class="pt-1">
        <v-card-title>Historie pozice</v-card-title>

        <v-card-text v-if="historiePoziceItems == null">
          <app-box-loader />
        </v-card-text>

        <v-simple-table v-else>
          <template>
            <thead>
              <tr>
                <th class="text-left">Kód</th>
                <th class="text-left">Název</th>
                <th class="text-left">Od</th>
                <th class="text-left">Do</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(pozice, index) in historiePoziceItems" :key="index">
                <td>{{ pozice.Code }}</td>
                <td>{{ pozice.Name }}</td>
                <td>{{ pozice.DateFrom | date }}</td>
                <td>{{ pozice.DateTo | date }}</td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>

        <v-card-actions class="pr-4 pb-3">
          <v-spacer></v-spacer>
          <v-btn text tile @click="dialogHistoriePozice = false">Zavřít</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import { UserRoles } from "@mpss/eporadce-common";
import { usersExtendedApi } from "@/code/apiServices";

export default {
  name: "UserExtendedDetail",

  data() {
    return {
      dialogHistoriePozice: false,
      historiePoziceItems: null
    };
  },

  computed: {
    model() {
      return this.$store.state.userDetail.user;
    },

    modelDetail() {
      return this.$store.state.userDetail.detail;
    }
  },

  methods: {
    fieldVisible(field) {
      switch (field) {
        case "PersonalId":
        case "Bank":
          return !this.$user.isInRole(UserRoles.SalesManager) || this.$user.instance.Id === this.model.Id;
        case "ContractDateTo":
          return this.$user.instance.Id !== this.model.Id;
      }
    },

    // vraci hodnotu p2 atributu
    getAttr(code, notFoundText) {
      if (this.$store.state.userDetail.p2attributes !== null) {
        const attr = this.$store.state.userDetail.p2attributes.find((t) => t.Code == code);
        if (attr) return attr.Value;
      }
      return notFoundText || "";
    },

    async historiePozice() {
      this.historiePoziceItems = await usersExtendedApi.GetPositionHistory(this.model.Id);
      this.dialogHistoriePozice = true;
    }
  }
};
</script>
