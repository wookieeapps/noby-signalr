<template>
  <v-card>
    <v-card-text>
      <app-box-loader v-if="items === null" />

      <v-simple-table v-else>
        <template>
          <thead>
            <tr>
              <th class="text-left">Oprávnění</th>
              <th class="text-left">Sjednatelské/a číslo/a</th>
              <th class="text-left">Datum udělení Oprávnění od</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in items" :key="index">
              <td style="max-width: 500px;">
                {{ item.Name }}
                <div v-if="item.Description" class="caption grey--text font-weight-light">
                  {{ item.Description }}
                </div>
              </td>
              <td>{{ item.MediatorNo }}</td>
              <td>{{ formatDate(item.ValidFrom)}}</td>
            </tr>
          </tbody>
        </template>
      </v-simple-table>
    </v-card-text>
  </v-card>
</template>

<script>
import { usersExtendedApi } from "@/code/apiServices";

export default {
  name: "UserMandates",

  data() {
    return {
      items: null
    };
  },
  methods: {
    formatDate(dateStr) {
      const date = new Date(dateStr);
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      return `${day}.${month}.${year}`;
    }
  },

  async mounted() {
    this.items = await usersExtendedApi.GetMandates(this.$store.state.userDetail.user.Id);
  }
};
</script>
