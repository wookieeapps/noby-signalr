<template>
  <div>
    <app-box-loader v-if="!loaded" />

    <v-card v-else>
      <v-card-title v-if="isAdmin" class="justify-space-between">
        <v-switch hide-details v-model="edit" label="editační mód" class="mt-2 mb-3" />

        <v-btn color="success" @click="save" tile v-if="edit" :loading="saveLoading">Uložit změny práv</v-btn>
      </v-card-title>

      <v-slide-x-transition hide-on-leave>
        <div v-if="!edit">
          <v-card-text v-if="model.Applications.length === 0">
            <app-box-no-entries>Uživatel nemá nastavena žádná práva</app-box-no-entries>
          </v-card-text>

          <v-treeview
            dense
            :items="model.Applications"
            item-children="Permissions"
            item-key="Id"
            item-text="Name"
            open-on-click
          >
            <template #label="{ item, leaf }">
              <span v-if="leaf">{{ item.Name }}</span>
              <strong v-else
                >{{ item.Name }}
                <span class="caption ml-2" v-if="item.AppAttribute"
                  >(Speciální atribut: {{ item.AppAttribute }})</span
                ></strong
              >
            </template>
            <template #prepend="{ leaf }">
              <v-icon v-if="leaf">vpn_key</v-icon>
            </template>
          </v-treeview>
        </div>
      </v-slide-x-transition>

      <v-slide-x-reverse-transition hide-on-leave>
        <div v-if="edit && isAdmin">
          <div class="px-4 pb-6">
            <!-- synchronizace FP -->
            <div v-if="showRemoveSync">
              <v-checkbox hide-details v-model="model.RemoveFromSync" label="Vypnutí synchronizace" />
              <span class="text-caption ml-8">Jen pro poradce interní a externí sítě MPSS a KB</span>
            </div>

            <!-- KB veci -->
            <v-row v-if="showKbStuff">
              <v-col cols="12" md="4">
                <v-checkbox hide-details v-model="model.FlyingBaPo" label="2. účet pro létající BaPo" />
                <span class="text-caption ml-8">Jen pro poradce KB</span>
              </v-col>
              <v-col cols="12" md="4">
                <v-text-field v-model="model.Domain" label="Doména" maxlength="2" />
              </v-col>
              <v-col cols="12" md="4">
                <v-text-field v-model="model.Login" label="Login" maxlength="20" />
              </v-col>
            </v-row>
          </div>

          <!-- aplikace a jejich prava -->
          <v-expansion-panels accordion>
            <v-expansion-panel v-for="app in itemsEdit" :key="app.Id">
              <v-expansion-panel-header>{{ app.Name }}</v-expansion-panel-header>
              <v-expansion-panel-content>
                <div v-if="app.IsNew">
                  <v-checkbox
                    dense
                    hide-details
                    v-for="(perm, index) in app.Permissions"
                    :key="index"
                    :label="perm.Name"
                    :value="`${app.Id}_${perm.Code}`"
                    v-model="selection"
                  />
                </div>
                <v-radio-group dense hide-details :value="rdbInitValue(app.Id)" v-else>
                  <v-radio
                    dense
                    hide-details
                    v-for="(perm, index) in app.Permissions"
                    :key="index"
                    :label="perm.Name"
                    :value="perm.Code"
                    @change="rdbChange(app.Id, perm.Code)"
                  />
                </v-radio-group>

                <!-- specialni atribut -->
                <div v-if="hasAppAttribute(app.Id)" class="mt-6">
                  <v-text-field
                    filled
                    dense
                    label="Speciální atribut"
                    hide-details
                    style="max-width: 200px"
                    type="number"
                    maxlength="6"
                    v-model="app.AppAttribute"
                  />
                </div>
              </v-expansion-panel-content>
            </v-expansion-panel>
          </v-expansion-panels>
        </div>
      </v-slide-x-reverse-transition>
    </v-card>
  </div>
</template>

<script>
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
import { pmpAppsApi } from "@/code/apiServices";
import { UserRoles } from "@mpss/eporadce-common";

export default {
  name: "UserPermissions",

  mixins: [MixinResolveGeneralResult],

  data: () => ({
    model: null,
    itemsEdit: [],
    edit: false,
    selection: [],
    saveLoading: false,
    loaded: false
  }),

  async mounted() {
    this.model = await pmpAppsApi.GetPermissions(this.$store.state.userDetail.user.Id);

    if (this.isAdmin) {
      this.model.Applications.forEach((t) => {
        t.Permissions.forEach((x) => this.selection.push(`${t.Id}_${x.Code}`));
      });

      this.itemsEdit = await pmpAppsApi.GetApplications();

      this.model.Applications.filter((t) => t.AppAttribute).forEach((t) => {
        this.itemsEdit.find((x) => x.Id == t.Id).AppAttribute = t.AppAttribute;
      });
    }

    this.loaded = true;
  },

  computed: {
    isAdmin() {
      if (!this.$user.loaded) return false;

      return (
        (this.$user.isInRole(UserRoles.eAdminSales) &&
          (this.$store.state.userDetail.user.UserRoles & UserRoles.Sales) > 0) ||
        (this.$user.isInRole(UserRoles.eAdminEmployees) &&
          (this.$store.state.userDetail.user.UserRoles & UserRoles.Employee) > 0)
      );
    },

    showRemoveSync() {
      return (this.$store.state.userDetail.user.UserRoles & UserRoles.Sales) != 0;
    },

    showKbStuff() {
      return this.$store.state.userDetail.user.CPM.startsWith("1");
    }
  },

  methods: {
    hasAppAttribute(appId) {
      return process.env.VUE_APP_EFORMULARE_APPID == appId;
    },

    rdbInitValue(appId) {
      const s = appId.toString();
      const obj = this.selection.find((t) => t.substr(0, s.length + 1) == s + "_");
      if (obj) return Number(obj.substr(s.length + 1));
      return null;
    },

    rdbChange(appId, code) {
      const s = appId.toString();
      const idx = this.selection.findIndex((t) => t.substr(0, s.length + 1) == s + "_");
      if (idx !== -1) this.$delete(this.selection, idx);

      this.selection.push(`${appId}_${code}`);
    },

    // ulozit zmeny prav
    async save() {
      this.saveLoading = true;

      const list = [];

      // prava
      this.selection.forEach((t) => {
        const [appId, code] = t.split("_");
        const idx = list.findIndex((x) => x.AppId == appId);
        if (idx === -1) list.push({ AppId: Number(appId), Permissions: [Number(code)] });
        else list[idx].Permissions.push(Number(code));
      });

      // atributy
      this.itemsEdit
        .filter((t) => t.AppAttribute)
        .forEach((t) => {
          const index = list.findIndex((x) => x.AppId == t.Id);
          if (index === -1) list.push({ AppId: Number(appId), AppAttribute: Number(t.AppAttribute) });
          else list[index].AppAttribute = Number(t.AppAttribute);
        });

      const model = {
        Permissions: list,
        RemoveFromSync: this.model.RemoveFromSync,
        FlyingBaPo: this.model.FlyingBaPo,
        Domain: this.model.Domain,
        Login: this.model.Login
      };

      if (
        await this.resolveGeneralResult(
          await pmpAppsApi.SavePermissions(this.$store.state.userDetail.user.Id, model),
          "",
          "Změny byly uloženy",
          "Změny nebylo možné uložit"
        )
      ) {
        this.model = await pmpAppsApi.GetPermissions(this.$store.state.userDetail.user.Id);
      }

      this.saveLoading = false;
    }
  }
};
</script>
