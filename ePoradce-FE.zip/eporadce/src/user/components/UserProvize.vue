<template>
  <v-card>
    <v-card-text>
      <app-box-loader v-if="items === null" />

      <div v-else>
        <p>
          <strong> Výňatky jsou k dispozici na intranetu KB</strong>
        </p>

        <div>
          <v-select
            v-model="filter"
            :items="filterItems"
            label="Název koeficientu..."
            outlined
            dense
            clearable
            hide-details
          />
        </div>

        <v-simple-table>
          <template>
            <thead>
              <tr>
                <th class="text-left">Datum</th>
                <th class="text-left">Název</th>
                <th class="text-left">Koeficient</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in filteredItems" :key="index">
                <td>{{ item.Date | date }}</td>
                <td>{{ item.CoefficientName }}</td>
                <td>{{ item.CoefficientValue }}</td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </div>
    </v-card-text>
  </v-card>
</template>

<script>
import { usersExtendedApi } from "@/code/apiServices";

export default {
  name: "UserProvize",

  data() {
    return {
      items: null,
      filter: null,
      filterItems: null
    };
  },

  async mounted() {
    this.items = await usersExtendedApi.GetProvisions(this.$store.state.userDetail.user.Id);
    this.filterItems = [...new Set(this.items.map((t) => t.CoefficientName))];
  },

  computed: {
    filteredItems() {
      if (!this.filter) return this.items;
      return this.items.filter((t) => t.CoefficientName == this.filter);
    }
  }
};
</script>
