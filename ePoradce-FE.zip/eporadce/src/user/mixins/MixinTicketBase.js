import { ObjectTypes } from "@mpss/eporadce-common";
import { MixinUpdateModel, MixinValidateField } from "@mpss/eporadce-common-vue";

export default {
  mixins: [MixinValidateField, MixinUpdateModel],

  props: ["value", "validationErrors", "action"],

  computed: {
    objTypeTicket() {
      return ObjectTypes.Ticket;
    },

    hasParent() {
      return this.value.ParentId;
    }
  }
};
