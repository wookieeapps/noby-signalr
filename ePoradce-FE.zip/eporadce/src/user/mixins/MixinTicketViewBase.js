import { ObjectTypes } from "@mpss/eporadce-common";
import { UserRoles } from "@mpss/eporadce-common";

export default {
  props: ["model", "id", "showComparison", "type", "dense"],

  computed: {
    objTypeTicket() {
      return ObjectTypes.Ticket;
    },

    enableFileDelete() {
      return this.$user.isInRole(UserRoles.AppAdministrator);
    }
  }
};
