<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'UserListWithFilter' }" :validation-errors="validationErrors">
      <template #back>Zpět na seznam</template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <app-box-loader />
    </v-card>

    <div v-else>
      <v-row>
        <v-col cols="12">
          <v-card>
            <v-card-title
              ><span class="mr-2 text--secondary font-weight-regular" v-if="model.Title">{{ model.Title }}</span
              >{{ model.DisplayName }}</v-card-title
            >
            <v-divider />
            <v-card-text>
              <app-text-with-label label="Login" :text="model.CPM" />

              <app-text-with-label label="Email" text-type="email" :text="model.Email" />

              <app-text-with-label label="Mobil" text-type="tel" :text="model.Mobil" />
            </v-card-text>
          </v-card>
        </v-col>
      </v-row>

      <v-tabs class="mt-4" background-color="transparent" v-model="tab" grow>
        <v-tab>Aplikace</v-tab>
      </v-tabs>

      <v-tabs-items v-model="tab" style="background-color: transparent;">
        <v-tab-item :key="1">
          <user-permissions />
        </v-tab-item>
      </v-tabs-items>
    </div>
  </div>
</template>

<script>
import UserPermissions from "../components/UserPermissions.vue";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";

export default {
  name: "UserDetail",

  props: ["id"],

  mixins: [MixinResolveGeneralResult],

  components: {
    UserPermissions
  },

  data() {
    return {
      tab: null
    };
  },

  async mounted() {
    await this.$store.dispatch("userDetail/init", this.id);
  },

  beforeRouteUpdate(to, from, next) {
    this.$store.dispatch("userDetail/init", to.params.id).then((t) => {
      next();
    });
  },

  computed: {
    model() {
      return this.$store.state.userDetail.user;
    }
  }
};
</script>
