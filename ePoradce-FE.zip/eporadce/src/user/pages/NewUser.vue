<template>
  <div>
    <app-page-toolbar :back-to="{ name: 'UserListWithFilter' }" :validation-errors="validationErrors">
      <template v-slot:back>Zpět na seznam</template>
      <template v-slot:actions>
        <v-btn color="success" tile @click="saveUser" :loading="saveBtnLoading">Založit nového uživatele</v-btn>
      </template>
    </app-page-toolbar>

    <div>
      <v-card class="mb-4">
        <v-card-title>Založení nového uživatele</v-card-title>
        <v-divider />
        <v-card-text>
          <v-row>
            <v-col cols="12" md="6">
              <v-text-field label="ČPM" v-model="cpm" maxlength="8" :error-messages="validateField('CPM')" />

              <v-text-field label="IČP" v-model="icp" maxlength="9" :error-messages="validateField('ICP')" />
            </v-col>
            <v-col cols="12" md="6">
              <v-text-field
                label="Jméno"
                maxlength="40"
                v-model="firstname"
                :error-messages="validateField('Firstname')"
              />

              <v-text-field
                label="Příjmení"
                maxlength="40"
                v-model="surname"
                :error-messages="validateField('Surname')"
              />
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>
    </div>
  </div>
</template>

<script>
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
import { usersApi } from "../../code/apiServices";

export default {
  name: "NewUser",

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      firstname: "",
      surname: "",
      cpm: "",
      icp: ""
    };
  },

  methods: {
    async saveUser() {
      this.onBeforeSave();

      const result = await usersApi.Create({
        ICP: this.icp,
        CPM: this.cpm,
        Firstname: this.firstname,
        Surname: this.surname
      });

      if (await this.resolveGeneralResult(result, "", "Uživatel byl založen", "Uživatele nebylo možné založit")) {
        this.cpm = "";
        this.icp = "";
        this.firstname = "";
        this.surname = "";
      }
    }
  }
};
</script>
