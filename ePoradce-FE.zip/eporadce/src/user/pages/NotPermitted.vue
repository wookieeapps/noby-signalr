<template>
  <div>
    <v-card class="mb-4">
      <v-card-title>Chybějící práva</v-card-title>
      <v-divider />
      <v-card-text>
        <v-alert dense border="left" type="error"> Na zobrazení tohoto uživatele nemáte právo. </v-alert>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
export default {
  name: "NotPermitted"
};
</script>