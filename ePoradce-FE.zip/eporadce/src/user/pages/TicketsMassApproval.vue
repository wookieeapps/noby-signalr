<template>
  <div>
    <v-card class="mb-4">
      <v-card-title>Ticketing - rychlé schvalování</v-card-title>
      <v-divider />
      <v-card-text>
        <v-alert dense text type="info" class="mb-0">
          Kliknutím na <v-icon color="success" small>thumb_up</v-icon> okamžitě příslušný ticket schválíte bez nutnosti
          přecházet na detail uživatele. Analogicky kliknutím na <v-icon color="error" small>thumb_down</v-icon> ticket
          zamítnete.
        </v-alert>
      </v-card-text>
    </v-card>

    <v-card v-if="items === null">
      <app-box-loader />
    </v-card>

    <v-alert type="warning" class="mt-7" v-else-if="items.length === 0">Nemáte žádné tickety na schválení.</v-alert>

    <div v-else>
      <div v-for="(group, index) in items" :key="index">
        <v-subheader v-if="items.length > 1">{{ group.GroupName }}</v-subheader>
        <v-slide-y-transition group>
          <v-card class="mb-4" v-for="ticket in group.Tickets" :key="ticket.Id">
            <v-card-text>
              <v-row>
                <v-col cols="12" md="4">
                  <div>
                    <strong class="mr-3 primary--text">{{ ticket.TypeText }}</strong>
                    <span v-if="ticket.ParentId" color="grey lighten-2"
                      >#{{ ticket.ParentId }} <v-icon x-small>forward</v-icon>
                    </span>
                    <span>#{{ ticket.Id }}</span>
                  </div>
                  <div class="mb-2">
                    <strong>{{ ticket.DisplayName }}</strong
                    ><br />{{ ticket.CPM }} / {{ ticket.ICP }}
                  </div>
                  <div class="caption">{{ ticket.InsertTime | datetime }} {{ ticket.InsertUserName }}</div>
                </v-col>
                <v-col cols="12" md="6" class="mass-approval-ticket-content">
                  <component :is="ticket.Component" :model="ticket.Model" :type="ticket.Type" :id="ticket.Id" />
                  <div class="mt-1" v-if="ticket.Note">{{ ticket.Note }}</div>
                </v-col>
                <v-col cols="12" md="2" class="d-flex justify-sm-space-between justify-md-end align-center">
                  <v-btn outlined fab color="error" class="mr-4" @click="disapprove(ticket.Id)">
                    <v-icon>thumb_down</v-icon>
                  </v-btn>
                  <v-btn outlined large fab color="success" @click="approve(ticket.Id)">
                    <v-icon>thumb_up</v-icon>
                  </v-btn>
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </v-slide-y-transition>
      </div>
    </div>

    <!-- upload/roztrideni souboru -->
    <tickets-dialog-files
      v-model="filesDialogId"
      :user-id="filesDialogUserId"
      :key="`dlgFl${filesDialogId}`"
      v-if="filesDialogId"
    />
  </div>
</template>

<script>
import TicketsDialogFiles from "../components/TicketsDialogFiles.vue";
import { ticketsApi } from "@/code/apiServices";
import components from "@/user/components/Tickets";

export default {
  name: "TicketsMassApproval",

  components: { ...components, TicketsDialogFiles },

  data() {
    return {
      items: null,

      // dialog archivace souboru
      filesDialogId: null,
      filesDialogUserId: null
    };
  },

  async mounted() {
    await this.init();
  },

  beforeRouteUpdate(to, from, next) {
    this.init().then((t) => {
      next();
    });
  },

  methods: {
    async init() {
      this.items = await ticketsApi.GetListForApprover();
    },

    // schvalit ticket
    async approve(ticketId) {
      this.filesDialogUserId = this.removeItem(ticketId);

      await ticketsApi.Approve(ticketId, "");

      this.$toast.success(`Ticket #${ticketId} byl schválen`);

      this.filesDialogId = ticketId;
    },

    // zamitnout ticket
    async disapprove(ticketId) {
      this.removeItem(ticketId);

      await ticketsApi.Disapprove(ticketId, "");

      this.$toast.info(`Ticket #${ticketId} byl smazán`);
    },

    removeItem(ticketId) {
      let index = -1;
      for (let i = 0; i < this.items.length; i++) {
        index = this.items[i].Tickets.findIndex((t) => t.Id === ticketId);
        if (index !== -1) {
          const userId = this.items[i].Tickets[index].UserId;

          if (this.items[i].Tickets.length === 1) {
            this.$delete(this.items, i);
          } else this.$delete(this.items[i].Tickets, index);

          return userId;
        }
      }
    }
  }
};
</script>