<template>
  <div>
    <app-page-toolbar :back-to="{ name: backLinkName }" :validation-errors="validationErrors">
      <template #back>Zpět na seznam</template>
      <template #actions>
        <!-- tisk -->
        <generate-user-docs :user-id="id" v-if="!isReadonly" />

        <!-- zalozeni ticketu -->
        <tickets-actions-list @action="createTicket" />
      </template>
    </app-page-toolbar>

    <v-card v-if="model === null">
      <app-box-loader />
    </v-card>

    <div v-else>
      <v-row>
        <v-col cols="12" sm="6">
          <v-card>
            <v-card-title>
              <span class="mr-2 text--secondary font-weight-regular" v-if="model.Title">{{ model.Title }}</span
              >{{ model.DisplayName }}
              <span class="ml-2 text--secondary font-weight-regular" v-if="model.Title2">{{ model.Title2 }}</span>
            </v-card-title>
            <v-divider />
            <v-card-text>
              <app-text-with-label label="ČPM / IČP">
                {{ model.CPM }}<span v-if="model.ICP"> / {{ model.ICP }}</span>
              </app-text-with-label>
              <app-text-with-label
                label="Datum narození"
                :text="model.BirthDate | date"
                v-if="fieldVisible('BirthDate')"
              />
              <app-text-with-label label="Pozice" v-if="model.PositionCode">
                <template> {{ model.PositionName }} ({{ model.PositionCode }}) </template>
              </app-text-with-label>
              <app-text-with-label label="Územní zařazení" :text="model.UserGroupCode" />
              <app-text-with-label label="Manažer distribuční sítě" v-if="model.ManagerName">
                <template> {{ model.ManagerName }} ({{ model.ManagerPositionCode }}) </template>
              </app-text-with-label>
              <app-text-with-label label="Email" text-type="email" :text="model.Email" />
              <app-text-with-label
                label-tooltip="Upozornění: veškerá e-mailová komunikace s klientem/potenciálním klientem a s MP je uskutečňována pouze prostřednictvím firemní emailové schránky MP, a to z důvodu dodržení bezpečnostních pravidel MP a ochrany osobních údajů"
                label="Email soukromý"
                text-type="email"
                :text="model.EmailPersonal"
              />
              <app-text-with-label label="Mobil" text-type="tel" :text="model.Mobil" />
            </v-card-text>
          </v-card>

          <!-- zobrazit vice informaci -->
          <v-slide-y-reverse-transition hide-on-leave>
            <div class="pt-3 mb-6 text-center" v-show="!showDetail">
              <v-btn tile small text @click="detail(true)"><v-icon>unfold_more</v-icon>Zobrazit více informací</v-btn>
            </div>
          </v-slide-y-reverse-transition>

          <v-slide-y-transition>
            <div v-show="showDetail" class="mt-3 mb-3">
              <user-extended-detail />

              <!-- skryt detail -->
              <div class="mt-3 mb-6 text-center" v-show="showDetail">
                <v-btn tile small text @click="detail(false)"><v-icon>unfold_less</v-icon>Skrýt více informací</v-btn>
              </div>
            </div>
          </v-slide-y-transition>
        </v-col>

        <v-col cols="12" sm="6">
          <tickets-list
            :id="id"
            ref="elTicketsList"
            @editTicket="editTicket"
            @approved="openFilesDialog"
            :key="`tickets${id}`"
          />
        </v-col>
      </v-row>

      <v-tabs class="mt-4" background-color="transparent" v-model="tab" grow>
        <v-tab v-if="tabVisible(1)">Oprávnění</v-tab>
        <v-tab v-if="tabVisible(2)">Provize</v-tab>
        <v-tab v-if="tabVisible(3)">Aplikace</v-tab>
        <v-tab v-if="tabVisible(4)">Školení</v-tab>
        <v-tab v-if="tabVisible(5)">Archiv</v-tab>
        <v-tab v-if="tabVisible(6)">Checklist</v-tab>
      </v-tabs>

      <v-tabs-items v-model="tab" style="background-color: transparent">
        <v-tab-item :key="1" v-if="tabVisible(1)">
          <user-mandates />
        </v-tab-item>
        <v-tab-item :key="2" v-if="tabVisible(2)">
          <user-provize />
        </v-tab-item>
        <v-tab-item :key="3" v-if="tabVisible(3)">
          <user-permissions />
        </v-tab-item>
        <v-tab-item :key="4" v-if="tabVisible(4)">
          <user-course-events />
        </v-tab-item>
        <v-tab-item :key="5" v-if="tabVisible(5)">
          <user-archive :readonly="isReadonly" />
        </v-tab-item>
        <v-tab-item :key="6" v-if="tabVisible(6)">
          <user-checklist :readonly="isReadonly" />
        </v-tab-item>
      </v-tabs-items>
    </div>

    <tickets-dialog
      v-model="ticketDialog"
      :action.sync="ticketAction"
      :parent-id="ticketParentId"
      @ticketCreated="$refs.elTicketsList.reload()"
      @approved="openFilesDialog"
    />

    <tickets-dialog-files v-model="filesDialogId" :user-id="id" :key="`dlgFl${filesDialogKey}`" v-if="filesDialogId" />
  </div>
</template>

<script>
import TicketsList from "../components/TicketsList.vue";
import TicketsDialog from "../components/TicketsDialog.vue";
import TicketsDialogFiles from "../components/TicketsDialogFiles.vue";
import UserChecklist from "../components/UserChecklist.vue";
import UserExtendedDetail from "../components/UserExtendedDetail.vue";
import UserMandates from "../components/UserMandates.vue";
import UserProvize from "../components/UserProvize.vue";
import UserPermissions from "../components/UserPermissions.vue";
import UserCourseEvents from "../components/UserCourseEvents.vue";
import UserArchive from "../components/UserArchive.vue";
import { ObjectTypes, UserRolesGroups, UserRoles } from "@mpss/eporadce-common";
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
import TicketsActionsList from "../components/TicketsActionsList.vue";
import GenerateUserDocs from "../components/GenerateUserDocs.vue";

export default {
  name: "UserDetail",

  props: ["id"],

  mixins: [MixinResolveGeneralResult],

  components: {
    TicketsDialog,
    TicketsDialogFiles,
    TicketsList,
    UserChecklist,
    UserExtendedDetail,
    UserMandates,
    UserProvize,
    UserPermissions,
    UserArchive,
    TicketsActionsList,
    GenerateUserDocs,
    UserCourseEvents
  },

  data() {
    return {
      showDetail: false,
      tab: null,

      // ticketing
      ticketParentId: null,
      ticketDialog: false,
      ticketAction: null,

      // dialog archivace souboru
      filesDialogId: null,
      filesDialogKey: 0
    };
  },

  async mounted() {
    await this.$store.dispatch("userDetail/init", this.id);
    if (this.$store.state.userDetail.user === null) this.$router.push({ name: "NotPermitted" });

    // prisel s hashem v url
    if (window.location.hash) {
      if (window.location.hash.startsWith("#ticket-")) {
        const ticketId = Number(window.location.hash.substr(8));
        this.$refs.elTicketsList.loadDetail(ticketId);
      }
    }
  },

  beforeRouteEnter(to, from, next) {
    if (from.matched.length > 0) {
      from.matched[0].instances.default.$store.dispatch("userDetail/clean");
    }
    next();
  },

  beforeRouteUpdate(to, from, next) {
    this.initLocal();
    this.$store.dispatch("userDetail/init", to.params.id).then((t) => {
      if (this.$store.state.userDetail.user === null) next({ name: "NotPermitted" });
      else next();
    });
  },

  computed: {
    model() {
      return this.$store.state.userDetail.user;
    },

    isReadonly() {
      return !this.$store.state.userDetail.user || !this.$store.state.userDetail.user.IsActual;
    },

    backLinkName() {
      if (!this.$user.loaded) return "";
      if (this.$store.state.userDetail.user && !this.model.IsActual && this.$user.isInRole(UserRoles.HiringSupervisor))
        return "UserListDeleted";
      return this.$user.isInRoleGroup(UserRolesGroups.CanSearchInUsers) ? "UserListWithFilter" : "Dashboard";
    }
  },

  methods: {
    initLocal() {
      this.showDetail = false;
      this.tab = null;
      this.ticketParentId = null;
      this.ticketDialog = false;
      this.ticketAction = null;
      this.filesDialogId = null;
      this.filesDialogKey = 0;
    },

    fieldVisible(field) {
      switch (field) {
        case "BirthDate":
          return !this.$user.isInRole(UserRoles.SalesManager) || this.$user.instance.Id === this.model.Id;
      }
    },

    // nastaveni zobrazovani tabu podle role uzivatele
    tabVisible(index) {
      switch (index) {
        default:
          return true;
        case 3: // permissions
          return this.$user.isInRoles([UserRoles.HiringSupervisor, UserRoles.eAdminSales]) && this.model.IsActual;
        case 6: // checklist
          return this.$user.isInRoles([
            UserRoles.HiringSupervisor,
            UserRoles.HiringController,
            UserRoles.HiringApprovers904906,
            UserRoles.HiringApprovers903998
          ]);
      }
    },

    // zobrazeni detailu FP
    async detail(toShow) {
      this.showDetail = toShow;
      if (toShow) await this.$store.dispatch("userDetail/initDetail");
    },

    // editovat ticket - admin muze upravit existujici ticket vytvorenim noveho
    editTicket(ticketId, action) {
      this.createTicket(action, ticketId);
    },

    // vytvoreni noveho ticketu
    createTicket(action, parentId) {
      this.ticketParentId = parentId;
      this.ticketAction = action;
      this.ticketDialog = true;
    },

    // zobrazit dialog pro archivaci souboru
    openFilesDialog(id) {
      this.filesDialogKey += 1;
      this.filesDialogId = id;
    }
  }
};
</script>
