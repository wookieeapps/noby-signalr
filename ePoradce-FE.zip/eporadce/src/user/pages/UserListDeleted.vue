<template>
  <v-card>
    <v-card-title>Seznam ukončených uživatelů</v-card-title>
    <v-divider />

    <query-builder v-model="queryFilter" ident="users-deleted" @input="onQueryChange" />

    <v-data-table
      v-model="selected"
      :headers="headers"
      :items="items"
      :options.sync="options"
      :server-items-length="total"
      :loading="loading"
      :items-per-page="itemsPerPage"
      item-key="UserId"
      @update:sort-by="getData"
      @update:sort-desc="getData"
      @update:page="getData"
      :footer-props="{
        showFirstLastPage: true,
        disableItemsPerPage: true,
        itemsPerPageOptions: [itemsPerPage]
      }"
    >
      <template #loading>
        <div class="pa-12">Nahrávám data...</div>
      </template>

      <template #no-data>
        <div class="pa-12">Filtru neodpovídají žádné záznamy</div>
      </template>

      <template v-slot:item.actions="{ item }">
        <v-btn icon exact :to="{ name: 'UserDetail', params: { id: item.Id } }">
          <v-icon small>edit</v-icon>
        </v-btn>
      </template>
    </v-data-table>
  </v-card>
</template>

<script>
import { UserRoles } from "@mpss/eporadce-common";
import { QueryBuilder } from "@mpss/eporadce-common-vue";
import { usersApi } from "@/code/apiServices";

export default {
  name: "UserListDeleted",

  components: { QueryBuilder },

  data() {
    return {
      // vychozi pocet zaznamu na strance gridu
      itemsPerPage: 15,

      akceMenu: false,

      // vychozi nastaveni filtru
      queryFilter: null,

      // celkem nalezenych radek podle zadaneho filtru
      total: 0,
      // loading state gridu
      loading: false,
      // nastaveni gridu
      options: { filters: null },

      // kolekce zaskrtnutych uzivatelu v gridu
      selected: [],

      // hlavicka gridu
      headers: [
        { text: "Příjmení, jméno", value: "Name" },
        { text: "ČPM", value: "CPM" },
        { text: "IČP", value: "ICP" },
        { text: "", value: "actions", sortable: false, align: "end" }
      ],
      // data/radky v gridu
      items: []
    };
  },

  async mounted() {
    // load default filter
    const userId = (await this.$user.get()).Id;
    this.queryFilter = await usersApi.GetMeta(userId, 3);
    if (this.queryFilter !== null) this.saveFilterToGrid();

    // initial data load
    await this.getData();
  },

  methods: {
    saveFilterToGrid() {
      this.options.filters = this.queryFilter.conditions;
      this.options.connector = this.queryFilter.conditionConnector;
    },

    onQueryChange() {
      // save filter to grid options
      this.saveFilterToGrid();

      // refresh data
      this.getData().then((t) => {});

      // save current filter
      this.$user.get().then((t) => {
        usersApi.SaveMeta(t.Id, 3, this.queryFilter).then((t) => {});
      });
    },

    // naplnit data do gridu podle zadaneho filtru
    async getData() {
      if (this.loading) return;
      this.loading = true;

      var model = await usersApi.GetListDeleted(this.options);
      this.total = model.TotalRows;
      this.items = model.Data;

      this.loading = false;
    }
  }
};
</script>
