<template>
  <v-card>
    <v-card-title class="justify-space-between">
      Seznam uživatelů
      <div>
        <v-menu v-model="akceMenu" :offset-y="true">
          <template v-slot:activator="{ on }">
            <v-btn color="primary" text tile v-on="on" :disabled="selected.length === 0">
              Provést akci
              <v-icon>keyboard_arrow_down</v-icon>
            </v-btn>
          </template>
          <v-list dense>
            <v-list-item>
              <v-list-item-icon />
              <v-list-item-title>Prvni akce</v-list-item-title>
            </v-list-item>
            <v-divider />
            <v-list-item>
              <v-list-item-icon>
                <v-icon>school</v-icon>
              </v-list-item-icon>
              <v-list-item-title>Prvni akce</v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-icon />
              <v-list-item-title>Prvni akce</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>

        <v-btn tile v-if="newBtnVisible" color="primary" :to="{ name: 'NewUser' }" class="ml-2"
          ><v-icon>add</v-icon>Nový</v-btn
        >
      </div>
    </v-card-title>
    <v-divider />

    <query-builder v-model="queryFilter" ident="users-general" @input="onQueryChange" />

    <v-data-table
      v-model="selected"
      :headers="headers"
      :items="items"
      :options.sync="options"
      :server-items-length="total"
      :loading="loading"
      :items-per-page="itemsPerPage"
      item-key="UserId"
      show-select
      @update:sort-by="getData"
      @update:sort-desc="getData"
      @update:page="getData"
      :footer-props="{
        showFirstLastPage: true,
        disableItemsPerPage: true,
        itemsPerPageOptions: [itemsPerPage]
      }"
    >
      <template #loading>
        <div class="pa-12">Nahrávám data...</div>
      </template>

      <template #no-data>
        <div class="pa-12">Filtru neodpovídají žádné záznamy</div>
      </template>

      <template v-slot:item.actions="{ item }">
        <v-btn
          icon
          exact
          :to="{ name: (item.Roles & 16384) > 0 ? 'EmployeeDetail' : 'UserDetail', params: { id: item.Id } }"
        >
          <v-icon small>edit</v-icon>
        </v-btn>
      </template>
    </v-data-table>
  </v-card>
</template>

<script>
import { UserRoles } from "@mpss/eporadce-common";
import { QueryBuilder } from "@mpss/eporadce-common-vue";
import { usersApi } from "@/code/apiServices";

export default {
  name: "UserListWithFilter",

  components: { QueryBuilder },

  data() {
    return {
      // vychozi pocet zaznamu na strance gridu
      itemsPerPage: 15,

      akceMenu: false,

      // vychozi nastaveni filtru
      queryFilter: null,

      // celkem nalezenych radek podle zadaneho filtru
      total: 0,
      // loading state gridu
      loading: false,
      // nastaveni gridu
      options: { filters: null },

      // kolekce zaskrtnutych uzivatelu v gridu
      selected: [],

      // hlavicka gridu
      headers: [
        { text: "Příjmení, jméno", value: "Name" },
        { text: "ČPM", value: "CPM" },
        { text: "IČP", value: "ICP" },
        { text: "", value: "actions", sortable: false, align: "end" }
      ],
      // data/radky v gridu
      items: []
    };
  },

  async mounted() {
    // load default filter
    const userId = (await this.$user.get()).Id;
    this.queryFilter = await usersApi.GetMeta(userId, 1);
    if (this.queryFilter !== null) this.saveFilterToGrid();

    // initial data load
    await this.getData();
  },

  computed: {
    newBtnVisible() {
      return this.$user.isInRole(UserRoles.eAdminSales);
    }
  },

  methods: {
    saveFilterToGrid() {
      this.options.filters = this.queryFilter.conditions;
      this.options.connector = this.queryFilter.conditionConnector;
    },

    onQueryChange() {
      // save filter to grid options
      this.saveFilterToGrid();

      // refresh data
      this.getData().then((t) => {});

      // save current filter
      this.$user.get().then((t) => {
        usersApi.SaveMeta(t.Id, 1, this.queryFilter).then((t) => {});
      });
    },

    // naplnit data do gridu podle zadaneho filtru
    async getData() {
      if (this.loading) return;
      this.loading = true;

      var model = await usersApi.GetList(this.options);
      this.total = model.TotalRows;
      this.items = model.Data;

      this.loading = false;
    }
  }
};
</script>
