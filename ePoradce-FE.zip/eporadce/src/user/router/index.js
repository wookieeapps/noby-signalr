const UserDetail = () => import(/* webpackChunkName: "UserDetail" */ "../pages/UserDetail.vue");
const NewUser = () => import(/* webpackChunkName: "NewUser" */ "../pages/NewUser.vue");
const EmployeeDetail = () => import(/* webpackChunkName: "UserDetail" */ "../pages/EmployeeDetail.vue");
const UserListWithFilter = () => import(/* webpackChunkName: "UserList" */ "../pages/UserListWithFilter.vue");
const UserListDeleted = () => import(/* webpackChunkName: "UserList" */ "../pages/UserListDeleted.vue");
const TicketsMassApproval = () =>
  import(/* webpackChunkName: "TicketsMassApproval" */ "../pages/TicketsMassApproval.vue");
const NotPermitted = () => import("../pages/NotPermitted.vue");

export default [
  {
    path: "/users",
    name: "UserListWithFilter",
    component: UserListWithFilter
  },
  {
    path: "/users-deleted",
    name: "UserListDeleted",
    component: UserListDeleted
  },
  {
    path: "/users/:id",
    name: "UserDetail",
    component: UserDetail,
    props: true
  },
  {
    path: "/new-users",
    name: "NewUser",
    component: NewUser
  },
  {
    path: "/not-permitted",
    name: "NotPermitted",
    component: NotPermitted
  },
  {
    path: "/employee/:id",
    name: "EmployeeDetail",
    component: EmployeeDetail,
    props: true
  },
  {
    path: "/tickets-mass-approval",
    name: "TicketsMassApproval",
    component: TicketsMassApproval
  }
];
