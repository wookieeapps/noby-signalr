import { usersApi, ticketsApi, usersExtendedApi, fileInfoApi } from "@/code/apiServices";
import { checklistsApi, attributesApi } from "@/hiring/code/apiServicesHiring";
import { ObjectTypes } from "@mpss/eporadce-common";

export default {
  namespaced: true,

  state: {
    user: null,
    p2attributes: null,
    detail: null,
    ticketActionsList: null,
    files: null,

    attributes: null,
    checklists: null
  },

  actions: {
    async init({ state, dispatch }, userId) {
      dispatch("clean");

      // instance uzivatele
      try {
        state.user = await usersApi.Get(userId);

        // seznam moznych akci ticketingu
        state.ticketActionsList = await ticketsApi.GetListOfActions(state.user.Id);
      } catch {
        state.user = null;
      }
    },

    async initDetail({ state }) {
      if (state.detail === null) {
        // jen pokud ma m04id
        if (state.user.m04ID) state.p2attributes = await usersExtendedApi.GetP2Attributes(state.user.Id);

        state.detail = await usersExtendedApi.GetDetail(state.user.Id);
      }
    },

    async initChecklist({ state }) {
      // checklisty
      const list = await checklistsApi.GetList(state.user.Id);
      list.forEach((t) => {
        if (t.HasRequest) t.RequestNoteReadonly = true;
      });
      state.checklists = list;

      // atributy
      state.attributes = await attributesApi.GetList(state.user.Id);
    },

    async initFiles({ state }, refresh) {
      if ((!refresh && state.files !== null) || !state.user) return;

      const result = await fileInfoApi.GetList(ObjectTypes.User, state.user.Id, 0, 999);
      state.files = result.Data || [];
    },

    clean({ state }) {
      state.user = null;
      state.ticketActionsList = null;
      state.detail = null;
      state.p2attributes = null;
      state.attributes = null;
      state.checklist = null;
      state.files = null;
    }
  }
};
