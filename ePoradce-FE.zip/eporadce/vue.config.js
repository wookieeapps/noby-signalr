//const BundleAnalyzerPlugin = require("webpack-bundle-analyzer").BundleAnalyzerPlugin;

module.exports = {
  publicPath: process.env.VUE_APP_FRONTEND_BASE_PATH,

  transpileDependencies: ["vuetify"],

  devServer: {
    open: false,
    https: true,
    noInfo: true,
    stats: "minimal"
  },

  configureWebpack: {
    plugins: [
      //new BundleAnalyzerPlugin()
    ]
  },

  chainWebpack: (config) => {
    config.plugin("define").tap((args) => {
      // read version
      let v = JSON.stringify(require("./package.json").version);
      args[0]["process.env"]["VERSION"] = v;
      return args;
    });
  }
};
