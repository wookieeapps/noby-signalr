
cd eporadce-common
call npm install
call npm run build

cd ../eporadce-common-api
call npm install
call link.bat
call npm run build

cd ../eola-api
call npm install
call link.bat
call npm run build

cd ../hiring-api
call npm install
call link.bat
call npm run build

cd ../eporadce-common-vue
call npm install
call link.bat
call npm run build

PAUSE