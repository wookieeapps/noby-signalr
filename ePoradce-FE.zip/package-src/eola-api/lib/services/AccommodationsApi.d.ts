import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { AccommodationTypes } from "../Enums";
import IAccommodation from "../types/IAccommodation";
export default class AccommodationApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    CreateEmptyModel(): IAccommodation;
    /**
     * Seznam ubytovani
     * @param accommodationType typ ubytovani
     * @param requireId  vrati polozku podle id, i kdyz je smazana nebo v jinem typu ubytovani
     */
    GetList(accommodationType: AccommodationTypes | undefined, requireIds: Array<number> | null): Promise<Array<IAccommodation>>;
    /**
     * Vrati ubytovani podle id
     * @param accommodationId
     */
    Get(accommodationId: number): Promise<IAccommodation>;
    /**
     * Zalozi novy a vrati id
     * @param accommodationModel
     */
    Create(accommodationModel: IAccommodation): Promise<number>;
    /**
     * Upraveni zaznamu
     * @param accommodationModel
     * @param accommodationId
     */
    Edit(accommodationModel: IAccommodation, accommodationId: number): Promise<any>;
    Delete(accommodationId: number): Promise<any>;
}
