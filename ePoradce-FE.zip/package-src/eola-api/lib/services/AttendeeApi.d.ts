import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { IAttendeeHistory, ICourseSequenceSignin } from "../types";
export default class CourseEventApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    AttendeeHistory(userId: number): Promise<Array<IAttendeeHistory>>;
    AttendeeCourseSequence(userId: number): Promise<Array<ICourseSequenceSignin>>;
}
