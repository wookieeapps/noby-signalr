import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { Types as CommonTypes } from "@mpss/eporadce-common-api";
import { IAttendee, ICourseEvent, ICourseEventList, ISearchAttendee, IAttendeeEvent, ICourseSequenceSignin } from "../types";
export default class CourseEventApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    CreateEmptyModel(): ICourseEvent;
    CreateAttendeeEventList(model: Array<ICourseSequenceSignin>): Array<IAttendeeEvent>;
    /**
     * Plny detail terminu kurzu
     * @param courseEventId ID terminu
     */
    Get(courseEventId: number): Promise<ICourseEvent>;
    /**
     * Detail terminu kurzu pro editaci
     * @param courseEventId ID terminu
     */
    GetEdit(courseEventId: number): Promise<ICourseEvent>;
    /**
     * Ulozeni noveho terminu
     * @param courseEventEditCompositeModel instance kurzu
     * @returns ID nove zalozeneho kurzu
     */
    Create(courseEventEditCompositeModel: ICourseEvent): Promise<number>;
    /**
     * Editace existujiciho terminu
     * @param courseEventModel instance terminu
     * @param courseEventId ID editovaneho terminu
     */
    Edit(courseEventModel: ICourseEvent, courseEventId: number): Promise<any>;
    /**
     * Smazani terminu
     * @param courseEventId ID terminu
     */
    Delete(courseEventId: number): Promise<any>;
    /**
     * Vraci strankovatelny seznam terminu kurzu podle zadaneho filtru
     * @param filter nastaveni filtru
     * @returns seznam
     */
    GetList(filter: any): Promise<CommonTypes.IPaginableResult<ICourseEventList>>;
    SearchAttendees(search: string, courseEventId: number): Promise<Array<ISearchAttendee>>;
    SaveAttendees(model: Array<IAttendee>, courseEventId: number): Promise<any>;
    /**
     * Tisk
     * @param docType Druh souboru
     * @returns URL vygenerovaneho souboru
     */
    GenerateDoc(courseEventId: number, docType: string): Promise<string>;
    /**
   * Tisk pro konkréniho uživatele
   * @param docType Druh souboru
   * @param userId Id uživatele
   * @returns URL vygenerovaneho souboru
   */
    GenerateDocForUser(courseEventId: number, userId: number, docType: string): Promise<string>;
    SaveEvaluation(model: Array<IAttendee>, closeEvaluation: boolean, courseEventId: number): Promise<any>;
    SearchEvents(courseId: number, afterDate: any): Promise<Array<ISearchAttendee>>;
    SaveAttendeeEvents(model: Array<IAttendeeEvent>, userId: number): Promise<any>;
}
