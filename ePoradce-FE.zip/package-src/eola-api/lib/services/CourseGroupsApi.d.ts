import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { ICourseGroupEdit, ICourseGroup, ICourseGroupTree } from "../types";
export default class CourseGroupsApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    CreateEmptyModel(): ICourseGroup;
    /**
     * Vraci detail skupiny kurzu
     * @param courseGroupId ID skupiny
     * @returns instance skupiny nebo NULL
     */
    Get(courseGroupId: number): Promise<ICourseGroup>;
    /**
     * Vraci strom skupin kurzu vcetne kurzu zarazenych ve skupinach
     * @returns instance skupiny nebo NULL
     */
    GetTree(includeCourses: boolean, ommitGroupId?: number): Promise<Array<ICourseGroupTree>>;
    /**
   * Smazat podřízených skupin
   * @param parentId ID skupiny
   */
    GetChild(parentId: number): Promise<any>;
    /**
     * Smazat skupinu
     * @param courseGroupId ID skupiny
     */
    Delete(courseGroupId: number): Promise<any>;
    /**
     * Zalozeni nove skupiny kurzu
     * @param courseGroupModel instance skupiny
     * @returns ID nove zalozene skupiny
     */
    Create(courseGroupModel: ICourseGroupEdit): Promise<number>;
    /**
     * Ulozeni existujici skupiny kurzu
     * @param courseGroupModel instance skupiny
     * @param courseGroupId ID editovane skupiny
     */
    Edit(courseGroupModel: ICourseGroupEdit, courseGroupId: number): Promise<any>;
}
