import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { ICourseSequence, ICourseWithGroup } from "../types";
export default class CourseSequenceApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    CreateEmptyModel(): ICourseSequence;
    /**
     * Update poradi kurzu v sekvenci
     * @param id List Course2CourseSequenceId v novem poradi
     */
    UpdateOrder(id: Array<number>): Promise<any>;
    /**
     * Vraci seznam kurzu v sekvenci
     * @param sequenceId ID sekvence
     * @returns list kurzu nebo []
     */
    GetCourses(sequenceId: number): Promise<Array<ICourseWithGroup>>;
    /**
     * Vraci detail sekvence
     * @param sequenceId ID sekvence
     * @returns instance sekvence nebo NULL
     */
    Get(sequenceId: number): Promise<ICourseSequence>;
    /**
     * Vraci seznam sekvenci
     * @returns instance sekvence nebo NULL
     */
    GetList(): Promise<Array<ICourseSequence>>;
    /**
     * Smazat sekvenci
     * @param sequenceId ID sekvence
     */
    Delete(sequenceId: number): Promise<any>;
    /**
     * Zalozeni nove sekvence
     * @param sequenceModel instance sekvence
     * @returns ID nove zalozene sekvence
     */
    Create(sequenceModel: ICourseSequence): Promise<number>;
    /**
     * Ulozeni existujici sekvence
     * @param sequenceModel instance sekvence
     * @param sequenceId ID editovane sekvence
     */
    Edit(sequenceModel: ICourseSequence, sequenceId: number): Promise<any>;
}
