import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { ICourseList, ICourse } from "../types";
export default class CoursesApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    CreateEmptyModel(courseGroupId?: number): ICourse;
    /**
     * Seznam kurzu v dane skupine kurzu
     * @param courseGroupId ID nadrizene skupiny kurzu
     */
    GetList(courseGroupId: number | null, requireId: number | null): Promise<Array<ICourseList>>;
    /**
     * Detail kurzu
     * @param courseId ID kurzu
     * @returns instance kurzu nebo NULL
     */
    Get(courseId: number): Promise<ICourse>;
    /**
     * Ulozeni noveho kurzu
     * @param courseModel instance kurzu
     * @returns ID nove zalozeneho kurzu
     */
    Create(courseModel: ICourse): Promise<number>;
    /**
     * Editace existujiciho kurzu
     * @param courseModel instance kurzu
     * @param courseId ID editovaneho kurzu
     */
    Edit(courseModel: ICourse, courseId: number): Promise<any>;
    /**
     * Smazat nebo archivovat kurz - podle toho, zda ma nastaveny atribut IsArchived
     * @param courseId ID kurzu
     */
    Delete(courseId: number): Promise<any>;
}
