export default interface IAttendeeEvent {
    CourseEventId: number;
    SignupNote: string;
    PrivateNote: string;
    WithAccommodation: boolean;
}
