import { EvaluationTypes, CertificateTypes } from "../Enums";
export default interface ICourseEvent {
    CourseId: number | null;
    TimeFrom: Date | null;
    TimeTo: Date | null;
    SignupDeadline: Date | null;
    SignoutDeadline: Date | null;
    MinAttendees: number | null;
    MaxAttendees: number | null;
    IsDraft: boolean;
    AccommodationId: number | null;
    AccommodationDescription: string;
    TrainingRoomId: number | null;
    TrainingRoomDescription: string;
    Description: string;
    EvaluationType: EvaluationTypes;
    CertificateType: CertificateTypes;
    EvaluationClosed: boolean;
}
