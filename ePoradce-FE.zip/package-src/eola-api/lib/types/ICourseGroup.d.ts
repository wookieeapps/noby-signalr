import { ICourseGroupEdit } from ".";
export default interface ICourseGroup extends ICourseGroupEdit {
    Id: number;
}
