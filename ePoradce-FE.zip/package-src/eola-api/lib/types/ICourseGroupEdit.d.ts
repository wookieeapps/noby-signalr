export default interface ICourseGroupEdit {
    Name: string;
    /**
     * ID nadrizene skupiny nebo NULL
     */
    ParentId?: number | null;
}
