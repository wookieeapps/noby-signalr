export default interface ICourseGroupTree {
    Id: number;
    Name: string;
    Desc: string;
    IsArchived: boolean;
    Children: Array<ICourseGroupTree> | null;
}
