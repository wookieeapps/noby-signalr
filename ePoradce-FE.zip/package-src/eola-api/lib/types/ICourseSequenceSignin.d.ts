import { ICourseSignin } from ".";
export default interface ICourseSequenceSignin {
    Id: number;
    Name: string;
    SigninCount: number;
    Courses: Array<ICourseSignin>;
}
