import { ISearchEvent } from ".";
export default interface ICourseSignin {
    Id: number;
    Name: string;
    PrevCourseId?: number;
    NextCourseId?: number;
    CourseEventId?: number;
    CourseEventAttendeeId?: number;
    WithAccommodation: boolean;
    SignupNote: string;
    PrivateNote: string;
    TimeFrom?: any;
    SignoutDeadline?: any;
    AccommodationId?: number;
    Accommodation: string;
    AccommodationDescription: string;
    TrainingRoom: string;
    TrainingRoomDescription?: string;
    CourseEvents: Array<ISearchEvent> | null;
    Active: boolean;
    Disabled: boolean;
}
