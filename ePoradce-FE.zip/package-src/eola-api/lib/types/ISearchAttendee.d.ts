export default interface ISearchAttendee {
    Id: number;
    Name: string;
    Cpm: string;
    Enabled: boolean;
}
