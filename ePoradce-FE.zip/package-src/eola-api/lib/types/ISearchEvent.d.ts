export default interface ISearchEvents {
    Id: number;
    TimeFrom?: any;
    SignupDeadline?: any;
    AccommodationId?: number;
    Accommodation?: string;
    TrainingRoom?: string;
}
