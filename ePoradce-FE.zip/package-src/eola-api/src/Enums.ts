export enum EvaluationTypes {
  PouzeUcast = 1,
  Scale1to5 = 2,
  YesNoNotmet = 3,
  ProductA = 4,
  ProductB = 5,
  ProductC = 6
}

export enum AccommodationTypes {
  CourseEvent = 1,
  TrainingRoom = 2,
  Employee = 4
}

export enum CertificateTypes {
  None = 0
}
