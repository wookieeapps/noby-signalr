import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { AccommodationTypes } from "../Enums";
import IAccommodation from "../types/IAccommodation";

export default class AccommodationApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "eola/accommodations");
  }

  CreateEmptyModel(): IAccommodation {
    return {
      Id: 0,
      Name: "",
      AccommodationTypes: [],
      City: "",
      Contact: "",
      Street: "",
      Zip: "",
      IsActual: true
    };
  }

  /**
   * Seznam ubytovani
   * @param accommodationType typ ubytovani
   * @param requireId  vrati polozku podle id, i kdyz je smazana nebo v jinem typu ubytovani
   */
  async GetList(
    accommodationType: AccommodationTypes | undefined,
    requireIds: Array<number> | null
  ): Promise<Array<IAccommodation>> {
    return (
      await this.axiosInstance.get(this.basePath, {
        params: { accommodationTypes: accommodationType, requireIds: requireIds }
      })
    ).data;
  }

  /**
   * Vrati ubytovani podle id
   * @param accommodationId
   */
  async Get(accommodationId: number): Promise<IAccommodation> {
    return (await this.axiosInstance.get(`${this.basePath}/${accommodationId}`)).data;
  }

  /**
   * Zalozi novy a vrati id
   * @param accommodationModel
   */
  async Create(accommodationModel: IAccommodation): Promise<number> {
    return (await this.axiosInstance.post(this.basePath, accommodationModel)).data;
  }

  /**
   * Upraveni zaznamu
   * @param accommodationModel
   * @param accommodationId
   */
  async Edit(accommodationModel: IAccommodation, accommodationId: number) {
    return (await this.axiosInstance.put(`${this.basePath}/${accommodationId}`, accommodationModel)).data;
  }

  async Delete(accommodationId: number) {
    return (await this.axiosInstance.delete(`${this.basePath}/${accommodationId}`)).data;
  }
}
