import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { BaseApiService, DateHelpers } from "@mpss/eporadce-common";
import { Types as CommonTypes } from "@mpss/eporadce-common-api";
import {
  IAttendee,
  ICourseEvent,
  ICourseEventList,
  ISearchAttendee,
  IAttendeeHistory,
  ICourseSequenceSignin
} from "../types";
import { EvaluationTypes, CertificateTypes } from "../Enums";

export default class CourseEventApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "eola/attendee");
  }

  /*
   * historie skoleni uzivatele
   */
  async AttendeeHistory(userId: number): Promise<Array<IAttendeeHistory>> {
    return this.resolveResponse(await this.axiosInstance.get(this.basePath + `/${userId}/history`));
  }

  /*
   * vyber skoleni pro uzivatele
   */
  async AttendeeCourseSequence(userId: number): Promise<Array<ICourseSequenceSignin>> {
    return (
      await this.axiosInstance.get(this.basePath + `/${userId}/sequence`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): Array<ICourseSequenceSignin> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: ICourseSequenceSignin): void => {
              t.Courses.forEach((c) => {
                c.Active = false;
                c.CourseEvents = [];
                c.Disabled = false;
              });
            });
            return data;
          }
          return null;
        })
      })
    ).data;
  }
}
