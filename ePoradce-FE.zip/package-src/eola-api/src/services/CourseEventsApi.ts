import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { BaseApiService, DateHelpers } from "@mpss/eporadce-common";
import { Types as CommonTypes } from "@mpss/eporadce-common-api";
import {
  IAttendee,
  ICourseEvent,
  ICourseEventList,
  ISearchAttendee,
  IAttendeeEvent,
  ICourseSequenceSignin
} from "../types";
import { EvaluationTypes, CertificateTypes } from "../Enums";

export default class CourseEventApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "eola/course-events");
  }

  CreateEmptyModel(): ICourseEvent {
    return {
      CourseId: null,
      TimeFrom: null,
      TimeTo: null,
      MinAttendees: null,
      MaxAttendees: null,
      SignupDeadline: null,
      SignoutDeadline: null,
      IsDraft: false,
      AccommodationId: null,
      AccommodationDescription: "",
      TrainingRoomId: null,
      TrainingRoomDescription: "",
      Description: "",
      EvaluationType: EvaluationTypes.PouzeUcast,
      CertificateType: CertificateTypes.None,
      EvaluationClosed: false
    };
  }

  CreateAttendeeEventList(model: Array<ICourseSequenceSignin>): Array<IAttendeeEvent> {
    const arr: Array<IAttendeeEvent> = [];
    model.forEach((s) =>
      s.Courses.forEach((c) => {
        if (c.CourseEventId && c.CourseEventAttendeeId == null) {
          const item: IAttendeeEvent = {
            CourseEventId: c.CourseEventId,
            WithAccommodation: c.WithAccommodation,
            PrivateNote: c.PrivateNote,
            SignupNote: c.SignupNote
          };
          arr.push(item);
        }
      })
    );

    return arr;
  }

  /**
   * Plny detail terminu kurzu
   * @param courseEventId ID terminu
   */
  async Get(courseEventId: number): Promise<ICourseEvent> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/${courseEventId}`));
  }

  /**
   * Detail terminu kurzu pro editaci
   * @param courseEventId ID terminu
   */
  async GetEdit(courseEventId: number): Promise<ICourseEvent> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/${courseEventId}/edit`));
  }

  /**
   * Ulozeni noveho terminu
   * @param courseEventEditCompositeModel instance kurzu
   * @returns ID nove zalozeneho kurzu
   */
  async Create(courseEventEditCompositeModel: ICourseEvent): Promise<number> {
    return this.resolveResponse(await this.axiosInstance.post(this.basePath, courseEventEditCompositeModel));
  }

  /**
   * Editace existujiciho terminu
   * @param courseEventModel instance terminu
   * @param courseEventId ID editovaneho terminu
   */
  async Edit(courseEventModel: ICourseEvent, courseEventId: number) {
    return this.resolveResponse(
      await this.axiosInstance.put(`${this.basePath}/${courseEventId}/edit`, courseEventModel)
    );
  }

  /**
   * Smazani terminu
   * @param courseEventId ID terminu
   */
  async Delete(courseEventId: number) {
    return this.resolveResponse(await this.axiosInstance.delete(`${this.basePath}/${courseEventId}`));
  }

  /**
   * Vraci strankovatelny seznam terminu kurzu podle zadaneho filtru
   * @param filter nastaveni filtru
   * @returns seznam
   */
  async GetList(filter: any): Promise<CommonTypes.IPaginableResult<ICourseEventList>> {
    return this.resolveResponse(
      await this.axiosInstance.post(this.basePath + "/search", filter, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): CommonTypes.IPaginableResult<ICourseEventList> | null {
          if (data && Array.isArray(data.Data)) {
            data.Data.forEach((t: ICourseEventList) => {
              if (t.TimeFrom) {
                const timeFrom = DateHelpers.parseISO(t.TimeFrom);
                if (timeFrom) t.TimeFrom = DateHelpers.formatDatetime(timeFrom);
              }
              if (t.SignupDeadline) {
                const signup = DateHelpers.parseISO(t.SignupDeadline);
                if (signup) t.SignupDeadline = DateHelpers.formatDatetime(signup);
              }
            });
            return data;
          }
          return data;
        })
      })
    );
  }

  /*
   * vyhledavani uzivatelu pro pridani do terminu
   */
  async SearchAttendees(search: string, courseEventId: number): Promise<Array<ISearchAttendee>> {
    return this.resolveResponse(
      await this.axiosInstance.get(this.basePath + "/search-attendees", { params: { courseEventId, search } })
    );
  }

  /*
   * upraveni uzivatelu v terminu
   */
  async SaveAttendees(model: Array<IAttendee>, courseEventId: number) {
    return this.resolveResponse(
      await this.axiosInstance.put(`${this.basePath}/${courseEventId}/save-attendees`, model)
    );
  }

  /**
   * Tisk
   * @param docType Druh souboru
   * @returns URL vygenerovaneho souboru
   */
  async GenerateDoc(courseEventId: number, docType: string): Promise<string> {
    return (await this.axiosInstance.get(`${this.basePath}/${courseEventId}/docs/${docType}`)).data;
  }

    /**
   * Tisk pro konkréniho uživatele
   * @param docType Druh souboru
   * @param userId Id uživatele
   * @returns URL vygenerovaneho souboru
   */
    async GenerateDocForUser(courseEventId: number, userId: number, docType: string): Promise<string> {
      return (await this.axiosInstance.get(`${this.basePath}/${courseEventId}/${userId}/docs/${docType}`)).data;
    }

  /*
   * ulozeni vysledku skoleni
   */
  async SaveEvaluation(model: Array<IAttendee>, closeEvaluation: boolean, courseEventId: number) {
    return this.resolveResponse(
      await this.axiosInstance.put(
        `${this.basePath}/${courseEventId}/save-evaluation?closeEvaluation=${closeEvaluation}`,
        model
      )
    );
  }

  /*
   * vyhledavani terminu pro uzivatele
   */
  async SearchEvents(courseId: number, afterDate: any): Promise<Array<ISearchAttendee>> {
    return this.resolveResponse(
      await this.axiosInstance.get(this.basePath + "/search-events", { params: { courseId, afterDate } })
    );
  }

  /*
   * ulozeni novych skoleni k uzivateli
   */
  async SaveAttendeeEvents(model: Array<IAttendeeEvent>, userId: number) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${userId}/save-events`, model));
  }
}
