import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { ICourseGroupEdit, ICourseGroup, ICourseGroupTree } from "../types";

export default class CourseGroupsApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "eola/course-groups");
  }

  CreateEmptyModel(): ICourseGroup {
    return {
      Id: 0,
      Name: "",
      ParentId: null
    };
  }

  /**
   * Vraci detail skupiny kurzu
   * @param courseGroupId ID skupiny
   * @returns instance skupiny nebo NULL
   */
  async Get(courseGroupId: number): Promise<ICourseGroup> {
    return (await this.axiosInstance.get(`${this.basePath}/${courseGroupId}`)).data;
  }

  /**
   * Vraci strom skupin kurzu vcetne kurzu zarazenych ve skupinach
   * @returns instance skupiny nebo NULL
   */
  async GetTree(includeCourses: boolean, ommitGroupId?: number): Promise<Array<ICourseGroupTree>> {
    return (
      await this.axiosInstance.get(this.basePath, {
        params: { includeCourses: includeCourses, ommitGroupId: ommitGroupId }
      })
    ).data;
  }

    /**
   * Smazat podřízených skupin
   * @param parentId ID skupiny
   */
    async GetChild(parentId: number) {
      return (await this.axiosInstance.get(`${this.basePath}/get-child/${parentId}`)).data;
    }

  /**
   * Smazat skupinu
   * @param courseGroupId ID skupiny
   */
  async Delete(courseGroupId: number) {
    return (await this.axiosInstance.delete(`${this.basePath}/${courseGroupId}`)).data;
  }

  /**
   * Zalozeni nove skupiny kurzu
   * @param courseGroupModel instance skupiny
   * @returns ID nove zalozene skupiny
   */
  async Create(courseGroupModel: ICourseGroupEdit): Promise<number> {
    return (await this.axiosInstance.post(this.basePath, courseGroupModel)).data;
  }

  /**
   * Ulozeni existujici skupiny kurzu
   * @param courseGroupModel instance skupiny
   * @param courseGroupId ID editovane skupiny
   */
  async Edit(courseGroupModel: ICourseGroupEdit, courseGroupId: number) {
    return (await this.axiosInstance.put(`${this.basePath}/${courseGroupId}`, courseGroupModel)).data;
  }
}
