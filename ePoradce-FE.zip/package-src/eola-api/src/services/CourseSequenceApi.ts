import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { ICourseSequence, ICourseWithGroup } from "../types";

export default class CourseSequenceApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "eola/course-sequences");
  }

  CreateEmptyModel(): ICourseSequence {
    return {
      Id: 0,
      Name: "",
    };
  }

  /**
   * Update poradi kurzu v sekvenci
   * @param id List Course2CourseSequenceId v novem poradi
   */
  async UpdateOrder(id: Array<number>) {
    return (await this.axiosInstance.put(`${this.basePath}/update-order`, id)).data;
  }

  /**
   * Vraci seznam kurzu v sekvenci
   * @param sequenceId ID sekvence
   * @returns list kurzu nebo []
   */
  async GetCourses(sequenceId: number): Promise<Array<ICourseWithGroup>> {
    return (await this.axiosInstance.get(`${this.basePath}/${sequenceId}/courses`)).data;
  }

  /**
   * Vraci detail sekvence
   * @param sequenceId ID sekvence
   * @returns instance sekvence nebo NULL
   */
  async Get(sequenceId: number): Promise<ICourseSequence> {
    return (await this.axiosInstance.get(`${this.basePath}/${sequenceId}`)).data;
  }

  /**
   * Vraci seznam sekvenci
   * @returns instance sekvence nebo NULL
   */
  async GetList(): Promise<Array<ICourseSequence>> {
    return (await this.axiosInstance.get(this.basePath)).data;
  }

  /**
   * Smazat sekvenci
   * @param sequenceId ID sekvence
   */
  async Delete(sequenceId: number) {
    return (await this.axiosInstance.delete(`${this.basePath}/${sequenceId}`)).data;
  }

  /**
   * Zalozeni nove sekvence
   * @param sequenceModel instance sekvence
   * @returns ID nove zalozene sekvence
   */
  async Create(sequenceModel: ICourseSequence): Promise<number> {
    return (await this.axiosInstance.post(this.basePath, sequenceModel)).data;
  }

  /**
   * Ulozeni existujici sekvence
   * @param sequenceModel instance sekvence
   * @param sequenceId ID editovane sekvence
   */
  async Edit(sequenceModel: ICourseSequence, sequenceId: number) {
    return (await this.axiosInstance.put(`${this.basePath}/${sequenceId}`, sequenceModel)).data;
  }
}
