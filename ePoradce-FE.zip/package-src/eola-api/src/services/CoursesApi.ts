import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { EvaluationTypes, CertificateTypes } from "../Enums";
import { ICourseList, ICourse } from "../types";

export default class CoursesApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "eola/courses");
  }

  CreateEmptyModel(courseGroupId: number = 0): ICourse {
    return {
      Id: 0,
      Name: "",
      CourseGroupId: courseGroupId,
      IsArchived: false,
      InternalNote: "",
      Description: "",
      EvaluationType: EvaluationTypes.PouzeUcast,
      CertificateType: CertificateTypes.None,
      Sequence: null,
      IsUserDashboard: true
    };
  }

  /**
   * Seznam kurzu v dane skupine kurzu
   * @param courseGroupId ID nadrizene skupiny kurzu
   */
  async GetList(courseGroupId: number | null, requireId: number | null): Promise<Array<ICourseList>> {
    return (
      await this.axiosInstance.get(this.basePath, { params: { courseGroupId: courseGroupId, requireId: requireId } })
    ).data;
  }

  /**
   * Detail kurzu
   * @param courseId ID kurzu
   * @returns instance kurzu nebo NULL
   */
  async Get(courseId: number): Promise<ICourse> {
    return (await this.axiosInstance.get(`${this.basePath}/${courseId}`)).data;
  }

  /**
   * Ulozeni noveho kurzu
   * @param courseModel instance kurzu
   * @returns ID nove zalozeneho kurzu
   */
  async Create(courseModel: ICourse): Promise<number> {
    return (await this.axiosInstance.post(this.basePath, courseModel)).data;
  }

  /**
   * Editace existujiciho kurzu
   * @param courseModel instance kurzu
   * @param courseId ID editovaneho kurzu
   */
  async Edit(courseModel: ICourse, courseId: number) {
    return (await this.axiosInstance.put(`${this.basePath}/${courseId}`, courseModel)).data;
  }

  /**
   * Smazat nebo archivovat kurz - podle toho, zda ma nastaveny atribut IsArchived
   * @param courseId ID kurzu
   */
  async Delete(courseId: number) {
    return (await this.axiosInstance.delete(`${this.basePath}/${courseId}`)).data;
  }
}
