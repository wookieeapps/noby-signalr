import IAccommodationBase from "./IAccommodationBase";

export default interface IAccommodation extends IAccommodationBase {
  Id: number;

  AccommodationTypes?: Array<number>;

  Contact?: string;

  IsActual?: boolean;
}
