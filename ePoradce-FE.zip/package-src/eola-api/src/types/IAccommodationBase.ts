export default interface IAccommodationBase {
  Name?: string;

  Street?: string;

  City?: string;

  Zip?: string;
}
