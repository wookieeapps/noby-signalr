export default interface IAttendee {
  UserId: number;

  DisplayName?: string;

  SignupNote?: string;

  PrivateNote?: string;

  WithAccommodation: boolean;

  EvaluationGratutade: boolean;

  EvaluationResult?: number;

  EvaluationNote?: string;

  BodyTest?: number;
}
