import { EvaluationTypes, CertificateTypes } from "../Enums";
import { IAccommodationBase } from ".";

export default interface IAttendeeHistory {
  AccommodationDescription?: string;

  CertificateType: CertificateTypes;

  CourseEventId: Number;

  CourseName: string;

  EvaluationClosed: boolean;

  EvaluationGratutade: boolean;

  EvaluationResult?: number;

  EvaluationType: EvaluationTypes;

  TimeFrom: Date | null;

  TimeTo: Date | null;

  TrainingRoomDescription?: string;

  WithAccommodation: boolean;

  Accommodation: IAccommodationBase;

  TrainingRoom: IAccommodationBase;

  IsCertificate: boolean;
}
