import { EvaluationTypes, CertificateTypes } from "../Enums";

export default interface ICourse {
  Id: number;

  Name: string;

  CourseGroupId: number;

  Description?: string;

  InternalNote?: string;

  MinAttendees?: number;

  MaxAttendees?: number;

  IsArchived: boolean;

  EvaluationType: EvaluationTypes;

  CertificateType: CertificateTypes;

  Sequence: number | null;

  IsUserDashboard: boolean;
}
