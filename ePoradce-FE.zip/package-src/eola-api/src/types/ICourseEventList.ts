export default interface ICourseEventList {
  Id: number;

  Name: string;

  TimeFrom: any;

  SignupDeadline: any;

  Capacity: string;

  AccommodationName: string;
  
  AccommodationAddress: string;

  TrainingRoomName: string;
  
  TrainingRoomAddress: string;

  AttendanceList: boolean;

  Lectors: string;

  IsDraft: boolean;
}
