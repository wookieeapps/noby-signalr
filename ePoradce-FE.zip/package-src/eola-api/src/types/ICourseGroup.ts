import { ICourse, ICourseGroupEdit } from ".";
import { Types as CommonTypes } from "@mpss/eporadce-common-api";

export default interface ICourseGroup extends ICourseGroupEdit {
  Id: number;
}
