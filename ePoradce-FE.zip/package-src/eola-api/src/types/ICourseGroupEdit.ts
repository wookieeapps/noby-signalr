import { Types as CommonTypes } from "@mpss/eporadce-common-api";

export default interface ICourseGroupEdit {
  Name: string;

  /**
   * ID nadrizene skupiny nebo NULL
   */
  ParentId?: number | null;
}
