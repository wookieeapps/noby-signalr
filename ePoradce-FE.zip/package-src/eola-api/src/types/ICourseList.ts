export default interface ICourseList {
  Id: number;

  Name: string;

  IsArchived: boolean;
}
