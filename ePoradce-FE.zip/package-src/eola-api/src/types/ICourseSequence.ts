export default interface ICourseSequence {
  Id: number;

  Name: string;
}
