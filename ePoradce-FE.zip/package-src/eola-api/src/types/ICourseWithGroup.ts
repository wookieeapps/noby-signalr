export default interface ICourseWithGroup {
  Id: number;

  Name: string;

  GroupName: string;

  SequenceOrder: number | null;
}
