export default interface IEvaluationType {
  Id: number;

  Text: string;
}
