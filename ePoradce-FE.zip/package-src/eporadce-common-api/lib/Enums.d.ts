/**
 * Stavy souboru uploadovaneho na server
 */
export declare enum FileInfoStates {
    Existing = 1,
    Uploading = 2,
    Uploaded = 3,
    UploadFailed = 4
}
/**
 * Seznam typu moznych poli na klientovi pro QueryBuilder
 */
export declare enum QueryBuilderFieldTypes {
    None = 0,
    Textbox = 1,
    NumericTextbox = 2,
    DatePicker = 3,
    Checkbox = 4,
    DropDown = 5
}
