import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
export default class DashboardApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    Get(): Promise<any>;
}
