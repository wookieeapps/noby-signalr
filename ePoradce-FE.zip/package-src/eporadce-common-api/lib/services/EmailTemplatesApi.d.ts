import { AxiosInstance } from "axios";
import { BaseApiService, ApplicationIdTypes, ObjectTypes, ICodeListItem } from "@mpss/eporadce-common";
import { IEmailTemplateType, IEmailTemplate, IEmailTemplate2Object, IEmailTemplateList } from "../types";
export default class EmailTemplatesApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    CreateEmptyModel(): IEmailTemplate;
    CreateEmptyModelForObject(id?: number): IEmailTemplate2Object;
    /**
     * Seznam TemplateTypes pro konkretni aplikaci a/nebo ObjectType
     * @param applicationId ID aplikace
     * @param objectTypeId Typ objektu nebo undefined
     */
    GetTemplateTypes(applicationId: ApplicationIdTypes, objectTypeId: ObjectTypes | undefined): Promise<Array<IEmailTemplateType>>;
    /**
     * Seznam objectTypes s konfiguraci pro mailTemplates
     * @param applicationId ID aplikace
     */
    GetObjectTypes(applicationId: ApplicationIdTypes): Promise<Array<ICodeListItem>>;
    GetConfiguration(objectTypeId: ObjectTypes, templateType: number): Promise<any>;
    /**
     * Seznam dostupnych sablon pro aplikaci, pripadne pro ObjectType
     * @param applicationId ID aplikace
     * @param objectTypeId Typ objektu nebo undefined
     */
    GetList(applicationId: ApplicationIdTypes, objectTypeId: ObjectTypes | undefined): Promise<Array<IEmailTemplateList>>;
    /**
     * List ulozenych udalosti/sablon ke konkretnimu objektu
     * @param objectTypeId Typ objektu
     * @param objectId ID objektu
     */
    GetListForObject(objectTypeId: ObjectTypes, objectId: number): Promise<Array<IEmailTemplate2Object>>;
    /**
     * Vraci detail sablony
     * @param templateId ID sablony
     */
    Get(templateId: number): Promise<IEmailTemplate>;
    /**
     * Zalozeni nove sablony
     * @param templateModel instance sablony
     * @returns ID nove zalozene sablony
     */
    Create(templateModel: IEmailTemplate): Promise<number>;
    /**
     * Ulozeni existujici sablony
     * @param templateModel instance sablony
     * @param templateId ID editovane sablony
     */
    Edit(templateModel: IEmailTemplate, templateId: number): Promise<any>;
    /**
     * Ulozeni vazby objektu na udalosti
     * @param objectTypeId Typ objektu
     * @param objectId ID objektu
     * @param items Udalosti/sablony ulozene k objektu
     */
    Update2Object(objectTypeId: ObjectTypes, objectId: number, items: Array<IEmailTemplate2Object>): Promise<any>;
    /**
     * Smazani sablony emailu
     * @param templateId ID sablony
     */
    Delete(templateId: number): Promise<import("axios").AxiosResponse<any>>;
    private EmailTemplateTypesCacheLoaded;
    private EmailTemplateTypesCache;
}
