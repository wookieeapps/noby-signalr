import { AxiosInstance } from "axios";
import { BaseApiService, ObjectTypes } from "@mpss/eporadce-common";
import { FileInfoStates } from "../Enums";
import { IFileInfoEdit, IFileInfoType, IFileInfoList, IIncrementalPaginableResult } from "../types";
export default class FileInfoApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    CreateEmptyModel(filename?: string, filesize?: number, insertUserName?: string, state?: FileInfoStates): IFileInfoList;
    /**
     * Seznam ulozenych souboru k danemu objektu
     * @param objectTypeId Typ objektu
     * @param objectId ID objektu
     */
    GetList(objectTypeId: ObjectTypes, objectId: number, start: number, count: number): Promise<IIncrementalPaginableResult<IFileInfoList>>;
    GetDownloadUrl(guid: string): string;
    /**
     * Update vazby objekt-soubor + update FileType
     */
    Update(objectTypeId: ObjectTypes, objectId: number, files: Array<IFileInfoEdit>, append?: boolean): Promise<any>;
    /**
     * Ulozeni/upload souboru pres API
     * @param formData Binarni reprezentace souboru
     * @param objectTypeId Type objektu
     */
    Create(file: any): Promise<IFileInfoList>;
    /**
     * Seznam typu souboru pro danou aplikaci
     */
    GetFileInfoTypes(objectTypeId: ObjectTypes): Promise<Array<IFileInfoType>>;
    /**
     * Odstraneni souboru
     */
    Delete(fileId: number): Promise<any>;
    private FileInfoTypesCache;
}
