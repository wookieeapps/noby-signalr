import { AxiosInstance } from "axios";
import { BaseApiService, ICodeListItem } from "@mpss/eporadce-common";
import IImpersonateSave from "../types/IImpersonateSave";
export default class ImpersonateApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    GetUserRoles(): Promise<Array<ICodeListItem>>;
    Save(model: IImpersonateSave): Promise<any>;
}
