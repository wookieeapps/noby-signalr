import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { IPoCe } from "../types";
export default class PlacesApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Vrati seznam mesto pro dane PSC
     * @param zip PSC
     */
    GetPlaceByZip(zip: string): Promise<Array<string>>;
    /**
     * Vrati seznam POCE pro zadany vyraz
     */
    GetPoCeByTerm(term: string): Promise<Array<IPoCe>>;
    /**
     * Vrati konkretni POCE podle jeho ID
     */
    GetPoCeById(id: Number): Promise<IPoCe>;
    /**
     * Vrati seznam POCE podle jejich ID
     */
    GetManyPoCeById(id: Array<Number>): Promise<Array<IPoCe>>;
}
