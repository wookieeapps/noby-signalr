import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
export default class PmpAppsApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Seznam aplikaci na ktere ma uzivatel pravo
     * @param userId ID FP
     */
    GetPermissions(userId: number): Promise<Array<any>>;
    /**
     * Seznam vsech aplikaci PMP
     */
    GetApplications(): Promise<Array<any>>;
    /**
     * Ulozeni prav na aplikace pro daneho uzivatele
     * @param userId FP ID
     * @param data seznam app a prav
     */
    SavePermissions(userId: number, data: any): Promise<any>;
}
