import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import IQueryBuilderField from "../types/IQueryBuilderField";
export default class QueryBuilderApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Vraci seznam poli gridu ktere jsou k filtrovani v query builderu
     * @param ident IDENT gridu pro ktery se maji pole stahnout
     * @returns seznam objectTypes
     */
    GetFields(ident: string): Promise<Array<IQueryBuilderField>>;
}
