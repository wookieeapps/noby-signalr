import { AxiosInstance } from "axios";
import { BaseApiService, ObjectTypes } from "@mpss/eporadce-common";
import { ITag } from "../types";
export default class TagsApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    CreateEmptyModel(): ITag;
    /**
     * Vraci seznam tagu
     * @returns [] tagu nebo NULL
     */
    GetList(objectTypeId: ObjectTypes): Promise<Array<ITag>>;
    /**
     * Smazat tag
     * @param tagId ID tagu
     */
    Delete(tagId: number): Promise<any>;
    /**
     * Zalozeni noveho tagu
     * @param model instance tagu
     * @returns ID nove zalozeneho tagu
     */
    Create(model: ITag): Promise<number>;
    /**
     * Ulozeni existujiciho tagu
     * @param model instance tagu
     * @param tagId ID editovaneho tagu
     */
    Edit(model: ITag, tagId: number): Promise<any>;
    SaveFileBinding(objectTypeId: ObjectTypes, objectId: number, tags: Array<number>): Promise<any>;
}
