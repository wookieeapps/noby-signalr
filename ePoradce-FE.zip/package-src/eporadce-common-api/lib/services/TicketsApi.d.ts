import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { ITicketList, ITicket, IIncrementalPaginableResult } from "../types";
export default class TicketsApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Seznam moznych druhu ticketu pro daneho FP a uzivatele
     * @param userId ID FP
     */
    GetListOfActions(userId: number): Promise<any>;
    Delete(ticketId: number): Promise<any>;
    /**
     * Detail typu akce - typu ticketu
     * @param ticketType Typ ticketu
     */
    GetAction(ticketType: number): Promise<any>;
    Approve(ticketId: number, note: string): Promise<any>;
    Disapprove(ticketId: number, note: string): Promise<any>;
    /**
     * Seznam approveru pro dany typ ticketu a uzivatele
     * @param userId ID FP
     * @param ticketType druh ticketu
     */
    GetListOfApprovers(userId: number, ticketType: number): Promise<Array<number>>;
    /**
     * Vytvoreni noveho ticketu
     * @param userId ID uzivatele, pro ktereho je ticket vytvoren
     * @param action TicketType
     * @param model obsah ticketu
     */
    Create(userId: number, action: string, model: any): Promise<any>;
    /**
     * Detail ticketu
     * @param ticketId ID ticketu
     */
    Get(ticketId: number): Promise<ITicket>;
    /**
     * Seznam ticketu k danemu uzivateli
     * @param userId ID uzivatele pro ktereho se ma list zobrazit
     */
    GetList(userId: number, start: number, count: number): Promise<IIncrementalPaginableResult<ITicketList>>;
    DeleteAttachments(ticketId: number, files: Array<number>): Promise<any>;
    GetListForApprover(): Promise<Array<ITicket>>;
}
