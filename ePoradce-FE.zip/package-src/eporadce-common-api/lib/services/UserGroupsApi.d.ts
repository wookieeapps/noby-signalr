import IUserGroup from "../types/IUserGroup";
import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
export default class UserGroupsApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    Get(userGroupId: number): Promise<IUserGroup>;
    Search(term: string, applicationId: number, minLevel: number | null, maxLevel: number | null): Promise<Array<IUserGroup>>;
}
