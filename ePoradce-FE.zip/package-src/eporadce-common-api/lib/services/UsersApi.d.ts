import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { IPaginableResult, IUserBaseQuery, IUserSimple, IUserList, IUser } from "../types";
export default class UsersApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    private stringConstructor;
    Create(model: any): Promise<number>;
    /**
     * Vraci instanci uzivatele
     * @param userId ID uzivatele
     * @returns Instance uzivatele
     */
    Get(userId: number): Promise<IUser>;
    /**
     * Vraci instanci aktualne prihlaseneho uzivatele
     * @returns Instance uzivatele
     */
    GetCurrentUser(): Promise<IUserSimple>;
    /**
     * Vraci strankovatelny seznam uzivatelu podle zadaneho filtru
     * @param filter nastaveni filtru uzivatelu
     * @returns seznam skupin
     */
    GetList(filter: any): Promise<IPaginableResult<IUserList>>;
    GetListDeleted(filter: any): Promise<IPaginableResult<IUserList>>;
    /**
     * Vraci seznam uzivatelu odpovidaji filtru
     * @param requireId uzivatele kteri se vzdy vrati bez ohledu na dalsi filtrovani
     * @param roles sum pozadovanych roli
     * @param term Hledani podle retezce - ve jmene, CPM
     */
    GetBaseList(requireIds: Array<number> | undefined, roles: number | undefined): Promise<Array<IUserBaseQuery>>;
    /**
     * Vyhledavani - naseptavac v hlavni liste aplikace
     * @param term Hledani podle retezce - ve jmene, CPM
     */
    GetGeneralSearch(term: string): Promise<any>;
    /**
     * Vraci obsah meta pro uzivatele
     * @param userId nastaveni filtru uzivatelu\
     * @param metaId typ meta informace
     * @returns instance meta nebo prazdny string
     */
    GetMeta(userId: number, metaId: number): Promise<string>;
    /**
     * Vytvori nebu updatuje konkretni meta k uzivateli
     * @param userId nastaveni filtru uzivatelu
     * @param metaId typ meta informace
     * @param value nova hodnota meta informace
     */
    SaveMeta(userId: number, metaId: number, value: any): Promise<any>;
    /**
     * Vraci absolute URL obrazku s ksichtem uzivatele
     * @param userId ID uzivatele
     * @returns URL obrazku nebo HTTP 404
     */
    GetUserImageUrl(userId: number): string;
}
