import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { IUserMandate, IUserProvision } from "../types";
export default class UsersExtendedApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Vraci rozsireny detail FP
     * @param userId UserId FP
     */
    GetDetail(userId: number): Promise<any>;
    /**
     * Vraci historii pozice
     * @param userId UserId FP
     */
    GetPositionHistory(userId: number): Promise<any>;
    /**
     * Vraci atributy FP z P2
     * @param userId UserId FP
     */
    GetP2Attributes(userId: number): Promise<any>;
    /**
     * Vraci seznam zmocneni FP
     * @param userId UserId FP
     */
    GetMandates(userId: number): Promise<Array<IUserMandate>>;
    /**
     * Vraci seznam provizi
     * @param userId UserId FP
     */
    GetProvisions(userId: number): Promise<Array<IUserProvision>>;
    SaveRiskType(riskType: number, userId: number): Promise<any>;
}
