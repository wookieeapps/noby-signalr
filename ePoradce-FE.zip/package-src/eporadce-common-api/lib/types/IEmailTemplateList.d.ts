import { ObjectTypes } from "@mpss/eporadce-common";
export default interface IEmailTemplateList {
    Id: number;
    Name: string;
    ObjectTypeId: ObjectTypes;
    IsReadonly: boolean;
}
