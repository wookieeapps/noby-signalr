export default interface IFileInfoEdit {
    Id: number;
    FileInfoTypeId?: number | null;
}
