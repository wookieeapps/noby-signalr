import { FileInfoStates } from "../Enums";
export default interface IFileInfoList {
    Id: number;
    FileInfoTypeId?: number | null;
    OriginalFileName: string;
    FileSize: number;
    ContentType: string;
    State: FileInfoStates;
    InsertTime: any;
    InsertUser: string;
    InserUserId: number;
    IsReadonly: boolean;
    TypeName: string;
}
