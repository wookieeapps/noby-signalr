export default interface IImpersonateSave {
    Login: string;
    UserRoles: Array<number>;
}
