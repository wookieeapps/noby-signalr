export default interface IIncrementalPaginableResult<T> {
    Start: number;
    End: number;
    HasMore: boolean;
    Data: Array<T>;
}
