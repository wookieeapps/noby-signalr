export default interface IPaginableResult<T> {
    TotalRows: number;
    Data: Array<T>;
}
