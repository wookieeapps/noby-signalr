export default interface IPoCe {
    Id: number;
    Street: string;
    City: string;
    Zip: string;
}
