import { QueryBuilderFieldTypes } from "../Enums";
export default interface IQueryBuilderField {
    Id: number;
    GroupName: string;
    Label: string;
    InputType: QueryBuilderFieldTypes;
    InputTypeConfiguration: string | undefined;
    Operators: object;
}
