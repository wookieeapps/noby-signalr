import ITicketList from "./ITicketList";
export default interface ITicket extends ITicketList {
    InsertUserName: string;
    UpdateTime: any;
    UpdateUserName: string;
    InsertUserId: number;
    UpdateUserId?: number;
    IsEditable: boolean;
}
