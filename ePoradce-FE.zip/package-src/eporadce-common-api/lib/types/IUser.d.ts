export default interface IUser {
    UserId: number;
    DisplayName: string;
    UserGroupId: number;
    PmpUserId: number;
    Username: string;
    UserRoles: number;
}
