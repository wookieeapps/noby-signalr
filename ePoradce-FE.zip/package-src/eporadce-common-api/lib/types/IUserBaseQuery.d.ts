export default interface IUserBaseQuery {
    UserId: number;
    DisplayName: string;
}
