export default interface IUserGroup {
    Id: number;
    Name: string;
    Groups: Array<IUserGroup> | null;
}
