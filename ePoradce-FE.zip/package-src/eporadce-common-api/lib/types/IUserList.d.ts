export default interface IUserList {
    Id: number;
    Name: string;
    Roles: number;
    CPM: string;
    Email: string;
    PersId: string;
}
