export default interface IUserMandate {
    Name: string;
    MediatorNo: string;
    RegistrationValidFrom: any;
    RegistrationValidTo: any;
    ValidFrom: any;
    Description: any;
}
