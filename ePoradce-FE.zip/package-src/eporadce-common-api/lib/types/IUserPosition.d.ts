export default interface IUserPosition {
    UserGroupType: string;
    Text: string;
    Code: string;
}
