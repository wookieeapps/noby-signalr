import { AxiosInstance } from "axios";
import { BaseApiService, ApplicationIdTypes, ICodeListItem, ObjectTypes } from "@mpss/eporadce-common";
import { ICountry } from "../types";

export default class CommonListsApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "common-lists");
  }

  async GetList(module: string, type: string) {
    const url = module ? `${this.basePath}/${module}/${type}` : `${this.basePath}/${type}`;
    return (await this.axiosInstance.get(url)).data;
  }

  /*CreateEmptyModel(): ICodeListItem {
    return {
      Id: 0,
      Text: "",
      Color: "",
      Code: ""
    };
  }
  async Save(module: string, type: string, model: ICodeListItem) {
    return (await this.axiosInstance.post(`${this.basePath}/${module}/${type}`, model)).data;
  }
  async Delete(module: string, type: string, id: number) {
    return (await this.axiosInstance.delete(`${this.basePath}/${module}/${type}/${id}`)).data;
  }*/

  async GetObjectTypes(applicationId: ApplicationIdTypes): Promise<Array<ICodeListItem>> {
    return (await this.axiosInstance.get(`${this.basePath}/object-types/${applicationId}`)).data;
  }

  async GetEmailTemplateTypes(objectTypeId: ObjectTypes): Promise<Array<ICodeListItem>> {
    return (await this.axiosInstance.get(`${this.basePath}/email-template-types/${objectTypeId}`)).data;
  }

  async GetUserGroupTypes(): Promise<Array<ICodeListItem>> {
    return await this.GetList("", "user-group-types");
  }

  async GetBanks(): Promise<Array<ICodeListItem>> {
    return await this.GetList("", "banks");
  }

  async GetUserSalutations(): Promise<Array<ICodeListItem>> {
    return await this.GetList("", "user-salutation-types");
  }

  async GetTitles(): Promise<Array<ICodeListItem>> {
    return await this.GetList("", "titles");
  }

  async GetTitles2(): Promise<Array<ICodeListItem>> {
    return await this.GetList("", "titles2");
  }

  async GetAllPositions(): Promise<Array<ICodeListItem>> {
    return await this.GetList("", "all-positions");
  }

  async GetPositions(userGroupType: string): Promise<Array<ICodeListItem>> {
    return await this.GetList("", `positions/${userGroupType}`);
  }

  async GetTicketStatuses(): Promise<Array<ICodeListItem>> {
    return await this.GetList("", "ticket-statuses");
  }

  async GetHiringChecklistStatuses(): Promise<Array<ICodeListItem>> {
    return await this.GetList("hiring", "checklist-statuses");
  }

  async GetEvaluationTypes(): Promise<Array<ICodeListItem>> {
    return await this.GetList("eola", "evaluation-types");
  }

  async GetAccommodationTypes(): Promise<Array<ICodeListItem>> {
    return await this.GetList("eola", "accommodation-types");
  }

  async GetCertificateTypes(): Promise<Array<ICodeListItem>> {
    return await this.GetList("eola", "certificate-types");
  }

  async GetEvaluationResults(): Promise<Array<ICodeListItem>> {
    return await this.GetList("eola", "evaluation-result-types");
  }

  async GetHiringRiskTypes(): Promise<Array<ICodeListItem>> {
    return await this.GetList("hiring", "risk-types");
  }

  async GetWorkInGroupTypes(): Promise<Array<ICodeListItem>> {
    return await this.GetList("hiring", "work-in-group");
  }

  async GetHiringWorkflowStatuses(): Promise<Array<ICodeListItem>> {
    return await this.GetList("hiring", "workflow-statuses");
  }

  async GetHiringExperienceTypes(): Promise<Array<ICodeListItem>> {
    return await this.GetList("hiring", "experience-types");
  }

  async GetHiringRecruitmentSources(): Promise<Array<ICodeListItem>> {
    return await this.GetList("hiring", "recruitment-sources");
  }

  async GetHiringJobClassifications(): Promise<Array<ICodeListItem>> {
    return await this.GetList("hiring", "job-classifications");
  }

  async GetHiringJobActivities(): Promise<Array<ICodeListItem>> {
    return await this.GetList("hiring", "job-activities");
  }

  async GetHiringPositions(): Promise<Array<ICodeListItem>> {
    return await this.GetList("hiring", "positions");
  }

  async GetCountries(): Promise<Array<ICountry>> {
    return await this.GetList("", "countries");
  }

  async GetHealthInsurances(): Promise<Array<ICodeListItem>> {
    return await this.GetList("", "health-insurances");
  }

  async GetTicketingTerminationReasons(): Promise<Array<ICountry>> {
    return await this.GetList("ticketing", "termination-reasons");
  }
}
