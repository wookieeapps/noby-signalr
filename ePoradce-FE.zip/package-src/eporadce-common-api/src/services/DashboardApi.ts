import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { BaseApiService, DateHelpers } from "@mpss/eporadce-common";

export default class DashboardApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "");
  }

  async Get(): Promise<any> {
    return this.resolveResponse(
      await this.axiosInstance.get("dashboard", {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): any {
          if (data && data.OpenedRequests && Array.isArray(data.OpenedRequests)) {
            data.OpenedRequests.forEach((t: any) => {
              t.Date = DateHelpers.parseISO(t.Date);
            });
          }
          if (data && data.DisapprovedTickets && Array.isArray(data.DisapprovedTickets)) {
            data.DisapprovedTickets.forEach((t: any) => {
              t.Date = DateHelpers.parseISO(t.Date);
            });
          }
          if (data && data.TicketsToApprove && Array.isArray(data.TicketsToApprove)) {
            data.TicketsToApprove.forEach((t: any) => {
              t.Date = DateHelpers.parseISO(t.Date);
            });
          }
          if (data && data.DisapprovedTicketsAsManager && Array.isArray(data.DisapprovedTicketsAsManager)) {
            data.DisapprovedTicketsAsManager.forEach((t: any) => {
              t.Date = DateHelpers.parseISO(t.Date);
            });
          }
          return data;
        })
      })
    );
  }
}
