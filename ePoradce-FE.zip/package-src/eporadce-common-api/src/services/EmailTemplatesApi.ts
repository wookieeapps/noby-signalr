import { AxiosInstance } from "axios";
import { BaseApiService, ApplicationIdTypes, ObjectTypes, ICodeListItem } from "@mpss/eporadce-common";
import { IEmailTemplateType, IEmailTemplate, IEmailTemplate2Object, IEmailTemplateList } from "../types";

export default class EmailTemplatesApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "email-templates");
  }

  CreateEmptyModel(): IEmailTemplate {
    return {
      Id: 0,
      Name: "",
      Subject: "",
      Text: "",
      ObjectTypeId: 0,
      IsReadonly: false,
      FileTypes: null
    };
  }

  CreateEmptyModelForObject(id = 0): IEmailTemplate2Object {
    return {
      Id: id,
      TemplateType: 0,
      TemplateId: 0
    };
  }

  /**
   * Seznam TemplateTypes pro konkretni aplikaci a/nebo ObjectType
   * @param applicationId ID aplikace
   * @param objectTypeId Typ objektu nebo undefined
   */
  async GetTemplateTypes(
    applicationId: ApplicationIdTypes,
    objectTypeId: ObjectTypes | undefined
  ): Promise<Array<IEmailTemplateType>> {
    if (!this.EmailTemplateTypesCacheLoaded) {
      this.EmailTemplateTypesCache = (await this.axiosInstance.get(`${this.basePath}/types/${applicationId}`)).data;
    }

    if (objectTypeId) {
      return this.EmailTemplateTypesCache.filter((t) => t.ObjectTypeId === objectTypeId);
    } else {
      return this.EmailTemplateTypesCache;
    }
  }

  /**
   * Seznam objectTypes s konfiguraci pro mailTemplates
   * @param applicationId ID aplikace
   */
  async GetObjectTypes(applicationId: ApplicationIdTypes): Promise<Array<ICodeListItem>> {
    return (await this.axiosInstance.get(`${this.basePath}/object-types/${applicationId}`)).data;
  }

  async GetConfiguration(objectTypeId: ObjectTypes, templateType: number) {
    return (await this.axiosInstance.get(`${this.basePath}/configuration/${objectTypeId}/${templateType}`)).data;
  }

  /**
   * Seznam dostupnych sablon pro aplikaci, pripadne pro ObjectType
   * @param applicationId ID aplikace
   * @param objectTypeId Typ objektu nebo undefined
   */
  async GetList(
    applicationId: ApplicationIdTypes,
    objectTypeId: ObjectTypes | undefined
  ): Promise<Array<IEmailTemplateList>> {
    return (await this.axiosInstance.get(this.basePath, { params: { applicationId, objectTypeId } })).data;
  }

  /**
   * List ulozenych udalosti/sablon ke konkretnimu objektu
   * @param objectTypeId Typ objektu
   * @param objectId ID objektu
   */
  async GetListForObject(objectTypeId: ObjectTypes, objectId: number): Promise<Array<IEmailTemplate2Object>> {
    return (await this.axiosInstance.get(`${this.basePath}/${objectTypeId}/${objectId}`)).data;
  }

  /**
   * Vraci detail sablony
   * @param templateId ID sablony
   */
  async Get(templateId: number): Promise<IEmailTemplate> {
    return (await this.axiosInstance.get(`${this.basePath}/${templateId}`)).data;
  }

  /**
   * Zalozeni nove sablony
   * @param templateModel instance sablony
   * @returns ID nove zalozene sablony
   */
  async Create(templateModel: IEmailTemplate): Promise<number> {
    return (await this.axiosInstance.post(this.basePath, templateModel)).data;
  }

  /**
   * Ulozeni existujici sablony
   * @param templateModel instance sablony
   * @param templateId ID editovane sablony
   */
  async Edit(templateModel: IEmailTemplate, templateId: number) {
    return (await this.axiosInstance.put(`${this.basePath}/${templateId}`, templateModel)).data;
  }

  /**
   * Ulozeni vazby objektu na udalosti
   * @param objectTypeId Typ objektu
   * @param objectId ID objektu
   * @param items Udalosti/sablony ulozene k objektu
   */
  async Update2Object(objectTypeId: ObjectTypes, objectId: number, items: Array<IEmailTemplate2Object>) {
    return (await this.axiosInstance.put(`${this.basePath}/${objectTypeId}/${objectId}`, items)).data;
  }

  /**
   * Smazani sablony emailu
   * @param templateId ID sablony
   */
  async Delete(templateId: number) {
    return await this.axiosInstance.delete(`${this.basePath}/${templateId}`);
  }

  // tise pocitam, ze v ramci jedne app se bude kesovat vzdy jen jedna kolekce pro konkretni appId
  private EmailTemplateTypesCacheLoaded = false;
  private EmailTemplateTypesCache: Array<IEmailTemplateType> = [];
}
