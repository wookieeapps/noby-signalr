import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { BaseApiService, ObjectTypes, DateHelpers } from "@mpss/eporadce-common";
import { FileInfoStates } from "../Enums";
import { IFileInfoEdit, IFileInfoType, IFileInfoList, IIncrementalPaginableResult } from "../types";

export default class FileInfoApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "files");
  }

  CreateEmptyModel(
    filename: string = "",
    filesize: number = 0,
    insertUserName: string = "",
    state: FileInfoStates = FileInfoStates.Uploading
  ): IFileInfoList {
    return {
      Id: 0,
      OriginalFileName: filename,
      State: state,
      ContentType: "",
      FileSize: filesize,
      FileInfoTypeId: null,
      InsertTime: new Date(),
      InsertUser: insertUserName,
      InserUserId: 0,
      IsReadonly: false,
      TypeName: ""
    };
  }

  /**
   * Seznam ulozenych souboru k danemu objektu
   * @param objectTypeId Typ objektu
   * @param objectId ID objektu
   */
  async GetList(
    objectTypeId: ObjectTypes,
    objectId: number,
    start: number,
    count: number
  ): Promise<IIncrementalPaginableResult<IFileInfoList>> {
    return this.resolveResponse(
      await this.axiosInstance.get(`${this.basePath}/${objectTypeId}/${objectId}?start=${start}&count=${count}`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): IIncrementalPaginableResult<IFileInfoList> | null {
          if (data) {
            data.Data.forEach((t: IFileInfoList) => {
              t.InsertTime = DateHelpers.parseISO(t.InsertTime);
            });
            return data;
          }
          return null;
        })
      })
    );
  }

  GetDownloadUrl(guid: string): string {
    return `/${this.basePath}/${guid}`;
  }

  /**
   * Update vazby objekt-soubor + update FileType
   */
  async Update(objectTypeId: ObjectTypes, objectId: number, files: Array<IFileInfoEdit>, append: boolean = false) {
    return (await this.axiosInstance.put(`${this.basePath}/${objectTypeId}/${objectId}?append=${append}`, files)).data;
  }

  /**
   * Ulozeni/upload souboru pres API
   * @param formData Binarni reprezentace souboru
   * @param objectTypeId Type objektu
   */
  async Create(file: any): Promise<IFileInfoList> {
    // append to ajax svc
    const formData = new FormData();
    formData.append("file", file, file.name);

    return (await this.axiosInstance.post(this.basePath, formData)).data;
  }

  /**
   * Seznam typu souboru pro danou aplikaci
   */
  async GetFileInfoTypes(objectTypeId: ObjectTypes): Promise<Array<IFileInfoType>> {
    return (await this.axiosInstance.get(`${this.basePath}/types/${objectTypeId}`)).data;
  }

  /**
   * Odstraneni souboru
   */
  async Delete(fileId: number) {
    return (await this.axiosInstance.delete(`${this.basePath}/${fileId}`)).data;
  }

  private FileInfoTypesCache: any = {};
}
