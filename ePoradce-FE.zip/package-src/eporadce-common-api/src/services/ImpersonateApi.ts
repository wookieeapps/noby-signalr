import { AxiosInstance } from "axios";
import { BaseApiService, ICodeListItem } from "@mpss/eporadce-common";
import IImpersonateSave from "../types/IImpersonateSave";

export default class ImpersonateApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "impersonate");
  }

  async GetUserRoles(): Promise<Array<ICodeListItem>> {
    return this.resolveResponse(await this.axiosInstance.get(this.basePath + "/roles"));
  }

  async Save(model: IImpersonateSave): Promise<any> {
    return this.resolveResponse(await this.axiosInstance.post(this.basePath, model));
  }
}
