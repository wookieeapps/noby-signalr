import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { IPoCe } from "../types";

export default class PlacesApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "");
  }

  /**
   * Vrati seznam mesto pro dane PSC
   * @param zip PSC
   */
  async GetPlaceByZip(zip: string): Promise<Array<string>> {
    return this.resolveResponse(await this.axiosInstance.get(`places/by-zip/${zip}`));
  }

  /**
   * Vrati seznam POCE pro zadany vyraz
   */
  async GetPoCeByTerm(term: string): Promise<Array<IPoCe>> {
    return this.resolveResponse(await this.axiosInstance.get("poce/by-term", { params: { Term: term } }));
  }

  /**
   * Vrati konkretni POCE podle jeho ID
   */
  async GetPoCeById(id: Number): Promise<IPoCe> {
    return this.resolveResponse(await this.axiosInstance.get(`poce/by-id/${id}`));
  }

  /**
   * Vrati seznam POCE podle jejich ID
   */
  async GetManyPoCeById(id: Array<Number>): Promise<Array<IPoCe>> {
    const qs = id.join(",");
    return this.resolveResponse(await this.axiosInstance.get("poce/by-ids?id=" + qs));
  }
}
