import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";

export default class PmpAppsApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "pmp-apps");
  }

  /**
   * Seznam aplikaci na ktere ma uzivatel pravo
   * @param userId ID FP
   */
  async GetPermissions(userId: number): Promise<Array<any>> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/${userId}`));
  }

  /**
   * Seznam vsech aplikaci PMP
   */
  async GetApplications(): Promise<Array<any>> {
    return this.resolveResponse(await this.axiosInstance.get(this.basePath));
  }

  /**
   * Ulozeni prav na aplikace pro daneho uzivatele
   * @param userId FP ID
   * @param data seznam app a prav
   */
  async SavePermissions(userId: number, data: any) {
    return (await this.axiosInstance.put(`${this.basePath}/${userId}`, data)).data;
  }
}
