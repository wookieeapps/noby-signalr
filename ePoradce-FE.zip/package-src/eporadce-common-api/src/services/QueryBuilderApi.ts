import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import IQueryBuilderField from "../types/IQueryBuilderField";

export default class QueryBuilderApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "query-builder");
  }

  /**
   * Vraci seznam poli gridu ktere jsou k filtrovani v query builderu
   * @param ident IDENT gridu pro ktery se maji pole stahnout
   * @returns seznam objectTypes
   */
  async GetFields(ident: string): Promise<Array<IQueryBuilderField>> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/${ident}`));
  }
}
