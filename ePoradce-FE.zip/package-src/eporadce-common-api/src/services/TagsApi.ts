import { AxiosInstance } from "axios";
import { BaseApiService, ObjectTypes } from "@mpss/eporadce-common";
import { ITag } from "../types";

export default class TagsApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "tags");
  }

  CreateEmptyModel(): ITag {
    return {
      Id: 0,
      Name: "",
      ObjectTypeId: 0
    };
  }

  /**
   * Vraci seznam tagu
   * @returns [] tagu nebo NULL
   */
  async GetList(objectTypeId: ObjectTypes): Promise<Array<ITag>> {
    return (await this.axiosInstance.get(`${this.basePath}/${objectTypeId}`)).data;
  }

  /**
   * Smazat tag
   * @param tagId ID tagu
   */
  async Delete(tagId: number) {
    return (await this.axiosInstance.delete(`${this.basePath}/${tagId}`)).data;
  }

  /**
   * Zalozeni noveho tagu
   * @param model instance tagu
   * @returns ID nove zalozeneho tagu
   */
  async Create(model: ITag): Promise<number> {
    return (await this.axiosInstance.post(this.basePath, model)).data;
  }

  /**
   * Ulozeni existujiciho tagu
   * @param model instance tagu
   * @param tagId ID editovaneho tagu
   */
  async Edit(model: ITag, tagId: number) {
    return (await this.axiosInstance.put(`${this.basePath}/${tagId}`, model)).data;
  }

  async SaveFileBinding(objectTypeId: ObjectTypes, objectId: number, tags: Array<number>) {
    return (await this.axiosInstance.post(`${this.basePath}/bind/${objectTypeId}/${objectId}`, tags)).data;
  }
}
