import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { BaseApiService, DateHelpers } from "@mpss/eporadce-common";
import { ITicketList, ITicket, IIncrementalPaginableResult } from "../types";

export default class TicketsApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "tickets");
  }

  /**
   * Seznam moznych druhu ticketu pro daneho FP a uzivatele
   * @param userId ID FP
   */
  async GetListOfActions(userId: number): Promise<any> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/actions/list/${userId}`));
  }

  async Delete(ticketId: number) {
    return (await this.axiosInstance.delete(`${this.basePath}/${ticketId}`)).data;
  }

  /**
   * Detail typu akce - typu ticketu
   * @param ticketType Typ ticketu
   */
  async GetAction(ticketType: number): Promise<any> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/actions/${ticketType}`));
  }

  async Approve(ticketId: number, note: string) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${ticketId}/approve`, { note }));
  }

  async Disapprove(ticketId: number, note: string) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${ticketId}/disapprove`, { note }));
  }

  /**
   * Seznam approveru pro dany typ ticketu a uzivatele
   * @param userId ID FP
   * @param ticketType druh ticketu
   */
  async GetListOfApprovers(userId: number, ticketType: number): Promise<Array<number>> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/approvers/${userId}/${ticketType}`));
  }

  /**
   * Vytvoreni noveho ticketu
   * @param userId ID uzivatele, pro ktereho je ticket vytvoren
   * @param action TicketType
   * @param model obsah ticketu
   */
  async Create(userId: number, action: string, model: any) {
    return (await this.axiosInstance.put(`${this.basePath}/${userId}/actions/${action}`, model)).data;
  }

  /**
   * Detail ticketu
   * @param ticketId ID ticketu
   */
  async Get(ticketId: number): Promise<ITicket> {
    return this.resolveResponse(
      await this.axiosInstance.get(`${this.basePath}/${ticketId}`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): Array<ITicket> | null {
          if (data) {
            data.InsertTime = DateHelpers.parseISO(data.InsertTime);
            if (data.UpdateTime) data.UpdateTime = DateHelpers.parseISO(data.UpdateTime);
          }
          return data;
        })
      })
    );
  }

  /**
   * Seznam ticketu k danemu uzivateli
   * @param userId ID uzivatele pro ktereho se ma list zobrazit
   */
  async GetList(userId: number, start: number, count: number): Promise<IIncrementalPaginableResult<ITicketList>> {
    return this.resolveResponse(
      await this.axiosInstance.get(`${this.basePath}/list/${userId}?start=${start}&count=${count}`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): IIncrementalPaginableResult<ITicketList> | null {
          if (data && Array.isArray(data.Data)) {
            data.Data.forEach((t: ITicketList) => {
              t.InsertTime = DateHelpers.parseISO(t.InsertTime);
              if (t.UpdateTime) t.UpdateTime = DateHelpers.parseISO(t.UpdateTime);
            });
            return data;
          }
          return null;
        })
      })
    );
  }

  async DeleteAttachments(ticketId: number, files: Array<number>) {
    return this.resolveResponse(
      await this.axiosInstance.post(`${this.basePath}/${ticketId}/delete-attachments`, files)
    );
  }

  async GetListForApprover(): Promise<Array<ITicket>> {
    return this.resolveResponse(
      await this.axiosInstance.get(`${this.basePath}/mass-approval`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): Array<ITicket> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: ITicket) => {
              t.InsertTime = DateHelpers.parseISO(t.InsertTime);
            });
            return data;
          }
          return null;
        })
      })
    );
  }
}
