import IUserGroup from "../types/IUserGroup";
import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";

export default class UserGroupsApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "user-groups");
  }

  async Get(userGroupId: number): Promise<IUserGroup> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/${userGroupId}`));
  }

  async Search(
    term: string,
    applicationId: number,
    minLevel: number | null,
    maxLevel: number | null
  ): Promise<Array<IUserGroup>> {
    return this.resolveResponse(
      await this.axiosInstance.get(`${this.basePath}/search/${applicationId}`, {
        params: { term: term, minLevel: minLevel, maxLevel: maxLevel }
      })
    );
  }
}
