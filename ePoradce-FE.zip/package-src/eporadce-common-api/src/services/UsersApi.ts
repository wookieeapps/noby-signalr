import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { BaseApiService, DateHelpers } from "@mpss/eporadce-common";
import { IPaginableResult, IUserBaseQuery, IUserSimple, IUserList, IUser } from "../types";

export default class UsersApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "users");
  }

  private stringConstructor = "test".constructor;

  async Create(model: any): Promise<number> {
    return (await this.axiosInstance.post(this.basePath, model)).data;
  }

  /**
   * Vraci instanci uzivatele
   * @param userId ID uzivatele
   * @returns Instance uzivatele
   */
  async Get(userId: number): Promise<IUser> {
    return this.resolveResponse(
      await this.axiosInstance.get(`${this.basePath}/${userId}`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): Array<IUser> | null {
          if (data) {
            data.ContractDateFrom = DateHelpers.parseISO(data.ContractDateFrom);
            if (data.ContractDateTo) data.ContractDateTo = DateHelpers.parseISO(data.ContractDateTo);
            if (data.BirthDate) data.BirthDate = DateHelpers.parseISO(data.BirthDate);
          }
          return data;
        })
      })
    );
  }

  /**
   * Vraci instanci aktualne prihlaseneho uzivatele
   * @returns Instance uzivatele
   */
  async GetCurrentUser(): Promise<IUserSimple> {
    return this.resolveResponse(await this.axiosInstance.get(this.basePath));
  }

  /**
   * Vraci strankovatelny seznam uzivatelu podle zadaneho filtru
   * @param filter nastaveni filtru uzivatelu
   * @returns seznam skupin
   */
  async GetList(filter: any): Promise<IPaginableResult<IUserList>> {
    return this.resolveResponse(await this.axiosInstance.post(this.basePath + "/search", filter));
  }

  async GetListDeleted(filter: any): Promise<IPaginableResult<IUserList>> {
    return this.resolveResponse(await this.axiosInstance.post(this.basePath + "/search-deleted", filter));
  }

  /**
   * Vraci seznam uzivatelu odpovidaji filtru
   * @param requireId uzivatele kteri se vzdy vrati bez ohledu na dalsi filtrovani
   * @param roles sum pozadovanych roli
   * @param term Hledani podle retezce - ve jmene, CPM
   */
  async GetBaseList(requireIds: Array<number> | undefined, roles: number | undefined): Promise<Array<IUserBaseQuery>> {
    return this.resolveResponse(
      await this.axiosInstance.get(this.basePath + "/search", { params: { requireIds, roles } })
    );
  }

  /**
   * Vyhledavani - naseptavac v hlavni liste aplikace
   * @param term Hledani podle retezce - ve jmene, CPM
   */
  async GetGeneralSearch(term: string) {
    return this.resolveResponse(await this.axiosInstance.get(this.basePath + "/general-search", { params: { term } }));
  }

  /**
   * Vraci obsah meta pro uzivatele
   * @param userId nastaveni filtru uzivatelu\
   * @param metaId typ meta informace
   * @returns instance meta nebo prazdny string
   */
  async GetMeta(userId: number, metaId: number): Promise<string> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/${userId}/meta/${metaId}`));
  }

  /**
   * Vytvori nebu updatuje konkretni meta k uzivateli
   * @param userId nastaveni filtru uzivatelu
   * @param metaId typ meta informace
   * @param value nova hodnota meta informace
   */
  async SaveMeta(userId: number, metaId: number, value: any) {
    let type = 1;
    if (value === null || value === undefined) {
      value = "";
      type = 3;
    } else if (this.stringConstructor !== Object.constructor) {
      value = JSON.stringify(value);
      type = 2;
    }

    return this.resolveResponse(
      await this.axiosInstance.post(`${this.basePath}/${userId}/meta/${metaId}`, {
        Value: value,
        MetaType: type
      })
    );
  }

  /**
   * Vraci absolute URL obrazku s ksichtem uzivatele
   * @param userId ID uzivatele
   * @returns URL obrazku nebo HTTP 404
   */
  GetUserImageUrl(userId: number) {
    return `${this.baseURL}/${this.basePath}/image/${userId}.jpg`;
  }
}
