import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { BaseApiService, DateHelpers } from "@mpss/eporadce-common";
import { IUserMandate, IUserProvision } from "../types";

export default class UsersExtendedApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "users");
  }

  /**
   * Vraci rozsireny detail FP
   * @param userId UserId FP
   */
  async GetDetail(userId: number): Promise<any> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/${userId}/detail`));
  }

  /**
   * Vraci historii pozice
   * @param userId UserId FP
   */
  async GetPositionHistory(userId: number): Promise<any> {
    return this.resolveResponse(
      await this.axiosInstance.get(`${this.basePath}/${userId}/position-history`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): Array<any> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: any) => {
              t.DateFrom = DateHelpers.parseISO(t.DateFrom);
              if (t.DateTo) t.DateTo = DateHelpers.parseISO(t.DateTo);
            });
            return data;
          }
          return null;
        })
      })
    );
  }

  /**
   * Vraci atributy FP z P2
   * @param userId UserId FP
   */
  async GetP2Attributes(userId: number): Promise<any> {
    return this.resolveResponse(await this.axiosInstance.get(`${this.basePath}/${userId}/p2attributes`));
  }

  /**
   * Vraci seznam zmocneni FP
   * @param userId UserId FP
   */
  async GetMandates(userId: number): Promise<Array<IUserMandate>> {
    return this.resolveResponse(
      await this.axiosInstance.get(`${this.basePath}/${userId}/mandates`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): Array<IUserMandate> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: IUserMandate) => {
              if (t.RegistrationValidFrom) t.RegistrationValidFrom = DateHelpers.parseISO(t.RegistrationValidFrom);
              if (t.RegistrationValidTo) t.RegistrationValidTo = DateHelpers.parseISO(t.RegistrationValidTo);
              if (t.ValidFrom) t.ValidFrom = DateHelpers.parseISO(t.ValidFrom);
            });
            return data;
          }
          return null;
        })
      })
    );
  }

  /**
   * Vraci seznam provizi
   * @param userId UserId FP
   */
  async GetProvisions(userId: number): Promise<Array<IUserProvision>> {
    return this.resolveResponse(
      await this.axiosInstance.get(`${this.basePath}/${userId}/provisions`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): Array<IUserProvision> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: IUserProvision) => {
              if (t.Date) t.Date = DateHelpers.parseISO(t.Date);
            });
            return data;
          }
          return null;
        })
      })
    );
  }

  async SaveRiskType(riskType: number, userId: number) {
    return (await this.axiosInstance.put(`${this.basePath}/${userId}/risk-type`, { riskType })).data;
  }
}
