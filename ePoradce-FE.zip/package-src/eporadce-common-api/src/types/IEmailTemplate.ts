import { IEmailTemplateList } from ".";
import { ObjectTypes } from "@mpss/eporadce-common";

export default interface IEmailTemplate extends IEmailTemplateList {
  Subject: string;

  Text: string;

  ObjectTypeId: ObjectTypes;

  FileTypes: Array<number> | null;

  IsReadonly: boolean;
}
