export default interface IEmailTemplate2Object {
  Id: number;

  TemplateType: number;

  TemplateId: number;
}
