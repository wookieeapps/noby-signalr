import { ObjectTypes } from "@mpss/eporadce-common";

export default interface IEmailTemplateType {
  ObjectTypeId: ObjectTypes;

  Name: string;

  Id: number;
}
