import { ApplicationIdTypes } from "@mpss/eporadce-common";

export default interface IFileInfoType {
  Id: number;

  Name: string;

  ApplicationId: ApplicationIdTypes;

  UserRolesRead: number;

  UserRolesWrite: number;
}
