import { QueryBuilderFieldTypes } from "../Enums";
import { ApplicationIdTypes } from "@mpss/eporadce-common";

export default interface IQueryBuilderField {
  Id: number;

  GroupName: string;

  Label: string;

  InputType: QueryBuilderFieldTypes;

  InputTypeConfiguration: string | undefined;

  Operators: object;
}
