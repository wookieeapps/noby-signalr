import { ObjectTypes } from "@mpss/eporadce-common";

export default interface ITag {
  Id: number;

  Name: string;

  ObjectTypeId: ObjectTypes;
}
