export default interface ITicketList {
  Id: number;

  ParentId?: number | null;

  TypeText: string;

  Status: number;

  InsertTime: any;

  UpdateTime: any;
}
