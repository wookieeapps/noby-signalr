export default interface IUserGeneralSearch {
  Id: number;

  DisplayName: string;
}
