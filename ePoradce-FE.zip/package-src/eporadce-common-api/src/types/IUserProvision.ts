export default interface IUserProvision {
  Date: any;

  CoefficientName: string;

  CoefficientValue: number;
}
