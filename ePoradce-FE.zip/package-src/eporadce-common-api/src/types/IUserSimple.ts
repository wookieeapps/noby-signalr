export default interface IUserSimple {
  Id: number;

  m04ID: number | null | undefined;

  DisplayName: string;

  UserGroupId: number;

  PmpId: number | null | undefined;

  CPM: string;

  ICP: string;

  UserRoles: number;
}
