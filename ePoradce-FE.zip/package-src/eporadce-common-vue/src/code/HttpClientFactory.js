import axios from "axios";

export default function HttpClientFactory(baseUrl, appVersion, notAuthenticatedUrl) {
  // vytvorit globalni instanci axiosu
  const httpClient = axios.create({
    baseURL: baseUrl,
    withCredentials: true
  });

  httpClient.baseURL = baseUrl;
  httpClient.defaults.headers.common["App-Version"] = appVersion;

  httpClient.interceptors.response.use(
    (response) => {
      return response;
    },
    (error) => {
      if (!error.response) {
        // neni k dispozici internet nejspis
        //store.dispatch("setNetworkConnection", true);
      } else if (error.response.status === 404) {
        // stranka neexistuje
        //Notify.create("404 - Page not found");
      } else if (error.response.status >= 500) {
        // chyba serveru
        //Notify.create("500 - Server error");
      } else if (error.response.status == 400) {
        // chyba validace (snad)
        if (error.response.data.errors) {
          return Promise.resolve(error.response);
        } else {
          // pokud response neobsahuje kolekci chyb, asi byl problem napr. v neexistenci objektu = vrat null
          return Promise.resolve(null);
        }
      } else if (error.response.status === 401) {
        const currentUrl = location.href.replace(location.search, "");
        if (currentUrl.endsWith(notAuthenticatedUrl)) console.info("401 - user is not authenticated");
        else location.href = notAuthenticatedUrl + "?url=" + encodeURIComponent(location.href);
      }

      return Promise.reject(error);
    }
  );

  return httpClient;
}
