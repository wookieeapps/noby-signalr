import { UsersApi } from "@mpss/eporadce-common-api";

export default class UserInstance {
  constructor(httpClient) {
    this.fetchCount = 0;
    this.instance = null;
    this.fetching = false;
    this.loaded = false;
    this.usersApi = new UsersApi(httpClient);
  }

  /**
   * Vraci nakesovanou instanci aktualne prihlaseneho uzivatele
   */
  async get() {
    if (this.instance === null) {
      // pokud se jiz stahuje uzivatel ze serveru
      // da se to udelat lip?
      if (this.fetching) {
        // uz to bezelo v rekurzi mockrat
        if (this.fetchCount++ > 20) throw "Can't fetch user instance";

        // sleep
        await new Promise((r) => setTimeout(r, 1000));
        return this.get();
      }

      this.fetching = true;
      this.instance = await this.usersApi.GetCurrentUser();
      this.loaded = this.instance !== null;
      this.fetching = false;
    }

    return this.instance;
  }

  /**
   * Vraci nakesovanou instanci aktualne prihlaseneho uzivatele.
   * !!! Jedna se o synchroni verzi get() - pokud uzivatel nebyl jiz nakesovan zavolanim await get(), tak tato metoda vraci null.
   */
  getSync() {
    if (this.instance === null) throw "Instance of user does not exists; getSync";
    return this.instance;
  }

  /**
   * Kontroluje zda uzivatel ma danou roli ci ne
   * @param {UserRoles} role Pozadovana role uzivatele
   * @returns true pokud uzivatel ma danou roli
   */
  isInRole(role) {
    if (this.instance === null) throw `Instance of user does not exists; isInRole: ${role}`;
    return (this.instance.UserRoles & role) > 0;
  }

  /**
   * Kontroluje zda uzivatel ma alespon jednu z danych roli ci ne
   * @param {UserRoles} roles Pozadovane role uzivatele
   * @returns true pokud uzivatel ma danou roli
   */
  isInRoles(roles) {
    for (const r in roles) {
      if (this.isInRole(roles[r])) return true;
    }
    return false;
  }

  isInRoleGroup(group) {
    if (this.instance === null) throw `Instance of user does not exists; isInRoleGroup: ${group}`;
    return (this.instance.UserRoles & group) != 0;
  }
}
