<template>
  <div class="pa-3" v-if="fields !== null">
    <v-chip outlined small class="mr-2 grey--text" v-if="conditions == null || conditions.length === 0"
      >Filtr není nastavený</v-chip
    >

    <v-btn text icon color="red" small @click="deleteConditions" v-if="conditions != null && conditions.length > 1">
      <v-icon>close</v-icon>
    </v-btn>

    <v-chip outlined small class="mr-2 grey--text" v-if="conditions != null && conditions.length > 1">{{
      conditionConnector == 1 ? "a" : "nebo"
    }}</v-chip>

    <v-chip
      close
      small
      @click="showDialog"
      @click:close="deleteCondition(item.Guid)"
      class="mr-2"
      v-for="item in conditions"
      :key="item.Guid"
      >{{ formattedCondition(item) }}</v-chip
    >

    <v-chip small color="primary" @click="showDialog" class="mr-2"> <v-icon small>add</v-icon>Přidat </v-chip>

    <query-builder-dialog
      v-model="queryBuilderDialog"
      :conditions="dialogConditions"
      :condition-connector="conditionConnector"
      :fields="fields"
      @change="onChange"
      :key="dialogKey"
    />
  </div>
</template>

<script>
import { VChip, VBtn, VIcon } from "vuetify/lib";
import QueryBuilderDialog from "./QueryBuilderDialog.vue";
import { QueryBuilderApi } from "@mpss/eporadce-common-api";
import { DateHelpers } from "@mpss/eporadce-common";

export default {
  name: "QueryBuilder",

  components: { QueryBuilderDialog, VChip, VBtn, VIcon },

  props: ["value", "ident"],

  data() {
    return {
      queryBuilderDialog: false,
      // finalni podminky pro filtrovani
      conditions: this.parseConditions(this.value ? this.value.conditions : []),
      // spojovaci podminka mezi where castmi
      conditionConnector:
        this.value && [1, 2].includes(this.value.conditionConnector) ? this.value.conditionConnector : 1,
      // podminky pro filtrovani zobrazene do modalniho dialogu
      dialogConditions: null,
      // mozna pole k filtrovani
      fields: null,
      dialogKey: 1
    };
  },

  async mounted() {
    // seznam poli podle kterych je mozne filtrovat
    const queryBuilderApi = new QueryBuilderApi(this.$httpClient);
    this.fields = await queryBuilderApi.GetFields(this.ident);

    // pridat zobrazeni skupin - oddelovatc do comboboxu
    var lastApp = "";
    var end = this.fields.length - 1;
    for (var i = end; i > 0; i--) {
      if (lastApp != this.fields[i].GroupName) {
        if (lastApp != "") {
          this.fields.splice(i + 1, 0, { header: lastApp });
          this.fields.splice(i + 1, 0, { divider: true });
        }
        lastApp = this.fields[i].GroupName;
      }
    }
  },

  watch: {
    value(v) {
      if (!this.fields) this.$nextTick();
      this.conditions = this.parseConditions(v.conditions);
      this.conditionConnector = v.conditionConnector;
    }
  },

  methods: {
    parseConditions(conditions) {
      // zkusit konvertovat datumy
      conditions.forEach((t) => {
        if (
          this.fields.find((t2) => t2.Id == t.FieldId).InputType === 3 &&
          Object.prototype.toString.call(t.Value) !== "[object Date]"
        ) {
          t.Value = DateHelpers.parseISO(t.Value);
        }
      });
      return conditions;
    },

    showDialog() {
      this.dialogKey += 1;
      this.dialogConditions = this.conditions.map((t) => {
        return {
          FieldId: t.FieldId,
          Operator: t.Operator,
          Value: t.Value,
          Guid: t.Guid
        };
      });

      this.queryBuilderDialog = true;
    },

    formattedCondition(item) {
      const field = this.fields.find((t) => t.Id == item.FieldId);
      const op = field.Operators.find((t) => t.Key == item.Operator).Value;

      // boolean
      if (field.InputType == 4) {
        return `${field.Label} ${op} ${item.Value ? "ANO" : "NE"}`;
      } else if (item.Value) {
        if (Object.prototype.toString.call(item.Value) === "[object Date]") {
          // value je Date()
          return `${field.Label} ${op} ${DateHelpers.format(item.Value)}`;
        } else return `${field.Label} ${op} ${item.Value}`;
      } else {
        return `${field.Label} ${op}`;
      }
    },

    deleteConditions() {
      this.conditions = [];
      this.emitChange();
    },

    deleteCondition(guid) {
      this.$delete(
        this.conditions,
        this.conditions.findIndex((t) => t.Guid == guid)
      );
      this.emitChange();
    },

    onChange(newConditions, conditionConnector) {
      this.conditions = newConditions;
      this.conditionConnector = conditionConnector;

      this.emitChange();
    },

    emitChange() {
      this.$emit("input", {
        conditions: this.conditions,
        conditionConnector: this.conditionConnector
      });
    }
  }
};
</script>
