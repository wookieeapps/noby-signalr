<template>
  <v-dialog v-model="value" max-width="950px" scrollable>
    <v-card>
      <v-card-title>Filtrování uživatelů</v-card-title>
      <v-card-text>
        <div>
          <v-btn-toggle v-model="andOr" dense mandatory>
            <v-btn :value="1">A</v-btn>
            <v-btn :value="2">NEBO</v-btn>
          </v-btn-toggle>
          <v-btn text icon class="ml-4" color="primary" @click="addCondition">
            <v-icon>add</v-icon>
          </v-btn>

          <app-box-no-entries
            v-if="conditions == null || conditions.length == 0"
            :padding-left="false"
          >Klikněte na tlačítko plus pro přidání nové podmínky do filtru</app-box-no-entries>

          <v-form v-else ref="frmQueryItems" v-model="valid" lazy-validation>
            <v-slide-y-transition group>
              <query-builder-item
                :fields="fields"
                :condition="item"
                v-for="item in conditions"
                :key="item.Guid"
                @delete="onDelete"
              ></query-builder-item>
            </v-slide-y-transition>
          </v-form>
        </div>
      </v-card-text>
      <v-card-actions class="pr-4">
        <v-spacer></v-spacer>
        <v-btn color="gray" text @click="closeDialog">Storno</v-btn>
        <v-btn
          color="green"
          text
          @click="queryBuilderSave"
          :disabled="conditions == null || conditions.length === 0"
        >Filtrovat</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import {
  VDialog,
  VCard,
  VCardActions,
  VBtn,
  VSpacer,
  VCardText,
  VForm,
  VSlideYTransition,
  VBtnToggle,
  VCardTitle,
  VIcon
} from "vuetify/lib";
import { AppBoxNoEntries } from "../global/index";
import QueryBuilderItem from "./QueryBuilderItem.vue";
import Utils from "../../code/Utils";

export default {
  name: "QueryBuilderDialog",

  props: ["value", "conditions", "fields", "conditionConnector"],

  components: {
    QueryBuilderItem,
    AppBoxNoEntries,
    VDialog,
    VCard,
    VCardActions,
    VBtn,
    VSpacer,
    VCardText,
    VForm,
    VSlideYTransition,
    VBtnToggle,
    VCardTitle,
    VIcon
  },

  data() {
    return {
      // nastaveni vazby OR nebo AND
      andOr: this.conditionConnector,
      // validace vyplneni vsech polozek na radku
      valid: true
    };
  },

  methods: {
    closeDialog() {
      this.$emit("input", false);
    },

    onDelete(guid) {
      this.$delete(
        this.conditions,
        this.conditions.findIndex(t => t.Guid == guid)
      );
    },

    addCondition() {
      this.conditions.push({
        Guid: Utils.generateGuid(),
        FieldId: null,
        Operator: null,
        Value: ""
      });
    },

    queryBuilderSave() {
      // validation
      if (this.$refs.frmQueryItems.validate()) {
        this.$emit("change", this.conditions, this.andOr);

        this.closeDialog();
      } else {
        this.$toast.error("Nejsou vyplněny všechny podmínky filtru");
      }
    }
  }
};
</script>