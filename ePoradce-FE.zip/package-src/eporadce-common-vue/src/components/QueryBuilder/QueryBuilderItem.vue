<template>
  <v-row align="end">
    <v-col cols="5">
      <v-select
        dense
        hide-details
        placeholder="Filtrovací pole"
        :items="fields"
        item-value="Id"
        item-text="Label"
        v-model="condition.FieldId"
        required
        :rules="[(v) => !!v || false]"
        @input="onFieldChange"
      >
        <template v-slot:item="data">
          <template v-if="typeof data.item !== 'object'">
            <v-list-item-content v-text="data.item"></v-list-item-content>
          </template>
          <template v-else>
            <v-list-item-content>
              <v-list-item-title>{{ data.item.Label }}</v-list-item-title>
            </v-list-item-content>
          </template>
        </template>
      </v-select>
    </v-col>

    <v-col cols="2">
      <v-select
        dense
        hide-details
        placeholder="Operátor"
        :items="operators"
        item-value="Key"
        item-text="Value"
        v-model="condition.Operator"
        required
        :disabled="operators.length < 2"
        :rules="[(v) => !!v || false]"
      />
    </v-col>

    <v-col cols="4">
      <v-text-field
        v-if="conditionType == 1 || conditionType == 2"
        dense
        hide-details
        placeholder="Text"
        v-model="condition.Value"
        :type="conditionType == 1 ? 'text' : 'number'"
        required
        :rules="[(v) => !!v || false]"
      />

      <app-date-picker
        v-else-if="conditionType == 3"
        v-model="condition.Value"
        placeholder="Datum"
        dense
        hide-details
      />

      <v-select
        v-else-if="conditionType == 4"
        v-model="condition.Value"
        placeholder="Vyberte"
        dense
        hide-details
        item-text="Value"
        item-value="Key"
        :items="checkboxValues"
      />

      <v-select
        v-else-if="conditionType == 5"
        v-model="condition.Value"
        placeholder="Vyberte"
        dense
        hide-details
        item-text="Value"
        item-value="Key"
        :multiple="dropdownMultiple"
        :items="dropdownItems"
      />

      <v-autocomplete
        v-else-if="conditionType == 6"
        v-model="condition.Value"
        placeholder="Vyberte"
        item-value="Key"
        item-text="Value"
        hide-details
        no-filter
        hide-no-data
        dense
        :cache-items="false"
        clearable
        :search-input.sync="acSearch"
        :items="acDropdownItems"
        :loading="acLoading"
      />
    </v-col>

    <v-col cols="1">
      <v-btn text icon @click="deleteItem">
        <v-icon>clear</v-icon>
      </v-btn>
    </v-col>
  </v-row>
</template>

<script>
import { Helpers } from "@mpss/eporadce-common";
import {
  VRow,
  VCol,
  VBtn,
  VSelect,
  VTextField,
  VListItemTitle,
  VListItemContent,
  VIcon,
  VAutocomplete
} from "vuetify/lib";
import { AppDatePicker } from "../global/index";

export default {
  name: "QueryBuilderItem",

  props: ["condition", "fields"],

  components: {
    AppDatePicker,
    VAutocomplete,
    VRow,
    VCol,
    VBtn,
    VSelect,
    VTextField,
    VListItemTitle,
    VListItemContent,
    VIcon
  },

  data() {
    return {
      operators: [],
      acSearch: null,
      acLoading: false,

      acDropdownItems: [],

      checkboxValues: [
        { Key: 0, Value: "NE" },
        { Key: 1, Value: "ANO" }
      ]
    };
  },

  mounted() {
    this.onFieldChange();

    if (
      this.field &&
      this.field.InputTypeConfiguration &&
      this.field.InputTypeConfiguration.Remote &&
      this.field.InputType == 6
    ) {
      this.$httpClient.get(`${this.field.InputTypeConfiguration.Remote.Url}/${this.condition.Value}`).then((t) => {
        this.acDropdownItems = [t.data];
      });
    }
  },

  asyncComputed: {
    dropdownItems: {
      async get() {
        if (this.conditionType != 5) return [];

        // remote loading
        if (!this.field.InputTypeConfiguration.Items && this.field.InputTypeConfiguration.Remote) {
          return (await this.$httpClient.get(this.field.InputTypeConfiguration.Remote.Url)).data;
        } else return this.field.InputTypeConfiguration.Items;
      },
      default: [],
      watch: ["field"]
    }
  },

  watch: {
    acSearch(term) {
      if (this.conditionType != 6) return null;

      Helpers.debounce((term) => {
        if (term != this.acSearch) return;
        if (this.acDropdownItems && this.acDropdownItems.some((t) => t.Value == term)) return;

        this.acLoading = true;
        this.$httpClient
          .get(this.field.InputTypeConfiguration.Remote.Url, { params: { term } })
          .then((t) => {
            this.acDropdownItems = t.data;
          })
          .finally(() => (this.acLoading = false));
      }, 400)(term);
    }
  },

  computed: {
    field() {
      if (this.condition.FieldId == null) return null;
      return this.fields.find((t) => t.Id == this.condition.FieldId);
    },

    conditionType() {
      if (this.field == null) return 1;
      return this.field.InputType;
    },

    dropdownMultiple() {
      if (this.field == null) return false;
      return this.field.InputTypeConfiguration.Multiple;
    }
  },

  methods: {
    onFieldChange() {
      if (this.condition.FieldId == null) {
        this.operators = [];
      } else {
        this.operators = this.field.Operators;
        if (this.operators.length === 1) this.condition.Operator = this.operators[0].Key;
      }
    },

    deleteItem() {
      this.$emit("delete", this.condition.Guid);
    }
  }
};
</script>
