<template>
  <div class="pb-12 pt-12 text-center">
    <v-progress-circular indeterminate color="primary" />
  </div>
</template>
<script>
  import { VProgressCircular } from "vuetify/lib";

  export default {
    name: "AppBoxLoader",

    components: { VProgressCircular }
  };
</script>
