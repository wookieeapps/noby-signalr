<template>
  <div
    :class="[{ 'pl-4': paddingLeft }, 'pb-12', 'pt-10', 'grey--text', 'font-weight-light', 'caption']"
  >
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: "AppBoxNoEntries",
  props: {
    paddingLeft: {
      type: Boolean,
      required: false,
      default: true
    }
  }
};
</script>
