<template>
  <div>
    <v-menu
      v-model="displayPicker"
      :close-on-content-click="false"
      transition="scale-transition"
      offset-y
      min-width="290px"
    >
      <template v-slot:activator="{ on }">
        <v-text-field
          :value="formattedDatetime"
          :label="label"
          :prepend-icon="prependIcon"
          :dense="dense"
          :filled="filled"
          :hide-details="hideDetails"
          :single-line="singleLine"
          :disabled="disabled"
          :error-messages="errorMessages"
          v-on="on"
          v-on:input="oninput"
          v-on:click="checkPicker"
          v-on:keydown="checkPicker"
          v-on:blur="inputBlur"
          v-on:click:prepend="displayPicker = true"
        ></v-text-field>
      </template>

      <v-date-picker
        v-if="!isTimePicker"
        no-title
        :value="datePickerValue"
        v-bind="datePickerProps"
        v-on:change="dateClick"
        first-day-of-week="1"
      />
      <v-time-picker
        ref="timer"
        v-else-if="isDatetime"
        no-title
        :value="timePickerValue"
        v-bind="timePickerProps"
        v-on:change="timeClick"
      />
    </v-menu>
  </div>
</template>

<script>
import { VMenu, VTextField, VDatePicker, VTimePicker } from "vuetify/lib";
import { DateHelpers } from "@mpss/eporadce-common";

const DEFAULT_DATE = "";
const DEFAULT_TIME = "09:00";
const DEFAULT_ICO = "event";

export default {
  name: "AppDatetimePicker",
  components: { VMenu, VTextField, VDatePicker, VTimePicker, DateHelpers },
  model: {
    prop: "datetime",
    event: "input"
  },
  props: {
    datetime: {
      type: [Date, String],
      default: null
    },
    isDatetime: {
      type: Boolean,
      default: false
    },
    label: {
      type: String,
      default: ""
    },
    datePickerProps: {
      type: Object,
      default: () => {}
    },
    timePickerProps: {
      type: Object,
      default: () => {}
    },
    prependIcon: {
      type: String,
      default: DEFAULT_ICO
    },
    dense: {
      type: Boolean,
      default: false
    },
    filled: {
      type: Boolean,
      default: false
    },
    hideDetails: {
      type: Boolean,
      default: false
    },
    singleLine: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    errorMessages: {
      type: String | Array,
      default: () => []
    }
  },
  data: () => ({
    date: DEFAULT_DATE,
    time: DEFAULT_TIME,
    inputDate: null,
    inputTime: null,
    displayPicker: false,
    isTimePicker: false,
    isFailedValue: false
  }),

  methods: {
    init() {
      let initDateTime;
      if (this.datetime instanceof Date) {
        initDateTime = this.datetime;
      } else if (typeof this.datetime === "string" || this.datetime instanceof String) {
        initDateTime = this.tryParse(this.datetime);
      }

      if (initDateTime) {
        this.setDate(initDateTime);
        this.setTime(initDateTime);
      } else {
        this.date = "";
        this.time = "";
      }
    },
    tryParse(value) {
      if (this.isDatetime) {
        return DateHelpers.parseDatetime(value);
      } else {
        return DateHelpers.parse(value);
      }
    },
    setDate(value) {
      this.date = DateHelpers.format(value, DateHelpers.getGuiDateFormat());
    },
    setTime(value) {
      this.time = DateHelpers.formatTime(value);
    },
    oninput(value) {
      const d = this.tryParse(value);
      if (d) {
        this.inputDate = DateHelpers.format(d, DateHelpers.getGuiDateFormat());
        this.inputTime = DateHelpers.formatTime(d);
      }
    },
    checkPicker(e) {
      this.isTimePicker = e.target.selectionStart > 10 && this.tryParse(e.target.value);
    },
    inputBlur(e) {
      const d = this.tryParse(e.target.value);
      if (d) {
        this.setDate(d);
        this.setTime(d);
        this.isFailedValue = false;
      } else {
        this.isFailedValue = true;
      }
      this.$emit("input", d);
    },
    dateClick(value) {
      this.inputDate = null;
      const d = this.tryParse(value);
      if (d) {
        this.setDate(d);
        this.$emit("input", d);
      }
      if (this.isDatetime) {
        this.isTimePicker = true;
      } else {
        this.reset();
      }
    },
    timeClick(value) {
      this.inputTime = null;
      const d = this.tryParse(this.date + " " + value);
      if (d) {
        this.setTime(d);
        this.$emit("input", d);
      }
      this.reset();
    },
    reset() {
      if (this.$refs.timer) {
        this.$refs.timer.selectingHour = true;
      }
      this.displayPicker = false;
    }
  },

  mounted() {
    this.init();
  },

  computed: {
    formattedDatetime() {
      const d = this.selectedDatetime;
      if (d) {
        this.isFailedValue = false;
        if (this.isDatetime) {
          return DateHelpers.formatDatetime(d);
        } else {
          return DateHelpers.format(d);
        }
      }
    },
    selectedDatetime() {
      if (this.isDatetime) {
        if (this.date && this.time) {
          return DateHelpers.parseISO(this.date + " " + this.time);
        } else if (this.date) {
          return DateHelpers.parseISO(this.date);
        }
      } else {
        if (this.date) {
          return DateHelpers.parseISO(this.date);
        }
      }
    },
    datePickerValue() {
      return this.inputDate ? this.inputDate : this.date;
    },
    timePickerValue() {
      return this.inputTime ? this.inputTime : this.date;
    }
  },
  watch: {
    datetime: function () {
      this.init();
    }
  }
};
</script>
