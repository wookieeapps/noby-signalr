<template>
  <div>
    <div class="pb-4 d-flex align-center justify-space-between">
      <div class="d-flex align-center" v-if="backTo">
        <v-btn light icon large :to="backTo" class="mr-4">
          <v-icon color="grey darken-2">arrow_back</v-icon>
        </v-btn>
        <span class="title font-weight-regular grey--text text--darken-4">
          <slot name="back"></slot>
        </span>
      </div>
      <v-spacer v-else />

      <div>
        <slot name="actions"></slot>

        <v-fab-transition>
          <v-btn
            v-show="showErrorsFab"
            color="red"
            fab
            dark
            absolute
            style="right: -60px; top: 6px;"
            @click="toggleErrorMessages"
          >
            <v-icon>report_problem</v-icon>
          </v-btn>
        </v-fab-transition>
      </div>
    </div>
    <v-alert dense outlined color="red" v-show="showErrorMessages">
      <div class="caption" v-html="messages"></div>
    </v-alert>
  </div>
</template>

<script>
import { VBtn, VAlert, VIcon, VFabTransition, VSpacer } from "vuetify/lib";

export default {
  name: "AppPageToolbar",

  components: { VBtn, VAlert, VIcon, VFabTransition, VSpacer },

  props: ["back-to", "validation-errors"],

  data() {
    return {
      showErrorMessages: false
    };
  },

  watch: {
    validationErrors(newState) {
      if (newState.length === 0) this.showErrorMessages = false;
    },

    messages(val) {
      this.$emit("validationChanged", val);
    }
  },

  computed: {
    showErrorsFab() {
      return Object.keys(this.validationErrors).length > 0;
    },

    messages() {
      const arr = [];
      for (let [key, value] of Object.entries(this.validationErrors)) {
        arr.push(value);
      }
      return arr.join("<br/>");
    }
  },

  methods: {
    toggleErrorMessages() {
      this.showErrorMessages = !this.showErrorMessages;
    }
  }
};
</script>
