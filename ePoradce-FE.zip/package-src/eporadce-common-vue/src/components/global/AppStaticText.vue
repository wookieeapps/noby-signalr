<template>
  <div :class="cssClass">
    <div class="v-input__control">
      <div class="v-input__slot">
        <div class="v-text-field__slot">
          <label class="v-label v-label--active v-label--is-disabled theme--light">{{ label }}</label
          ><span><slot></slot></span>
        </div>
      </div>
      <div v-if="!hideDetails" class="v-text-field__details"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "AppStaticText",

  props: {
    label: {
      type: String
    },

    dense: {
      type: Boolean,
      default: false
    },

    hideDetails: {
      type: Boolean,
      default: false
    }
  },

  computed: {
    cssClass() {
      const arr = ["v-input", "app-static-text", "v-input--is-label-active", "theme--light", "v-text-field"];
      if (this.dense) arr.push("v-input--dense");
      return arr;
    }
  }
};
</script>
