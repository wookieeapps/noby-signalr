<template>
  <div :class="masterClass">
    <v-tooltip bottom v-if="labelTooltip">
      <template v-slot:activator="{ on }">
        <label v-html="label" v-on="on"></label>
      </template>
      <span>{{ this.labelTooltip }}</span>
    </v-tooltip>
    <label v-else v-html="label"></label>

    <div>
      <slot>
        <v-tooltip bottom v-if="tooltip">
          <template v-slot:activator="{ on }">
            <span v-html="compText" v-on="on"></span>
          </template>
          <span>{{ this.tooltip }}</span>
        </v-tooltip>
        <a v-else-if="textType == 'tel' && text" :href="('tel:' + text)">{{ text }}</a>
        <a v-else-if="textType == 'email' && text" :href="('mailto:' + text)">{{ text }}</a>
        <span v-else v-html="compText"></span>
        <span :class="secondaryClass" v-if="textSecondary && !hideSecondary">({{ textSecondary }})</span>
      </slot>
    </div>
  </div>
</template>

<script>
import { VTooltip } from "vuetify/lib";

export default {
  name: "AppTextWithLabel",

  components: { VTooltip },

  props: {
    hideSecondary: {
      required: false,
      default: false,
      type: Boolean
    },
    textType: {
      required: false,
      type: String,
      default: "text"
    },
    compareText: {
      required: false,
      type: Boolean,
      default: false
    },
    label: {
      required: true,
      type: String
    },
    text: {
      required: false,
      type: String
    },
    textSecondary: {
      required: false,
      type: String
    },
    width: {
      required: false,
      type: Number
    },
    dense: {
      required: false,
      type: Boolean,
      default: false
    },
    labelTooltip: {
      required: false,
      type: String,
      default: null
    },
    tooltip: {
      required: false,
      type: String,
      default: null
    }
  },

  computed: {
    compText() {
      return this.text ? this.text : '<i class="grey--text font-weight-light">není</i>';
    },

    masterClass() {
      const base = ["app-text-w-label"];

      if (this.width) base.push("lw" + this.width);
      if (this.dense) base.push("dense");

      return base;
    },

    secondaryClass() {
      const base = ["font-weight-light"];

      if (this.compareText) {
        if (this.textSecondary && this.textSecondary !== this.text) base.push("warning--text");
        else base.push("text--disabled");
      } else base.push("text--disabled");

      return base;
    }
  }
};
</script>
