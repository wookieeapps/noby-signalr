<template>
  <v-avatar color="white">
    <v-img
      :src="getUserImg"
      lazy-src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAwBJREFUeNrsWTFok1EQ/hsyZMjg0CFDBkULGRwqtFChQsUKgkIVFRQEFbs5qChRUSeVQrDgYDeHCkIFFRUtIioOdggoWNAhYEWFDBk6OHRwCMTv4AI/Ie9/995/MS28g48/Td7/7r57d+/evQ60Wq1oI0sm2uASCAQCgUAg0F/Jpp2gXC7H/xwHpoBtQIFBUgcaQA14Ciy3X6hUKv0lABkErgEn+HM32Rz7fJ0J3QdmgbU0ygd8KzE8n2XDzwObPPXTqtzCKsz9VwIwnkLjGTCmFMqvgOMgstZzAjC+hMdboKicj9+AvSDR6BkB9vyXWHImyQonK4XaiJAwkdjpshIZB+NzeLwUGE/KTwFDwFHgELAFuAQ0Le9uBxZ6VQdusidtQsY/6PiuyTvOFcH7B+Css6ohhAlp+b8DOcvQKoWAZdv+KQgnyoMhSShlHLyfE4yrWn6nlfgsmIfC9KJKCMH7eTyOCYk2BWP+Cuea1sqBPULvkwwLxowI5yrCecMaBI44JPokMJHw+0k+J0nlsAaBkmNBWjCQIGPuOc5l1Z0VJpSL0PgPwLtYIRvzPHYUNAj4HhkmGWmkqBFC67pfkRBo9JFAXSOEGg55sMSggvYj1qxQv7CVO7YJ4XYrcp6EwIpFYZN3lzkea5Jlbifb9eIcn5tsulOH0HOLh+jsc0GirIPMaWCfpXq/0CCwmKBkWni2Mckb7o27ySoOc0upCWCSP9zydZPfCon6xPD9Q81+4KphFR57FLrOQtVtBchpt9UIYBVqBo9QqX/tWeyo+/rYceXSlrvQuardkZkSlXaUr8AZ4a5GJ9vLwCfDwa4q9b5PU19ixXnDkF+8UovcoMfrABGd4t6ikFC4Rl1uJnyuVcY5bPLKVZeM3s3h2pOmvp0PtLWNOu77NqGteIer8d6HOVZEJOaFbWRSe3kH2OV6oeUdQoa8mKHrkEh+WUyGPwJuwPB6Gv0at9M1vryiRN0PHIySr9epcL2PUt5Kq61AvyX8iykQCAQCgUAglfwTYADuRs8ngznCOAAAAABJRU5ErkJggg=="
      :width="width"
    />
  </v-avatar>
</template>

<script>
import { VAvatar, VImg } from "vuetify/lib";
import { UsersApi } from "@mpss/eporadce-common-api";

export default {
  name: "AppUserAvatar",

  props: {
    userId: {
      type: Number,
      required: true
    },
    width: {
      type: Number,
      required: false,
      default: 40
    }
  },

  components: { VAvatar, VImg },

  computed: {
    getUserImg() {
      const api = new UsersApi(this.$httpClient);
      return api.GetUserImageUrl(this.userId);
    }
  }
};
</script>
