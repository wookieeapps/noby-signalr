// Import vue components
import * as components from "@/components/global/index";
import UserInstance from "@/code/UserInstance";
import { DateHelpers } from "@mpss/eporadce-common";
import * as filters from "@/filters/index";

// install function executed by Vue.use()
const install = function installEporadceCommonVue(Vue, options) {
  if (install.installed) return;
  install.installed = true;

  // options check
  if (!options.httpClient) {
    throw "options.httpClient not passed to plugin";
  }

  // globally register shared components
  Object.entries(components).forEach(([componentName, component]) => {
    Vue.component(componentName, component);
  });

  // globally register axios
  Vue.prototype.$httpClient = options.httpClient;

  // create shared vuex store
  Vue.prototype.$appConfiguration = {
    appVersion: options.appVersion,
    applicationId: options.applicationId
  };

  // user instance in VUE instance
  Vue.prototype.$user = new UserInstance(options.httpClient);

  // let dateHelpers be accessible from templates
  Vue.prototype.$dates = DateHelpers;

  // register global filters
  Object.keys(filters).forEach((key) => {
    Vue.filter(key, filters[key]);
  });
};

// Create module definition for Vue.use()
const plugin = {
  install
};

// To auto-install when vue is found
// eslint-disable-next-line no-redeclare
/* global window, global */
let GlobalVue = null;
if (typeof window !== "undefined") {
  GlobalVue = window.Vue;
} else if (typeof global !== "undefined") {
  GlobalVue = global.Vue;
}
if (GlobalVue) {
  GlobalVue.use(plugin);
}

// Default export is library as a whole, registered via Vue.use()
export default plugin;

// To allow individual component use, export components
// each can be registered via Vue.component()
export * from "@/components/global/index";
export * from "@/components/index";

export { default as Utils } from "./code/Utils";

// AXIOS INSTANCE
export { default as HttpClientFactory } from "./code/HttpClientFactory.js";

// MIXINS
export * from "@/mixins/index";

// LAYOUTS
export * from "@/layouts/index";
