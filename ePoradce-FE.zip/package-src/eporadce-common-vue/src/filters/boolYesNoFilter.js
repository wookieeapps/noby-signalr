export default function (value) {
  if (value === undefined || value === null) return "";
  return value ? "ANO" : "NE";
}
