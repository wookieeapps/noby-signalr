import { DateHelpers } from "@mpss/eporadce-common";

export default function (value, defaultValue) {
  if (!value || !(value instanceof Date)) return defaultValue || "";
  return DateHelpers.format(value);
}
