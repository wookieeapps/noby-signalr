import { DateHelpers } from "@mpss/eporadce-common";

export default function(value) {
  if (!value || !(value instanceof Date)) return "";
  return DateHelpers.formatDatetime(value);
}
