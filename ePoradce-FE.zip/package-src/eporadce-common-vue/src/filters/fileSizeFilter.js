export default function (value) {
  if (!value) return "";
  const x = Math.round(Number(value) / 10, 2) / 1000;
  return `${x} MB`;
}
