import { DateHelpers } from "@mpss/eporadce-common";

export default function (value, defaultValue) {
  const d = DateHelpers.parseISO(value);
  if (!d || !(d instanceof Date)) return defaultValue || "";
  return DateHelpers.formatDatetime(d);
}
