<template>
  <v-main class="body-2" style="background-color: #f1f1f1;">
    <v-responsive max-width="1224px" class="mx-auto my-4 overflow-visible">
      <v-container>
        <slot></slot>
      </v-container>
    </v-responsive>
  </v-main>
</template>

<script>
import { VMain, VResponsive, VContainer } from "vuetify/lib";

export default {
  name: "LayoutContent",

  components: {
    VMain,
    VResponsive,
    VContainer
  }
};
</script>
