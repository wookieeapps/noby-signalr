<template>
  <v-navigation-drawer v-model="opened" :clipped="$vuetify.breakpoint.lgAndUp" app>
    <v-list class="font-weight-medium app-main-menu" v-if="items && items.length > 0">
      <template v-for="(item, index) in items">
        <template v-if="item.children">
          <v-divider :key="'d' + index" />
          <v-list-group :key="index" :prepend-icon="item.icon" no-action>
            <template v-slot:activator>
              <v-list-item-content>
                <v-list-item-title>{{ item.text }}</v-list-item-title>
              </v-list-item-content>
            </template>
            <v-list-item v-for="(child, i) in item.children" :key="'s' + i" exact link :to="child.link">
              <v-list-item-content>
                <v-list-item-title class="grey--text text--darken-1">{{ child.text }}</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list-group>
        </template>

        <v-list-item v-else :key="index" :to="item.link" exact link>
          <v-list-item-action>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title>{{ item.text }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </template>
    </v-list>

    <app-box-loader v-else />
  </v-navigation-drawer>
</template>

<script>
import VAppBoxLoader from "../components/global/AppBoxLoader.vue";
import {
  VNavigationDrawer,
  VList,
  VListItem,
  VListItemContent,
  VListItemAction,
  VListItemTitle,
  VDivider,
  VIcon,
  VListGroup
} from "vuetify/lib";

export default {
  props: ["value", "items"],

  name: "LayoutMainMenu",

  components: {
    VAppBoxLoader,
    VNavigationDrawer,
    VList,
    VListItem,
    VListItemContent,
    VListItemAction,
    VListItemTitle,
    VDivider,
    VIcon,
    VListGroup
  },

  computed: {
    opened: {
      get() {
        return this.value;
      },
      set(value) {
        this.$emit("input", value);
      }
    }
  }
};
</script>
