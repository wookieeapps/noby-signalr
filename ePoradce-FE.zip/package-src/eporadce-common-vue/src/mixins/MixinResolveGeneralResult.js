import { MixinValidateField } from "./MixinValidateField";

export const MixinResolveGeneralResult = {
  mixins: [MixinValidateField],

  data() {
    return {
      // list chyb pri validaci (ulozeni)
      validationErrors: {},
      // state ukladaciho buttonu
      saveBtnLoading: false,
      // state delete buttonu
      deleteBtnLoading: false
    };
  },

  methods: {
    onBeforeSave() {
      this.saveBtnLoading = true;
      this.validationErrors = {};
    },

    async resolveGeneralResult(result, successRouteName, successMessage = null, errorMessage = null, callback = null, errorsPrefix = null) {
      this.saveBtnLoading = false;
      this.deleteBtnLoading = false;

      if (this.resolveSubResult(result, errorMessage, errorsPrefix)) {
        if (callback) {
          if (!(await callback(result))) return false;
        }

        if (successMessage) this.$toast.success(successMessage);

        if (successRouteName) {
          if (typeof successRouteName === "string") {
            this.$router.push({ name: successRouteName, params: { refresh: true } });
          } else {
            this.$router.push(successRouteName);
          }
        } 

        return true;
      } else return false;
    },

    resolveSubResult(result, errorMessage, errorsPrefix) {
      if (result !== null && result.errors) {
        if (errorsPrefix) {
          let obj = {};

          for (var prop in result.errors) {
            obj[errorsPrefix + prop] = result.errors[prop];
          }
          for (var prop in this.validationErrors) {
            obj[prop] = this.validationErrors[prop];
          }

          this.validationErrors = obj;
        } else this.validationErrors = result.errors;

        this.$toast.error(errorMessage ? errorMessage : "Akci nebylo možno provést");

        return false;
      } else return true;
    }
  }
};
