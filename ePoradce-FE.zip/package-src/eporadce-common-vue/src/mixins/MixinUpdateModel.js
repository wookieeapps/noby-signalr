export const MixinUpdateModel = {
  methods: {
    update(key, value) {
      this.$emit("input", { ...this.value, [key]: value });
    }
  }
};
