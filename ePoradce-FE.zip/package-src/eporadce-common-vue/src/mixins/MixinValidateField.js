export const MixinValidateField = {
  methods: {
    validateField(name) {
      if (this.validationErrors) return this.validationErrors[name] || [];
    },

    validateFieldPrefix(prefix, index, name) {
      if (this.validationErrors) return this.validationErrors[`${prefix}[${index}].${name}`] || [];
    }
  }
};
