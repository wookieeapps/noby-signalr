<template>
  <div>
    <v-card>
      <v-card-title class="justify-space-between">
        <span>{{ title }}</span>
        <div>
          <v-btn color="primary" text tile small @click.stop="itemEdit()">Nová položka</v-btn>
        </div>
      </v-card-title>
      <v-divider />

      <app-box-loader v-if="items === null" />

      <app-box-no-entries v-else-if="items.length === 0">Nejsou uloženy žádné položky</app-box-no-entries>

      <v-card-text class="pa-0" v-else>
        <v-simple-table>
          <thead>
            <tr>
              <th>Text</th>
              <th>Kód</th>
              <th>Barva</th>
            </tr>
          </thead>
          <template v-slot:default>
            <tbody>
              <tr v-for="item in items" :key="item.Id">
                <td>{{ item.Text }}</td>
                <td>{{ item.Code }}</td>
                <td>{{ item.Color }}</td>
                <td class="text-right">
                  <v-btn icon class="mr-2">
                    <v-icon small @click="itemEdit(item.Id)">edit</v-icon>
                  </v-btn>
                  <v-btn icon>
                    <v-icon small @click="itemDelete(item.Id)">delete</v-icon>
                  </v-btn>
                </td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-card-text>
    </v-card>

    <v-dialog v-model="dialog" max-width="500px">
      <v-card>
        <v-card-title>
          <span class="headline">Editace položky</span>
        </v-card-title>
        <v-card-text>
          <v-text-field label="Název" v-model="model.Name" :error-messages="validateField('Name')" />
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="gray" text @click="dialog = false">Storno</v-btn>
          <v-btn color="green" text @click="itemSave" :loading="saveLoading">Uložit</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import { MixinResolveGeneralResult } from "@mpss/eporadce-common-vue";
import { CommonListsApi } from "@mpss/eporadce-common-api";

export default {
  name: "PageCodeLists",

  props: ["title", "module", "listType"],

  mixins: [MixinResolveGeneralResult],

  data() {
    return {
      items: null,
      dialog: false,
      model: {},
      saveLoading: false,
      api: null
    };
  },

  async mounted() {
    this.api = new CommonListsApi(this.$httpClient);
    this.items = await this.api.GetList(this.module, this.listType);
  },

  methods: {
    // Smazani polozky
    async itemDelete(id) {
      if (await this.$confirm("Opravdu si přejete smazat tuto položku?")) {
        if (this.resolveSubResult(await api.Delete(id, "Položku nebylo možné smazat"))) {
          this.$delete(
            this.items,
            this.items.findIndex((t) => t.Id === id)
          );
        }
      }
    },

    // zobrazeni detailu sekvence
    async itemEdit(id) {
      this.model = id ? await this.api.Get(id) : this.api.CreateEmptyModel();

      this.dialog = true;
    },

    // ulozeni sekvence
    async itemSave() {
      this.saveLoading = true;

      const result =
        this.model.Id > 0 ? await this.api.Edit(this.model, this.model.Id) : await this.api.Create(this.model);

      if (this.resolveSubResult(result, "Položku nebylo možné uložit", "")) {
        this.dialog = false;

        // nove ID
        if (this.model.Id === 0) this.model.Id = parseInt(result);

        // index objektu v gridu
        const index = this.items.findIndex((t) => t.Id == this.model.Id);

        // updatovat grid
        if (index >= 0) this.$set(this.items, index, this.model);
        else this.items.push(this.model);

        this.$toast.success("Položka byla uložena");
      }

      this.saveLoading = false;
    }
  }
};
</script>
