import "material-design-icons-iconfont/dist/material-design-icons.css";
import "vuetify/dist/vuetify.min.css";
import Vue from "vue";
import Dev from "@/serve-dev.vue";
import Vuetify from "vuetify";
import VueRouter from "vue-router";

Vue.config.productionTip = false;

Vue.use(Vuetify, {
  icons: {
    iconfont: "md"
  }
});

Vue.use(VueRouter);
const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes: []
});

new Vue({
  router,
  vuetify: new Vuetify(),
  render: h => h(Dev)
}).$mount("#app");
