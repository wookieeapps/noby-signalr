<script>
  import Vue from "vue";
  import {
    AppBoxLoader,
    AppBoxNoEntries,
    AppPageToolbar,
    LayoutAppBar,
    LayoutContent,
    LayoutMainMenu,
    PageEmailTemplates,
    AppDatePicker
  } from "@/entry";

  export default Vue.extend({
    name: "ServeDev",
    components: {
      AppBoxLoader,
      AppBoxNoEntries,
      AppPageToolbar,
      LayoutAppBar,
      LayoutContent,
      LayoutMainMenu,
      PageEmailTemplates,
      AppDatePicker
    },

    data() {
      return {
        coll: [],
        dateProps: { noTitle: true },
        dateValue: "2000-01-01",
        newDate: new Date(),
        dateISO: ""//new Date().toISOString()
      };
    },

    methods: {
      dateChanged: function(value) {
        this.dateISO = value;
      }
    }
  });
</script>

<template>
  <v-app>
    <layout-main-menu />
    <layout-app-bar />
    <layout-content>
      <app-box-loader />
      <app-box-no-entries text="no entries" />
      <app-page-toolbar back-to="test" validation-errors="coll" />
      <app-date-picker label="Datum" v-model="newDate" />
      <app-date-picker label="Datum a čas v-model" v-model="dateISO" isDatetime />
      <app-date-picker label="Datum a čas v-bind & v-on" :datetime="dateISO" @input="dateChanged" />
      <span>{{dateISO}}</span>
    </layout-content>
  </v-app>
</template>
