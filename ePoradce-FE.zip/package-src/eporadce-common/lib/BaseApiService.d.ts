import { AxiosInstance, AxiosResponse } from "axios";
export default abstract class BaseApiService {
    /**
     * instance HTTP klienta
     */
    protected readonly axiosInstance: AxiosInstance;
    /**
     * Base API URL
     */
    protected readonly baseURL: string;
    /**
     * Base API route
     */
    protected readonly basePath: string;
    constructor(axiosInstance: AxiosInstance, basePath: string);
    protected resolveResponse(response: AxiosResponse): any;
}
