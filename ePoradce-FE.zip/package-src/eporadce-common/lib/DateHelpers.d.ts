export declare function addMonths(date: Date, amount: number): Date;
export declare function startOfMonth(date: Date): Date;
/** Zformatuje datum na string */
export declare function format(date: Date | number, formatString?: string): string;
/** Zformatuje datum a cas na string */
export declare function formatDatetime(datetime: Date | number): string;
/** Zformatuje cas z datumu */
export declare function formatTime(datetime: Date | number): string;
/** Zkusi udelat ze stringu datum */
export declare function parse(argument: string): Date | null;
/** Zkusi udelat ze stringu datum a cas */
export declare function parseDatetime(argument: string): Date | null;
/** Zkusi udelat datum ze stringu a vlastniho formatu */
export declare function parseFormat(argument: string, formatString: string): Date | null;
/** Prevede datum v ISO formatu do data */
export declare function parseISO(argument: string): Date | null;
/** Vraci vychozi format */
export declare function getDateFormat(): string;
/** Vraci vychozi format */
export declare function getDatetimeFormat(): string;
/** Vraci vychozi format */
export declare function getGuiDateFormat(): string;
