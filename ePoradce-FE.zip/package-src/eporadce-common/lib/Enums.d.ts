/**
 * Seznam aplikaci v ePoradci
 */
export declare enum ApplicationIdTypes {
    None = 0,
    eOla = 1,
    Hiring = 2,
    User = 3
}
/**
 * Entity v ramci vsech aplikaci
 */
export declare enum ObjectTypes {
    None = 1,
    eOlaCourse = 2,
    eOlaCourseGroup = 4,
    eOlaCourseEvent = 8,
    HiringUser = 16,
    Ticket = 32,
    User = 64
}
/**
 * Seznam uzivatelsky roli
 */
export declare enum UserRoles {
    Unknown = 0,
    None = 1,
    Ufo = 2,
    Newbie = 4,
    Sales = 8,
    SalesManager = 16,
    Agency = 32,
    eOlaAdmin = 64,
    eOlaLector = 128,
    HiringRecruiter = 256,
    HiringController = 512,
    HiringSupervisor = 1024,
    HiringApprovers904906 = 2048,
    HiringApprovers903998 = 4096,
    AppAdministrator = 8192,
    Employee = 16384,
    eAdminEmployees = 32768,
    eAdminSales = 65536,
    ReadOnlyUserList = 131072,
    eOlaAttendeeManager = 262144
}
export declare enum UserRolesGroups {
    CanSearchInUsers = 493520,
    Hiring = 7936,
    eOla = 262336
}
