export declare function createUUID(): string;
export declare function debounce(callback: any, wait: any): (this: any, ...args: any) => void;
export declare function sleep(ms: number): Promise<unknown>;
