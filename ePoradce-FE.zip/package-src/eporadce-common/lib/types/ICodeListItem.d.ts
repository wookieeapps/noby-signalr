export default interface ICodeListItem {
    Id: number;
    Code: string | null;
    Text: string;
    Color: string | null;
}
