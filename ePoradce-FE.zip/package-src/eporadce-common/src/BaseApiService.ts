import { AxiosInstance, AxiosResponse } from "axios";

export default abstract class BaseApiService {
  /**
   * instance HTTP klienta
   */
  protected readonly axiosInstance: AxiosInstance;

  /**
   * Base API URL
   */
  protected readonly baseURL: string;

  /**
   * Base API route
   */
  protected readonly basePath: string;

  constructor(axiosInstance: AxiosInstance, basePath: string) {
    this.axiosInstance = axiosInstance;
    this.basePath = basePath;
    // @ts-ignore
    this.baseURL = axiosInstance.baseURL;
  }

  protected resolveResponse(response: AxiosResponse) {
    return response.status === 204 ? null : response.data;
  }
}
