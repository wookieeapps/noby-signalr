import {
  addMonths as addMonthsFns,
  startOfMonth as startOfMonthFns,
  format as formatFns,
  parse as parseFns,
  parseISO as parseISOFns,
} from "date-fns";
import { cs } from "date-fns/locale";

const DEFAULT_DATE_FORMAT = "dd.MM.yyyy";
const DEFAULT_TIME_FORMAT = "HH:mm";
const GUI_DATE_FORMAT = "yyyy-MM-dd";
const SMALL_DATE_FORMAT = "d.M.yyyy";

export function addMonths(date: Date, amount: number): Date {
  return addMonthsFns(date, amount);
}

export function startOfMonth(date: Date): Date {
  return startOfMonthFns(date);
}

/** Zformatuje datum na string */
export function format(date: Date | number, formatString = DEFAULT_DATE_FORMAT): string {
  return formatFns(date, formatString, {
    locale: cs,
  });
}

/** Zformatuje datum a cas na string */
export function formatDatetime(datetime: Date | number): string {
  return format(datetime, DEFAULT_DATE_FORMAT + " " + DEFAULT_TIME_FORMAT);
}

/** Zformatuje cas z datumu */
export function formatTime(datetime: Date | number): string {
  return format(datetime, DEFAULT_TIME_FORMAT);
}

/** Zkusi udelat ze stringu datum */
export function parse(argument: string): Date | null {
  let d = parseFormat(argument, DEFAULT_DATE_FORMAT);

  if (d == null) {
    d = parseFormat(argument, GUI_DATE_FORMAT);
  }

  if (d == null) {
    d = parseFormat(argument, SMALL_DATE_FORMAT);
  }

  if (d == null) {
    d = parseISO(argument);
  }

  return d;
}

/** Zkusi udelat ze stringu datum a cas */
export function parseDatetime(argument: string): Date | null {
  let d = parseFormat(argument, DEFAULT_DATE_FORMAT + " " + DEFAULT_TIME_FORMAT);

  if (d == null) {
    d = parseFormat(argument, GUI_DATE_FORMAT + " " + DEFAULT_TIME_FORMAT);
  }

  if (d == null) {
    d = parseFormat(argument, SMALL_DATE_FORMAT + " " + DEFAULT_TIME_FORMAT);
  }

  if (d == null) {
    d = parse(argument);
  }

  if (d == null) {
    d = parseISO(argument);
  }

  return d;
}

/** Zkusi udelat datum ze stringu a vlastniho formatu */
export function parseFormat(argument: string, formatString: string): Date | null {
  const d = parseFns(argument, formatString, new Date(), { locale: cs });
  if (!isNaN(d.getTime())) {
    return d;
  }
  //console && console.log("parseFormat:", `hodnota ${argument} neodpovida formatu ${formatString}`);
  return null;
}

/** Prevede datum v ISO formatu do data */
export function parseISO(argument: string): Date | null {
  const d = parseISOFns(argument);
  if (!isNaN(d.getTime())) {
    return d;
  }
  //console && console.log("parseISO:", `hodnota ${argument} neni datum`);
  return null;
}

/** Vraci vychozi format */
export function getDateFormat(): string {
  return DEFAULT_DATE_FORMAT;
}
/** Vraci vychozi format */
export function getDatetimeFormat(): string {
  return DEFAULT_DATE_FORMAT + " " + DEFAULT_TIME_FORMAT;
}
/** Vraci vychozi format */
export function getGuiDateFormat(): string {
  return GUI_DATE_FORMAT;
}
