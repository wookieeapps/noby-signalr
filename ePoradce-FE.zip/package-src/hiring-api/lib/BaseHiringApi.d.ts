import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
export default abstract class BaseHiringApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance, basePath: string);
    /**
     * Smazat poradce
     * @param userId ID poradce
     */
    Delete(userId: number): Promise<any>;
}
