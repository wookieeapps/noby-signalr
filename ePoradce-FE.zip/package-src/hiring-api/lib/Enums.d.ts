/**
 * Mozne vysledkky kontrol noveho FP
 */
export declare enum UserValidationResults {
    Unknown = 0,
    Ok = 1,
    Unwanted = 2,
    DuplicityCPM = 4,
    IsExPa = 8,
    Renewal = 16,
    Renumbering = 32
}
export declare enum UserWorkflowStatuses {
    None = 0,
    Onboarding = 1,
    Checkin = 2,
    Validation = 3,
    Approval = 4,
    FinalCheck = 5,
    Seating = 6,
    ToDelete = 7,
    Deleted = 8,
    Seated = 9,
    FailedSeating = 10
}
/**
 * Mozne statusy radku checklistu
 */
export declare enum ChecklistStatuses {
    None = 0,
    Passed = 1,
    PassedWithWarning = 2,
    Failed = 3
}
