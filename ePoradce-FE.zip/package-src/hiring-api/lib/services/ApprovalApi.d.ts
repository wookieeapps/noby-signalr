import { AxiosInstance } from "axios";
import BaseHiringApi from "../BaseHiringApi";
import { IApprovalEdit } from "../types";
export default class ApprovalApi extends BaseHiringApi {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Odeslani FP na Pě
     * @param userId ID poradce
     */
    Approve(model: IApprovalEdit, userId: number): Promise<any>;
    /**
     * Odeslani FP na smazani
     * @param userId ID poradce
     */
    Disapprove(model: IApprovalEdit, userId: number): Promise<any>;
}
