import { AxiosInstance } from "axios";
import { IUser2Attribute, IHiringAttributeValue } from "../types";
import { BaseApiService } from "@mpss/eporadce-common";
export default class AttributesApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Vraci atributy P2 pro dane FP
     * @param userId ID FP
     */
    GetList(userId: number): Promise<Array<IUser2Attribute>>;
    GetOverview(userId: number): Promise<Array<IHiringAttributeValue>>;
}
