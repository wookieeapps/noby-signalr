import { AxiosInstance } from "axios";
import { IHiringCompositeModel, ICheckinProceedResult } from "../types";
import BaseHiringApi from "../BaseHiringApi";
export default class CheckinApi extends BaseHiringApi {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Editace existujiciho poradce
     * @param userModel instance poradce
     * @param userId ID editovaneho poradce
     */
    Edit(model: IHiringCompositeModel, userId: number): Promise<any>;
    /**
     * Odeslani poradce do dalsiho workflow statusu
     * @param userId ID poradce
     */
    Proceed(model: IHiringCompositeModel, userId: number): Promise<any>;
    /**
     * Vraci prvni volne CPM a ICP
     * @param userId ID FP
     */
    GetFreeCPM(userId: number): Promise<ICheckinProceedResult>;
}
