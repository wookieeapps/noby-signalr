import { AxiosInstance } from "axios";
import { IUser2Checklist, IChecklistHistory } from "../types";
import { BaseApiService } from "@mpss/eporadce-common";
export default class ChecklistsApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Vraci checklist kontrol pro dane FP
     * @param userId ID FP
     */
    GetList(userId: number): Promise<Array<IUser2Checklist>>;
    /**
     * Vraci historii checklistu pro dane FP
     * @param userId ID FP
     * @param checklistId ID checklistu
     */
    GetHistory(userId: number, checklistId: number): Promise<Array<IChecklistHistory>>;
    Save(model: any, userId: number): Promise<any>;
    ClearPeriodic(userId: number): Promise<any>;
}
