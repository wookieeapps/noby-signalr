import { AxiosInstance } from "axios";
import BaseHiringApi from "../BaseHiringApi";
import { IFinalCheckEdit } from "../types";
export default class FinalCheckApi extends BaseHiringApi {
    constructor(axiosInstance: AxiosInstance);
    Proceed(model: IFinalCheckEdit, userId: number): Promise<any>;
}
