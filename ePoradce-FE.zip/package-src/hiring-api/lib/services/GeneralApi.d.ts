import { AxiosInstance } from "axios";
import { IHiringUserList, IHiringUser, IFilesCollection } from "../types";
import { BaseApiService } from "@mpss/eporadce-common";
export default class GeneralApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    Dashboard(): Promise<any>;
    /**
     * Detail poradce
     * @param userId ID poradce
     * @returns instance poradce nebo NULL
     */
    Get(userId: number): Promise<IHiringUser>;
    /**
     * Seznam poradcu pro aktualniho uzivatele
     * @returns Seznam poradcu
     */
    GetList(): Promise<Array<IHiringUserList>>;
    /**
     * Vygeneruje dany typ souboru pro FP a ulozi ho do tempu
     * @param docType Druh souboru
     * @returns URL vygenerovaneho souboru
     */
    GenerateDoc(userId: number, docType: string): Promise<string>;
    /**
     * Pouze upload souboru k FP
     * @param userId ID FP
     * @param files seznam uploadovanych souboru
     */
    Upload(files: IFilesCollection, userId: number): Promise<any>;
}
