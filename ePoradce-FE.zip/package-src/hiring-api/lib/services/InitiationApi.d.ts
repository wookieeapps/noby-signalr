import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { IInitiationCreate } from "../types";
export default class InitiationApi extends BaseApiService {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Ulozeni noveho poradce
     * @param userModel instance poradce
     * @returns ID nove zalozeneho poradce
     */
    Create(model: IInitiationCreate): Promise<number>;
}
