import { AxiosInstance } from "axios";
import IHiringCompositeModel from "../types/IHiringCompositeModel";
import BaseHiringApi from "../BaseHiringApi";
export default class OnboardingApi extends BaseHiringApi {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Editace existujiciho poradce
     * @param model instance poradce a soubory
     * @param userId ID editovaneho poradce
     */
    Edit(model: IHiringCompositeModel, userId: number): Promise<any>;
    /**
     * Odeslani poradce do dalsiho workflow statusu
     * @param userId ID poradce
     */
    Proceed(model: IHiringCompositeModel, userId: number): Promise<any>;
}
