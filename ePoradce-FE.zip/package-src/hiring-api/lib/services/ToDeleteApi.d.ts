import { AxiosInstance } from "axios";
import BaseHiringApi from "../BaseHiringApi";
export default class ToDeleteApi extends BaseHiringApi {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Navrat do predchoziho statusu
     * @param userId ID poradce
     */
    ReturnToLastStatus(userId: number): Promise<any>;
    GetList(): Promise<Array<any>>;
}
