import { AxiosInstance } from "axios";
import BaseHiringApi from "../BaseHiringApi";
import IValidationCompositeModel from "../types/IValidationCompositeModel";
export default class ValidationApi extends BaseHiringApi {
    constructor(axiosInstance: AxiosInstance);
    /**
     * Editace existujiciho poradce
     * @param model instance poradce a soubory
     * @param userId ID editovaneho poradce
     */
    Edit(model: IValidationCompositeModel, userId: number): Promise<any>;
    /**
     * Odeslani poradce do dalsiho workflow statusu
     * @param userId ID poradce
     */
    Proceed(model: IValidationCompositeModel, userId: number): Promise<any>;
}
