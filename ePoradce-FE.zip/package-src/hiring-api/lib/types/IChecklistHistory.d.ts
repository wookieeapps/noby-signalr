import IUser2ChecklistEdit from "./IUser2ChecklistEdit";
export default interface IChecklistHistory extends IUser2ChecklistEdit {
    InsertTime: any;
    InsertUser: string;
}
