export default interface IFilesCollection {
    Files: Array<any>;
}
