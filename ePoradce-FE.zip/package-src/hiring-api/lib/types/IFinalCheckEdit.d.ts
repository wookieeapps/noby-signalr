export default interface IFinalCheckEdit {
    ContractDateFrom: Date;
}
