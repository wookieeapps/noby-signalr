export default interface IHiringAttributeValue {
    Code: string;
    Value: string;
    DateFrom: any;
    DateTo: any;
}
