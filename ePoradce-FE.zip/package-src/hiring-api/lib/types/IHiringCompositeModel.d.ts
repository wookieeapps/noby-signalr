import { IHiringUser, IFilesCollection } from ".";
export default interface IHiringCompositeModel extends IFilesCollection {
    User: IHiringUser;
}
