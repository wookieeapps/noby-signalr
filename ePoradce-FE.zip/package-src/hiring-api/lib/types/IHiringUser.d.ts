import { IUserWorkflow } from ".";
import { UserWorkflowStatuses } from "..";
export default interface IHiringUser {
    Id?: number;
    PersonalId: string;
    Firstname: string;
    Surname: string;
    Email: string;
    EmailPersonal: string;
    Mobil: string;
    Addr1Street: string;
    Addr1City: string;
    Addr1Zip: string;
    Addr2Street: string;
    Addr2City: string;
    Addr2Zip: string;
    IsReadonly: boolean;
    InsertUserId: number;
    WorkflowStatus: UserWorkflowStatuses;
    Workflow: Array<IUserWorkflow> | null;
    AccountNo: string;
    BankCode: string;
    SpecificSymbol: string;
    PositionCode: string;
}
