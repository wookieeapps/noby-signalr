export default interface IInitiationCreate {
    PersonalId: string;
    UserGroupType: string;
}
