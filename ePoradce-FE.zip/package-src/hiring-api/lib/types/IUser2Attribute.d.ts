import IUser2AttributeEdit from "./IUser2AttributeEdit";
export default interface IUser2Attribute extends IUser2AttributeEdit {
    User2AttributeId: number | null;
    ChecklistId: number | null;
    Name: string;
    Code: string;
    Configuration: any;
}
