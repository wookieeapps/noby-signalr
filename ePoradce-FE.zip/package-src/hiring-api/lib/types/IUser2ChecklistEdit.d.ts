import { ChecklistStatuses } from "..";
export default interface IUser2ChecklistEdit {
    Id: number;
    Status: ChecklistStatuses;
    HasRequest: boolean;
    Note: string;
    RequestNote: string;
}
