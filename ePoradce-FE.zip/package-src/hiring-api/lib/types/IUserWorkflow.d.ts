export default interface IUserWorkflow {
    DisplayName: string;
    Status: number;
    StatusName: string;
    InsertTime: any;
}
