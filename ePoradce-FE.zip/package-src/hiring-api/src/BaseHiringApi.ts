import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";

export default abstract class BaseHiringApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance, basePath: string) {
    super(axiosInstance, basePath);
  }

  /**
   * Smazat poradce
   * @param userId ID poradce
   */
  async Delete(userId: number) {
    return (await this.axiosInstance.delete(`${this.basePath}/${userId}`)).data;
  }
}
