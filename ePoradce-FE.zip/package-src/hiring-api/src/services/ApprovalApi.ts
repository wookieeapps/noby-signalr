import { AxiosInstance } from "axios";
import BaseHiringApi from "../BaseHiringApi";
import { IApprovalEdit } from "../types";

export default class ApprovalApi extends BaseHiringApi {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring/approval");
  }

  /**
   * Odeslani FP na Pě
   * @param userId ID poradce
   */
  async Approve(model: IApprovalEdit, userId: number) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${userId}/approve`, model));
  }

  /**
   * Odeslani FP na smazani
   * @param userId ID poradce
   */
  async Disapprove(model: IApprovalEdit, userId: number) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${userId}/disapprove`, model));
  }
}
