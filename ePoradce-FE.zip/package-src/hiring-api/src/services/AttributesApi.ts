import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { IUser2Attribute, IValidationCompositeModel, IHiringAttributeValue } from "../types";
import { DateHelpers, BaseApiService } from "@mpss/eporadce-common";

export default class AttributesApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring/attributes");
  }

  /**
   * Vraci atributy P2 pro dane FP
   * @param userId ID FP
   */
  async GetList(userId: number): Promise<Array<IUser2Attribute>> {
    return (
      await this.axiosInstance.get(`${this.basePath}/${userId}`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function(
          data: any
        ): Array<IUser2Attribute> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: IUser2Attribute): void => {
              if (t.DateFrom) t.DateFrom = DateHelpers.parseISO(t.DateFrom);
              if (t.DateTo) t.DateTo = DateHelpers.parseISO(t.DateTo);
            });
            return data;
          }
          return null;
        })
      })
    ).data;
  }

  async GetOverview(userId: number): Promise<Array<IHiringAttributeValue>> {
    return (
      await this.axiosInstance.get(`${this.basePath}/${userId}/p2`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function(
          data: any
        ): Array<IHiringAttributeValue> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: IHiringAttributeValue): void => {
              if (t.DateFrom) t.DateFrom = DateHelpers.parseISO(t.DateFrom);
              if (t.DateTo) t.DateTo = DateHelpers.parseISO(t.DateTo);
            });
            return data;
          }
          return null;
        })
      })
    ).data;
  }
}
