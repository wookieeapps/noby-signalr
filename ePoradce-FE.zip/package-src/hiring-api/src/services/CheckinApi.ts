import { AxiosInstance } from "axios";
import { IHiringCompositeModel, ICheckinProceedResult } from "../types";
import BaseHiringApi from "../BaseHiringApi";

export default class CheckinApi extends BaseHiringApi {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring/checkin");
  }

  /**
   * Editace existujiciho poradce
   * @param userModel instance poradce
   * @param userId ID editovaneho poradce
   */
  async Edit(model: IHiringCompositeModel, userId: number) {
    return this.resolveResponse(await this.axiosInstance.put(`${this.basePath}/${userId}`, model));
  }

  /**
   * Odeslani poradce do dalsiho workflow statusu
   * @param userId ID poradce
   */
  async Proceed(model: IHiringCompositeModel, userId: number) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${userId}`, model));
  }

  /**
   * Vraci prvni volne CPM a ICP
   * @param userId ID FP
   */
  async GetFreeCPM(userId: number): Promise<ICheckinProceedResult> {
    return (await this.axiosInstance.get(`${this.basePath}/${userId}/getcpm`)).data;
  }
}
