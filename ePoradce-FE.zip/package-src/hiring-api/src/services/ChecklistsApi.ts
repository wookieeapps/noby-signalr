import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { IUser2Checklist, IChecklistHistory } from "../types";
import { DateHelpers, BaseApiService } from "@mpss/eporadce-common";

export default class ChecklistsApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring/checklists");
  }

  /**
   * Vraci checklist kontrol pro dane FP
   * @param userId ID FP
   */
  async GetList(userId: number): Promise<Array<IUser2Checklist>> {
    return (
      await this.axiosInstance.get(`${this.basePath}/${userId}`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function(
          data: any
        ): Array<IUser2Checklist> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: IUser2Checklist): void => {
              t.InsertTime = DateHelpers.parseISO(t.InsertTime);
              if (t.RequestSentDate) t.RequestSentDate = DateHelpers.parseISO(t.RequestSentDate);
            });
            return data;
          }
          return null;
        })
      })
    ).data;
  }

  /**
   * Vraci historii checklistu pro dane FP
   * @param userId ID FP
   * @param checklistId ID checklistu
   */
  async GetHistory(userId: number, checklistId: number): Promise<Array<IChecklistHistory>> {
    return (
      await this.axiosInstance.get(`${this.basePath}/${userId}/${checklistId}/history`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function(
          data: any
        ): Array<IChecklistHistory> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: IChecklistHistory): void => {
              t.InsertTime = DateHelpers.parseISO(t.InsertTime);
            });
            return data;
          }
          return null;
        })
      })
    ).data;
  }

  async Save(model: any, userId: number) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${userId}`, model));
  }

  async ClearPeriodic(userId: number) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${userId}/clear-periodic`));
  }
}
