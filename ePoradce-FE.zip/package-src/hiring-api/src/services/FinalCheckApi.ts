import { AxiosInstance } from "axios";
import BaseHiringApi from "../BaseHiringApi";
import { IFinalCheckEdit } from "../types";

export default class FinalCheckApi extends BaseHiringApi {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring/finalcheck");
  }

  async Proceed(model: IFinalCheckEdit, userId: number) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${userId}/proceed`, model));
  }
}
