import axios, { AxiosInstance, AxiosTransformer } from "axios";
import { IHiringUserList, IHiringUser, IUserWorkflow, IFilesCollection } from "../types";
import { DateHelpers, BaseApiService } from "@mpss/eporadce-common";

export default class GeneralApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring");
  }

  async Dashboard(): Promise<any> {
    return (
      await this.axiosInstance.get(`${this.basePath}/dashboard`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): any {
          if (data && data.OpenedRequests && Array.isArray(data.OpenedRequests)) {
            data.OpenedRequests.forEach((t: any) => {
              t.Date = DateHelpers.parseISO(t.Date);
            });
          }
          return data;
        })
      })
    ).data;
  }

  /**
   * Detail poradce
   * @param userId ID poradce
   * @returns instance poradce nebo NULL
   */
  async Get(userId: number): Promise<IHiringUser> {
    return (
      await this.axiosInstance.get(`${this.basePath}/${userId}`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): Array<IHiringUser> | null {
          if (data && data.Id) {
            if (data.DraftContractDate) data.DraftContractDate = DateHelpers.parseISO(data.DraftContractDate);
            if (data.ContractDateFrom) data.ContractDateFrom = DateHelpers.parseISO(data.ContractDateFrom);

            // datumy ve statusech
            if (data.Workflow && Array.isArray(data.Workflow)) {
              data.Workflow.forEach((w: IUserWorkflow): void => {
                w.InsertTime = DateHelpers.parseISO(w.InsertTime);
              });
            }
            return data;
          }
          return null;
        })
      })
    ).data;
  }

  /**
   * Seznam poradcu pro aktualniho uzivatele
   * @returns Seznam poradcu
   */
  async GetList(): Promise<Array<IHiringUserList>> {
    return (
      await this.axiosInstance.get(`${this.basePath}/list`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function (
          data: any
        ): Array<IHiringUserList> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: IHiringUserList): void => {
              t.InsertTime = DateHelpers.parseISO(t.InsertTime);
              if (t.DraftDate) t.DraftDate = DateHelpers.parseISO(t.DraftDate);
            });
            return data;
          }
          return null;
        })
      })
    ).data;
  }

  /**
   * Vygeneruje dany typ souboru pro FP a ulozi ho do tempu
   * @param docType Druh souboru
   * @returns URL vygenerovaneho souboru
   */
  async GenerateDoc(userId: number, docType: string): Promise<string> {
    return (await this.axiosInstance.get(`${this.basePath}/${userId}/docs/${docType}`)).data;
  }

  /**
   * Pouze upload souboru k FP
   * @param userId ID FP
   * @param files seznam uploadovanych souboru
   */
  async Upload(files: IFilesCollection, userId: number) {
    return (await this.axiosInstance.put(`${this.basePath}/${userId}/upload`, files)).data;
  }
}
