import { AxiosInstance } from "axios";
import { BaseApiService } from "@mpss/eporadce-common";
import { IInitiationCreate } from "../types";

export default class InitiationApi extends BaseApiService {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring/initiation");
  }

  /**
   * Ulozeni noveho poradce
   * @param userModel instance poradce
   * @returns ID nove zalozeneho poradce
   */
  async Create(model: IInitiationCreate): Promise<number> {
    return this.resolveResponse(await this.axiosInstance.post(this.basePath, model));
  }
}
