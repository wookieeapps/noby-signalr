import { AxiosInstance } from "axios";
import IHiringCompositeModel from "../types/IHiringCompositeModel";
import BaseHiringApi from "../BaseHiringApi";

export default class OnboardingApi extends BaseHiringApi {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring/onboarding");
  }

  /**
   * Editace existujiciho poradce
   * @param model instance poradce a soubory
   * @param userId ID editovaneho poradce
   */
  async Edit(model: IHiringCompositeModel, userId: number) {
    return this.resolveResponse(await this.axiosInstance.put(`${this.basePath}/${userId}`, model));
  }

  /**
   * Odeslani poradce do dalsiho workflow statusu
   * @param userId ID poradce
   */
  async Proceed(model: IHiringCompositeModel, userId: number) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${userId}/proceed`, model));
  }
}
