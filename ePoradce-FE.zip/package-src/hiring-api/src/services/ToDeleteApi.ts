import { DateHelpers } from "@mpss/eporadce-common";
import axios, { AxiosInstance, AxiosTransformer } from "axios";
import BaseHiringApi from "../BaseHiringApi";

export default class ToDeleteApi extends BaseHiringApi {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring/to-delete");
  }

  /**
   * Navrat do predchoziho statusu
   * @param userId ID poradce
   */
  async ReturnToLastStatus(userId: number) {
    return (await this.axiosInstance.post(`${this.basePath}/${userId}`)).data;
  }

  async GetList(): Promise<Array<any>> {
    return (
      await this.axiosInstance.get(`${this.basePath}/list`, {
        transformResponse: (axios.defaults.transformResponse as Array<AxiosTransformer>).concat(function(
          data: any
        ): Array<any> | null {
          if (data && Array.isArray(data)) {
            data.forEach((t: any): void => {
              t.UpdateTime = DateHelpers.parseISO(t.UpdateTime);
            });
            return data;
          }
          return null;
        })
      })
    ).data;
  }
}
