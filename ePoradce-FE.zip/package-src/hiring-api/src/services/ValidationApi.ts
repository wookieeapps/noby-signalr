import { AxiosInstance } from "axios";
import BaseHiringApi from "../BaseHiringApi";
import IValidationCompositeModel from "../types/IValidationCompositeModel";

export default class ValidationApi extends BaseHiringApi {
  constructor(axiosInstance: AxiosInstance) {
    super(axiosInstance, "hiring/validation");
  }

  /**
   * Editace existujiciho poradce
   * @param model instance poradce a soubory
   * @param userId ID editovaneho poradce
   */
  async Edit(model: IValidationCompositeModel, userId: number) {
    return this.resolveResponse(await this.axiosInstance.put(`${this.basePath}/${userId}`, model));
  }

  /**
   * Odeslani poradce do dalsiho workflow statusu
   * @param userId ID poradce
   */
  async Proceed(model: IValidationCompositeModel, userId: number) {
    return this.resolveResponse(await this.axiosInstance.post(`${this.basePath}/${userId}/proceed`, model));
  }
}
