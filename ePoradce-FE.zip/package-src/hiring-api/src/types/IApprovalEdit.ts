export default interface IApprovalEdit {
  ApprovalNote: string;

  Approve: boolean;
}
