import { UserValidationResults } from "../Enums";

export default interface ICheckinProceedResult {
  CPM: string;

  ICP: string;

  ValidationResults: UserValidationResults;
}
