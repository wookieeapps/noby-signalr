export default interface IChecklistConfiguration {
  FileInfoTypes: Array<number> | null;
}
