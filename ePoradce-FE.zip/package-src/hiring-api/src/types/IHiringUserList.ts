export default interface IHiringUserList {
  Id: number;

  PersonalId: string;

  Displayname: string;

  Status: number;

  StatusText: string;

  InsertTime: any;

  InsertedBy: string;

  DraftDate: any;
}
