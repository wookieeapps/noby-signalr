export default interface IUser2AttributeEdit {
  Id: number;
  Value: any;
  DateFrom: any;
  DateTo: any;
}
