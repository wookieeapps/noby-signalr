import IChecklistConfiguration from "./IChecklistConfiguration";
import IUser2ChecklistEdit from "./IUser2ChecklistEdit";

export default interface IUser2Checklist extends IUser2ChecklistEdit {
  User2ChecklistId: number | null;
  Help: string;
  InsertTime: any;
  InsertUser: string;
  Name: string;
  Configuration: IChecklistConfiguration | null;
  RequestSentDate: any;
}
