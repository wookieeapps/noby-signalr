import { IHiringCompositeModel, IUser2ChecklistEdit, IUser2AttributeEdit } from ".";

export default interface IValidationCompositeModel extends IHiringCompositeModel {
  Checklists: Array<IUser2ChecklistEdit> | null;

  Attributes: Array<IUser2AttributeEdit> | null;
}
