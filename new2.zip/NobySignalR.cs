﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using NOBY.Api.Hubs;
using NOBY.Api.Services.SignalR;
using StackExchange.Redis;

namespace NOBY.Api.StartupExtensions;

internal static class NobySignalR
{
    /// <summary>
    /// Adds SignalR services to the application with optional Redis backplane
    /// </summary>
    public static IServiceCollection AddNobySignalR(this IServiceCollection services, IConfiguration configuration)
    {
        var signalRBuilder = services.AddSignalR();

        // Configure Redis backplane if connection string is available
        var redisConnectionString = configuration.GetConnectionString("cisDistributedCache");
        if (!string.IsNullOrEmpty(redisConnectionString))
        {
            signalRBuilder.AddStackExchangeRedis(options =>
            {
                options.Configuration = ConfigurationOptions.Parse(redisConnectionString);
                options.Configuration.ChannelPrefix = RedisChannel.Literal("SignalR:");
            });
        }

        // Register custom user ID provider to use CIS.Core.Security.SecurityConstants.ClaimTypeId
        services.AddSingleton<IUserIdProvider, NobyUserIdProvider>();

        // Register SignalR documentation service for automatic documentation generation
        services.AddSingleton<ISignalRDocumentationService, SignalRDocumentationService>();
        
        return services;
    }
}
