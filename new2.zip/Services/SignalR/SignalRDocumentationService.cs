using System.Reflection;
using Microsoft.AspNetCore.SignalR;

namespace NOBY.Api.Services.SignalR;

/// <summary>
/// Service that generates SignalR documentation dynamically from Hub definitions using reflection
/// </summary>
public interface ISignalRDocumentationService
{
    /// <summary>
    /// Gets documentation for all SignalR hubs in the application
    /// </summary>
    SignalRDocumentation GetDocumentation();
}

/// <summary>
/// Implementation that reflects Hub types to generate documentation automatically
/// </summary>
internal sealed class SignalRDocumentationService : ISignalRDocumentationService
{
    private readonly ILogger<SignalRDocumentationService> _logger;

    public SignalRDocumentationService(ILogger<SignalRDocumentationService> logger)
    {
        _logger = logger;
    }

    public SignalRDocumentation GetDocumentation()
    {
        var documentation = new SignalRDocumentation
        {
            Hubs = []
        };

        try
        {
            // Get all Hub types from the current assembly
            var hubTypes = Assembly.GetExecutingAssembly()
                .GetTypes()
                .Where(t => t.IsClass && !t.IsAbstract && IsHubType(t))
                .ToList();

            _logger.LogInformation("Found {Count} SignalR hub(s) in assembly", hubTypes.Count);

            foreach (var hubType in hubTypes)
            {
                var hubDoc = GenerateHubDocumentation(hubType);
                if (hubDoc != null)
                {
                    documentation.Hubs.Add(hubDoc);
                    _logger.LogDebug("Generated documentation for hub: {HubName}", hubDoc.Name);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating SignalR documentation");
            throw;
        }

        return documentation;
    }

    private static bool IsHubType(Type type)
    {
        var baseType = type.BaseType;
        while (baseType != null)
        {
            if (baseType.IsGenericType && baseType.GetGenericTypeDefinition() == typeof(Hub<>))
            {
                return true;
            }
            baseType = baseType.BaseType;
        }
        return false;
    }

    private HubDocumentation? GenerateHubDocumentation(Type hubType)
    {
        try
        {
            // Get client interface type from Hub<T>
            var clientInterfaceType = hubType.BaseType?.GetGenericArguments().FirstOrDefault();
            if (clientInterfaceType == null)
            {
                _logger.LogWarning("Could not find client interface for hub: {HubType}", hubType.Name);
                return null;
            }

            // Get XML documentation summary
            var xmlSummary = GetXmlDocumentation(hubType);
            
            // Determine endpoint - by convention it's /api/{hubname without 'Hub' suffix}
            var hubName = hubType.Name;
            var endpointName = hubName.EndsWith("Hub", StringComparison.OrdinalIgnoreCase) 
                ? hubName[..^3].ToLowerInvariant() 
                : hubName.ToLowerInvariant();
            var endpoint = $"/api/{endpointName}hub";

            // Check if [Authorize] attribute is present
            var requiresAuth = hubType.GetCustomAttribute<Microsoft.AspNetCore.Authorization.AuthorizeAttribute>() != null;

            var hubDoc = new HubDocumentation
            {
                Name = hubName,
                Description = xmlSummary ?? $"SignalR hub: {hubName}",
                Endpoint = endpoint,
                RequiresAuthentication = requiresAuth,
                ServerMethods = GetServerMethods(hubType),
                ClientMethods = GetClientMethods(clientInterfaceType)
            };

            return hubDoc;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating documentation for hub: {HubType}", hubType.Name);
            return null;
        }
    }

    private List<MethodDocumentation> GetServerMethods(Type hubType)
    {
        var methods = new List<MethodDocumentation>();

        try
        {
            // Get all public methods that are not inherited from Hub base class
            var publicMethods = hubType.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)
                .Where(m => !m.IsSpecialName && m.DeclaringType == hubType);

            foreach (var method in publicMethods)
            {
                // Skip lifecycle methods
                if (method.Name is "OnConnectedAsync" or "OnDisconnectedAsync")
                {
                    continue;
                }

                var methodDoc = new MethodDocumentation
                {
                    Name = method.Name,
                    Description = GetXmlDocumentation(method) ?? $"Server method: {method.Name}",
                    Parameters = method.GetParameters()
                        .Where(p => p.Name != "cancellationToken") // Exclude cancellation token
                        .Select(p => new ParameterDocumentation
                        {
                            Name = p.Name ?? "param",
                            Type = GetFriendlyTypeName(p.ParameterType),
                            Description = GetParameterXmlDocumentation(method, p.Name ?? "") ?? $"Parameter: {p.Name}",
                            Required = !p.IsOptional && !p.HasDefaultValue
                        })
                        .ToList(),
                    ReturnType = GetFriendlyTypeName(method.ReturnType)
                };

                methods.Add(methodDoc);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting server methods for hub: {HubType}", hubType.Name);
        }

        return methods;
    }

    private List<MethodDocumentation> GetClientMethods(Type clientInterfaceType)
    {
        var methods = new List<MethodDocumentation>();

        try
        {
            // Get all methods from the client interface
            var interfaceMethods = clientInterfaceType.GetMethods();

            foreach (var method in interfaceMethods)
            {
                var methodDoc = new MethodDocumentation
                {
                    Name = ToCamelCase(method.Name), // Convert to camelCase for SignalR convention
                    Description = GetXmlDocumentation(method) ?? $"Client method: {method.Name}",
                    Parameters = method.GetParameters()
                        .Where(p => p.Name != "cancellationToken")
                        .Select(p => new ParameterDocumentation
                        {
                            Name = p.Name ?? "param",
                            Type = GetFriendlyTypeName(p.ParameterType),
                            Description = GetParameterXmlDocumentation(method, p.Name ?? "") ?? $"Parameter: {p.Name}",
                            Required = !p.IsOptional && !p.HasDefaultValue
                        })
                        .ToList(),
                    ReturnType = GetFriendlyTypeName(method.ReturnType)
                };

                methods.Add(methodDoc);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting client methods for interface: {InterfaceType}", clientInterfaceType.Name);
        }

        return methods;
    }

    private static string GetFriendlyTypeName(Type type)
    {
        if (type == typeof(Task) || type == typeof(void))
        {
            return "Promise<void>";
        }

        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Task<>))
        {
            var innerType = type.GetGenericArguments()[0];
            return $"Promise<{GetFriendlyTypeName(innerType)}>";
        }

        if (type == typeof(string))
        {
            return "string";
        }

        if (type == typeof(int) || type == typeof(long) || type == typeof(short) || type == typeof(byte))
        {
            return "number";
        }

        if (type == typeof(bool))
        {
            return "boolean";
        }

        if (type.IsArray)
        {
            return $"{GetFriendlyTypeName(type.GetElementType()!)}[]";
        }

        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(List<>))
        {
            var elementType = type.GetGenericArguments()[0];
            return $"{GetFriendlyTypeName(elementType)}[]";
        }

        if (type == typeof(DateTime) || type == typeof(DateTimeOffset))
        {
            return "Date";
        }

        if (type == typeof(decimal) || type == typeof(double) || type == typeof(float))
        {
            return "number";
        }

        if (type == typeof(Guid))
        {
            return "string";
        }

        return type.Name;
    }

    private static string ToCamelCase(string str)
    {
        if (string.IsNullOrEmpty(str) || char.IsLower(str[0]))
        {
            return str;
        }

        return char.ToLowerInvariant(str[0]) + str[1..];
    }

    // XML Documentation helpers
    // Note: Full XML documentation reading would require loading the XML file
    // For now, we return null and rely on descriptive method names
    private static string? GetXmlDocumentation(Type type)
    {
        // TODO: Implement XML documentation reading using the XML file generated during build
        // You could use libraries like Namotion.Reflection or implement a custom XML reader
        return null;
    }

    private static string? GetXmlDocumentation(MethodInfo method)
    {
        // TODO: Implement XML documentation reading
        return null;
    }

    private static string? GetParameterXmlDocumentation(MethodInfo method, string parameterName)
    {
        // TODO: Implement XML documentation reading
        return null;
    }
}

// Documentation models
public class SignalRDocumentation
{
    public required List<HubDocumentation> Hubs { get; set; }
}

public class HubDocumentation
{
    public required string Name { get; set; }
    public required string Description { get; set; }
    public required string Endpoint { get; set; }
    public required bool RequiresAuthentication { get; set; }
    public required List<MethodDocumentation> ServerMethods { get; set; }
    public required List<MethodDocumentation> ClientMethods { get; set; }
}

public class MethodDocumentation
{
    public required string Name { get; set; }
    public required string Description { get; set; }
    public required List<ParameterDocumentation> Parameters { get; set; }
    public required string ReturnType { get; set; }
}

public class ParameterDocumentation
{
    public required string Name { get; set; }
    public required string Type { get; set; }
    public required string Description { get; set; }
    public required bool Required { get; set; }
}
