using Microsoft.AspNetCore.Mvc;
using NOBY.Api.Services.SignalR;
using Swashbuckle.AspNetCore.Annotations;

namespace NOBY.Api.Endpoints.SignalR;

/// <summary>
/// SignalR Hub documentation endpoint
/// </summary>
[ApiController]
[Route("api/v1/signalr-docs")]
public class SignalRDocumentationController : ControllerBase
{
    private readonly ISignalRDocumentationService _documentationService;

    public SignalRDocumentationController(ISignalRDocumentationService documentationService)
    {
        _documentationService = documentationService;
    }

    /// <summary>
    /// Get SignalR hub documentation
    /// </summary>
    /// <returns>Hub documentation including available hubs, endpoints, and methods</returns>
    /// <remarks>
    /// This endpoint provides **automatically generated** documentation for all SignalR hubs using reflection.
    /// 
    /// Documentation is generated from:
    /// - Hub class definitions (server methods)
    /// - Client interface definitions (client methods)
    /// - Authorization attributes
    /// - Method signatures and parameters
    /// 
    /// No manual updates needed when hub methods change!
    /// </remarks>
    [HttpGet]
    [SwaggerOperation(
        Summary = "Get SignalR documentation (Auto-generated)",
        Description = "Returns automatically generated documentation for all available SignalR hubs including connection endpoints, server methods, and client methods. Uses reflection to discover hubs and their methods."
    )]
    [ProducesResponseType(typeof(SignalRDocumentation), StatusCodes.Status200OK)]
    public IActionResult GetDocumentation()
    {
        var documentation = _documentationService.GetDocumentation();
        return Ok(documentation);
    }
}
