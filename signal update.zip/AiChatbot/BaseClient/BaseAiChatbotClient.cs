﻿using CIS.Infrastructure.ExternalServicesHelpers;
using System.Net.ServerSentEvents;

namespace ExternalServices.AiChatbot.BaseClient;

internal abstract class BaseAiChatbotClient(HttpClient _httpClient)
    : IBaseAiChatbotClient
{
    public async Task<Contracts.Chat> CreateChat(string userId, Contracts.CreateChat request, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .PostAsJsonAsync(_httpClient.BaseAddress + $"/users/{userId}/chats", request, cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.Chat>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task CreateMessage(string userId, string chatId, Contracts.CreateMessage request, CancellationToken cancellationToken = default)
    {
        await (await _httpClient
            .PostAsJsonAsync(_httpClient.BaseAddress + $"/users/{userId}/chats/{chatId}/messages", request, cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusCode(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.User> CreateUser(Contracts.CreateUser request, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .PostAsJsonAsync(_httpClient.BaseAddress + $"/users", request, cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.User>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task DeleteChat(string userId, string chatId, CancellationToken cancellationToken = default)
    {
        await (await _httpClient
            .DeleteAsync(_httpClient.BaseAddress + $"/users/{userId}/chats/{chatId}", cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusCode(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.MessagesList> GetChatDetail(string userId, string chatId, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .GetAsync(_httpClient.BaseAddress + $"/users/{userId}/chats/{chatId}/messages", cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.MessagesList>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.ChatsList> GetChatList(string userId, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .GetAsync(_httpClient.BaseAddress + $"/users/{userId}/chats", cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.ChatsList>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.User> GetUser(string userId, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .GetAsync(_httpClient.BaseAddress + $"/users/{userId}", cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.User>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.Message> RateResponse(string userId, string chatId, Contracts.PatchMessage request, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .PatchAsJsonAsync(_httpClient.BaseAddress + $"/users/{userId}/chats/{chatId}/messages", request, cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.Message>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.Chat> UpdateChat(string userId, string chatId, string? title, bool? favorite, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .PatchAsJsonAsync(_httpClient.BaseAddress + $"/users/{userId}/chats/{chatId}", new { title, favorite }, cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.Chat>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task StreamChatResponseAsync(string userId, string chatId, Func<string, Task> onMessageReceived, CancellationToken cancellationToken = default)
    {
        var requestUri = $"{_httpClient.BaseAddress}/users/{userId}/chats/{chatId}/stream";
        
        using var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("text/event-stream"));
        
        using var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken)
            .ConfigureAwait(false);
        
        response.EnsureSuccessStatusCode();
        
        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
        
        await foreach (var sseEvent in SseParser.Create(stream).EnumerateAsync(cancellationToken).ConfigureAwait(false))
        {
            // Process events with type "message" or no type (default event type)
            if (string.IsNullOrEmpty(sseEvent.EventType) || sseEvent.EventType == "message")
            {
                var data = sseEvent.Data;
                if (!string.IsNullOrEmpty(data))
                {
                    await onMessageReceived(data).ConfigureAwait(false);
                }
            }
        }
    }
}
