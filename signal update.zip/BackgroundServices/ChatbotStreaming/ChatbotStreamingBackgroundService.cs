using Microsoft.AspNetCore.SignalR;
using NOBY.Api.Hubs;
using System.Threading.Channels;

namespace NOBY.Api.BackgroundServices.ChatbotStreaming;

/// <summary>
/// Background service that processes chatbot streaming requests from a channel
/// and forwards SSE events to SignalR clients
/// </summary>
internal sealed class ChatbotStreamingBackgroundService : BackgroundService
{
    private readonly Channel<ChatbotStreamingRequest> _channel;
    private readonly IServiceScopeFactory _serviceScopeFactory;
    private readonly ILogger<ChatbotStreamingBackgroundService> _logger;

    public ChatbotStreamingBackgroundService(
        Channel<ChatbotStreamingRequest> channel,
        IServiceScopeFactory serviceScopeFactory,
        ILogger<ChatbotStreamingBackgroundService> logger)
    {
        _channel = channel;
        _serviceScopeFactory = serviceScopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("ChatbotStreamingBackgroundService started");

        await foreach (var request in _channel.Reader.ReadAllAsync(stoppingToken))
        {
            // Process each request in a separate task to allow concurrent streaming
            _ = Task.Run(async () => await ProcessStreamingRequestAsync(request, stoppingToken), stoppingToken);
        }

        _logger.LogInformation("ChatbotStreamingBackgroundService stopped");
    }

    private async Task ProcessStreamingRequestAsync(ChatbotStreamingRequest request, CancellationToken stoppingToken)
    {
        using var scope = _serviceScopeFactory.CreateScope();
        var hubContext = scope.ServiceProvider.GetRequiredService<IHubContext<NobyHub, INobyHubClient>>();
        var externalClient = scope.ServiceProvider.GetRequiredService<ExternalServices.AiChatbot.External.IAiChatbotExternalClient>();
        var internalClient = scope.ServiceProvider.GetRequiredService<ExternalServices.AiChatbot.Internal.IAiChatbotInternalClient>();

        ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient client = request.UseInternalClient 
            ? (ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient)internalClient 
            : (ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient)externalClient;

        using var timeoutCts = new CancellationTokenSource(request.Timeout);
        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken, timeoutCts.Token);

        try
        {
            _logger.LogInformation(
                "Starting chatbot streaming for NobyUserId: {NobyUserId}, ChatId: {ChatId}, UseInternalClient: {UseInternalClient}",
                request.NobyUserId, request.ChatId, request.UseInternalClient);

            await hubContext.Clients
                .User(request.NobyUserId.ToString())
                .ReceiveChatStreamStart(request.ChatId, linkedCts.Token);

            var messageCount = 0;

            await client.StreamChatResponseAsync(
                request.ChatbotUserId,
                request.ChatId,
                async (message) =>
                {
                    messageCount++;
                    _logger.LogDebug(
                        "Received SSE message #{MessageCount} for ChatId: {ChatId}, NobyUserId: {NobyUserId}",
                        messageCount, request.ChatId, request.NobyUserId);

                    await hubContext.Clients
                        .User(request.NobyUserId.ToString())
                        .ReceiveChatStreamChunk(request.ChatId, message, linkedCts.Token);
                },
                linkedCts.Token);

            _logger.LogInformation(
                "Chatbot streaming completed for NobyUserId: {NobyUserId}, ChatId: {ChatId}, TotalMessages: {TotalMessages}",
                request.NobyUserId, request.ChatId, messageCount);

            await hubContext.Clients
                .User(request.NobyUserId.ToString())
                .ReceiveChatStreamEnd(request.ChatId, linkedCts.Token);
        }
        catch (OperationCanceledException) when (timeoutCts.IsCancellationRequested)
        {
            _logger.LogWarning(
                "Chatbot streaming timeout for NobyUserId: {NobyUserId}, ChatId: {ChatId}",
                request.NobyUserId, request.ChatId);

            await hubContext.Clients
                .User(request.NobyUserId.ToString())
                .ReceiveChatStreamError(request.ChatId, "Streaming timeout", default);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error during chatbot streaming for NobyUserId: {NobyUserId}, ChatId: {ChatId}",
                request.NobyUserId, request.ChatId);

            await hubContext.Clients
                .User(request.NobyUserId.ToString())
                .ReceiveChatStreamError(request.ChatId, "Streaming error occurred", default);
        }
    }
}
