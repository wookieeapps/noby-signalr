using CIS.Core.Attributes;
using System.Threading.Channels;

namespace NOBY.Api.BackgroundServices.ChatbotStreaming;

/// <summary>
/// Service for coordinating chatbot streaming requests
/// </summary>
[ScopedService, SelfService]
internal sealed class ChatbotStreamingCoordinator
{
    private readonly Channel<ChatbotStreamingRequest> _channel;
    private readonly ILogger<ChatbotStreamingCoordinator> _logger;

    public ChatbotStreamingCoordinator(
        Channel<ChatbotStreamingRequest> channel,
        ILogger<ChatbotStreamingCoordinator> logger)
    {
        _channel = channel;
        _logger = logger;
    }

    /// <summary>
    /// Enqueues a chatbot streaming request for background processing
    /// </summary>
    /// <param name="request">The streaming request</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>True if the request was enqueued successfully, false otherwise</returns>
    public async Task<bool> EnqueueStreamingRequestAsync(ChatbotStreamingRequest request, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation(
                "Enqueueing chatbot streaming request for NobyUserId: {NobyUserId}, ChatId: {ChatId}",
                request.NobyUserId, request.ChatId);

            await _channel.Writer.WriteAsync(request, cancellationToken);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Failed to enqueue chatbot streaming request for NobyUserId: {NobyUserId}, ChatId: {ChatId}",
                request.NobyUserId, request.ChatId);
            return false;
        }
    }
}
