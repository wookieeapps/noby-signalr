namespace NOBY.Api.BackgroundServices.ChatbotStreaming;

/// <summary>
/// Represents a request to stream chatbot responses to a specific user
/// </summary>
internal sealed class ChatbotStreamingRequest
{
    /// <summary>
    /// The NOBY user ID (used for SignalR routing)
    /// </summary>
    public required int NobyUserId { get; init; }

    /// <summary>
    /// The chatbot user ID
    /// </summary>
    public required string ChatbotUserId { get; init; }

    /// <summary>
    /// The chat ID
    /// </summary>
    public required string ChatId { get; init; }

    /// <summary>
    /// Whether to use internal or external chatbot client
    /// </summary>
    public required bool UseInternalClient { get; init; }

    /// <summary>
    /// Timeout for the streaming operation
    /// </summary>
    public TimeSpan Timeout { get; init; } = TimeSpan.FromMinutes(5);
}
