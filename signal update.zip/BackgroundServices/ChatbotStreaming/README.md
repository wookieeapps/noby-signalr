# Chatbot Streaming Implementation

This folder contains the infrastructure for streaming AI Chatbot responses via Server-Sent Events (SSE) to clients through SignalR.

## Architecture Overview

```
User Message ? NOBY.Api ? Enqueue Request ? Background Service ? SSE Stream ? SignalR Hub ? Client
```

## Components

### 1. **ChatbotStreamingRequest.cs**
Data model containing:
- `NobyUserId` - For SignalR user routing
- `ChatbotUserId` - For chatbot API calls
- `ChatId` - Chat identifier
- `UseInternalClient` - Internal vs External chatbot flag
- `Timeout` - Stream timeout (default: 5 minutes)

### 2. **In-Memory Channel Implementation** (CURRENTLY ACTIVE)

#### ChatbotStreamingCoordinator.cs
Enqueues streaming requests to an in-memory channel for background processing.

#### ChatbotStreamingBackgroundService.cs
Background service that:
- Reads from the in-memory channel
- Connects to AI Chatbot SSE endpoint
- Forwards events to SignalR clients
- Handles timeouts and errors

**Pros:**
- ? Simple implementation
- ? Fast (no network overhead)
- ? No additional infrastructure

**Cons:**
- ?? Requires sticky sessions for multi-node deployments
- ?? Uneven load distribution across servers
- ?? Lost streams on server restart

### 3. **Redis Queue Implementation** (AVAILABLE, NOT ACTIVE)

#### RedisChatbotStreamingCoordinator.cs
Enqueues streaming requests to Redis List for distributed processing.

#### RedisChatbotStreamingBackgroundService.cs
Background service that:
- Reads from Redis queue (distributed)
- Includes concurrency limiting (5 concurrent streams per server)
- Same SSE/SignalR processing as in-memory version

**Pros:**
- ? True horizontal scaling
- ? Automatic load balancing
- ? Failover on server restart
- ? No sticky sessions needed

**Cons:**
- ?? Slightly more complex
- ?? Network hop to Redis

## Usage

### Current Setup (In-Memory)

In `Program.cs`:
```csharp
builder.AddNobyChatbotStreaming();
```

### Switching to Redis (Multi-Node)

In `Program.cs`, replace the above with:
```csharp
builder.AddNobyChatbotStreamingWithRedis();
```

And in `CreateMessageHandler.cs`, inject `RedisChatbotStreamingCoordinator` instead of `ChatbotStreamingCoordinator`.

## SignalR Events

Clients receive these events:

| Event | Parameters | Description |
|-------|------------|-------------|
| `ReceiveChatStreamStart` | `chatId` | Stream started |
| `ReceiveChatStreamChunk` | `chatId`, `chunk` | Message chunk received |
| `ReceiveChatStreamEnd` | `chatId` | Stream completed successfully |
| `ReceiveChatStreamError` | `chatId`, `errorMessage` | Stream error occurred |

## Configuration

Default timeout is 5 minutes. To change:

```csharp
var request = new ChatbotStreamingRequest
{
    // ... other properties
    Timeout = TimeSpan.FromMinutes(10)
};
```

## Multi-Node Considerations

### Current In-Memory Implementation

**Requirements:**
- Sticky sessions on load balancer (route user to same server)
- Health checks for detecting server failures
- Accept that in-flight streams are lost on restart

**When to Use:**
- Single server deployments
- Dev/Test environments
- Low-to-medium traffic (< 100 concurrent streams per server)
- 99.9% uptime is acceptable

### Redis Implementation

**Requirements:**
- Redis connection (already configured for SignalR backplane)
- No sticky sessions needed

**When to Use:**
- Multi-node production deployments
- High traffic scenarios
- Need failover/resilience
- Want even load distribution
- 99.99% uptime target

## Testing

### Local Testing
Both implementations work identically from a client perspective. Test with:

1. Connect to SignalR hub
2. Send chat message via REST API
3. Listen for streaming events
4. Verify chunks arrive in correct order

### Load Testing
For production readiness:
- Test with 50+ concurrent streams
- Verify SignalR Redis backplane routes messages correctly
- Test server restart scenarios
- Monitor Redis queue depth (if using Redis implementation)

## Performance

### In-Memory Channel
- **Latency**: < 1ms enqueue time
- **Throughput**: Thousands of requests/second
- **Resource usage**: Minimal (in-memory only)

### Redis Queue
- **Latency**: 1-5ms enqueue time (network hop)
- **Throughput**: Limited by Redis (typically 10k+ ops/sec)
- **Resource usage**: Redis memory for queue

## Troubleshooting

### Streams not reaching client
- Check SignalR connection is established
- Verify user ID in SignalR matches NobyUserId
- Check Redis backplane configuration (multi-node)

### Timeout errors
- Increase timeout in `ChatbotStreamingRequest`
- Check AI Chatbot API response time
- Verify network connectivity

### Uneven load (in-memory)
- Switch to Redis implementation
- Or configure sticky sessions properly

## Future Enhancements

Potential improvements:
- [ ] Dead letter queue for failed streams
- [ ] Stream resumption on disconnect
- [ ] Metrics/monitoring dashboard
- [ ] Configurable concurrency limits
- [ ] Circuit breaker for chatbot API
