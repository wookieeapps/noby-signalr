using Microsoft.AspNetCore.SignalR;
using NOBY.Api.Hubs;
using StackExchange.Redis;
using System.Text.Json;

namespace NOBY.Api.BackgroundServices.ChatbotStreaming;

/// <summary>
/// Distributed background service that processes chatbot streaming requests from Redis.
/// This is an alternative to ChatbotStreamingBackgroundService for multi-node deployments.
/// Works across multiple server instances for load balancing and failover.
/// To use this, call AddNobyChatbotStreamingWithRedis() instead of AddNobyChatbotStreaming() in Program.cs.
/// </summary>
internal sealed class RedisChatbotStreamingBackgroundService : BackgroundService
{
    private readonly IConnectionMultiplexer _redis;
    private readonly IServiceScopeFactory _serviceScopeFactory;
    private readonly ILogger<RedisChatbotStreamingBackgroundService> _logger;
    private const string _redisListKey = "chatbot:streaming:queue";
    private const int _batchSize = 5; // Process up to 5 streams concurrently per server
    private readonly SemaphoreSlim _concurrencyLimiter;

    public RedisChatbotStreamingBackgroundService(
        IConnectionMultiplexer redis,
        IServiceScopeFactory serviceScopeFactory,
        ILogger<RedisChatbotStreamingBackgroundService> logger)
    {
        _redis = redis;
        _serviceScopeFactory = serviceScopeFactory;
        _logger = logger;
        _concurrencyLimiter = new SemaphoreSlim(_batchSize, _batchSize);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("RedisChatbotStreamingBackgroundService started");

        var db = _redis.GetDatabase();

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                // Wait for available slot (rate limiting)
                await _concurrencyLimiter.WaitAsync(stoppingToken);

                // Blocking right pop with 5 second timeout
                var result = await db.ListRightPopAsync(_redisListKey);

                if (result.HasValue)
                {
                    var json = result.ToString();
                    var request = JsonSerializer.Deserialize<ChatbotStreamingRequest>(json);

                    if (request != null)
                    {
                        // Process in background, releasing semaphore when done
                        _ = Task.Run(async () =>
                        {
                            try
                            {
                                await ProcessStreamingRequestAsync(request, stoppingToken);
                            }
                            finally
                            {
                                _concurrencyLimiter.Release();
                            }
                        }, stoppingToken);
                    }
                    else
                    {
                        _concurrencyLimiter.Release();
                    }
                }
                else
                {
                    // No item available, release and wait before retry
                    _concurrencyLimiter.Release();
                    await Task.Delay(TimeSpan.FromSeconds(1), stoppingToken);
                }
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error reading from Redis streaming queue");
                _concurrencyLimiter.Release();
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
        }

        _logger.LogInformation("RedisChatbotStreamingBackgroundService stopped");
    }

    private async Task ProcessStreamingRequestAsync(ChatbotStreamingRequest request, CancellationToken stoppingToken)
    {
        using var scope = _serviceScopeFactory.CreateScope();
        var hubContext = scope.ServiceProvider.GetRequiredService<IHubContext<NobyHub, INobyHubClient>>();
        var externalClient = scope.ServiceProvider.GetRequiredService<ExternalServices.AiChatbot.External.IAiChatbotExternalClient>();
        var internalClient = scope.ServiceProvider.GetRequiredService<ExternalServices.AiChatbot.Internal.IAiChatbotInternalClient>();

        ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient client = request.UseInternalClient 
            ? (ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient)internalClient 
            : (ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient)externalClient;

        using var timeoutCts = new CancellationTokenSource(request.Timeout);
        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken, timeoutCts.Token);

        try
        {
            _logger.LogInformation(
                "Starting chatbot streaming for NobyUserId: {NobyUserId}, ChatId: {ChatId}, UseInternalClient: {UseInternalClient}",
                request.NobyUserId, request.ChatId, request.UseInternalClient);

            await hubContext.Clients
                .User(request.NobyUserId.ToString())
                .ReceiveChatStreamStart(request.ChatId, linkedCts.Token);

            var messageCount = 0;

            await client.StreamChatResponseAsync(
                request.ChatbotUserId,
                request.ChatId,
                async (message) =>
                {
                    messageCount++;
                    _logger.LogDebug(
                        "Received SSE message #{MessageCount} for ChatId: {ChatId}, NobyUserId: {NobyUserId}",
                        messageCount, request.ChatId, request.NobyUserId);

                    await hubContext.Clients
                        .User(request.NobyUserId.ToString())
                        .ReceiveChatStreamChunk(request.ChatId, message, linkedCts.Token);
                },
                linkedCts.Token);

            _logger.LogInformation(
                "Chatbot streaming completed for NobyUserId: {NobyUserId}, ChatId: {ChatId}, TotalMessages: {TotalMessages}",
                request.NobyUserId, request.ChatId, messageCount);

            await hubContext.Clients
                .User(request.NobyUserId.ToString())
                .ReceiveChatStreamEnd(request.ChatId, linkedCts.Token);
        }
        catch (OperationCanceledException) when (timeoutCts.IsCancellationRequested)
        {
            _logger.LogWarning(
                "Chatbot streaming timeout for NobyUserId: {NobyUserId}, ChatId: {ChatId}",
                request.NobyUserId, request.ChatId);

            await hubContext.Clients
                .User(request.NobyUserId.ToString())
                .ReceiveChatStreamError(request.ChatId, "Streaming timeout", default);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error during chatbot streaming for NobyUserId: {NobyUserId}, ChatId: {ChatId}",
                request.NobyUserId, request.ChatId);

            await hubContext.Clients
                .User(request.NobyUserId.ToString())
                .ReceiveChatStreamError(request.ChatId, "Streaming error occurred", default);
        }
    }

    public override void Dispose()
    {
        _concurrencyLimiter?.Dispose();
        base.Dispose();
    }
}
