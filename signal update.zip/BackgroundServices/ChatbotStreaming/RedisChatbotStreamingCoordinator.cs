using CIS.Core.Attributes;
using StackExchange.Redis;
using System.Text.Json;

namespace NOBY.Api.BackgroundServices.ChatbotStreaming;

/// <summary>
/// Redis-based coordinator for distributing chatbot streaming requests across multiple servers.
/// This is an alternative to the in-memory ChatbotStreamingCoordinator for multi-node deployments.
/// To use this, call AddNobyChatbotStreamingWithRedis() instead of AddNobyChatbotStreaming() in Program.cs.
/// </summary>
[ScopedService, SelfService]
internal sealed class RedisChatbotStreamingCoordinator
{
    private readonly IConnectionMultiplexer _redis;
    private readonly ILogger<RedisChatbotStreamingCoordinator> _logger;
    private const string _redisListKey = "chatbot:streaming:queue";

    public RedisChatbotStreamingCoordinator(
        IConnectionMultiplexer redis,
        ILogger<RedisChatbotStreamingCoordinator> logger)
    {
        _redis = redis;
        _logger = logger;
    }

    /// <summary>
    /// Enqueues a chatbot streaming request to Redis for distributed processing
    /// </summary>
    public async Task<bool> EnqueueStreamingRequestAsync(ChatbotStreamingRequest request, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation(
                "Enqueueing chatbot streaming request to Redis for NobyUserId: {NobyUserId}, ChatId: {ChatId}",
                request.NobyUserId, request.ChatId);

            var db = _redis.GetDatabase();
            var json = JsonSerializer.Serialize(request);
            
            await db.ListLeftPushAsync(_redisListKey, json);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Failed to enqueue chatbot streaming request for NobyUserId: {NobyUserId}, ChatId: {ChatId}",
                request.NobyUserId, request.ChatId);
            return false;
        }
    }
}
