﻿#pragma warning disable CA1515 // Consider making public types internal
using Swashbuckle.AspNetCore.Annotations;

namespace NOBY.Api.Endpoints.Chatbot;

[ApiController]
[Route("api/v1/chatbot")]
public sealed class ChatbotController(IMediator _mediator)
    : ControllerBase
{
    /// <summary>
    /// Seznam chatů pro daného uživatele
    /// </summary>
    /// <remarks>
    /// Vrátí kolekci chatů pro daného uživatele seřazenou dle příznaku oblíbené a data poslední modifikace (novější dříve)
    /// </remarks>
    [HttpGet("chats")]
    [SwaggerOperation(Tags = ["Chatbot"])]
    [ProducesResponseType(typeof(ChatbotGetChatListResponse), StatusCodes.Status200OK)]
    [SwaggerEaDiagram("https://eacloud.ds.kb.cz/webea/index.php?m=1&o=30994C1E-6FCA-490e-BFB8-675D361FE4DF")]
    public async Task<ChatbotGetChatListResponse> GetChatList(CancellationToken cancellationToken)
        => await _mediator.Send(new GetChatList.GetChatListRequest(), cancellationToken);

    /// <summary>
    /// Poslání dotazu
    /// </summary>
    /// <remarks>
    /// Poslání dotazu buď do již existujícího chatu specifikovaného v query parametru. Nebo poslání prvního dotazu do nového chatu, čímž dojde k založení nového chatu.
    /// </remarks>
    [HttpPost("chats")]
    [SwaggerOperation(Tags = ["Chatbot"])]
    [Consumes(MediaTypeNames.Application.Json)]
    [ProducesResponseType(typeof(ChatbotCreateMessageResponse), StatusCodes.Status200OK)]
    [SwaggerEaDiagram("https://eacloud.ds.kb.cz/webea/index.php?m=1&o=2665485F-9CF4-4d75-9D39-F3CB7FB217C2")]
    public async Task<ChatbotCreateMessageResponse> CreateMessage([FromBody] ChatbotCreateMessageRequest request, [FromQuery] string? chatId = null, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request, nameof(request));
        return await _mediator.Send(request.InfuseId(chatId), cancellationToken);
    }

    /// <summary>
    /// Detail konkrétního chatu
    /// </summary>
    /// <remarks>
    /// Vrátí detail konkrétního chatu včetně jednotlivých dotazů o odpovědí a jejich případného hodnocení
    /// </remarks>
    [HttpGet("chatbot/chats/{chatId}")]
    [SwaggerOperation(Tags = ["Chatbot"])]
    [ProducesResponseType(typeof(ChatbotGetChatDetailResponse), StatusCodes.Status200OK)]
    [SwaggerEaDiagram("https://eacloud.ds.kb.cz/webea/index.php?m=1&o=0A5B5833-0EAD-445f-9D51-825ED92F06A8")]
    public async Task<ChatbotGetChatDetailResponse> GetChatDetail([FromRoute] string chatId, CancellationToken cancellationToken = default)
        => await _mediator.Send(new GetChatDetail.GetChatDetailRequest(chatId), cancellationToken);

    /// <summary>
    /// Update konkrétního chatu
    /// </summary>
    /// <remarks>
    /// Update konkrétního chatu: umožňuje změnit název chatu nebo změnit příznak oblíbené u daného chatu
    /// </remarks>
    [HttpPut("chatbot/chats/{chatId}")]
    [SwaggerOperation(Tags = ["Chatbot"])]
    [Consumes(MediaTypeNames.Application.Json)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [SwaggerEaDiagram("https://eacloud.ds.kb.cz/webea/index.php?m=1&o=6056FABA-E4C1-4519-9EFE-6481EBB2F074")]
    public async Task<IActionResult> UpdateChat([FromRoute] string chatId, [FromBody] ChatbotUpdateChatRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request, nameof(request));
        await _mediator.Send(request.InfuseId(chatId), cancellationToken);
        return NoContent();
    }

    /// <summary>
    /// Smazání konkrétního chatu
    /// </summary>
    /// <remarks>
    /// Smaže konkrétní chat
    /// </remarks>
    [HttpDelete("chatbot/chats/{chatId}")]
    [SwaggerOperation(Tags = ["Chatbot"])]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [SwaggerEaDiagram("https://eacloud.ds.kb.cz/webea/index.php?m=1&o=74A918B3-E754-4726-BD14-90813D298874")]
    public async Task<IActionResult> DeleteChat([FromRoute] string chatId, CancellationToken cancellationToken = default)
    {
        await _mediator.Send(new DeleteChat.DeleteChatRequest(chatId), cancellationToken);
        return NoContent();
    }

    /// <summary>
    /// Zadání nebo update hodnocení konkrétní zprávy
    /// </summary>
    /// <remarks>
    /// Zadání hodnocení konkrétní zprávy nebo upravení již existujícího hodnocení konkrétní zprávy: je možné upravit jak počet hvězdiček, tak komentář k hodnocení
    /// </remarks>
    [HttpPut("chatbot/chats/{chatId}/messages/{messageId}")]
    [SwaggerOperation(Tags = ["Chatbot"])]
    [Consumes(MediaTypeNames.Application.Json)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [SwaggerEaDiagram("https://eacloud.ds.kb.cz/webea/index.php?m=1&o=50BBFCBF-4093-424d-BF4F-447F4AFB6C9F")]
    public async Task<IActionResult> RateResponse([FromRoute] string chatId, [FromRoute] string messageId, [FromBody] ChatbotUpdateResponseRatingRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request, nameof(request));
        await _mediator.Send(request.InfuseId(chatId, messageId), cancellationToken);
        return NoContent();
    }
}
