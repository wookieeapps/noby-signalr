﻿using CIS.Core.Attributes;
using DomainServices.UserService.Clients.v1;

namespace NOBY.Api.Endpoints.Chatbot;

[SelfService, ScopedService]
internal sealed class ChatbotHelperService(
    IUserServiceClient _userService,
    ExternalServices.AiChatbot.External.IAiChatbotExternalClient _externalClient,
    ExternalServices.AiChatbot.Internal.IAiChatbotInternalClient _internalClient)
{
    public async Task<(string ChatbotUserId, ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient Client)> GetChatbotUserId(CancellationToken cancellationToken)
    {
        var (_, chatbotUserId, client, _) = await GetChatbotUserInfo(cancellationToken);
        return (chatbotUserId, client);
    }

    public async Task<(int NobyUserId, string ChatbotUserId, ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient Client, bool UseInternalClient)> GetChatbotUserInfo(CancellationToken cancellationToken)
    {
        var user = await _userService.GetCurrentUser(cancellationToken);

        var useInternalModel = user.UserInfo.IsInternal;
        string? chatUserId = useInternalModel ? user.UserProperties?.InternalChatbotUserId : user.UserProperties?.ExternalChatbotUserId;
        ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient client = useInternalModel ? _internalClient : _externalClient;

        // vytvorit novy userId
        if (string.IsNullOrEmpty(chatUserId))
        {
            var chatUser = await client.CreateUser(new ExternalServices.AiChatbot.Contracts.CreateUser
            {
                Email = user.UserInfo.Email,
                Name = user.UserInfo.DisplayName
            }, cancellationToken);

            chatUserId = chatUser.Id;

            await _userService.UpdateUserProperties(new DomainServices.UserService.Contracts.UpdateUserPropertiesRequest
            {
                UserId = user.UserId,
                InternalChatbotUserId = useInternalModel ? chatUserId : user.UserProperties?.InternalChatbotUserId,
                ExternalChatbotUserId = useInternalModel ? user.UserProperties?.ExternalChatbotUserId : chatUserId
            }, cancellationToken);
        }

        return (user.UserId, chatUserId, client, useInternalModel);
    }
}
