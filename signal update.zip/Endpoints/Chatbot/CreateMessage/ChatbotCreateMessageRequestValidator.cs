﻿using FluentValidation;

namespace NOBY.Api.Endpoints.Chatbot.CreateMessage;

internal sealed class ChatbotCreateMessageRequestValidator
    : AbstractValidator<ChatbotCreateMessageRequest>
{
    public ChatbotCreateMessageRequestValidator()
    {
        RuleFor(t => t.CommunicationRequestText)
            .MaximumLength(500)
            .NotEmpty()
            .WithErrorCode(90032);
    }
}
