﻿using NOBY.Api.BackgroundServices.ChatbotStreaming;

namespace NOBY.Api.Endpoints.Chatbot.CreateMessage;

internal sealed class CreateMessageHandler(
    ChatbotHelperService _chatbotHelper,
    ChatbotStreamingCoordinator _streamingCoordinator,
    ILogger<CreateMessageHandler> _logger)
    : IRequestHandler<ChatbotCreateMessageRequest, ChatbotCreateMessageResponse>
{
    public async Task<ChatbotCreateMessageResponse> Handle(ChatbotCreateMessageRequest request, CancellationToken cancellationToken)
    {
        // vytvorit / ziskat userId
        var (nobyUserId, chatbotUserId, client, useInternalClient) = await _chatbotHelper.GetChatbotUserInfo(cancellationToken);
        string? chatId = request.ChatId;
        string? chatTitle = null;

        // create chat if needed
        if (string.IsNullOrEmpty(chatId))
        {
            chatTitle = request.CommunicationRequestText[..Math.Min(32, request.CommunicationRequestText.Length)];

            var createResponse = await client.CreateChat(chatbotUserId, new ExternalServices.AiChatbot.Contracts.CreateChat
            {
                Title = chatTitle
            }, cancellationToken);

            chatId = createResponse.Id;
        }

        // Send message to chatbot (non-blocking)
        await client.CreateMessage(chatbotUserId, chatId, new ExternalServices.AiChatbot.Contracts.CreateMessage
        {
            Content = request.CommunicationRequestText
        }, cancellationToken);

        // Enqueue streaming request for background processing
        var streamingRequest = new ChatbotStreamingRequest
        {
            NobyUserId = nobyUserId,
            ChatbotUserId = chatbotUserId,
            ChatId = chatId,
            UseInternalClient = useInternalClient
        };

        var enqueued = await _streamingCoordinator.EnqueueStreamingRequestAsync(streamingRequest, cancellationToken);
        
        if (!enqueued)
        {
            _logger.LogWarning(
                "Failed to enqueue streaming request for NobyUserId: {NobyUserId}, ChatId: {ChatId}",
                nobyUserId, chatId);
        }

        return new ChatbotCreateMessageResponse
        {
            ChatTitle = chatTitle,
            ChatId = chatId
        };
    }
}
