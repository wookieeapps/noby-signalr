﻿namespace NOBY.Api.Endpoints.Chatbot.DeleteChat;

internal sealed class DeleteChatHandler(ChatbotHelperService _chatbotHelper)
    : IRequestHandler<DeleteChatRequest>
{
    public async Task Handle(DeleteChatRequest request, CancellationToken cancellationToken)
    {
        // vytvorit / ziskat userId
        var (chatbotUserId, client) = await _chatbotHelper.GetChatbotUserId(cancellationToken);

        await client.DeleteChat(chatbotUserId, request.ChatId, cancellationToken);
    }
}
