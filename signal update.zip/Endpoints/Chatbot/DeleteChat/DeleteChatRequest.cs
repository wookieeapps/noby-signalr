﻿namespace NOBY.Api.Endpoints.Chatbot.DeleteChat;

internal sealed record DeleteChatRequest(string ChatId) : IRequest;