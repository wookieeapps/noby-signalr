﻿using System.Globalization;

namespace NOBY.Api.Endpoints.Chatbot.GetChatDetail;

internal sealed class GetChatDetailHandler(ChatbotHelperService _chatbotHelper)
    : IRequestHandler<GetChatDetailRequest, ChatbotGetChatDetailResponse>
{
    public async Task<ChatbotGetChatDetailResponse> Handle(GetChatDetailRequest request, CancellationToken cancellationToken)
    {
        // vytvorit / ziskat userId
        var (chatbotUserId, client) = await _chatbotHelper.GetChatbotUserId(cancellationToken);

        var chatDetail = await client.GetChatDetail(chatbotUserId, request.ChatId, cancellationToken);

        return new ChatbotGetChatDetailResponse
        {
            ChatId = request.ChatId,
            Communication = [.. chatDetail.Messages.Select(t =>
            {
                if (t.Role == ExternalServices.AiChatbot.Contracts.MessageOutputRole.User)
                {
                    return new CommunicationItem
                    {
                        CommunicationRequest = new CommunicationRequest
                        {
                            CommunicationRequestText = t.Content,
                            CreatedOn = DateTime.Parse(t.CreatedAt, CultureInfo.InvariantCulture),
                            MessageId = t.Id
                        }
                    };
                }
                else
                {
                    return new CommunicationItem
                    {
                        CommunicationResponse = new CommunicationResponse
                        {
                            CommunicationResponseText = t.Content,
                            CreatedOn = DateTime.Parse(t.CreatedAt, CultureInfo.InvariantCulture),
                            MessageId = t.Id,
                            Rating = t.Rating != 0 ? new Rating
                            {
                                Comment = t.RatingComment,
                                Value = t.Rating
                            } : null
                        }
                    };
                }
            })]
        };
    }
}
