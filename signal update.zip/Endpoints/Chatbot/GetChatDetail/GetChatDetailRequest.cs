﻿namespace NOBY.Api.Endpoints.Chatbot.GetChatDetail;

internal sealed record GetChatDetailRequest(string ChatId) : IRequest<ChatbotGetChatDetailResponse>;
