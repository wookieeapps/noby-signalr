﻿using System.Globalization;

namespace NOBY.Api.Endpoints.Chatbot.GetChatList;

internal sealed class GetChatListHandler(ChatbotHelperService _chatbotHelper)
    : IRequestHandler<GetChatListRequest, ChatbotGetChatListResponse>
{
    public async Task<ChatbotGetChatListResponse> Handle(GetChatListRequest request, CancellationToken cancellationToken)
    {
        // vytvorit / ziskat userId
        var (chatbotUserId, client) = await _chatbotHelper.GetChatbotUserId(cancellationToken);

        // seznam chatu
        var list = await client.GetChatList(chatbotUserId, cancellationToken);

        return new ChatbotGetChatListResponse
        {
            FavoriteChats = list.Chats?
                .Where(t => t.Favorite)
                .OrderByDescending(t => t.LastMessageAt)
                .Select(t => createChatListItem(t))
                .ToList() ?? [],

            HistoricalChats = list.Chats?
                .Where(t => !t.Favorite)
                .OrderByDescending(t => t.LastMessageAt)
                .Select(t => createChatListItem(t))
                .ToList() ?? []
        };
    }

    private static ChatListItem createChatListItem(ExternalServices.AiChatbot.Contracts.ChatOutput item)
    {
        return new ChatListItem
        {
            ChatId = item.Id,
            ChatTitle = item.Title,
            LastMessageAdded = DateTime.Parse(item.LastMessageAt, CultureInfo.InvariantCulture)
        };
    }
}
