﻿namespace NOBY.Api.Endpoints.Chatbot.GetChatList;

internal sealed class GetChatListRequest : IRequest<ChatbotGetChatListResponse>;