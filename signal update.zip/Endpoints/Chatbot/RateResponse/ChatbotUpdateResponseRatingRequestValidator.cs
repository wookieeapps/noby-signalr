﻿using FluentValidation;

namespace NOBY.Api.Endpoints.Chatbot.RateResponse;

internal sealed class ChatbotUpdateResponseRatingRequestValidator
    : AbstractValidator<ChatbotUpdateResponseRatingRequest>
{
    public ChatbotUpdateResponseRatingRequestValidator()
    {
        RuleFor(t => t.RatingComment)
            .MaximumLength(50)
            .WithErrorCode(90032);
    }
}
