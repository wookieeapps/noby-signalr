﻿namespace NOBY.Api.Endpoints.Chatbot.RateResponse;

internal sealed class RateResponseHandler(ChatbotHelperService _chatbotHelper)
    : IRequestHandler<ChatbotUpdateResponseRatingRequest>
{
    public async Task Handle(ChatbotUpdateResponseRatingRequest request, CancellationToken cancellationToken)
    {
        // vytvorit / ziskat userId
        var (chatbotUserId, client) = await _chatbotHelper.GetChatbotUserId(cancellationToken);

        await client.RateResponse(chatbotUserId, request.ChatId, new ExternalServices.AiChatbot.Contracts.PatchMessage
        {
            MessageId = request.Messageid,
            Rating = request.Rating,
            RatingComment = request.RatingComment ?? ""
        }, cancellationToken);
    }
}
