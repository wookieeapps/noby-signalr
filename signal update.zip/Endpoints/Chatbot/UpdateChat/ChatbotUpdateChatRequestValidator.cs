﻿using FluentValidation;

namespace NOBY.Api.Endpoints.Chatbot.UpdateChat;

internal sealed class ChatbotUpdateChatRequestValidator
    : AbstractValidator<ChatbotUpdateChatRequest>
{
    public ChatbotUpdateChatRequestValidator()
    {
        RuleFor(t => t.ChatTitle)
            .MaximumLength(50)
            .MinimumLength(1)
            .When(t => !string.IsNullOrEmpty(t.ChatTitle))
            .WithErrorCode(90032);
    }
}
