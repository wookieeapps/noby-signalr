﻿namespace NOBY.Api.Endpoints.Chatbot.UpdateChat;

internal sealed class UpdateChatHandler(ChatbotHelperService _chatbotHelper)
    : IRequestHandler<ChatbotUpdateChatRequest>
{
    public async Task Handle(ChatbotUpdateChatRequest request, CancellationToken cancellationToken)
    {
        // vytvorit / ziskat userId
        var (chatbotUserId, client) = await _chatbotHelper.GetChatbotUserId(cancellationToken);

        // kontrola favs
        if (request.IsFavorite.GetValueOrDefault())
        {
            var list = await client.GetChatList(chatbotUserId, cancellationToken);
            if (list.Chats.Count(t => t.Favorite) >= 10)
            {
                throw new NobyValidationException(90032, "Maximum number of fav chat reached");
            }
        }

        await client.UpdateChat(chatbotUserId, request.ChatId, request.ChatTitle, request.IsFavorite, cancellationToken);
    }
}
