namespace NOBY.Api.Hubs;

/// <summary>
/// Client interface for NobyHub - defines methods that can be called on connected clients
/// </summary>
public interface INobyHubClient
{
    /// <summary>
    /// Receives a chat response message from the server
    /// </summary>
    /// <param name="message">The chat message content</param>
    /// <param name="cancellationToken">Cancellation token</param>
    Task ReceiveChatResponse(string message, CancellationToken cancellationToken = default);

    /// <summary>
    /// Called when chatbot streaming starts for a specific chat
    /// </summary>
    /// <param name="chatId">The chat ID</param>
    /// <param name="cancellationToken">Cancellation token</param>
    Task ReceiveChatStreamStart(string chatId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Receives a chunk of streamed chat response
    /// </summary>
    /// <param name="chatId">The chat ID</param>
    /// <param name="chunk">The message chunk content</param>
    /// <param name="cancellationToken">Cancellation token</param>
    Task ReceiveChatStreamChunk(string chatId, string chunk, CancellationToken cancellationToken = default);

    /// <summary>
    /// Called when chatbot streaming ends successfully for a specific chat
    /// </summary>
    /// <param name="chatId">The chat ID</param>
    /// <param name="cancellationToken">Cancellation token</param>
    Task ReceiveChatStreamEnd(string chatId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Called when chatbot streaming encounters an error
    /// </summary>
    /// <param name="chatId">The chat ID</param>
    /// <param name="errorMessage">The error message</param>
    /// <param name="cancellationToken">Cancellation token</param>
    Task ReceiveChatStreamError(string chatId, string errorMessage, CancellationToken cancellationToken = default);
}
