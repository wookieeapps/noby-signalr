using NOBY.Api.BackgroundServices.ChatbotStreaming;
using System.Threading.Channels;

namespace NOBY.Api.StartupExtensions;

internal static class NobyChatbotStreaming
{
    /// <summary>
    /// Adds chatbot streaming services with in-memory channel-based background processing.
    /// Note: For multi-node deployments, consider using AddNobyChatbotStreamingWithRedis instead.
    /// </summary>
    public static WebApplicationBuilder AddNobyChatbotStreaming(this WebApplicationBuilder builder)
    {
        // Create unbounded channel for streaming requests
        // Use unbounded to ensure we never lose streaming requests under high load
        var channel = Channel.CreateUnbounded<ChatbotStreamingRequest>(new UnboundedChannelOptions
        {
            SingleReader = true, // Only one background service reads from the channel
            SingleWriter = false // Multiple HTTP requests can write to the channel
        });

        // Register channel as singleton
        builder.Services.AddSingleton(channel);

        // Register in-memory channel coordinator
        // Note: This is registered via [ScopedService] attribute, no manual registration needed

        // Register background service for in-memory channel processing
        builder.Services.AddHostedService<ChatbotStreamingBackgroundService>();

        return builder;
    }

    /// <summary>
    /// Adds chatbot streaming services with Redis-based distributed queue for multi-node deployments.
    /// Requires Redis to be configured for SignalR backplane.
    /// Use this when running multiple NOBY.Api instances for better load balancing and failover.
    /// </summary>
    public static WebApplicationBuilder AddNobyChatbotStreamingWithRedis(this WebApplicationBuilder builder)
    {
        // Redis coordinator is registered via [ScopedService] attribute

        // Register Redis-based background service for distributed processing
        builder.Services.AddHostedService<RedisChatbotStreamingBackgroundService>();

        return builder;
    }
}
