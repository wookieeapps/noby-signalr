# NobyHub SignalR Integration Guide for Frontend (Vue.js)

## Table of Contents
1. [Overview](#overview)
2. [Authentication](#authentication)
3. [Installation](#installation)
4. [Quick Start](#quick-start)
5. [Vue.js Integration Patterns](#vuejs-integration-patterns)
6. [API Reference](#api-reference)
7. [Testing](#testing)
8. [Troubleshooting](#troubleshooting)
9. [Best Practices](#best-practices)

---

## Overview

### What is NobyHub?

NobyHub is a SignalR hub that provides real-time bidirectional communication between the NOBY backend and frontend clients. It is primarily used for streaming chatbot responses to clients.

### Architecture

```
???????????????                    ????????????????                 ???????????????
?             ?  1. HTTP POST      ?              ?  3. SignalR     ?             ?
?  Frontend   ? ?????????????????> ?  NOBY API    ? ??????????????> ?  Frontend   ?
?  (Vue.js)   ?  /api/v1/chatbot   ?              ?  Streaming      ?  (SignalR)  ?
?             ?                    ?              ?  Response       ?             ?
???????????????                    ????????????????                 ???????????????
                                          ?
                                          ? 2. Processes message
                                          ?    via AI Chatbot
                                          ?
```

**Flow:**
1. User sends a chat message via REST API (`POST /api/v1/chatbot/chats`)
2. Backend processes the message using the AI chatbot
3. Backend streams the response chunks via SignalR (`ReceiveChatResponse`)
4. Frontend receives and displays the streaming response in real-time

### Key Features

- ? **Cookie-based authentication** - No JWT tokens needed
- ? **Automatic reconnection** - Handles network interruptions gracefully
- ? **Streaming responses** - Real-time chat message delivery
- ? **Redis backplane support** - Scales across multiple servers
- ? **User-specific messaging** - Messages routed by authenticated user ID
- ? **TypeScript support** - Fully typed contracts

---

## Authentication

### Important: Cookie-Based Authentication

NobyHub uses **cookie-based authentication**, NOT JWT tokens. This means:

1. ? Users must be authenticated via the normal login flow before connecting
2. ? SignalR automatically includes cookies in connection requests
3. ? The `withCredentials: true` option MUST be set in SignalR configuration
4. ? Do NOT try to pass JWT tokens in headers or query strings

### Authentication Flow

```typescript
// 1. User logs in via your standard authentication endpoint
await loginUser(username, password); // Sets authentication cookie

// 2. Connect to SignalR - cookie is automatically included
const hub = new NobyHubClient({
  withCredentials: true  // ?? REQUIRED for cookie auth
});

await hub.start(); // Will succeed if cookie is valid
```

### CORS Considerations

If your frontend is on a different domain than the API:

```typescript
// Production configuration for cross-origin requests
const hub = new NobyHubClient({
  baseUrl: 'https://api.yourapp.com',
  withCredentials: true,  // Include cookies cross-origin
});
```

Your backend must have proper CORS configuration:
```csharp
// Backend CORS setup (already configured in NOBY.Api)
app.UseCors(policy => policy
    .WithOrigins("https://yourfrontend.com")
    .AllowCredentials()  // ?? Required for cookie auth
    .AllowAnyMethod()
    .AllowAnyHeader()
);
```

---

## Installation

### Prerequisites

- Node.js 16+ or compatible
- Vue.js 3.x (recommended) or Vue.js 2.7+
- TypeScript 4.x+ (optional but recommended)

### Install SignalR Client

```bash
npm install @microsoft/signalr
# or
yarn add @microsoft/signalr
# or
pnpm add @microsoft/signalr
```

### Add Contract Files

Copy the TypeScript contract files to your project:

```
src/
  services/
    signalr/
      noby-hub.contract.ts          # Contract file (provided)
      noby-hub.service.ts           # Your service wrapper (see examples)
  composables/
      useNobyHub.ts                 # Vue composable (recommended)
```

---

## Quick Start

### Basic Example (TypeScript)

```typescript
import { NobyHubClient } from '@/services/signalr/noby-hub.contract';

// Create and configure the hub client
const hubClient = new NobyHubClient(
  {
    baseUrl: '',  // Empty for same-origin requests
    withCredentials: true,
  },
  {
    // Event handlers
    onConnected: (connectionId) => {
      console.log('? Connected to NobyHub:', connectionId);
    },
    
    onDisconnected: (error) => {
      console.log('? Disconnected from NobyHub:', error);
    },
    
    onChatResponse: (chatId, message, isComplete) => {
      console.log(`?? Chat ${chatId}:`, message);
      console.log(`   Complete: ${isComplete}`);
    },
  }
);

// Connect to the hub
await hubClient.start();

// Later: disconnect
await hubClient.stop();
```

### Sending a Chat Message

```typescript
// Send message via REST API (NOT SignalR)
const response = await fetch('/api/v1/chatbot/chats', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include',  // Include auth cookies
  body: JSON.stringify({
    communicationRequestText: 'Hello, how can you help me?'
  })
});

const data = await response.json();
console.log('Chat created:', data.chatId, data.chatTitle);

// Response will arrive via SignalR onChatResponse callback
```

### Continue Existing Chat

```typescript
const chatId = 'existing-chat-id-from-previous-response';

const response = await fetch(`/api/v1/chatbot/chats?chatId=${chatId}`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include',
  body: JSON.stringify({
    communicationRequestText: 'Tell me more about that.'
  })
});

// Streaming response will arrive via SignalR
```

---

## Vue.js Integration Patterns

### Pattern 1: Composition API (Recommended)

Create a composable for managing the SignalR connection. See the complete implementation in `examples/useNobyHub.composable.ts`.

```typescript
// composables/useNobyHub.ts
import { ref, onMounted, onUnmounted } from 'vue';
import { NobyHubClient } from '@/services/signalr/noby-hub.contract';

export function useNobyHub() {
  const isConnected = ref(false);
  const connectionId = ref<string | null>(null);
  const error = ref<string | null>(null);
  
  let hubClient: NobyHubClient | null = null;
  
  // Chat state
  const currentChatId = ref<string | null>(null);
  const messages = ref<Array<{ role: 'user' | 'assistant', text: string }>>([]);
  const isReceivingResponse = ref(false);
  const currentStreamingMessage = ref('');
  
  const connect = async () => {
    try {
      hubClient = new NobyHubClient(
        {
          withCredentials: true,
        },
        {
          onConnected: (id) => {
            isConnected.value = true;
            connectionId.value = id;
            error.value = null;
          },
          
          onDisconnected: (err) => {
            isConnected.value = false;
            connectionId.value = null;
            if (err) error.value = err.message;
          },
          
          onChatResponse: (chatId, message, isComplete) => {
            if (isComplete) {
              // Final message received
              messages.value.push({
                role: 'assistant',
                text: message
              });
              isReceivingResponse.value = false;
              currentStreamingMessage.value = '';
            } else {
              // Streaming chunk (optional: show progress)
              isReceivingResponse.value = true;
              currentStreamingMessage.value = message;
            }
          },
        }
      );
      
      await hubClient.start();
    } catch (err: any) {
      error.value = err.message || 'Connection failed';
      console.error('Failed to connect to NobyHub:', err);
    }
  };
  
  const disconnect = async () => {
    if (hubClient) {
      await hubClient.stop();
      hubClient = null;
    }
  };
  
  const sendMessage = async (text: string) => {
    if (!text.trim()) return;
    
    // Add user message to UI
    messages.value.push({ role: 'user', text });
    isReceivingResponse.value = true;
    
    try {
      // Send via REST API
      const url = currentChatId.value 
        ? `/api/v1/chatbot/chats?chatId=${currentChatId.value}`
        : '/api/v1/chatbot/chats';
      
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ communicationRequestText: text })
      });
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const data = await response.json();
      currentChatId.value = data.chatId;
      
      // Response will arrive via SignalR
    } catch (err: any) {
      error.value = err.message;
      isReceivingResponse.value = false;
      console.error('Failed to send message:', err);
    }
  };
  
  const clearChat = () => {
    messages.value = [];
    currentChatId.value = null;
    currentStreamingMessage.value = '';
    isReceivingResponse.value = false;
  };
  
  // Auto-connect on mount
  onMounted(() => {
    connect();
  });
  
  // Auto-disconnect on unmount
  onUnmounted(() => {
    disconnect();
  });
  
  return {
    // Connection state
    isConnected,
    connectionId,
    error,
    connect,
    disconnect,
    
    // Chat functionality
    messages,
    currentChatId,
    isReceivingResponse,
    currentStreamingMessage,
    sendMessage,
    clearChat,
  };
}
```

### Using the Composable in a Component

```vue
<template>
  <div class="chat-container">
    <!-- Connection Status -->
    <div class="status-bar">
      <span :class="isConnected ? 'connected' : 'disconnected'">
        {{ isConnected ? '?? Connected' : '?? Disconnected' }}
      </span>
    </div>

    <!-- Error Display -->
    <div v-if="error" class="error">
      ?? {{ error }}
    </div>

    <!-- Messages -->
    <div class="messages">
      <div
        v-for="(msg, index) in messages"
        :key="index"
        :class="['message', msg.role]"
      >
        {{ msg.text }}
      </div>

      <!-- Streaming Indicator -->
      <div v-if="isReceivingResponse" class="message assistant streaming">
        {{ currentStreamingMessage || 'Thinking...' }}
      </div>
    </div>

    <!-- Input -->
    <input
      v-model="messageText"
      @keyup.enter="handleSend"
      :disabled="!isConnected || isReceivingResponse"
    />
    <button
      @click="handleSend"
      :disabled="!isConnected || isReceivingResponse || !messageText.trim()"
    >
      Send
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useNobyHub } from '@/composables/useNobyHub';

const {
  isConnected,
  error,
  messages,
  currentStreamingMessage,
  isReceivingResponse,
  sendMessage,
} = useNobyHub();

const messageText = ref('');

const handleSend = async () => {
  const text = messageText.value.trim();
  if (!text) return;
  
  await sendMessage(text);
  messageText.value = '';
};
</script>
```

### Pattern 2: Options API

```vue
<script lang="ts">
import { defineComponent } from 'vue';
import { NobyHubClient } from '@/services/signalr/noby-hub.contract';

export default defineComponent({
  name: 'ChatComponent',
  
  data() {
    return {
      hubClient: null as NobyHubClient | null,
      isConnected: false,
      messages: [] as Array<{ role: string; text: string }>,
      messageText: '',
      isReceivingResponse: false,
    };
  },
  
  async mounted() {
    await this.connectToHub();
  },
  
  beforeUnmount() {
    this.hubClient?.stop();
  },
  
  methods: {
    async connectToHub() {
      this.hubClient = new NobyHubClient(
        { withCredentials: true },
        {
          onConnected: (id) => {
            this.isConnected = true;
            console.log('Connected:', id);
          },
          
          onChatResponse: (chatId, message, isComplete) => {
            if (isComplete) {
              this.messages.push({
                role: 'assistant',
                text: message
              });
              this.isReceivingResponse = false;
            }
          },
        }
      );
      
      await this.hubClient.start();
    },
    
    async sendMessage() {
      if (!this.messageText.trim()) return;
      
      this.messages.push({
        role: 'user',
        text: this.messageText
      });
      
      this.isReceivingResponse = true;
      
      const response = await fetch('/api/v1/chatbot/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          communicationRequestText: this.messageText
        })
      });
      
      this.messageText = '';
    },
  },
});
</script>
```

---

## API Reference

### REST API Endpoints

#### Create New Chat or Send Message to Existing Chat

```http
POST /api/v1/chatbot/chats
POST /api/v1/chatbot/chats?chatId={existingChatId}
Content-Type: application/json
Cookie: {auth-cookie}

{
  "communicationRequestText": "Your message here"
}
```

**Response:**
```json
{
  "chatId": "550e8400-e29b-41d4-a716-446655440000",
  "chatTitle": "Chat about XYZ" // Only for new chats
}
```

**Important:** The actual chat response is delivered via SignalR, not in the HTTP response.

### SignalR Hub Endpoint

```
/api/nobyhub
```

### Client Methods (Receive from Server)

#### ReceiveChatResponse

```typescript
receiveChatResponse(chatId: string, message: string, isComplete: boolean): void
```

Called by the server to deliver chat responses (both streaming chunks and final message).

**Parameters:**
- `chatId` - The chat session identifier
- `message` - The message content (partial during streaming, complete when `isComplete=true`)
- `isComplete` - `true` for the final message, `false` for intermediate chunks

**Example:**
```typescript
hubClient.on('ReceiveChatResponse', (chatId, message, isComplete) => {
  console.log(`Chat: ${chatId}`);
  console.log(`Message: ${message}`);
  console.log(`Complete: ${isComplete}`);
});
```

---

## Testing

### Test Pages

The NOBY API includes two HTML test pages for SignalR testing:

1. **General SignalR Test**
   - URL: `https://your-api/signalr-test.html`
   - Tests basic SignalR connectivity
   - Allows sending test messages to specific users

2. **Chatbot Test**
   - URL: `https://your-api/chatbot-test.html`
   - Full chatbot integration testing
   - Shows streaming response behavior
   - Demonstrates typewriter effect

### Test API Endpoint

```http
GET /api/v1/test/signalr/send-to-user?chatId={chatId}&userId={userId}
```

Sends a test message to a specific user via SignalR. Useful for testing user-specific message routing.

### Manual Testing with Browser Console

```javascript
// In browser console after logging in
const connection = new signalR.HubConnectionBuilder()
  .withUrl('/api/nobyhub', { withCredentials: true })
  .build();

connection.on('ReceiveChatResponse', (chatId, message, isComplete) => {
  console.log('Received:', { chatId, message, isComplete });
});

await connection.start();
console.log('Connected!', connection.connectionId);

// Send a message via fetch
await fetch('/api/v1/chatbot/chats', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include',
  body: JSON.stringify({ communicationRequestText: 'Hello!' })
});

// Watch console for SignalR messages
```

---

## Troubleshooting

### Connection Fails with 401 Unauthorized

**Problem:** SignalR connection fails immediately with authentication error.

**Solution:**
1. Verify user is logged in (check cookies in DevTools)
2. Ensure `withCredentials: true` is set in SignalR config
3. Check CORS configuration allows credentials
4. Try accessing the API in the same browser tab to ensure session is active

```typescript
// ? Correct
const hub = new NobyHubClient({ withCredentials: true });

// ? Wrong
const hub = new NobyHubClient({ withCredentials: false });
```

### Messages Not Received

**Problem:** Connection succeeds but no messages arrive.

**Checklist:**
1. ? Is the SignalR connection still active? Check `hub.isConnected`
2. ? Did the REST API call succeed? Check network tab
3. ? Is the `ReceiveChatResponse` handler registered?
4. ? Are you listening for the correct chat ID?
5. ? Check browser console for errors

```typescript
// Debug: Log all SignalR traffic
connection.on('ReceiveChatResponse', (...args) => {
  console.log('RAW SignalR args:', args);
});
```

### Connection Drops Frequently

**Problem:** SignalR connection disconnects unexpectedly.

**Solutions:**
1. Check network stability
2. Verify firewall/proxy settings allow WebSockets
3. Enable automatic reconnection (default in NobyHubClient)
4. Increase server-side keep-alive interval

```typescript
const hub = new NobyHubClient({
  automaticReconnect: true,
  reconnectDelays: [0, 2000, 5000, 10000, 30000],
});
```

### CORS Errors

**Problem:** CORS policy blocks SignalR connection.

**Solution:**
Verify backend CORS is configured for your frontend origin:

```csharp
// Backend: Startup.cs or Program.cs
builder.Services.AddCors(options => {
  options.AddPolicy("AllowFrontend", policy => {
    policy.WithOrigins("https://yourfrontend.com")
          .AllowCredentials()  // Required for cookies
          .AllowAnyMethod()
          .AllowAnyHeader();
  });
});
```

Frontend configuration:
```typescript
const hub = new NobyHubClient({
  baseUrl: 'https://api.yourbackend.com',
  withCredentials: true,  // Must match backend AllowCredentials
});
```

### TypeScript Type Errors

**Problem:** TypeScript complains about SignalR types.

**Solution:**
Ensure `@microsoft/signalr` types are installed:

```bash
npm install --save-dev @types/node  # If needed
```

Check `tsconfig.json`:
```json
{
  "compilerOptions": {
    "moduleResolution": "node",
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true
  }
}
```

---

## Best Practices

### 1. Connection Management

? **DO:**
- Connect once when app/component mounts
- Reuse the same connection for multiple chats
- Handle reconnection events gracefully
- Disconnect when component unmounts

? **DON'T:**
- Create new connections for every message
- Leave connections open after logout
- Ignore connection state in UI

```typescript
// ? Good: One connection for entire chat session
onMounted(() => connectToHub());
onUnmounted(() => disconnectFromHub());

// ? Bad: New connection per message
async function sendMessage(text: string) {
  const hub = new NobyHubClient();  // Don't do this!
  await hub.start();
  // ...
}
```

### 2. Error Handling

Always handle connection errors:

```typescript
const hub = new NobyHubClient({}, {
  onDisconnected: (error) => {
    if (error) {
      // Log error
      console.error('SignalR error:', error);
      
      // Show user-friendly message
      showNotification('Connection lost. Reconnecting...');
      
      // Track in monitoring
      trackError('signalr-disconnect', error);
    }
  },
});
```

### 3. User Experience

Provide visual feedback:

```vue
<template>
  <div class="chat">
    <!-- Connection indicator -->
    <div v-if="!isConnected" class="banner warning">
      ?? Reconnecting to chat...
    </div>
    
    <!-- Typing indicator while streaming -->
    <div v-if="isReceivingResponse" class="typing-indicator">
      AI is typing...
    </div>
  </div>
</template>
```

### 4. Message Handling

Handle both streaming and final messages:

```typescript
onChatResponse: (chatId, message, isComplete) => {
  if (isComplete) {
    // Final message: add to conversation history
    addFinalMessage(message);
    
    // Stop loading indicators
    setIsTyping(false);
  } else {
    // Optional: Show streaming progress
    updateStreamingPreview(message);
  }
}
```

### 5. Performance

- Debounce rapid message updates during streaming
- Use virtual scrolling for long conversations
- Clean up old messages from memory

```typescript
import { debounce } from 'lodash-es';

const updateStreamingMessage = debounce((message: string) => {
  streamingPreview.value = message;
}, 50); // Update UI every 50ms max

onChatResponse: (chatId, message, isComplete) => {
  if (!isComplete) {
    updateStreamingMessage(message);
  }
}
```

### 6. Security

- Never trust client-side data
- Validate all user inputs before sending
- Sanitize received HTML if displaying rich content
- Keep SignalR library updated

```typescript
import DOMPurify from 'dompurify';

onChatResponse: (chatId, message, isComplete) => {
  // Sanitize if rendering as HTML
  const safeMessage = DOMPurify.sanitize(message);
  // ...
}
```

### 7. Testing

Create mock implementations for unit tests:

```typescript
// tests/mocks/mockNobyHub.ts
export class MockNobyHubClient {
  async start() { /* mock */ }
  async stop() { /* mock */ }
  
  // Simulate receiving a message
  simulateMessage(chatId: string, message: string) {
    this.events.onChatResponse?.(chatId, message, true);
  }
}
```

---

## Additional Resources

- **SignalR Documentation:** https://learn.microsoft.com/en-us/aspnet/core/signalr/
- **@microsoft/signalr NPM:** https://www.npmjs.com/package/@microsoft/signalr
- **Test Pages:** `/signalr-test.html` and `/chatbot-test.html`
- **API Documentation:** `/swagger` (OpenAPI/Swagger UI)
- **SignalR Hub Docs:** `GET /api/v1/signalrdocs` (auto-generated documentation)

---

## Support

If you encounter issues:

1. Check this guide's Troubleshooting section
2. Review browser console for errors
3. Test with the provided HTML test pages
4. Check `/api/v1/signalrdocs` for latest hub documentation
5. Contact the backend team with:
   - Browser console logs
   - Network tab screenshots
   - Steps to reproduce

---

**Document Version:** 1.0.0  
**Last Updated:** 2024  
**Maintained By:** NOBY Backend Team
