# NobyHub SignalR - Quick Start Cheat Sheet

## ?? Installation (1 minute)

```bash
npm install @microsoft/signalr
```

## ?? Basic Setup (5 minutes)

### Step 1: Copy Files

```
your-project/src/
??? services/signalr/
?   ??? noby-hub.contract.ts     ? Copy from SignalR-Contracts/
??? composables/
    ??? useNobyHub.ts             ? Copy from SignalR-Contracts/examples/
```

### Step 2: Use in Component

```vue
<script setup>
import { useNobyHub } from '@/composables/useNobyHub'

const { isConnected, messages, sendMessage } = useNobyHub()
</script>

<template>
  <div>
    <!-- Connection Status -->
    <div>Status: {{ isConnected ? '?? Connected' : '?? Disconnected' }}</div>
    
    <!-- Messages -->
    <div v-for="msg in messages" :key="msg.id">
      <strong>{{ msg.role }}:</strong> {{ msg.text }}
    </div>
    
    <!-- Send Message -->
    <input v-model="userInput" @keyup.enter="sendMessage(userInput)" />
  </div>
</template>
```

## ?? Common Patterns

### Pattern 1: Simple Message Sending

```typescript
const { sendMessage } = useNobyHub()

// Send a message
await sendMessage('Hello, AI!')
```

### Pattern 2: Handle Connection State

```vue
<script setup>
const { isConnected, isConnecting, reconnect } = useNobyHub()
</script>

<template>
  <button v-if="!isConnected" @click="reconnect">
    {{ isConnecting ? 'Connecting...' : 'Reconnect' }}
  </button>
</template>
```

### Pattern 3: Display Streaming Responses

```vue
<script setup>
const { 
  isReceivingResponse, 
  currentStreamingMessage 
} = useNobyHub()
</script>

<template>
  <div v-if="isReceivingResponse" class="streaming">
    {{ currentStreamingMessage }}
    <span class="cursor">?</span>
  </div>
</template>
```

### Pattern 4: Error Handling

```vue
<script setup>
const { error, clearError } = useNobyHub()
</script>

<template>
  <div v-if="error" class="error">
    ?? {{ error }}
    <button @click="clearError">�</button>
  </div>
</template>
```

## ?? Configuration

### Default (Same Origin)

```typescript
// Auto-connects with cookies
const hub = useNobyHub()
```

### Custom URL (Different Domain)

```typescript
const hub = useNobyHub({
  baseUrl: 'https://api.example.com',
  autoConnect: true,
  debug: true
})
```

### Manual Connection Control

```typescript
const { connect, disconnect } = useNobyHub({
  autoConnect: false  // Don't auto-connect
})

// Connect when needed
await connect()

// Disconnect when done
await disconnect()
```

## ?? REST API Quick Reference

### Send New Chat Message

```typescript
// Creates new chat
fetch('/api/v1/chatbot/chats', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include',
  body: JSON.stringify({
    communicationRequestText: 'Your message here'
  })
})
```

### Continue Existing Chat

```typescript
// Uses existing chatId
fetch('/api/v1/chatbot/chats?chatId=YOUR-CHAT-ID', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include',
  body: JSON.stringify({
    communicationRequestText: 'Follow-up message'
  })
})
```

## ? Important Notes

### ? DO

- ? Use **cookie-based authentication** (login first!)
- ? Set `withCredentials: true` (auto-configured in composable)
- ? Connect once, reuse for multiple messages
- ? Handle disconnection events

### ? DON'T

- ? Try to use JWT tokens (won't work!)
- ? Create new connection for each message
- ? Forget to authenticate before connecting
- ? Ignore error states

## ?? Quick Troubleshooting

| Problem | Solution |
|---------|----------|
| 401 Unauthorized | Make sure you're logged in first |
| No messages received | Check if `isConnected === true` |
| CORS errors | Backend must allow your domain + credentials |
| Connection drops | Auto-reconnect is enabled by default |

## ?? Complete Example Component

```vue
<template>
  <div class="chat">
    <!-- Status -->
    <div class="status" :class="isConnected ? 'online' : 'offline'">
      {{ isConnected ? '?? Online' : '?? Offline' }}
    </div>
    
    <!-- Messages -->
    <div class="messages">
      <div v-for="msg in messages" :key="msg.id" :class="msg.role">
        {{ msg.text }}
      </div>
      
      <!-- Streaming indicator -->
      <div v-if="isReceivingResponse" class="streaming">
        {{ currentStreamingMessage || 'Typing...' }}
      </div>
    </div>
    
    <!-- Input -->
    <form @submit.prevent="send">
      <input 
        v-model="input" 
        placeholder="Type a message..."
        :disabled="!canSendMessage"
      />
      <button :disabled="!canSendMessage || !input.trim()">
        Send
      </button>
    </form>
    
    <!-- Error -->
    <div v-if="error" class="error">{{ error }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useNobyHub } from '@/composables/useNobyHub'

const {
  isConnected,
  messages,
  isReceivingResponse,
  currentStreamingMessage,
  canSendMessage,
  error,
  sendMessage
} = useNobyHub()

const input = ref('')

const send = async () => {
  if (!input.value.trim()) return
  await sendMessage(input.value)
  input.value = ''
}
</script>
```

## ?? Resources

- **Full Documentation:** `INTEGRATION-GUIDE.md`
- **Complete Component:** `examples/ChatComponent.vue`
- **Test Page:** `https://your-api/chatbot-test.html`
- **API Docs:** `https://your-api/swagger`

## ?? Need Help?

1. Read `INTEGRATION-GUIDE.md` (comprehensive guide)
2. Check browser console for errors
3. Test with `/chatbot-test.html`
4. Contact backend team

---

**That's it! You're ready to integrate NobyHub SignalR in your Vue.js app! ??**
