# NobyHub SignalR - TypeScript Contracts & Integration

This directory contains TypeScript contracts, integration guides, and example implementations for integrating the **NobyHub SignalR** hub into your Vue.js frontend application.

## ?? Directory Structure

```
SignalR-Contracts/
??? README.md                           # This file
??? QUICK-START.md                      # Quick reference cheat sheet
??? noby-hub.contract.ts               # TypeScript contracts and client wrapper
??? INTEGRATION-GUIDE.md               # Comprehensive integration documentation
??? examples/
    ??? useNobyHub.composable.ts       # Vue 3 Composition API composable
    ??? package.json                   # Example dependencies
```

## ?? Quick Start

### 1. Install Dependencies

```bash
npm install @microsoft/signalr
```

### 2. Copy Contract Files

Copy the following files to your Vue.js project:

```
your-project/
??? src/
    ??? services/
    ?   ??? signalr/
    ?       ??? noby-hub.contract.ts      # Copy from this directory
    ??? composables/
        ??? useNobyHub.ts                  # Copy from examples/
```

### 3. Basic Usage

```vue
<script setup lang="ts">
import { useNobyHub } from '@/composables/useNobyHub'

const { 
  isConnected, 
  messages, 
  sendMessage 
} = useNobyHub()
</script>

<template>
  <div>
    <div v-if="isConnected">? Connected</div>
    
    <div v-for="msg in messages" :key="msg.id">
      <strong>{{ msg.role }}:</strong> {{ msg.text }}
    </div>
    
    <button @click="sendMessage('Hello!')">
      Send Message
    </button>
  </div>
</template>
```

### 4. Run Your Application

Make sure you're authenticated (logged in) before the SignalR connection is established, as NobyHub uses **cookie-based authentication**.

## ?? Documentation

### Primary Documentation

- **[INTEGRATION-GUIDE.md](./INTEGRATION-GUIDE.md)** - Complete integration guide including:
  - Authentication details (cookie-based)
  - Installation instructions
  - Vue.js integration patterns (Composition API, Options API)
  - API reference
  - Testing guides
  - Troubleshooting
  - Best practices

- **[QUICK-START.md](./QUICK-START.md)** - Quick reference cheat sheet for common patterns

### Quick Reference

#### TypeScript Contracts

- **`noby-hub.contract.ts`** - Contains:
  - `INobyHubClient` - Interface for client methods
  - `INobyHubServer` - Interface for server methods
  - `NobyHubClient` - Wrapper class for easy integration
  - Type definitions for messages and configuration

#### Examples

- **`examples/useNobyHub.composable.ts`** - Production-ready Vue 3 composable with full state management

## ?? Key Features

### NobyHub Capabilities

- ? **Real-time chat streaming** - Receive AI responses as they're generated
- ? **Cookie-based authentication** - No JWT tokens needed
- ? **Automatic reconnection** - Handles network issues gracefully
- ? **User-specific messaging** - Messages routed by authenticated user ID
- ? **Redis backplane support** - Scales across multiple servers

### Contract Features

- ? **Fully typed** - TypeScript contracts for type safety
- ? **Wrapper class** - Easy-to-use `NobyHubClient` class
- ? **Vue composable** - Ready-to-use composable for Vue 3
- ? **Production-ready** - Complete error handling and state management

## ?? How It Works

### Architecture Flow

```
1. User sends message via REST API
   ?
   POST /api/v1/chatbot/chats
   
2. Backend processes message with AI
   ?
   (AI generates response)
   
3. Backend streams response via SignalR
   ?
   SignalR: ReceiveChatResponse(chatId, message, isComplete)
   
4. Frontend displays streaming response
   ?
   UI updates in real-time
```

### Authentication

**Important:** NobyHub uses **cookie-based authentication**, NOT JWT tokens.

```typescript
// ? Correct - Cookies are automatically included
const hub = new NobyHubClient({
  withCredentials: true  // Required for cookie auth
});

// ? Wrong - Don't try to pass JWT tokens
const hub = new NobyHubClient({
  accessTokenFactory: () => getJwtToken()  // Won't work!
});
```

## ?? Common Use Cases

### Use Case 1: Simple Chat Integration

```typescript
import { useNobyHub } from '@/composables/useNobyHub'

const { isConnected, sendMessage, messages } = useNobyHub()

// Send a message
await sendMessage('Hello, how can you help me?')

// Messages automatically appear in the `messages` ref
```

### Use Case 2: Custom Event Handling

```typescript
const hub = new NobyHubClient(
  { withCredentials: true },
  {
    onChatResponse: (chatId, message, isComplete) => {
      if (isComplete) {
        // Final message received
        saveMessageToDatabase(message)
      } else {
        // Streaming chunk
        updateUIWithPartialMessage(message)
      }
    }
  }
)

await hub.start()
```

### Use Case 3: Advanced Connection Management

```typescript
const { 
  isConnected, 
  isConnecting, 
  error, 
  reconnect 
} = useNobyHub()

// Show reconnection UI
watchEffect(() => {
  if (error.value) {
    showToast('Connection error: ' + error.value)
  }
})

// Manual reconnect button
<button @click="reconnect" :disabled="isConnecting">
  {{ isConnecting ? 'Reconnecting...' : 'Reconnect' }}
</button>
```

## ?? Testing

### Test Pages

The NOBY API provides two HTML test pages:

1. **General SignalR Test**
   - URL: `https://your-api/signalr-test.html`
   - Tests basic SignalR connectivity

2. **Chatbot Test**
   - URL: `https://your-api/chatbot-test.html`
   - Full chatbot integration with streaming

### Browser Console Testing

```javascript
// In browser console (after logging in)
const connection = new signalR.HubConnectionBuilder()
  .withUrl('/api/nobyhub', { withCredentials: true })
  .build()

connection.on('ReceiveChatResponse', (chatId, message, isComplete) => {
  console.log({ chatId, message, isComplete })
})

await connection.start()
console.log('Connected:', connection.connectionId)

// Send test message
await fetch('/api/v1/chatbot/chats', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include',
  body: JSON.stringify({ communicationRequestText: 'Hello!' })
})
```

## ?? Troubleshooting

### Connection Fails with 401 Unauthorized

**Problem:** SignalR connection fails immediately.

**Solution:**
1. Verify user is logged in (check cookies in DevTools)
2. Ensure `withCredentials: true` is set
3. Check CORS configuration allows credentials

```typescript
// ? Correct configuration
const hub = new NobyHubClient({
  baseUrl: 'https://your-api.com',
  withCredentials: true  // Required!
})
```

### No Messages Received

**Problem:** Connection works but no messages arrive.

**Checklist:**
- ? Is SignalR still connected? Check `isConnected`
- ? Did the REST API call succeed? Check network tab
- ? Is the `ReceiveChatResponse` handler registered?
- ? Are you listening for the correct chat ID?

### CORS Errors

**Problem:** CORS policy blocks requests.

**Solution:** Verify backend CORS configuration:

```csharp
// Backend must allow credentials
builder.Services.AddCors(options => {
  options.AddPolicy("AllowFrontend", policy => {
    policy.WithOrigins("https://your-frontend.com")
          .AllowCredentials()  // Required
          .AllowAnyMethod()
          .AllowAnyHeader();
  });
});
```

## ?? API Reference

### REST Endpoints

```http
# Create new chat or send to existing chat
POST /api/v1/chatbot/chats
POST /api/v1/chatbot/chats?chatId={chatId}

# Get SignalR documentation (auto-generated)
GET /api/v1/signalrdocs
```

### SignalR Hub

```
Endpoint: /api/nobyhub
Authentication: Cookie-based
```

### Client Methods (Receive from Server)

```typescript
// Receives chat response (streaming or final)
receiveChatResponse(
  chatId: string,      // Chat session ID
  message: string,     // Message content
  isComplete: boolean  // true = final, false = streaming chunk
): void
```

## ?? Best Practices

### 1. Connection Management

- ? Connect once on app/component mount
- ? Reuse connection for multiple messages
- ? Disconnect on unmount
- ? Don't create new connections per message

### 2. Error Handling

- ? Always handle `onDisconnected` events
- ? Show user-friendly error messages
- ? Implement retry logic for failed connections
- ? Log errors for debugging

### 3. User Experience

- ? Show connection status indicator
- ? Display typing/loading indicators
- ? Handle streaming messages gracefully
- ? Provide offline fallbacks

### 4. Performance

- ? Debounce rapid message updates
- ? Use virtual scrolling for long chats
- ? Clean up old messages from memory
- ? Avoid unnecessary re-renders

## ?? Additional Resources

- **SignalR Documentation:** https://learn.microsoft.com/en-us/aspnet/core/signalr/
- **@microsoft/signalr NPM:** https://www.npmjs.com/package/@microsoft/signalr
- **Vue.js 3 Docs:** https://vuejs.org/
- **TypeScript Handbook:** https://www.typescriptlang.org/docs/

## ?? Support

For issues or questions:

1. Check [INTEGRATION-GUIDE.md](./INTEGRATION-GUIDE.md) troubleshooting section
2. Review browser console for errors
3. Test with `/signalr-test.html` and `/chatbot-test.html`
4. Check `/api/v1/signalrdocs` for latest hub documentation
5. Contact the backend team with:
   - Browser console logs
   - Network tab screenshots
   - Steps to reproduce

## ?? License

Internal use only - NOBY Project

---

**Version:** 1.0.0  
**Last Updated:** 2024  
**Maintained By:** NOBY Backend Team
