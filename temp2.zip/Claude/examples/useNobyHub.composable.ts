/**
 * Vue.js Composable for NobyHub SignalR Integration
 * 
 * This composable provides a ready-to-use implementation for integrating
 * NobyHub SignalR functionality into your Vue.js 3 application.
 * 
 * @example
 * ```vue
 * <script setup>
 * import { useNobyHub } from '@/composables/useNobyHub'
 * 
 * const { isConnected, messages, sendMessage, clearChat } = useNobyHub()
 * </script>
 * ```
 */

import { ref, onMounted, onUnmounted, computed, readonly } from 'vue';
import { NobyHubClient, type ChatMessageRequest, type ChatMessageResponse } from './noby-hub.contract';

// ============================================================================
// Types
// ============================================================================

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: Date;
  isStreaming?: boolean;
}

export interface NobyHubOptions {
  /**
   * Base URL for the API (leave empty for same-origin)
   */
  baseUrl?: string;

  /**
   * Auto-connect on composable initialization
   * @default true
   */
  autoConnect?: boolean;

  /**
   * Enable debug logging
   * @default false
   */
  debug?: boolean;

  /**
   * Custom error handler
   */
  onError?: (error: Error) => void;
}

// ============================================================================
// Composable
// ============================================================================

export function useNobyHub(options: NobyHubOptions = {}) {
  const {
    baseUrl = '',
    autoConnect = true,
    debug = false,
    onError,
  } = options;

  // ============================================================================
  // State
  // ============================================================================

  const hubClient = ref<NobyHubClient | null>(null);
  const isConnected = ref(false);
  const isConnecting = ref(false);
  const connectionId = ref<string | null>(null);
  const error = ref<string | null>(null);

  // Chat state
  const messages = ref<ChatMessage[]>([]);
  const currentChatId = ref<string | null>(null);
  const chatTitle = ref<string | null>(null);
  const isReceivingResponse = ref(false);
  const currentStreamingMessage = ref<string>('');
  const currentStreamingMessageId = ref<string | null>(null);

  // ============================================================================
  // Computed
  // ============================================================================

  const connectionStatus = computed(() => {
    if (isConnecting.value) return 'connecting';
    if (isConnected.value) return 'connected';
    return 'disconnected';
  });

  const hasMessages = computed(() => messages.value.length > 0);

  const canSendMessage = computed(() => 
    isConnected.value && !isReceivingResponse.value
  );

  // ============================================================================
  // Internal Helpers
  // ============================================================================

  const log = (...args: any[]) => {
    if (debug) {
      console.log('[useNobyHub]', ...args);
    }
  };

  const setError = (errorMessage: string, originalError?: Error) => {
    error.value = errorMessage;
    log('Error:', errorMessage, originalError);
    
    if (originalError && onError) {
      onError(originalError);
    }
  };

  const clearError = () => {
    error.value = null;
  };

  const generateMessageId = () => {
    return `msg-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  };

  // ============================================================================
  // Connection Management
  // ============================================================================

  const connect = async () => {
    if (isConnected.value || isConnecting.value) {
      log('Already connected or connecting');
      return;
    }

    isConnecting.value = true;
    clearError();

    try {
      log('Connecting to NobyHub...');

      hubClient.value = new NobyHubClient(
        {
          baseUrl,
          withCredentials: true,
          automaticReconnect: true,
          reconnectDelays: [0, 2000, 5000, 10000, 30000],
        },
        {
          onConnected: (id) => {
            log('Connected successfully:', id);
            isConnected.value = true;
            isConnecting.value = false;
            connectionId.value = id;
            clearError();
          },

          onDisconnected: (err) => {
            log('Disconnected:', err);
            isConnected.value = false;
            isConnecting.value = false;
            connectionId.value = null;

            if (err) {
              setError(`Connection lost: ${err.message}`, err);
            }
          },

          onReconnecting: (err) => {
            log('Reconnecting...', err);
            isConnecting.value = true;
            if (err) {
              setError(`Reconnecting: ${err.message}`, err);
            }
          },

          onReconnected: (id) => {
            log('Reconnected:', id);
            isConnected.value = true;
            isConnecting.value = false;
            connectionId.value = id;
            clearError();
          },

          onChatResponse: (chatId, message, isComplete) => {
            log('Chat response:', { chatId, message, isComplete });
            handleChatResponse(chatId, message, isComplete);
          },
        }
      );

      await hubClient.value.start();
    } catch (err: any) {
      const errorMsg = err.message || 'Failed to connect to chat server';
      log('Connection failed:', err);
      
      isConnecting.value = false;
      
      if (err.toString().includes('401') || err.toString().includes('Unauthorized')) {
        setError('Authentication failed. Please log in again.', err);
      } else {
        setError(errorMsg, err);
      }
      
      throw err;
    }
  };

  const disconnect = async () => {
    if (!hubClient.value) {
      return;
    }

    try {
      log('Disconnecting...');
      await hubClient.value.stop();
      hubClient.value = null;
      isConnected.value = false;
      isConnecting.value = false;
      connectionId.value = null;
      log('Disconnected successfully');
    } catch (err: any) {
      log('Disconnect error:', err);
      setError('Failed to disconnect properly', err);
    }
  };

  const reconnect = async () => {
    log('Manual reconnect requested');
    await disconnect();
    await connect();
  };

  // ============================================================================
  // Chat Functionality
  // ============================================================================

  const handleChatResponse = (chatId: string, message: string, isComplete: boolean) => {
    // Verify this is for our current chat
    if (chatId !== currentChatId.value) {
      log('Received message for different chat:', chatId);
      return;
    }

    if (isComplete) {
      // Final message received
      const messageId = currentStreamingMessageId.value || generateMessageId();
      
      messages.value.push({
        id: messageId,
        role: 'assistant',
        text: message,
        timestamp: new Date(),
        isStreaming: false,
      });

      // Reset streaming state
      isReceivingResponse.value = false;
      currentStreamingMessage.value = '';
      currentStreamingMessageId.value = null;

      log('Final message added to chat');
    } else {
      // Streaming chunk (update preview)
      if (!currentStreamingMessageId.value) {
        currentStreamingMessageId.value = generateMessageId();
      }
      
      currentStreamingMessage.value = message;
      isReceivingResponse.value = true;

      log('Streaming chunk received');
    }
  };

  const sendMessage = async (text: string): Promise<void> => {
    if (!text.trim()) {
      throw new Error('Message cannot be empty');
    }

    if (!canSendMessage.value) {
      throw new Error('Cannot send message: not connected or already receiving response');
    }

    clearError();

    // Add user message to UI immediately
    const userMessageId = generateMessageId();
    messages.value.push({
      id: userMessageId,
      role: 'user',
      text: text.trim(),
      timestamp: new Date(),
    });

    // Set receiving state
    isReceivingResponse.value = true;

    try {
      // Prepare API request
      const url = currentChatId.value
        ? `/api/v1/chatbot/chats?chatId=${encodeURIComponent(currentChatId.value)}`
        : '/api/v1/chatbot/chats';

      const requestBody: ChatMessageRequest = {
        communicationRequestText: text.trim(),
      };

      log('Sending message via API:', url);

      // Send message via REST API
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include', // Include auth cookies
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status} ${response.statusText}`);
      }

      const data: ChatMessageResponse = await response.json();
      
      log('API response:', data);

      // Update chat metadata
      currentChatId.value = data.chatId;
      if (data.chatTitle) {
        chatTitle.value = data.chatTitle;
      }

      // Response will arrive via SignalR (handleChatResponse will be called)
    } catch (err: any) {
      log('Send message error:', err);
      
      // Remove user message on error
      messages.value = messages.value.filter(m => m.id !== userMessageId);
      
      // Reset state
      isReceivingResponse.value = false;
      
      setError(err.message || 'Failed to send message', err);
      throw err;
    }
  };

  const clearChat = () => {
    log('Clearing chat');
    messages.value = [];
    currentChatId.value = null;
    chatTitle.value = null;
    currentStreamingMessage.value = '';
    currentStreamingMessageId.value = null;
    isReceivingResponse.value = false;
    clearError();
  };

  const startNewChat = () => {
    log('Starting new chat');
    currentChatId.value = null;
    chatTitle.value = null;
    clearError();
  };

  // ============================================================================
  // Lifecycle
  // ============================================================================

  onMounted(() => {
    if (autoConnect) {
      log('Auto-connecting on mount');
      connect();
    }
  });

  onUnmounted(() => {
    log('Disconnecting on unmount');
    disconnect();
  });

  // ============================================================================
  // Return Public API
  // ============================================================================

  return {
    // Connection state (readonly)
    isConnected: readonly(isConnected),
    isConnecting: readonly(isConnecting),
    connectionId: readonly(connectionId),
    connectionStatus: readonly(connectionStatus),
    error: readonly(error),

    // Chat state (readonly)
    messages: readonly(messages),
    currentChatId: readonly(currentChatId),
    chatTitle: readonly(chatTitle),
    isReceivingResponse: readonly(isReceivingResponse),
    currentStreamingMessage: readonly(currentStreamingMessage),
    hasMessages,
    canSendMessage,

    // Connection methods
    connect,
    disconnect,
    reconnect,

    // Chat methods
    sendMessage,
    clearChat,
    startNewChat,
    clearError,
  };
}

// ============================================================================
// Export Types
// ============================================================================

export type UseNobyHubReturn = ReturnType<typeof useNobyHub>;
