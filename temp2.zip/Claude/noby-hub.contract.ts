/**
 * TypeScript Contract for NobyHub SignalR Integration
 * 
 * This file contains TypeScript type definitions and interfaces for integrating
 * with the NOBY SignalR Hub in your Vue.js application.
 * 
 * @generated from NobyHub.cs and INobyHubClient.cs
 * @version 1.0.0
 * @hub-endpoint /api/nobyhub
 */

import { HubConnection, HubConnectionBuilder, HubConnectionState, LogLevel } from '@microsoft/signalr';

// ============================================================================
// Client Methods - Methods that the server can invoke on the client
// ============================================================================

/**
 * Interface defining methods that the server can call on connected clients.
 * Implement this interface to handle incoming messages from the NobyHub.
 */
export interface INobyHubClient {
  /**
   * Receives a chat response chunk from the chatbot.
   * This method is called by the server when streaming chat responses.
   * 
   * @param chatId - The unique identifier for the chat session
   * @param message - The message content (can be a partial chunk during streaming or complete response)
   * @param isComplete - True if this is the final/complete message, false for streaming chunks
   * 
   * @example
   * // During streaming, you might receive multiple calls:
   * // 1. ReceiveChatResponse("chat-123", "Hello", false)
   * // 2. ReceiveChatResponse("chat-123", "Hello, how", false)
   * // 3. ReceiveChatResponse("chat-123", "Hello, how can I help you?", true)
   */
  receiveChatResponse(chatId: string, message: string, isComplete: boolean): void | Promise<void>;
}

// ============================================================================
// Server Methods - Methods that clients can invoke on the server
// ============================================================================

/**
 * Interface defining methods that clients can call on the NobyHub server.
 * Note: Currently, NobyHub only exposes lifecycle methods (connect/disconnect).
 * Chat messages are sent via REST API, and responses come through SignalR.
 */
export interface INobyHubServer {
  /**
   * Send a chat response to the calling client.
   * Note: This is typically not called directly by clients. It's used internally
   * by the server or for testing purposes.
   * 
   * @param chatId - The chat ID
   * @param message - The message content
   * @param isComplete - Whether this is the final message (default: false)
   */
  sendChatResponse(chatId: string, message: string, isComplete?: boolean): Promise<void>;
}

// ============================================================================
// Connection Configuration
// ============================================================================

/**
 * Configuration options for NobyHub SignalR connection
 */
export interface NobyHubConfig {
  /**
   * The base URL of your API (without the hub endpoint)
   * @example "https://api.example.com" or "" for same-origin
   */
  baseUrl?: string;

  /**
   * The SignalR hub endpoint path
   * @default "/api/nobyhub"
   */
  hubPath?: string;

  /**
   * Whether to enable automatic reconnection
   * @default true
   */
  automaticReconnect?: boolean;

  /**
   * Retry delays in milliseconds for automatic reconnection
   * @default [0, 2000, 5000, 10000, 30000]
   */
  reconnectDelays?: number[];

  /**
   * SignalR logging level
   * @default LogLevel.Information
   */
  logLevel?: LogLevel;

  /**
   * Whether to include credentials (cookies) in requests
   * Required for cookie-based authentication
   * @default true
   */
  withCredentials?: boolean;

  /**
   * Skip negotiation and force WebSockets transport
   * @default false
   */
  skipNegotiation?: boolean;
}

// ============================================================================
// Connection State Management
// ============================================================================

/**
 * NobyHub connection lifecycle events
 */
export interface NobyHubEvents {
  /**
   * Called when the connection is successfully established
   * @param connectionId - The unique connection identifier
   */
  onConnected?: (connectionId: string | null) => void;

  /**
   * Called when the connection is closed
   * @param error - The error that caused the disconnection (if any)
   */
  onDisconnected?: (error?: Error) => void;

  /**
   * Called when the connection is attempting to reconnect
   * @param error - The error that triggered the reconnection attempt
   */
  onReconnecting?: (error?: Error) => void;

  /**
   * Called when the connection successfully reconnects
   * @param connectionId - The new connection identifier
   */
  onReconnected?: (connectionId: string | null) => void;

  /**
   * Called when a chat response is received
   * Same as INobyHubClient.receiveChatResponse but as an event callback
   */
  onChatResponse?: (chatId: string, message: string, isComplete: boolean) => void;
}

// ============================================================================
// NobyHub Client Wrapper Class
// ============================================================================

/**
 * Type-safe wrapper class for NobyHub SignalR connection.
 * Provides a convenient API for connecting to and interacting with the NobyHub.
 * 
 * @example
 * ```typescript
 * const hubClient = new NobyHubClient({
 *   baseUrl: 'https://api.example.com',
 *   onChatResponse: (chatId, message, isComplete) => {
 *     console.log(`Chat ${chatId}: ${message} (Complete: ${isComplete})`);
 *   }
 * });
 * 
 * await hubClient.start();
 * ```
 */
export class NobyHubClient {
  private connection: HubConnection;
  private config: Required<NobyHubConfig>;
  private events: NobyHubEvents;

  /**
   * Creates a new NobyHub client instance
   * @param config - Configuration options for the hub connection
   * @param events - Event handlers for connection lifecycle
   */
  constructor(config: NobyHubConfig = {}, events: NobyHubEvents = {}) {
    // Set default configuration
    this.config = {
      baseUrl: config.baseUrl ?? '',
      hubPath: config.hubPath ?? '/api/nobyhub',
      automaticReconnect: config.automaticReconnect ?? true,
      reconnectDelays: config.reconnectDelays ?? [0, 2000, 5000, 10000, 30000],
      logLevel: config.logLevel ?? LogLevel.Information,
      withCredentials: config.withCredentials ?? true,
      skipNegotiation: config.skipNegotiation ?? false,
    };

    this.events = events;

    // Build the connection
    const hubUrl = `${this.config.baseUrl}${this.config.hubPath}`;
    
    let connectionBuilder = new HubConnectionBuilder()
      .withUrl(hubUrl, {
        withCredentials: this.config.withCredentials,
        skipNegotiation: this.config.skipNegotiation,
      })
      .configureLogging(this.config.logLevel);

    // Add automatic reconnection if enabled
    if (this.config.automaticReconnect) {
      connectionBuilder = connectionBuilder.withAutomaticReconnect(this.config.reconnectDelays);
    }

    this.connection = connectionBuilder.build();

    // Register lifecycle event handlers
    this.setupLifecycleHandlers();

    // Register client methods
    this.registerClientMethods();
  }

  /**
   * Sets up connection lifecycle event handlers
   */
  private setupLifecycleHandlers(): void {
    this.connection.onclose((error) => {
      console.log('[NobyHub] Connection closed', error);
      this.events.onDisconnected?.(error);
    });

    this.connection.onreconnecting((error) => {
      console.log('[NobyHub] Reconnecting...', error);
      this.events.onReconnecting?.(error);
    });

    this.connection.onreconnected((connectionId) => {
      console.log('[NobyHub] Reconnected', connectionId);
      this.events.onReconnected?.(connectionId);
    });
  }

  /**
   * Registers client-side methods that the server can invoke
   */
  private registerClientMethods(): void {
    // Register the ReceiveChatResponse method
    this.connection.on('ReceiveChatResponse', (chatId: string, message: string, isComplete: boolean) => {
      console.log(`[NobyHub] ReceiveChatResponse - ChatId: ${chatId}, IsComplete: ${isComplete}`, message);
      this.events.onChatResponse?.(chatId, message, isComplete);
    });
  }

  /**
   * Starts the SignalR connection
   * @throws Error if connection fails
   */
  public async start(): Promise<void> {
    try {
      await this.connection.start();
      console.log('[NobyHub] Connected successfully', this.connection.connectionId);
      this.events.onConnected?.(this.connection.connectionId);
    } catch (error) {
      console.error('[NobyHub] Connection failed', error);
      throw error;
    }
  }

  /**
   * Stops the SignalR connection
   */
  public async stop(): Promise<void> {
    try {
      await this.connection.stop();
      console.log('[NobyHub] Disconnected');
    } catch (error) {
      console.error('[NobyHub] Error during disconnect', error);
      throw error;
    }
  }

  /**
   * Gets the current connection state
   */
  public get state(): HubConnectionState {
    return this.connection.state;
  }

  /**
   * Gets the connection ID (null if not connected)
   */
  public get connectionId(): string | null {
    return this.connection.connectionId;
  }

  /**
   * Checks if the connection is currently active
   */
  public get isConnected(): boolean {
    return this.connection.state === HubConnectionState.Connected;
  }

  /**
   * Gets the underlying HubConnection instance for advanced scenarios
   */
  public get hubConnection(): HubConnection {
    return this.connection;
  }

  /**
   * Manually invoke a server method (for advanced scenarios)
   * @param methodName - The name of the server method to invoke
   * @param args - Arguments to pass to the method
   */
  public async invoke<T = void>(methodName: string, ...args: any[]): Promise<T> {
    return await this.connection.invoke<T>(methodName, ...args);
  }

  /**
   * Register a custom handler for server-to-client method calls
   * @param methodName - The name of the client method
   * @param handler - The handler function
   */
  public on(methodName: string, handler: (...args: any[]) => void): void {
    this.connection.on(methodName, handler);
  }

  /**
   * Unregister a handler for server-to-client method calls
   * @param methodName - The name of the client method
   */
  public off(methodName: string, handler?: (...args: any[]) => void): void {
    this.connection.off(methodName, handler);
  }
}

// ============================================================================
// Helper Types
// ============================================================================

/**
 * Chat message sent via REST API to trigger SignalR responses
 */
export interface ChatMessageRequest {
  /**
   * The text content of the user's message
   */
  communicationRequestText: string;
}

/**
 * Response from the chat API endpoint
 */
export interface ChatMessageResponse {
  /**
   * The unique identifier for the chat session
   */
  chatId: string;

  /**
   * The title of the chat (only present for new chats)
   */
  chatTitle?: string;
}

/**
 * Connection status type
 */
export type ConnectionStatus = 'Disconnected' | 'Connecting' | 'Connected' | 'Reconnecting' | 'Disconnecting';

/**
 * Maps HubConnectionState to friendly status names
 */
export function getConnectionStatus(state: HubConnectionState): ConnectionStatus {
  switch (state) {
    case HubConnectionState.Disconnected:
      return 'Disconnected';
    case HubConnectionState.Connecting:
      return 'Connecting';
    case HubConnectionState.Connected:
      return 'Connected';
    case HubConnectionState.Reconnecting:
      return 'Reconnecting';
    case HubConnectionState.Disconnecting:
      return 'Disconnecting';
    default:
      return 'Disconnected';
  }
}

// ============================================================================
// Export all types
// ============================================================================

export default NobyHubClient;
