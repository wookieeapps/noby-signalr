/**
 * NobyHub SignalR Contract
 * 
 * This file defines the TypeScript interface for the NobyHub SignalR hub.
 * It includes both the server-side methods (callable from client) and 
 * client-side methods (events received from server).
 */

/**
 * Interface for methods that can be called on the server (Hub methods).
 * These correspond to public methods in the NobyHub class.
 */
export interface INobyHubServer {
    /**
     * Sends a chat response to the calling client.
     * Note: This method is primarily used for testing or internal echoing.
     * In production, chat messages are typically sent via REST API and responses received via SignalR.
     * 
     * @param chatId The chat ID
     * @param message The message content
     * @param isComplete Whether the message is complete
     */
    sendChatResponse(chatId: string, message: string, isComplete?: boolean): Promise<void>;
}

/**
 * Interface for methods that the client handles (Client events).
 * These correspond to methods in the INobyHubClient interface on the server.
 */
export interface INobyHubClient {
    /**
     * Receives a chat response chunk from the chatbot.
     * 
     * @param chatId The chat ID
     * @param message The message content (partial chunk or complete response)
     * @param isComplete True if this is the final/complete message, false for streaming chunks
     */
    receiveChatResponse(chatId: string, message: string, isComplete: boolean): void;
}

/**
 * Combined contract for the NobyHub connection.
 * This can be used to type the SignalR HubConnection.
 */
export interface NobyHubContract {
    server: INobyHubServer;
    client: INobyHubClient;
}

/**
 * SignalR Hub Configuration Constants
 */
export const NobyHubConfig = {
    /**
     * The relative path to the hub endpoint
     */
    hubUrl: '/api/nobyhub',

    /**
     * Event names used in connection.on() and connection.invoke()
     */
    events: {
        ReceiveChatResponse: 'ReceiveChatResponse',
        SendChatResponse: 'SendChatResponse'
    }
};
