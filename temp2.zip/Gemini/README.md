# NobyHub SignalR Documentation

This directory contains the TypeScript contract and documentation for the `NobyHub` SignalR hub used in the NOBY application.

## Overview

`NobyHub` is used for real-time communication between the backend and the frontend (SPA). Its primary use case currently is streaming chatbot responses.

## Connection Details

- **Hub URL**: `/api/nobyhub`
- **Authentication**: Cookie-based authentication.
  - The client **MUST** be authenticated (logged in) before connecting.
  - The connection request **MUST** include credentials (cookies).

## TypeScript Contract

The TypeScript contract is defined in `NobyHub.ts`. It exports interfaces for:
- `INobyHubServer`: Methods you can call on the server.
- `INobyHubClient`: Events you should listen to from the server.

## OpenAPI / Swagger Documentation

The application automatically generates documentation for SignalR hubs. You can access the Swagger UI (usually at `/swagger`) to see the `NobyHub` description and details, which are generated from the backend code.

## Usage Example (using @microsoft/signalr)

```typescript
import * as signalR from "@microsoft/signalr";
import { NobyHubConfig, INobyHubClient } from "./NobyHub";

// 1. Build the connection
const connection = new signalR.HubConnectionBuilder()
    .withUrl(NobyHubConfig.hubUrl, {
        // IMPORTANT: This is required for cookie authentication
        withCredentials: true 
    })
    .withAutomaticReconnect()
    .build();

// 2. Register event handlers (Client Methods)
connection.on(NobyHubConfig.events.ReceiveChatResponse, (chatId: string, message: string, isComplete: boolean) => {
    console.log(`Received message for chat ${chatId}:`, message);
    
    if (isComplete) {
        console.log("Message stream complete.");
    } else {
        console.log("Streaming chunk...");
    }
});

// 3. Start the connection
async function startConnection() {
    try {
        await connection.start();
        console.log("SignalR Connected.");
    } catch (err) {
        console.error("SignalR Connection Error: ", err);
    }
}

startConnection();
```

## Chatbot Implementation Pattern

The Chatbot feature uses a hybrid REST + SignalR pattern:

1.  **Send Message**: The frontend sends the user's message via a standard REST API call (`POST /api/v1/chatbot/chats`).
2.  **Receive Response**: The backend processes the message and streams the response chunks back to the client via the SignalR `ReceiveChatResponse` event.

This means you generally **do not** invoke methods on the Hub directly to send chat messages. You only listen for responses.

## Testing

There are two HTML test pages available in the `wwwroot` folder of the API project which demonstrate the functionality:

1.  **`signalr-test.html`**: A generic test page for the Hub.
    -   Located at: `NOBY.Api/wwwroot/signalr-test.html`
    -   Can be accessed via browser if serving static files is enabled (e.g., `https://localhost:xxxx/signalr-test.html`).

2.  **`chatbot-test.html`**: A specific test page for the Chatbot functionality.
    -   Located at: `NOBY.Api/wwwroot/chatbot-test.html`
    -   Demonstrates the REST + SignalR flow.
    -   **Note**: The JavaScript in this file might use an older signature for `ReceiveChatResponse`. Please refer to the `NobyHub.ts` contract for the authoritative signature.

## Troubleshooting

-   **401 Unauthorized**: Ensure the user is logged in and `withCredentials: true` is set in the SignalR connection options.
-   **No messages received**: Verify you are listening to the correct event name (`ReceiveChatResponse`) and that the `chatId` matches the one you sent in the REST request.
