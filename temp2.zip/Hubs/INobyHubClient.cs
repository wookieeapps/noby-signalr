namespace NOBY.Api.Hubs;

/// <summary>
/// Client interface for NobyHub - defines methods that can be called on connected clients
/// </summary>
public interface INobyHubClient
{
    /// <summary>
    /// Receives a chat response message from the server
    /// </summary>
    /// <param name="message">The chat message content</param>
    /// <param name="cancellationToken">Cancellation token</param>
    Task ReceiveChatResponse(string message, CancellationToken cancellationToken = default);
}
