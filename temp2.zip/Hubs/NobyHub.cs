using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace NOBY.Api.Hubs;

/// <summary>
/// SignalR hub for real-time communication with NOBY frontend clients
/// </summary>
[Authorize]
public sealed class NobyHub : Hub<INobyHubClient>
{
    private readonly ILogger<NobyHub> _logger;

    public NobyHub(ILogger<NobyHub> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Sends a chat response to the calling client
    /// </summary>
    /// <param name="message">The message to send</param>
    /// <param name="cancellationToken">Cancellation token</param>
    public async Task SendChatResponse(string message, CancellationToken cancellationToken = default)
    {
        _logger.LogDebug("Sending chat response to connection {ConnectionId}", Context.ConnectionId);
        
        await Clients.Caller.ReceiveChatResponse(message, cancellationToken);
    }

    public override async Task OnConnectedAsync()
    {
        _logger.LogInformation("Client connected to NobyHub. ConnectionId: {ConnectionId}, User: {User}", 
            Context.ConnectionId, 
            Context.User?.Identity?.Name ?? "Unknown");
        
        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        _logger.LogInformation("Client disconnected from NobyHub. ConnectionId: {ConnectionId}, Exception: {Exception}", 
            Context.ConnectionId, 
            exception?.Message);
        
        await base.OnDisconnectedAsync(exception);
    }
}
