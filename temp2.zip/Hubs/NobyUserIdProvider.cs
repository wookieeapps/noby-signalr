using CIS.Core.Security;
using Microsoft.AspNetCore.SignalR;
using System.Security.Claims;

namespace NOBY.Api.Hubs;

/// <summary>
/// Custom user ID provider for SignalR that uses the user ID from claims
/// </summary>
internal sealed class NobyUserIdProvider : IUserIdProvider
{
    public string? GetUserId(HubConnectionContext connection)
    {
        // Get user ID from CIS.Core.Security.SecurityConstants.ClaimTypeId claim
        var userIdClaim = connection.User?.FindFirst(SecurityConstants.ClaimTypeId);
        return userIdClaim?.Value;
    }
}
