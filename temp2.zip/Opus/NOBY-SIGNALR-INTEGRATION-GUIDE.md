# NobyHub SignalR Integration Guide for Vue.js

This document provides comprehensive guidance for integrating the NobyHub SignalR hub into a Vue.js SPA application.

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Installation](#installation)
4. [Authentication](#authentication)
5. [Basic Implementation](#basic-implementation)
6. [Vue Composable Implementation](#vue-composable-implementation)
7. [Chatbot Integration Example](#chatbot-integration-example)
8. [Error Handling](#error-handling)
9. [Connection State Management](#connection-state-management)
10. [Testing](#testing)
11. [API Reference](#api-reference)
12. [Troubleshooting](#troubleshooting)

---

## Overview

NobyHub is a SignalR hub that provides real-time communication capabilities for the NOBY application. The primary use case is **streaming chatbot responses** to connected clients.

### Architecture Flow

```
???????????????????     POST /api/v1/chatbot/chats     ???????????????????
?   Vue.js SPA    ? ????????????????????????????????????   NOBY API      ?
?                 ?                                     ?                 ?
?  (Send message  ?     SignalR: ReceiveChatResponse   ?  (Process chat) ?
?   via REST API) ? ????????????????????????????????????                 ?
???????????????????                                     ???????????????????
```

**Key Points:**
- Messages are sent to the chatbot via **REST API** (`POST /api/v1/chatbot/chats`)
- Responses are streamed back via **SignalR** (`receiveChatResponse` event)
- Authentication uses **cookies** (not JWT tokens)

---

## Prerequisites

- Node.js 18+ and npm/yarn/pnpm
- Vue.js 3.x with Composition API
- Microsoft SignalR JavaScript client library
- TypeScript (recommended)

---

## Installation

Install the SignalR client library:

```bash
# npm
npm install @microsoft/signalr

# yarn
yarn add @microsoft/signalr

# pnpm
pnpm add @microsoft/signalr
```

Copy the TypeScript contracts file (`noby-signalr-hub.ts`) to your project's types directory.

---

## Authentication

### Cookie-Based Authentication

NobyHub uses **cookie-based authentication**. This means:

1. The user must be authenticated via the normal login flow before connecting to the hub
2. The authentication cookie is automatically sent with SignalR connection requests
3. **No additional token configuration is needed** in the SignalR connection

### Important Configuration

When creating the SignalR connection, you must enable credentials to include cookies:

```typescript
const connection = new HubConnectionBuilder()
  .withUrl('/api/nobyhub', {
    withCredentials: true  // ? Required for cookie authentication
  })
  .build();
```

### Authentication Errors

If the user is not authenticated, the connection will fail with a `401 Unauthorized` error. Handle this gracefully:

```typescript
try {
  await connection.start();
} catch (error) {
  if (error.message?.includes('401')) {
    // Redirect to login page
    router.push('/login');
  }
}
```

---

## Basic Implementation

### Simple Connection Example

```typescript
import * as signalR from '@microsoft/signalr';
import { NOBY_HUB_URL, ClientMethods } from '@/types/noby-signalr-hub';

// Create connection
const connection = new signalR.HubConnectionBuilder()
  .withUrl(NOBY_HUB_URL, {
    withCredentials: true
  })
  .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
  .configureLogging(signalR.LogLevel.Warning)
  .build();

// Register event handler
connection.on(ClientMethods.ReceiveChatResponse, (chatId, message, isComplete) => {
  console.log(`Chat ${chatId}: ${message} (complete: ${isComplete})`);
});

// Start connection
await connection.start();
console.log('Connected with ID:', connection.connectionId);

// Later: stop connection
await connection.stop();
```

---

## Vue Composable Implementation

Create a reusable composable for SignalR connection management:

### `useNobyHub.ts`

```typescript
import { ref, readonly, onUnmounted, shallowRef } from 'vue';
import * as signalR from '@microsoft/signalr';
import type { HubConnection } from '@microsoft/signalr';
import {
  NOBY_HUB_URL,
  DEFAULT_HUB_OPTIONS,
  ClientMethods,
  HubConnectionState,
  type NobyHubOptions,
  type ReceiveChatResponsePayload
} from '@/types/noby-signalr-hub';

export interface UseNobyHubReturn {
  /** Current connection state */
  connectionState: Readonly<Ref<HubConnectionState>>;
  /** Current connection ID (null if disconnected) */
  connectionId: Readonly<Ref<string | null>>;
  /** Whether the hub is currently connected */
  isConnected: Readonly<ComputedRef<boolean>>;
  /** Connect to the hub */
  connect: () => Promise<void>;
  /** Disconnect from the hub */
  disconnect: () => Promise<void>;
  /** Register a handler for chat responses */
  onChatResponse: (handler: (payload: ReceiveChatResponsePayload) => void) => void;
  /** Remove a chat response handler */
  offChatResponse: (handler: (payload: ReceiveChatResponsePayload) => void) => void;
}

export function useNobyHub(options: NobyHubOptions = {}): UseNobyHubReturn {
  const mergedOptions = { ...DEFAULT_HUB_OPTIONS, ...options };
  
  const connection = shallowRef<HubConnection | null>(null);
  const connectionState = ref<HubConnectionState>(HubConnectionState.Disconnected);
  const connectionId = ref<string | null>(null);
  
  const chatResponseHandlers = new Set<(payload: ReceiveChatResponsePayload) => void>();

  const isConnected = computed(() => connectionState.value === HubConnectionState.Connected);

  function createConnection(): HubConnection {
    const newConnection = new signalR.HubConnectionBuilder()
      .withUrl(mergedOptions.url, {
        withCredentials: true,
        transport: signalR.HttpTransportType.WebSockets |
                   signalR.HttpTransportType.ServerSentEvents |
                   signalR.HttpTransportType.LongPolling
      })
      .withAutomaticReconnect(mergedOptions.reconnectDelays)
      .configureLogging(signalR.LogLevel[mergedOptions.logLevel])
      .build();

    // Set up event handlers
    newConnection.on(ClientMethods.ReceiveChatResponse, handleChatResponse);

    newConnection.onclose((error) => {
      connectionState.value = HubConnectionState.Disconnected;
      connectionId.value = null;
      console.log('SignalR disconnected', error);
    });

    newConnection.onreconnecting((error) => {
      connectionState.value = HubConnectionState.Reconnecting;
      console.log('SignalR reconnecting', error);
    });

    newConnection.onreconnected((newConnectionId) => {
      connectionState.value = HubConnectionState.Connected;
      connectionId.value = newConnectionId ?? null;
      console.log('SignalR reconnected', newConnectionId);
    });

    return newConnection;
  }

  function handleChatResponse(chatId: string, message: string, isComplete: boolean): void {
    const payload: ReceiveChatResponsePayload = { chatId, message, isComplete };
    chatResponseHandlers.forEach(handler => handler(payload));
  }

  async function connect(): Promise<void> {
    if (connection.value?.state === signalR.HubConnectionState.Connected) {
      return; // Already connected
    }

    connectionState.value = HubConnectionState.Connecting;

    try {
      if (!connection.value) {
        connection.value = createConnection();
      }

      await connection.value.start();
      connectionState.value = HubConnectionState.Connected;
      connectionId.value = connection.value.connectionId ?? null;
      console.log('SignalR connected', connectionId.value);
    } catch (error) {
      connectionState.value = HubConnectionState.Disconnected;
      connectionId.value = null;
      throw error;
    }
  }

  async function disconnect(): Promise<void> {
    if (connection.value) {
      await connection.value.stop();
      connection.value = null;
    }
    connectionState.value = HubConnectionState.Disconnected;
    connectionId.value = null;
  }

  function onChatResponse(handler: (payload: ReceiveChatResponsePayload) => void): void {
    chatResponseHandlers.add(handler);
  }

  function offChatResponse(handler: (payload: ReceiveChatResponsePayload) => void): void {
    chatResponseHandlers.delete(handler);
  }

  // Cleanup on unmount
  onUnmounted(async () => {
    chatResponseHandlers.clear();
    await disconnect();
  });

  return {
    connectionState: readonly(connectionState),
    connectionId: readonly(connectionId),
    isConnected: readonly(isConnected),
    connect,
    disconnect,
    onChatResponse,
    offChatResponse
  };
}
```

---

## Chatbot Integration Example

### Complete Chatbot Component

```vue
<script setup lang="ts">
import { ref, onMounted, onUnmounted, computed } from 'vue';
import { useNobyHub } from '@/composables/useNobyHub';
import type {
  ChatbotCreateMessageRequest,
  ChatbotCreateMessageResponse,
  ReceiveChatResponsePayload
} from '@/types/noby-signalr-hub';

// State
const messages = ref<Array<{
  id: string;
  content: string;
  role: 'user' | 'assistant';
  isStreaming?: boolean;
}>>([]);
const currentChatId = ref<string | null>(null);
const inputMessage = ref('');
const isLoading = ref(false);
const streamingContent = ref('');

// SignalR Hub
const { connectionState, isConnected, connect, onChatResponse, offChatResponse } = useNobyHub();

// Chat response handler
function handleChatResponse(payload: ReceiveChatResponsePayload): void {
  // Ignore messages for different chats
  if (payload.chatId !== currentChatId.value) return;

  if (payload.isComplete) {
    // Final message - replace streaming content with complete message
    const lastMessage = messages.value[messages.value.length - 1];
    if (lastMessage?.role === 'assistant') {
      lastMessage.content = payload.message;
      lastMessage.isStreaming = false;
    }
    streamingContent.value = '';
  } else {
    // Streaming chunk - accumulate content
    streamingContent.value += payload.message;
    const lastMessage = messages.value[messages.value.length - 1];
    if (lastMessage?.role === 'assistant') {
      lastMessage.content = streamingContent.value;
    }
  }
}

// Send message to chatbot
async function sendMessage(): Promise<void> {
  const text = inputMessage.value.trim();
  if (!text || isLoading.value) return;

  inputMessage.value = '';
  isLoading.value = true;

  // Add user message
  messages.value.push({
    id: crypto.randomUUID(),
    content: text,
    role: 'user'
  });

  // Prepare assistant message placeholder
  messages.value.push({
    id: crypto.randomUUID(),
    content: '',
    role: 'assistant',
    isStreaming: true
  });

  streamingContent.value = '';

  try {
    // Build API URL
    const url = currentChatId.value
      ? `/api/v1/chatbot/chats?chatId=${encodeURIComponent(currentChatId.value)}`
      : '/api/v1/chatbot/chats';

    // Send message via REST API
    const response = await fetch(url, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        communicationRequestText: text
      } satisfies ChatbotCreateMessageRequest)
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data: ChatbotCreateMessageResponse = await response.json();
    currentChatId.value = data.chatId;
    
    // Response will arrive via SignalR
  } catch (error) {
    console.error('Failed to send message:', error);
    // Remove the pending assistant message
    messages.value.pop();
  } finally {
    isLoading.value = false;
  }
}

// Lifecycle
onMounted(async () => {
  onChatResponse(handleChatResponse);
  
  try {
    await connect();
  } catch (error) {
    console.error('Failed to connect to SignalR:', error);
  }
});

onUnmounted(() => {
  offChatResponse(handleChatResponse);
});
</script>

<template>
  <div class="chatbot">
    <!-- Connection Status -->
    <div class="status" :class="connectionState.toLowerCase()">
      {{ connectionState }}
    </div>

    <!-- Messages -->
    <div class="messages">
      <div
        v-for="msg in messages"
        :key="msg.id"
        class="message"
        :class="[msg.role, { streaming: msg.isStreaming }]"
      >
        <div class="content">{{ msg.content }}</div>
        <div v-if="msg.isStreaming" class="typing-indicator">???</div>
      </div>
    </div>

    <!-- Input -->
    <div class="input-area">
      <input
        v-model="inputMessage"
        placeholder="Type your message..."
        :disabled="!isConnected || isLoading"
        @keypress.enter="sendMessage"
      />
      <button
        :disabled="!isConnected || isLoading || !inputMessage.trim()"
        @click="sendMessage"
      >
        Send
      </button>
    </div>
  </div>
</template>
```

---

## Error Handling

### Common Errors and Solutions

| Error | Cause | Solution |
|-------|-------|----------|
| `401 Unauthorized` | User not authenticated | Redirect to login, then reconnect |
| `Connection refused` | Server not available | Implement retry logic with backoff |
| `Connection timeout` | Network issues | Check network, use automatic reconnect |
| `WebSocket error` | Transport fallback | SignalR auto-falls back to SSE/Long Polling |

### Error Handling Pattern

```typescript
async function connectWithRetry(maxRetries = 3): Promise<void> {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      await connect();
      return;
    } catch (error) {
      if (error.message?.includes('401')) {
        // Authentication error - don't retry
        throw new AuthenticationError('Please log in to continue');
      }
      
      if (attempt === maxRetries) {
        throw error;
      }
      
      // Wait before retry (exponential backoff)
      await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, attempt)));
    }
  }
}
```

---

## Connection State Management

### Using Pinia Store

```typescript
// stores/signalr.ts
import { defineStore } from 'pinia';
import { useNobyHub } from '@/composables/useNobyHub';

export const useSignalRStore = defineStore('signalr', () => {
  const hub = useNobyHub();
  
  // Expose hub state and methods
  return {
    connectionState: hub.connectionState,
    isConnected: hub.isConnected,
    connect: hub.connect,
    disconnect: hub.disconnect,
    onChatResponse: hub.onChatResponse,
    offChatResponse: hub.offChatResponse
  };
});
```

### Automatic Reconnection on App Focus

```typescript
// App.vue
import { onMounted, onUnmounted } from 'vue';
import { useSignalRStore } from '@/stores/signalr';

const signalR = useSignalRStore();

function handleVisibilityChange(): void {
  if (document.visibilityState === 'visible' && !signalR.isConnected) {
    signalR.connect().catch(console.error);
  }
}

onMounted(() => {
  document.addEventListener('visibilitychange', handleVisibilityChange);
});

onUnmounted(() => {
  document.removeEventListener('visibilitychange', handleVisibilityChange);
});
```

---

## Testing

### Test HTML Pages

The API provides two test HTML pages for SignalR testing:

1. **General SignalR Test**: `/signalr-test.html`
   - Basic connection testing
   - Send test messages to specific users

2. **Chatbot-Specific Test**: `/chatbot-test.html`
   - Complete chatbot flow testing
   - Send messages and receive streaming responses

Access these pages in your browser while logged in to test SignalR functionality.

### Mock SignalR for Unit Tests

```typescript
// __mocks__/signalr.ts
export const mockConnection = {
  start: vi.fn().mockResolvedValue(undefined),
  stop: vi.fn().mockResolvedValue(undefined),
  on: vi.fn(),
  off: vi.fn(),
  connectionId: 'mock-connection-id',
  state: 'Connected'
};

export const HubConnectionBuilder = vi.fn().mockImplementation(() => ({
  withUrl: vi.fn().mockReturnThis(),
  withAutomaticReconnect: vi.fn().mockReturnThis(),
  configureLogging: vi.fn().mockReturnThis(),
  build: vi.fn().mockReturnValue(mockConnection)
}));
```

---

## API Reference

### REST API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/chatbot/chats` | GET | List user's chats |
| `/api/v1/chatbot/chats` | POST | Create/send message (query param: `chatId` for existing chat) |
| `/api/v1/chatbot/chats/{chatId}` | GET | Get chat details with messages |
| `/api/v1/chatbot/chats/{chatId}` | PUT | Update chat (title, favorite) |
| `/api/v1/chatbot/chats/{chatId}` | DELETE | Delete chat |
| `/api/v1/chatbot/chats/{chatId}/messages/{messageId}` | PUT | Rate a message |

### SignalR Documentation Endpoint

Get auto-generated SignalR hub documentation:

```
GET /api/v1/signalrdocs
```

This endpoint returns JSON documentation for all SignalR hubs, including:
- Hub names and endpoints
- Server methods (callable by clients)
- Client methods (events from server)
- Parameter types and descriptions

---

## Troubleshooting

### "Connection failed with 401"
- **Cause**: User session expired or not logged in
- **Solution**: Ensure user is authenticated before connecting. Redirect to login if needed.

### "Connection keeps reconnecting"
- **Cause**: Server restarts or network instability
- **Solution**: This is normal behavior. The automatic reconnect feature handles this.

### "Messages not received"
- **Cause**: Handler not registered or wrong chatId
- **Solution**: 
  1. Verify `onChatResponse` handler is registered before sending messages
  2. Check that `chatId` matches between API response and SignalR messages

### "WebSocket connection failed, falling back"
- **Cause**: WebSocket blocked by proxy/firewall
- **Solution**: This is handled automatically by SignalR fallback. Check console for actual transport used.

### Debugging Tips

1. Enable verbose logging:
   ```typescript
   .configureLogging(signalR.LogLevel.Debug)
   ```

2. Check browser DevTools:
   - Network tab ? WS filter for WebSocket frames
   - Console for SignalR logs

3. Use the test HTML pages to verify server-side functionality

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2025 | Initial release |
