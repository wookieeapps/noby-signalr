# NobyHub SignalR Quick Reference

## Connection

```typescript
import * as signalR from '@microsoft/signalr';

const connection = new signalR.HubConnectionBuilder()
  .withUrl('/api/nobyhub', { withCredentials: true })  // Cookie auth
  .withAutomaticReconnect()
  .build();

await connection.start();
```

## Events (Server ? Client)

| Event | Parameters | Description |
|-------|------------|-------------|
| `receiveChatResponse` | `chatId: string, message: string, isComplete: boolean` | Streaming chatbot response |

### Subscribe to Events

```typescript
connection.on('receiveChatResponse', (chatId, message, isComplete) => {
  if (isComplete) {
    // Final complete message
  } else {
    // Streaming chunk - accumulate
  }
});
```

## REST API (Client ? Server)

### Send Chat Message

```http
POST /api/v1/chatbot/chats?chatId={existingChatId}
Content-Type: application/json

{
  "communicationRequestText": "Your message here"
}
```

**Response:**
```json
{
  "chatId": "abc-123",
  "chatTitle": "Chat Title"
}
```

> ?? Omit `chatId` query param to create a new chat

### Other Endpoints

| Action | Endpoint |
|--------|----------|
| List chats | `GET /api/v1/chatbot/chats` |
| Get chat detail | `GET /api/v1/chatbot/chats/{chatId}` |
| Update chat | `PUT /api/v1/chatbot/chats/{chatId}` |
| Delete chat | `DELETE /api/v1/chatbot/chats/{chatId}` |
| Rate message | `PUT /api/v1/chatbot/chats/{chatId}/messages/{messageId}` |

## Flow Diagram

```
User types message
       ?
       ?
POST /api/v1/chatbot/chats ????? Returns chatId
       ?
       ?
SignalR receives 'receiveChatResponse' events
       ?
       ??? isComplete: false ? Streaming chunk (accumulate)
       ?
       ??? isComplete: true  ? Final message (display)
```

## Key Points

? **Authentication**: Cookie-based (user must be logged in)  
? **Send messages**: Via REST API  
? **Receive responses**: Via SignalR events  
? **Reconnection**: Automatic with configurable delays  
? **Test pages**: `/signalr-test.html` and `/chatbot-test.html`  
? **API Docs**: `GET /api/v1/signalrdocs`  

## Common Patterns

### Vue Composable Usage

```typescript
const { isConnected, connect, onChatResponse } = useNobyHub();

onMounted(async () => {
  onChatResponse((payload) => {
    // Handle: payload.chatId, payload.message, payload.isComplete
  });
  await connect();
});
```

### Error Handling

```typescript
try {
  await connect();
} catch (error) {
  if (error.message?.includes('401')) {
    // User not authenticated - redirect to login
  }
}
```
