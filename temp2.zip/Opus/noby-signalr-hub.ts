/**
 * NobyHub SignalR TypeScript Contracts
 * 
 * This file contains TypeScript type definitions and contracts for the NobyHub SignalR hub.
 * Use these types in your Vue.js application to ensure type-safe communication with the hub.
 * 
 * @module NobyHubContracts
 * @version 1.0.0
 */

// ============================================================================
// HUB CONFIGURATION
// ============================================================================

/**
 * SignalR Hub endpoint URL
 */
export const NOBY_HUB_URL = '/api/nobyhub';

/**
 * SignalR Hub configuration options
 */
export interface NobyHubOptions {
  /**
   * The hub URL (default: '/api/nobyhub')
   */
  url?: string;
  
  /**
   * Whether to automatically reconnect on connection loss
   */
  autoReconnect?: boolean;
  
  /**
   * Reconnection retry intervals in milliseconds
   */
  reconnectDelays?: number[];
  
  /**
   * Log level for SignalR (default: 'Warning')
   */
  logLevel?: 'Trace' | 'Debug' | 'Information' | 'Warning' | 'Error' | 'Critical' | 'None';
}

/**
 * Default hub options
 */
export const DEFAULT_HUB_OPTIONS: Required<NobyHubOptions> = {
  url: NOBY_HUB_URL,
  autoReconnect: true,
  reconnectDelays: [0, 2000, 5000, 10000, 30000],
  logLevel: 'Warning'
};

// ============================================================================
// CLIENT METHODS (Events received from server)
// ============================================================================

/**
 * Client method names that can be invoked by the server.
 * Subscribe to these events to receive messages from the hub.
 */
export const ClientMethods = {
  /**
   * Receives chat response chunks or complete messages from the chatbot.
   * This is called by the server to deliver streaming responses.
   */
  ReceiveChatResponse: 'receiveChatResponse'
} as const;

/**
 * Union type of all client method names
 */
export type ClientMethodName = typeof ClientMethods[keyof typeof ClientMethods];

/**
 * Payload for the ReceiveChatResponse client method
 */
export interface ReceiveChatResponsePayload {
  /**
   * The unique identifier of the chat session
   */
  chatId: string;
  
  /**
   * The message content - can be a partial chunk during streaming or the complete response
   */
  message: string;
  
  /**
   * Indicates whether this is the final/complete message.
   * - `false`: This is a streaming chunk, more content will follow
   * - `true`: This is the final complete message, no more chunks expected
   */
  isComplete: boolean;
}

/**
 * Type-safe client method handlers interface.
 * Implement this interface to handle all hub events.
 */
export interface INobyHubClientHandlers {
  /**
   * Handler for receiving chat responses from the chatbot
   * 
   * @param chatId - The chat session identifier
   * @param message - The message content (chunk or complete)
   * @param isComplete - Whether this is the final message
   */
  onReceiveChatResponse(chatId: string, message: string, isComplete: boolean): void;
}

// ============================================================================
// SERVER METHODS (Methods that can be called on the server)
// ============================================================================

/**
 * Server method names that can be invoked by the client.
 * 
 * Note: Currently, NobyHub does not expose any server-callable methods for clients.
 * All chat message sending is done via REST API endpoints, and responses
 * are pushed to clients via the ReceiveChatResponse event.
 */
export const ServerMethods = {
  // No server methods currently available for client invocation
  // Chat messages are sent via REST API: POST /api/v1/chatbot/chats
} as const;

// ============================================================================
// CONNECTION STATE
// ============================================================================

/**
 * SignalR connection states
 */
export enum HubConnectionState {
  /** The hub connection is disconnected */
  Disconnected = 'Disconnected',
  /** The hub connection is connecting */
  Connecting = 'Connecting',
  /** The hub connection is connected */
  Connected = 'Connected',
  /** The hub connection is reconnecting */
  Reconnecting = 'Reconnecting'
}

/**
 * Connection event types
 */
export interface NobyHubConnectionEvents {
  /** Fired when connection is established */
  onConnected: (connectionId: string) => void;
  /** Fired when connection is closed */
  onDisconnected: (error?: Error) => void;
  /** Fired when reconnection starts */
  onReconnecting: (error?: Error) => void;
  /** Fired when reconnection succeeds */
  onReconnected: (connectionId: string) => void;
}

// ============================================================================
// CHATBOT API TYPES (Related REST API contracts)
// ============================================================================

/**
 * Request payload for creating a new chat message
 * Used with: POST /api/v1/chatbot/chats
 */
export interface ChatbotCreateMessageRequest {
  /**
   * The user's message/question to send to the chatbot
   */
  communicationRequestText: string;
}

/**
 * Response from creating a new chat message
 * Returned from: POST /api/v1/chatbot/chats
 */
export interface ChatbotCreateMessageResponse {
  /**
   * The chat session identifier (use this to continue the conversation)
   */
  chatId: string;
  
  /**
   * The title of the chat (may be auto-generated from the first message)
   */
  chatTitle?: string;
}

/**
 * Chat list item in the chat list response
 */
export interface ChatListItem {
  /**
   * Unique chat identifier
   */
  chatId: string;
  
  /**
   * Chat title
   */
  title: string;
  
  /**
   * Whether this chat is marked as favorite
   */
  isFavorite: boolean;
  
  /**
   * Last modification date
   */
  modifiedAt: string;
}

/**
 * Response from getting the chat list
 * Returned from: GET /api/v1/chatbot/chats
 */
export interface ChatbotGetChatListResponse {
  /**
   * List of user's chats
   */
  chats: ChatListItem[];
}

/**
 * Message in a chat conversation
 */
export interface ChatMessage {
  /**
   * Unique message identifier
   */
  messageId: string;
  
  /**
   * The message content
   */
  content: string;
  
  /**
   * Message role - 'user' for user messages, 'assistant' for chatbot responses
   */
  role: 'user' | 'assistant';
  
  /**
   * Timestamp when the message was created
   */
  createdAt: string;
  
  /**
   * User rating (1-5 stars), if rated
   */
  rating?: number;
  
  /**
   * User's comment on the rating
   */
  ratingComment?: string;
}

/**
 * Response from getting chat details
 * Returned from: GET /api/v1/chatbot/chats/{chatId}
 */
export interface ChatbotGetChatDetailResponse {
  /**
   * Chat identifier
   */
  chatId: string;
  
  /**
   * Chat title
   */
  title: string;
  
  /**
   * Whether this chat is marked as favorite
   */
  isFavorite: boolean;
  
  /**
   * List of messages in the conversation
   */
  messages: ChatMessage[];
}

/**
 * Request to update a chat
 * Used with: PUT /api/v1/chatbot/chats/{chatId}
 */
export interface ChatbotUpdateChatRequest {
  /**
   * New title for the chat (optional)
   */
  title?: string;
  
  /**
   * Whether to mark this chat as favorite (optional)
   */
  isFavorite?: boolean;
}

/**
 * Request to rate a message response
 * Used with: PUT /api/v1/chatbot/chats/{chatId}/messages/{messageId}
 */
export interface ChatbotUpdateResponseRatingRequest {
  /**
   * Rating value (1-5 stars)
   */
  rating: number;
  
  /**
   * Optional comment explaining the rating
   */
  comment?: string;
}
