using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace NOBY.Api.Endpoints.SignalR;

/// <summary>
/// SignalR Hub documentation endpoint
/// </summary>
[ApiController]
[Route("api/v1/signalr-docs")]
public class SignalRDocumentationController : ControllerBase
{
    /// <summary>
    /// Get SignalR hub documentation
    /// </summary>
    /// <returns>Hub documentation including available hubs, endpoints, and methods</returns>
    /// <remarks>
    /// This endpoint provides documentation for all SignalR hubs.
    /// When you add new methods to hubs, update this endpoint manually or implement automatic reflection-based generation.
    /// </remarks>
    [HttpGet]
    [SwaggerOperation(
        Summary = "Get SignalR documentation",
        Description = "Returns documentation for all available SignalR hubs including connection endpoints, server methods, and client methods"
    )]
    [ProducesResponseType(typeof(SignalRDocumentation), StatusCodes.Status200OK)]
    public IActionResult GetDocumentation()
    {
        // TODO: For automatic documentation, implement a reflection-based service
        // See NOBY.Api/wwwroot/docs/SIGNALR-UPDATE-GUIDE.md for implementation details
        
        var documentation = new SignalRDocumentation
        {
            Hubs =
            [
                new HubDocumentation
                {
                    Name = "NobyHub",
                    Description = "SignalR hub for real-time communication with NOBY frontend clients",
                    Endpoint = "/api/nobyhub",
                    RequiresAuthentication = true,
                    ServerMethods =
                    [
                        new MethodDocumentation
                        {
                            Name = "SendChatResponse",
                            Description = "Sends a chat response to the calling client",
                            Parameters =
                            [
                                new ParameterDocumentation
                                {
                                    Name = "message",
                                    Type = "string",
                                    Description = "The message to send",
                                    Required = true
                                }
                            ],
                            ReturnType = "Promise<void>"
                        }
                    ],
                    ClientMethods =
                    [
                        new MethodDocumentation
                        {
                            Name = "ReceiveChatResponse",
                            Description = "Receives a chat response message from the server. Client must implement this method.",
                            Parameters =
                            [
                                new ParameterDocumentation
                                {
                                    Name = "message",
                                    Type = "string",
                                    Description = "The chat message content",
                                    Required = true
                                }
                            ],
                            ReturnType = "Promise<void>"
                        }
                    ]
                }
            ]
        };

        return Ok(documentation);
    }
}

/// <summary>
/// SignalR documentation model
/// </summary>
public class SignalRDocumentation
{
    /// <summary>
    /// List of available SignalR hubs
    /// </summary>
    public required List<HubDocumentation> Hubs { get; set; }
}

/// <summary>
/// Hub documentation
/// </summary>
public class HubDocumentation
{
    /// <summary>
    /// Hub name
    /// </summary>
    public required string Name { get; set; }

    /// <summary>
    /// Hub description
    /// </summary>
    public required string Description { get; set; }

    /// <summary>
    /// Hub connection endpoint
    /// </summary>
    public required string Endpoint { get; set; }

    /// <summary>
    /// Whether authentication is required
    /// </summary>
    public required bool RequiresAuthentication { get; set; }

    /// <summary>
    /// Methods that can be called by clients (client ? server)
    /// </summary>
    public required List<MethodDocumentation> ServerMethods { get; set; }

    /// <summary>
    /// Methods that clients must implement to receive messages (server ? client)
    /// </summary>
    public required List<MethodDocumentation> ClientMethods { get; set; }
}

/// <summary>
/// Method documentation
/// </summary>
public class MethodDocumentation
{
    /// <summary>
    /// Method name
    /// </summary>
    public required string Name { get; set; }

    /// <summary>
    /// Method description
    /// </summary>
    public required string Description { get; set; }

    /// <summary>
    /// Method parameters
    /// </summary>
    public required List<ParameterDocumentation> Parameters { get; set; }

    /// <summary>
    /// Return type
    /// </summary>
    public required string ReturnType { get; set; }
}

/// <summary>
/// Parameter documentation
/// </summary>
public class ParameterDocumentation
{
    /// <summary>
    /// Parameter name
    /// </summary>
    public required string Name { get; set; }

    /// <summary>
    /// Parameter type
    /// </summary>
    public required string Type { get; set; }

    /// <summary>
    /// Parameter description
    /// </summary>
    public required string Description { get; set; }

    /// <summary>
    /// Whether the parameter is required
    /// </summary>
    public required bool Required { get; set; }
}
