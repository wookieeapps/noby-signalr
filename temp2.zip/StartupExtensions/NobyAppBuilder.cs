﻿using CIS.Infrastructure.WebApi;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.StaticFiles;
using NOBY.Infrastructure.Configuration;
using NOBY.Infrastructure.Security.Endpoints;
using NOBY.Infrastructure.Security.Middleware;
using NOBY.Infrastructure.Swagger;
using NOBY.Api.Hubs;

namespace NOBY.Api.StartupExtensions;

internal static class NobyAppBuilder
{
    public static IApplicationBuilder UseNobySpa(this IApplicationBuilder app)
        => app.MapWhen(_isSpaCall, appBuilder =>
        {
            appBuilder.UseSpaStaticFiles();

            app.UseStaticFiles("/docs");

            appBuilder.UseStaticFiles(new StaticFileOptions
            {
                ContentTypeProvider = new FileExtensionContentTypeProvider
                {
                    Mappings =
                    {
                        [".avif"] = "image/avif",
                        [".webp"] = "image/webp"
                    }
                }
            });

            appBuilder.UseSpa(spa =>
            {
                spa.Options.SourcePath = "wwwroot";
                spa.Options.DefaultPageStaticFileOptions = new StaticFileOptions
                {
                    OnPrepareResponse = ctx =>
                    {
                        if (ctx.File.Name == "index.html" || ctx.File.Name == "simple-login.html")
                        {
                            var headers = ctx.Context.Response.GetTypedHeaders();
                            headers.CacheControl = new Microsoft.Net.Http.Headers.CacheControlHeaderValue
                            {
                                NoCache = true,
                                NoStore = true,
                                MustRevalidate = true,
                                MaxAge = TimeSpan.Zero
                            };
                        }
                    }
                };
            });
        });

    public static IApplicationBuilder UseNobyHealthChecks(this IApplicationBuilder app)
        => app.MapWhen(_isHealthCheck, appBuilder =>
        {
            appBuilder.UseRouting();
            appBuilder.UseEndpoints(endpoints =>
            {
                endpoints.MapCisHealthChecks();
            });
        });

    public static IApplicationBuilder UseNobyApi(this WebApplication app, AppConfiguration appConfiguration)
        => app.MapWhen(_isApiCall, appBuilder =>
        {
            appBuilder.UseHttpLogging();
            appBuilder.UseMiddleware<CIS.Infrastructure.WebApi.Middleware.TraceIdResponseHeaderMiddleware>();
            appBuilder.UseCisSecurityHeaders();

            // detailed error page
            if (appConfiguration.UseDeveloperExceptionPage)
            {
                appBuilder.UseDeveloperExceptionPage();
            }
            else // custom exception handling
            {
                appBuilder.UseMiddleware<Infrastructure.ErrorHandling.Internals.NobyApiExceptionMiddleware>();
            }

            // namapovani API modulu - !poradi je dulezite
            appBuilder
                // autentizace
                .UseAuthentication()
                // routing
                .UseRouting();

            if (appConfiguration.LogRequestContractDifferences)
            {
                appBuilder.UseMiddleware<CIS.Infrastructure.WebApi.Middleware.RequestBufferingMiddleware>();
            }

            // autorizace
            appBuilder
                .UseMiddleware<NobySecurityMiddleware>()
                .UseAuthorization()
                .UseMiddleware<CaseOwnerValidationMiddleware>()
                // endpointy
                .UseEndpoints(t =>
                {
                    t.MapControllers();
                    // Map SignalR hub
                    t.MapHub<NobyHub>("/api/nobyhub");
                });
        });

    /// <summary>
    /// routy pro autentizaci a signout uzivatele
    /// </summary>
    public static IApplicationBuilder UseNobyAuthStrategy(this IApplicationBuilder app)
        => app
        .UseWhen(_isAuthCall, (appBuilder) =>
        {
            appBuilder.UseRouting();

            appBuilder.UseAuthentication();
            appBuilder.UseAuthorization();
            appBuilder.MapNobyAuthenticationEndpoints();
        });

    public static IApplicationBuilder UseNobySwagger(this IApplicationBuilder app)
        => app
        .UseSwagger()
        .UseSwaggerUI(c =>
        {
            c.SwaggerEndpoint($"/swagger/{Constants.OpenApiDocName}/swagger.json", "API all versions");
            c.DisplayOperationId();
        });

    private static readonly Func<HttpContext, bool> _isApiCall = (HttpContext context)
        => context.Request.Path.StartsWithSegments("/api", StringComparison.InvariantCulture);

    private static readonly Func<HttpContext, bool> _isAuthCall = (HttpContext context)
        => context.Request.Path.StartsWithSegments(AuthenticationConstants.DefaultAuthenticationUrlSegment, StringComparison.InvariantCulture);

    private static readonly Func<HttpContext, bool> _isHealthCheck = (HttpContext context)
        => context.Request.Path.StartsWithSegments(CIS.Core.CisGlobalConstants.CisHealthCheckEndpointUrl, StringComparison.InvariantCulture);

    private static readonly Func<HttpContext, bool> _isSpaCall = (HttpContext context)
        => !context.Request.Path.StartsWithSegments(AuthenticationConstants.DefaultAuthenticationUrlSegment, StringComparison.InvariantCulture)
            && !context.Request.Path.StartsWithSegments("/api", StringComparison.InvariantCulture)
            && !context.Request.Path.StartsWithSegments("/swagger", StringComparison.InvariantCulture)
            && !context.Request.Path.StartsWithSegments(CIS.Core.CisGlobalConstants.CisHealthCheckEndpointUrl, StringComparison.InvariantCulture)
            && !context.Request.Path.StartsWithSegments("/kafkaflow", StringComparison.InvariantCulture);
}