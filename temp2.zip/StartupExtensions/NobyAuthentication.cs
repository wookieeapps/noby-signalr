﻿using NOBY.Infrastructure.Configuration;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.CodeAnalysis;

namespace NOBY.Api.StartupExtensions;

internal static class NobyAuthentication
{
    public static AuthenticationBuilder AddNobyAuthentication([NotNull] this WebApplicationBuilder builder, [NotNull] AppConfiguration configuration)
    {
        // its mandatory to have auth scheme
        if (string.IsNullOrEmpty(configuration.Security?.AuthenticationScheme))
        {
            throw new ArgumentException($"Authentication scheme is not specified. Please add correct NOBY.AuthenticationScheme in appsettings.json");
        }

        // set up data protection
        var connectionString = builder.Configuration.GetConnectionString("dataProtection");
        if (!string.IsNullOrEmpty(connectionString))
        {
            builder.Services.AddDbContext<DataProtectionKeysContext>(options => options.UseSqlServer(connectionString, sqlOptions => sqlOptions.EnableRetryOnFailure()));
            builder.Services.AddDataProtection()
                .SetApplicationName("NobyFeApi")
                .PersistKeysToDbContext<DataProtectionKeysContext>()
                .SetDefaultKeyLifetime(TimeSpan.FromDays(100));
        }

        // set up auth provider
        return configuration.Security.AuthenticationScheme switch
        {
            AuthenticationConstants.CaasAuthScheme => builder.Services.AddFomsCaasAuthentication(),
            // fake authentication
            AuthenticationConstants.MockAuthScheme => builder.Services.AddFomsMockAuthentication(),
            // simple login
            AuthenticationConstants.SimpleLoginAuthScheme => builder.Services.AddFomsSimpleLoginAuthentication(configuration.Security),
            // not existing auth scheme
            _ => throw new NotImplementedException($"Authentication scheme '{configuration.Security.AuthenticationScheme}' not implemented"),
        };
    }
}
