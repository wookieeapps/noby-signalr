﻿using NOBY.Infrastructure.ErrorHandling.Internals;
using CIS.Infrastructure.StartupExtensions;
using MPSS.Security.Noby;
using ExternalServices;
using CIS.Infrastructure.WebApi;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using NOBY.Infrastructure.ConcurrentExecution;
using SharedComponents.TaxReturn;

namespace NOBY.Api.StartupExtensions;

internal static class NobyServices
{
    public static WebApplicationBuilder AddNobyServices(this WebApplicationBuilder builder, Infrastructure.Configuration.AppConfiguration appConfiguration)
    {
        var assemblyType = typeof(IApiAssembly);

        // user accessor
        builder.Services.AddTransient<CIS.Core.Security.ICurrentUserAccessor, NobyCurrentUserAccessor>();

        builder.Services
               .AddMediatR(cfg => cfg.RegisterServicesFromAssembly(assemblyType.Assembly))
               .AddTransient(typeof(IPipelineBehavior<,>), typeof(NobyValidationBehavior<,>));

        if (appConfiguration.LogRequestContractDifferences)
        {
            builder.Services.AddTransient(typeof(IPipelineBehavior<,>), typeof(NobyAdditionalRequestPropertiesLoggerBehavior<,>));
        }

        // add validators
        builder.Services.Scan(selector => selector
            .FromAssembliesOf(assemblyType)
            .AddClasses(x => x.AssignableTo(typeof(FluentValidation.IValidator<>)), false)
            .AsImplementedInterfaces()
            .WithTransientLifetime());

        // controllers and validation
        builder.Services
            .AddControllers(x =>
            {
                x.Filters.Add(new ResponseCacheAttribute { NoStore = true, Location = ResponseCacheLocation.None });
            })
            .ConfigureApiBehaviorOptions(options =>
            {
                // disable default asp model validation - tohle chteji vypnout
                //options.SuppressModelStateInvalidFilter = true;
                //options.SuppressMapClientErrors = true;

                // misto toho budeme vracet model state chyby
                options.InvalidModelStateResponseFactory = context =>
                {
                    List<ApiErrorItem> errors = context
                        .ModelState
                        .Where(t => t.Value?.ValidationState == ModelValidationState.Invalid)
                        .Select(t => new ApiErrorItem
                        {
                            ErrorCode = 90100,
                            Severity = ApiErrorItemServerity.Error,
                            Message = "Nastala neočekávaná chyba, opakujte akci později prosím.",
                            Description = "Chybí povinné parametry.",
                            Reason = appConfiguration.AddReasonsToErrorResponse ? new()
                            { 
                                ReasonType = "ModelState validation",
                                ReasonDescription = t.Value?.Errors.Select(e => e.ErrorMessage).FirstOrDefault() ?? "" 
                            } : null
                        })
                        .ToList();

                    return new BadRequestObjectResult(errors);
                };
            })
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.Converters.Add(new JsonConverterForNullableDateTime());
                // FE nechce datetime z ms a timezone
                options.JsonSerializerOptions.Converters.Add(new JsonConverterForZonelessDateTime());
                
                // esacping problemovych znaku na vystupu
                //options.JsonSerializerOptions.Converters.Add(new CIS.Infrastructure.WebApi.JsonConverterForStringEncoding());
            });

        // dbcontext
        builder.AddEntityFramework<Database.FeApiDbContext>();

        // ext services
        builder.AddExternalService<ExternalServices.Crem.V1.ICremClient>();
        builder.AddExternalService<ExternalServices.AddressWhisperer.V2.IAddressWhispererClient>(CIS.Infrastructure.ExternalServicesHelpers.HttpHandlers.KbHeadersHttpHandler.DefaultAppCompOriginatorValue, CIS.Infrastructure.ExternalServicesHelpers.HttpHandlers.KbHeadersHttpHandler.DefaultAppCompOriginatorValue);
        builder.AddExternalService<ExternalServices.RuianAddress.V1.IRuianAddressClient>();
        builder.AddExternalService<ExternalServices.SbWebApi.V1.ISbWebApiClient>();
        builder.AddExternalService<ExternalServices.Party.V1.IPartyClient>();
        builder.AddExternalService<ExternalServices.MpHome.V1.IMpHomeClient>();

        // pridat mpss cookie
        builder.AddMpssSecurityCookie();

        // tax return
        builder.AddTaxReturnService();

        return builder;
    }
}

