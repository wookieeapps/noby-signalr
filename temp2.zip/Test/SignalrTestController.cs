﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using NOBY.Api.Hubs;

namespace NOBY.Api.Endpoints.Test;

[ApiController]
[Route("api/v1/test/signalr")]
public class SignalrTestController
{
    private readonly IHubContext<NobyHub, INobyHubClient> _hubContext;
    private readonly ILogger<SignalrTestController> _logger;

    public SignalrTestController(
        IHubContext<NobyHub, INobyHubClient> hubContext,
        ILogger<SignalrTestController> logger)
    {
        _hubContext = hubContext;
        _logger = logger;
    }

    /// <summary>
    /// Test endpoint to send a SignalR message to a specific user
    /// </summary>
    /// <param name="userId">The user ID to send the message to</param>
    /// <param name="cancellationToken">Cancellation token</param>
    [HttpGet("t1")]
    public async Task TestSendToSpecificUser([FromQuery] int userId, CancellationToken cancellationToken)
    {
        var message = $"Test notification for user {userId} at {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} UTC";

        _logger.LogInformation("Sending test SignalR message to user {UserId}: {Message}", userId, message);

        // Send message to specific user identified by their userId
        // SignalR uses the user identifier from claims to route messages
        await _hubContext.Clients
            .User(userId.ToString())
            .ReceiveChatResponse(message, cancellationToken);

        _logger.LogInformation("Test SignalR message sent to user {UserId}", userId);
    }
}
