﻿using Microsoft.AspNetCore.Authorization;
using SharedComponents.NobyEventLogger;
using SharedComponents.NobyEventLogger.Dto;
using SharedComponents.NobyEventLogger.Metadata;

namespace NOBY.Api.Endpoints.Test;

/*[ApiController]
[Route("api/v1/test")]
[AllowAnonymous]
public sealed class TestController()
    : ControllerBase
{
    [HttpGet("delayed")]
    public async Task<IActionResult> GetWithDelay(CancellationToken cancellationToken)
    {
        await Task.Delay(5000, cancellationToken);
        return Ok("Response after delay");
    }

    [HttpGet("log1")]
    public async Task Log1([FromServices] INobyEventLogger logger)
    {
        logger.LogEvent(new NobyEventLogItem
        {
            CaseId = 1,
            EventType = NobyEventLogTypes.SalesArrangementOwnerUnassigned,
            RelatedKeys =
            [
                new(10, NobyEventLogKeyTypes.SalesArrangementId),
                new(20, NobyEventLogKeyTypes.UserId),
            ],
            Metadata = new SalesArrangementOwnerUnassignedMetadata(1, 1, "test")
        });
    }

    [HttpGet("logget")]
    public async Task<NobyEventLogListItem[]> LogGet([FromServices] INobyEventLogger logger)
    {
        var list = await logger.GetEventsAsync(new SearchEventQuery
        {
            CaseId = [1],
            //RelatedKeys = [new(10, NobyEventLogKeyTypes.SalesArrangementId)]
        }, true);
        //return list.OrderBy(t => t.CreatedTime).Last().GetMetadata<SalesArrangementOwnerUnassignedMetadata>();
        return list;
    }

    [HttpGet("logget2")]
    public async Task<SalesArrangementOwnerUnassignedMetadata> LogGet2([FromServices] INobyEventLogger logger)
    {
        var list = await logger.GetEventsAsync(new SearchEventQuery
        {
            CaseId = [1],
            EventTypes = [NobyEventLogTypes.SalesArrangementOwnerUnassigned]
        });
        return list.First(t => t.HasMetadata).GetMetadata<SalesArrangementOwnerUnassignedMetadata>();
    }

    [HttpGet("neautorizovany")]
    public void Neautorizovany()
    {
        throw new CisAuthorizationException("Neautorizovany");
    }
}*/
