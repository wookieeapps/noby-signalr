using System.Threading.Channels;

namespace NOBY.Api.BackgroundServices.Chatbot;

/// <summary>
/// Implementation of IChatMessageQueue using System.Threading.Channels
/// </summary>
public sealed class ChatMessageQueue : IChatMessageQueue
{
    private readonly Channel<ChatMessageRequest> _channel;

    public ChatMessageQueue()
    {
        // Create a bounded channel with a capacity limit to prevent unbounded memory growth
        var options = new BoundedChannelOptions(100)
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleReader = true,  // Only one background service instance reads from this channel
            SingleWriter = false  // Multiple requests can write concurrently
        };
        
        _channel = Channel.CreateBounded<ChatMessageRequest>(options);
    }

    /// <inheritdoc />
    public async ValueTask EnqueueAsync(ChatMessageRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        
        await _channel.Writer.WriteAsync(request, cancellationToken).ConfigureAwait(false);
    }

    /// <inheritdoc />
    public async ValueTask<ChatMessageRequest> DequeueAsync(CancellationToken cancellationToken)
    {
        return await _channel.Reader.ReadAsync(cancellationToken).ConfigureAwait(false);
    }
}
