namespace NOBY.Api.BackgroundServices.Chatbot;

/// <summary>
/// Represents a request to send a message to the chatbot and stream the response
/// </summary>
internal sealed record ChatMessageRequest
{
    /// <summary>
    /// The NOBY user ID (used for SignalR routing)
    /// </summary>
    public required int NobyUserId { get; init; }

    /// <summary>
    /// The chatbot user ID
    /// </summary>
    public required string ChatbotUserId { get; init; }

    /// <summary>
    /// The chat ID
    /// </summary>
    public required string ChatId { get; init; }

    /// <summary>
    /// The message content to send
    /// </summary>
    public required string Content { get; init; }

    /// <summary>
    /// Whether to use the internal chatbot client (true) or external (false)
    /// </summary>
    public required bool UseInternalClient { get; init; }
}
