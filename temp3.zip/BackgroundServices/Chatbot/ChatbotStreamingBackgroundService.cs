using ExternalServices.AiChatbot.External;
using ExternalServices.AiChatbot.Internal;
using Microsoft.AspNetCore.SignalR;
using NOBY.Api.Hubs;

namespace NOBY.Api.BackgroundServices.Chatbot;

/// <summary>
/// Background service responsible for processing chat message requests and streaming SSE responses via SignalR
/// </summary>
public sealed class ChatbotStreamingBackgroundService : BackgroundService
{
    private const int MaxConcurrentChats = 50;

    private readonly IChatMessageQueue _messageQueue;
    private readonly IServiceScopeFactory _serviceScopeFactory;
    private readonly IHubContext<NobyHub, INobyHubClient> _hubContext;
    private readonly ILogger<ChatbotStreamingBackgroundService> _logger;
    private readonly SemaphoreSlim _semaphore = new(MaxConcurrentChats);

    public ChatbotStreamingBackgroundService(
        IChatMessageQueue messageQueue,
        IServiceScopeFactory serviceScopeFactory,
        IHubContext<NobyHub, INobyHubClient> hubContext,
        ILogger<ChatbotStreamingBackgroundService> logger)
    {
        _messageQueue = messageQueue;
        _serviceScopeFactory = serviceScopeFactory;
        _hubContext = hubContext;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("ChatbotStreamingBackgroundService started with max {MaxConcurrentChats} concurrent chats", MaxConcurrentChats);

        await foreach (var request in ProcessQueueAsync(stoppingToken))
        {
            await _semaphore.WaitAsync(stoppingToken).ConfigureAwait(false);

            // Fire and forget - process message in background
            _ = ProcessMessageWithSemaphoreAsync(request, stoppingToken);
        }

        _logger.LogInformation("ChatbotStreamingBackgroundService stopped");
    }

    private async Task ProcessMessageWithSemaphoreAsync(ChatMessageRequest request, CancellationToken cancellationToken)
    {
        try
        {
            await ProcessMessageAsync(request, cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // Graceful shutdown - don't log as error
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing chat message for user {NobyUserId}, chat {ChatId}",
                request.NobyUserId, request.ChatId);
        }
        finally
        {
            _semaphore.Release();
        }
    }

    private async IAsyncEnumerable<ChatMessageRequest> ProcessQueueAsync(
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            ChatMessageRequest? request = null;
            try
            {
                request = await _messageQueue.DequeueAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                yield break;
            }

            if (request is not null)
            {
                yield return request;
            }
        }
    }

    private async Task ProcessMessageAsync(ChatMessageRequest request, CancellationToken cancellationToken)
    {
        _logger.LogDebug("Processing chat message for user {NobyUserId}, chat {ChatId}",
            request.NobyUserId, request.ChatId);

        await using var scope = _serviceScopeFactory.CreateAsyncScope();

        ExternalServices.AiChatbot.BaseClient.IBaseAiChatbotClient client = request.UseInternalClient
            ? scope.ServiceProvider.GetRequiredService<IAiChatbotInternalClient>()
            : scope.ServiceProvider.GetRequiredService<IAiChatbotExternalClient>();

        var userIdString = request.NobyUserId.ToString(System.Globalization.CultureInfo.InvariantCulture);

        await client.CreateMessageWithCallback(
            request.ChatbotUserId,
            request.ChatId,
            request.Content,
            async (content, isComplete) =>
            {
                await _hubContext.Clients
                    .User(userIdString)
                    .ReceiveChatResponse(request.ChatId, content, isComplete, cancellationToken)
                    .ConfigureAwait(false);

                if (isComplete)
                {
                    _logger.LogDebug("Completed streaming chat response for user {NobyUserId}, chat {ChatId}",
                        request.NobyUserId, request.ChatId);
                }
            },
            cancellationToken).ConfigureAwait(false);
    }

    public override void Dispose()
    {
        _semaphore.Dispose();
        base.Dispose();
    }
}
