namespace NOBY.Api.BackgroundServices.Chatbot;

/// <summary>
/// Interface for enqueueing chat message requests to be processed by the background service
/// </summary>
internal interface IChatMessageQueue
{
    /// <summary>
    /// Enqueues a chat message request for background processing
    /// </summary>
    /// <param name="request">The chat message request to enqueue</param>
    /// <param name="cancellationToken">Cancellation token</param>
    ValueTask EnqueueAsync(ChatMessageRequest request, CancellationToken cancellationToken = default);

    /// <summary>
    /// Dequeues a chat message request for processing
    /// </summary>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>The next chat message request to process</returns>
    ValueTask<ChatMessageRequest> DequeueAsync(CancellationToken cancellationToken);
}
