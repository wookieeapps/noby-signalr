﻿using CIS.Infrastructure.ExternalServicesHelpers;
using System.Collections.Immutable;
using System.Net.ServerSentEvents;

namespace ExternalServices.AiChatbot.BaseClient;

internal abstract class BaseAiChatbotClient(HttpClient _httpClient)
    : IBaseAiChatbotClient
{
    public async Task<Contracts.Chat> CreateChat(string userId, Contracts.CreateChat request, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .PostAsJsonAsync(_httpClient.BaseAddress + $"/users/{userId}/chats", request, cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.Chat>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.User> CreateUser(Contracts.CreateUser request, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .PostAsJsonAsync(_httpClient.BaseAddress + $"/users", request, cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.User>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task DeleteChat(string userId, string chatId, CancellationToken cancellationToken = default)
    {
        await (await _httpClient
            .DeleteAsync(_httpClient.BaseAddress + $"/users/{userId}/chats/{chatId}", cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusCode(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.MessagesList> GetChatDetail(string userId, string chatId, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .GetAsync(_httpClient.BaseAddress + $"/users/{userId}/chats/{chatId}/messages", cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.MessagesList>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.ChatsList> GetChatList(string userId, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .GetAsync(_httpClient.BaseAddress + $"/users/{userId}/chats", cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.ChatsList>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.User> GetUser(string userId, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .GetAsync(_httpClient.BaseAddress + $"/users/{userId}", cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.User>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.Message> RateResponse(string userId, string chatId, Contracts.PatchMessage request, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .PatchAsJsonAsync(_httpClient.BaseAddress + $"/users/{userId}/chats/{chatId}/messages", request, cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.Message>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task<Contracts.Chat> UpdateChat(string userId, string chatId, string? title, bool? favorite, CancellationToken cancellationToken = default)
    {
        return await (await _httpClient
            .PatchAsJsonAsync(_httpClient.BaseAddress + $"/users/{userId}/chats/{chatId}", new { title, favorite }, cancellationToken)
            .ConfigureAwait(false))
            .EnsureSuccessStatusAndReadJson<Contracts.Chat>(StartupExtensions.ServiceName, cancellationToken);
    }

    public async Task CreateMessageWithCallback(string userId, string chatId, string content, Func<CreateMessageContentReceivedEvent, Task> onContentReceived, CancellationToken cancellationToken = default)
    {
        var requestUri = $"{_httpClient.BaseAddress}/users/{userId}/chats/{chatId}/messages";
        var requestBody = new
        {
            content
        };

        using var request = new HttpRequestMessage(HttpMethod.Post, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("text/event-stream"));
        request.Content = JsonContent.Create(requestBody);

        using var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken)
            .ConfigureAwait(false);
        
        response.EnsureSuccessStatusCode();

        string? messageId = null;
        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        
        await foreach (var sseEvent in SseParser.Create(stream).EnumerateAsync(cancellationToken))
        {
            if (sseEvent.EventType.Trim() == "content")
            {
                var obj = System.Text.Json.JsonSerializer.Deserialize<ChatStreamEvent>(sseEvent.Data);
                messageId ??= obj?.response.id;
                var msg = obj?.response.choices.FirstOrDefault()?.message.content;
                if (!string.IsNullOrEmpty(msg))
                {
                    await onContentReceived(new CreateMessageContentReceivedEvent(false, messageId!, msg));
                }
            }
            else if (sseEvent.EventType.Trim() == "finalContent")
            {
                var obj = System.Text.Json.JsonSerializer.Deserialize<ChatStreamEventFinalResponse>(sseEvent.Data);
                if (!string.IsNullOrEmpty(obj?.response))
                {
                    await onContentReceived(new CreateMessageContentReceivedEvent(true, messageId ?? "unknown", obj.response));
                }
            }
        }
    }

    private sealed record ChatStreamEventFinalResponse(string response);
    private sealed record ChatStreamEvent(ChatStreamEventResponse response);
    private sealed record ChatStreamEventResponse(string id, List<ChatStreamEventResponseChoice> choices);
    private sealed record ChatStreamEventResponseChoice(ChatStreamEventResponseChoiceMessage message);
    private sealed record ChatStreamEventResponseChoiceMessage(string content);
}
