﻿using ExternalServices.AiChatbot.Contracts;
using ExternalServices.AiChatbot.External;
using ExternalServices.AiChatbot.Internal;

namespace ExternalServices.AiChatbot.BaseClient;

internal sealed class BaseMockAiChatbotClient : IAiChatbotExternalClient, IAiChatbotInternalClient
{
    public Task<Chat> CreateChat(string userId, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<User> CreateUser(CreateUser request, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task DeleteChat(string userId, string chatId, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<MessagesList> GetChatDetail(string userId, string chatId, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<ChatsList> GetChatList(string userId, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<User> GetUser(string userId, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<Message> RateResponse(string userId, string chatId, PatchMessage request, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<Chat> UpdateChat(string userId, string chatId, string? title, bool? favorite, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task StreamChatResponseAsync(string userId, string chatId, Func<string, Task> onMessageReceived, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<Chat> CreateChat(string userId, CreateChat request, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task CreateMessage(string userId, string chatId, Func<string, Task> onMessageReceived, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task CreateMessage(string userId, string chatId, string content, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task CreateMessageWithCallback(string userId, string chatId, string content, Func<CreateMessageContentReceivedEvent, Task> onContentReceived, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }
}
