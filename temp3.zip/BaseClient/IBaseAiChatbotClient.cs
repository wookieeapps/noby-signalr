﻿namespace ExternalServices.AiChatbot.BaseClient;

public interface IBaseAiChatbotClient
{
    Task<Contracts.Chat> CreateChat(string userId, Contracts.CreateChat request, CancellationToken cancellationToken = default);

    Task<Contracts.User> CreateUser(Contracts.CreateUser request, CancellationToken cancellationToken = default);

    Task DeleteChat(string userId, string chatId, CancellationToken cancellationToken = default);

    Task<Contracts.MessagesList> GetChatDetail(string userId, string chatId, CancellationToken cancellationToken = default);

    Task<Contracts.ChatsList> GetChatList(string userId, CancellationToken cancellationToken = default);

    Task<Contracts.User> GetUser(string userId, CancellationToken cancellationToken = default);

    Task<Contracts.Message> RateResponse(string userId, string chatId, Contracts.PatchMessage request, CancellationToken cancellationToken = default);

    Task<Contracts.Chat> UpdateChat(string userId, string chatId, string? title, bool? favorite, CancellationToken cancellationToken = default);

    /// <summary>
    /// Streams chatbot responses using Server-Sent Events (SSE) with callback for each message chunk
    /// </summary>
    /// <param name="userId">The chatbot user ID</param>
    /// <param name="chatId">The chat ID</param>
    /// <param name="content">The message content to send</param>
    /// <param name="onContentReceived">Callback invoked for each content chunk received (isComplete indicates final message)</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Task that completes when the stream ends or is cancelled</returns>
    Task CreateMessageWithCallback(string userId, string chatId, string content, Func<CreateMessageContentReceivedEvent, Task> onContentReceived, CancellationToken cancellationToken = default);
}

public sealed record CreateMessageContentReceivedEvent(
    bool IsFinal,
    string MessageId,
    string Content);