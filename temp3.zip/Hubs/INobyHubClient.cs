namespace NOBY.Api.Hubs;

/// <summary>
/// Client interface for NobyHub - defines methods that can be called on connected clients
/// </summary>
public interface INobyHubClient
{
    /// <summary>
    /// Receives a chat response chunk from the chatbot
    /// </summary>
    /// <param name="chatId">The chat ID</param>
    /// <param name="message">The message content (partial chunk or complete response)</param>
    /// <param name="isComplete">True if this is the final/complete message, false for streaming chunks</param>
    /// <param name="cancellationToken">Cancellation token</param>
    Task ReceiveChatResponse(string chatId, string message, bool isComplete, CancellationToken cancellationToken = default);
}
