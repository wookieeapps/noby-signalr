﻿#pragma warning disable CA1515 // Consider making public types internal
using Microsoft.AspNetCore.SignalR;
using NOBY.Api.Hubs;

namespace NOBY.Api.Endpoints.Test;

[ApiController]
[Route("api/v1/test/signalr")]
public class SignalrTestController(
    IHubContext<NobyHub, INobyHubClient> _hubContext,
    ILogger<SignalrTestController> _logger)
{
    /// <summary>
    /// Test endpoint to send a SignalR message to a specific user
    /// </summary>
    /// <param name="chatId">The chat ID</param>
    /// <param name="userId">The user ID to send the message to</param>
    /// <param name="cancellationToken">Cancellation token</param>
    [HttpGet("send-to-user")]
    public async Task TestSendToSpecificUser([FromQuery] string chatId, [FromQuery] int userId, CancellationToken cancellationToken)
    {
        var message = $"Test notification for user {userId} at {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} UTC";

        _logger.LogInformation("Sending test SignalR message to user {UserId}: {Message}", userId, message);

        // Send message to specific user identified by their userId
        // SignalR uses the user identifier from claims to route messages
        await _hubContext.Clients
            .User(userId.ToString(System.Globalization.CultureInfo.InvariantCulture))
            .ReceiveChatResponse(chatId, "unknown", message, true, cancellationToken);

        _logger.LogInformation("Test SignalR message sent to user {UserId}", userId);
    }
}
