# SignalR Documentation Update Guide

This guide explains how to keep your SignalR documentation in sync when you make changes to Hub APIs.

## Overview

The NOBY.Api project uses a **multi-layered documentation approach**:

1. **Automatic REST API Documentation** - Auto-generated from Hub code via reflection
2. **TypeScript Definitions** - Manually maintained, shared with frontend
3. **Markdown Documentation** - Manually maintained, human-readable guide

## When Hub API Changes

### 1. Update the Hub Code (C#)

Make your changes to the Hub or client interface:

```csharp
// Example: Adding a new method to NobyHub
public async Task SendNotification(int userId, string title, string message, CancellationToken cancellationToken = default)
{
    await Clients.User(userId.ToString()).ReceiveNotification(title, message, cancellationToken);
}
```

```csharp
// Example: Adding corresponding client method to INobyHubClient
public interface INobyHubClient
{
    Task ReceiveChatResponse(string message, CancellationToken cancellationToken = default);
    
    // NEW METHOD
    Task ReceiveNotification(string title, string message, CancellationToken cancellationToken = default);
}
```

### 2. Automatic REST API Documentation ?

**No action needed!** The `/api/v1/signalr-docs` endpoint automatically reflects changes via the `SignalRDocumentationService`.

**How it works:**
- Uses reflection to discover all Hub types
- Extracts methods, parameters, and return types
- Reads XML documentation comments (if available)
- Generates JSON documentation on-the-fly

**Test it:**
```bash
GET https://your-api.com/api/v1/signalr-docs
```

### 3. Update TypeScript Definitions ??

**File:** `NOBY.Api/wwwroot/signalr-types/noby-hub.d.ts`

**Action required:** Manually update the interfaces

**Steps:**
1. Open `noby-hub.d.ts`
2. Update `INobyHubClient` interface (server ? client methods)
3. Update `INobyHubServer` interface (client ? server methods)
4. Update usage examples if needed
5. Increment version number in file header

**Example update:**
```typescript
/**
 * @version 1.1  <-- Increment version
 */
export interface INobyHubClient {
  receiveChatResponse(message: string): Promise<void>;
  
  // NEW METHOD - matches C# ReceiveNotification
  receiveNotification(title: string, message: string): Promise<void>;
}

export interface INobyHubServer {
  sendChatResponse(message: string): Promise<void>;
  
  // NEW METHOD - matches C# SendNotification
  sendNotification(userId: number, title: string, message: string): Promise<void>;
}
```

**Important naming conventions:**
- C# method names are PascalCase: `ReceiveNotification`
- TypeScript/JavaScript uses camelCase: `receiveNotification`
- SignalR automatically handles this conversion

### 4. Update Markdown Documentation ??

**File:** `NOBY.Api/wwwroot/docs/signalr-api-documentation.md`

**Action required:** Manually update sections

**Steps:**
1. Open `signalr-api-documentation.md`
2. Update the **Server Methods** section for new client ? server methods
3. Update the **Client Methods** section for new server ? client methods
4. Update code examples
5. Update version history table at the bottom

**Example update:**

Add to **Server Methods** section:
```markdown
### SendNotification

Sends a notification to a specific user.

**Method Name:** `SendNotification`

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| userId | number | Yes | The ID of the user to notify |
| title | string | Yes | Notification title |
| message | string | Yes | Notification message content |

**Returns:** `Promise<void>`

**Example:**
\`\`\`typescript
await connection.invoke('SendNotification', 123, 'New Message', 'You have a new chat message');
\`\`\`
```

Add to **Client Methods** section:
```markdown
### ReceiveNotification

Receives a notification from the server.

**Method Name:** `ReceiveNotification`

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| title | string | Yes | Notification title |
| message | string | Yes | Notification message content |

**Returns:** `void` or `Promise<void>`

**Example:**
\`\`\`typescript
connection.on('ReceiveNotification', (title: string, message: string) => {
  console.log('Notification:', title, message);
  showNotification(title, message);
});
\`\`\`
```

Update **Version History** section:
```markdown
| Version | Date | Changes |
|---------|------|---------|
| 1.1 | 2025-01-XX | Added SendNotification/ReceiveNotification methods |
| 1.0 | 2025 | Initial release with NobyHub and chat functionality |
```

## Update Checklist

When you change Hub APIs, follow this checklist:

- [ ] Update C# Hub code (`NobyHub.cs`)
- [ ] Update C# client interface (`INobyHubClient.cs`)
- [ ] Add XML documentation comments to new methods
- [ ] Build and test the changes
- [ ] ? **REST API documentation** - Updates automatically
- [ ] ?? Update TypeScript definitions (`noby-hub.d.ts`)
- [ ] ?? Update Markdown documentation (`signalr-api-documentation.md`)
- [ ] Increment version numbers in both files
- [ ] Commit all changes together
- [ ] Notify frontend team of the changes

## Distribution Strategy

### For Frontend Team

After updating documentation, share with the frontend team:

1. **TypeScript Definitions:**
   - Copy `noby-hub.d.ts` to the frontend project
   - Or publish to a shared npm package
   - Or host on a CDN/shared location

2. **Markdown Documentation:**
   - Share link to the markdown file in your repository
   - Or publish to your team wiki/Confluence
   - Or convert to PDF for distribution

3. **REST API Endpoint:**
   - Share the endpoint URL: `GET /api/v1/signalr-docs`
   - Frontend can query this programmatically
   - Visible in Swagger UI for easy access

## Automation Tips

### Option 1: TypeScript Generator (Future Enhancement)

Install TypeScript generator to auto-generate `.d.ts` files:

```bash
dotnet add package Microsoft.TypeScript.MSBuild
```

Configure it to generate TypeScript from C# during build.

### Option 2: Pre-commit Hook

Create a git pre-commit hook to remind about documentation:

```bash
#!/bin/sh
# .git/hooks/pre-commit

if git diff --cached --name-only | grep -q "Hubs/.*\.cs"; then
  echo "??  Hub files changed! Remember to update:"
  echo "   - wwwroot/signalr-types/noby-hub.d.ts"
  echo "   - wwwroot/docs/signalr-api-documentation.md"
  echo ""
  read -p "Have you updated the documentation? (y/n) " -n 1 -r
  echo
  if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 1
  fi
fi
```

### Option 3: CI/CD Check

Add a build step to check if documentation versions match:

```yaml
# Azure DevOps example
- script: |
    # Compare version in .d.ts with version in .cs
    # Fail build if documentation is stale
  displayName: 'Check SignalR Documentation'
```

## Best Practices

1. **Keep Changes Atomic**
   - Update Hub code and documentation in the same commit
   - Use descriptive commit messages

2. **Version Everything**
   - Increment version numbers in documentation files
   - Track changes in version history table

3. **Test Before Committing**
   - Test new Hub methods
   - Verify REST API documentation endpoint
   - Review TypeScript definitions for accuracy

4. **Communication**
   - Notify frontend team of breaking changes
   - Provide migration guide if needed
   - Schedule coordination for major changes

## Breaking Changes

If you're making **breaking changes** to Hub APIs:

1. **Version the Hub itself:**
   ```csharp
   // Old hub
   public class NobyHub : Hub<INobyHubClient> { }
   
   // New versioned hub
   public class NobyHubV2 : Hub<INobyHubClientV2> { }
   ```

2. **Keep old endpoint running:**
   ```csharp
   // In NobyAppBuilder.cs
   t.MapHub<NobyHub>("/api/nobyhub");      // v1
   t.MapHub<NobyHubV2>("/api/nobyhub/v2"); // v2
   ```

3. **Document deprecation timeline:**
   ```markdown
   ## Deprecated Methods
   
   ### SendChatResponse (Deprecated in v2.0)
   **Deprecated:** This method will be removed in v3.0
   **Alternative:** Use `SendMessage` instead
   ```

## Troubleshooting

### REST API Documentation Not Updating

- **Issue:** Changes to Hub not reflected in `/api/v1/signalr-docs`
- **Solution:** 
  - Ensure the Hub is in the same assembly
  - Check that `SignalRDocumentationService` is registered
  - Restart the application
  - Clear any API gateway caches

### TypeScript Definitions Out of Sync

- **Issue:** Frontend getting type errors
- **Solution:**
  - Compare C# method signatures with TypeScript interfaces
  - Check camelCase vs PascalCase naming
  - Verify parameter types match
  - Re-share updated `.d.ts` file with frontend

## Questions?

- Review existing Hubs in `NOBY.Api/Hubs/`
- Check Swagger documentation at `/swagger`
- Query REST API documentation at `/api/v1/signalr-docs`
- Consult with the backend team
