# NOBY SignalR Hub API Documentation

## Overview
This document describes the SignalR hubs available in the NOBY.Api application for real-time communication between the server and frontend clients.

## General Information

### Authentication
All SignalR hubs require authentication. Include a valid JWT bearer token when establishing the connection.

### Connection URL
```
/api/nobyhub
```

### Transport
- WebSockets (preferred)
- Server-Sent Events (fallback)
- Long Polling (fallback)

---

## NobyHub

Real-time communication hub for NOBY frontend clients.

### Connection Details

| Property | Value |
|----------|-------|
| Endpoint | `/api/nobyhub` |
| Authentication | Required |
| Authorization | Bearer Token |

### Connection Example (JavaScript/TypeScript)

```typescript
import * as signalR from '@microsoft/signalr';

const connection = new signalR.HubConnectionBuilder()
  .withUrl('/api/nobyhub', {
    accessTokenFactory: () => getAuthToken() // Your auth token provider
  })
  .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
  .configureLogging(signalR.LogLevel.Information)
  .build();

// Start connection
try {
  await connection.start();
  console.log('Connected to NobyHub');
} catch (err) {
  console.error('Connection failed:', err);
}
```

---

## Server Methods
Methods that clients can invoke on the server (Client ? Server)

### SendChatResponse

Sends a chat response to the calling client.

**Method Name:** `SendChatResponse`

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| message | string | Yes | The message to send |

**Returns:** `Promise<void>`

**Example:**
```typescript
await connection.invoke('SendChatResponse', 'Hello from client!');
```

**Notes:**
- The message is sent only to the calling client
- Requires an active connection
- The client must implement `ReceiveChatResponse` to receive the response

---

## Client Methods
Methods that must be implemented by clients to receive server messages (Server ? Client)

### ReceiveChatResponse

Receives a chat response message from the server.

**Method Name:** `ReceiveChatResponse`

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| message | string | Yes | The chat message content |

**Returns:** `void` or `Promise<void>`

**Example:**
```typescript
connection.on('ReceiveChatResponse', (message: string) => {
  console.log('Received message:', message);
  // Display message to user
  displayChatMessage(message);
});
```

**Notes:**
- This method must be registered before starting the connection
- Messages are received in real-time as they are sent from the server
- Method name is case-sensitive

---

## Error Handling

### Connection Errors

```typescript
connection.onclose((error) => {
  if (error) {
    console.error('Connection closed due to error:', error);
  } else {
    console.log('Connection closed gracefully');
  }
});
```

### Reconnection Handling

```typescript
connection.onreconnecting((error) => {
  console.warn('Connection lost. Reconnecting...', error);
  showReconnectingIndicator();
});

connection.onreconnected((connectionId) => {
  console.log('Reconnected successfully. ConnectionId:', connectionId);
  hideReconnectingIndicator();
});
```

### Method Invocation Errors

```typescript
try {
  await connection.invoke('SendChatResponse', 'Hello');
} catch (err) {
  console.error('Failed to send message:', err);
  // Handle error (e.g., show error notification)
}
```

---

## Best Practices

### 1. Connection Management
- Establish connection on app startup or when needed
- Properly dispose connection when component unmounts
- Use automatic reconnection for better reliability

### 2. Authentication
- Always provide a valid JWT token
- Refresh token before it expires
- Handle authentication failures gracefully

### 3. Event Handlers
- Register all event handlers before starting the connection
- Unregister handlers when they're no longer needed
- Use try-catch blocks for async operations

### 4. Performance
- Avoid sending large payloads (>32KB)
- Batch messages when possible
- Use compression for large messages

---

## Complete Example

```typescript
import * as signalR from '@microsoft/signalr';

class NobyHubClient {
  private connection: signalR.HubConnection;

  constructor(private getToken: () => string) {
    this.connection = new signalR.HubConnectionBuilder()
      .withUrl('/api/nobyhub', {
        accessTokenFactory: () => this.getToken()
      })
      .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
      .configureLogging(signalR.LogLevel.Information)
      .build();

    this.setupHandlers();
  }

  private setupHandlers(): void {
    // Client method: Receive chat response
    this.connection.on('ReceiveChatResponse', (message: string) => {
      this.onChatResponseReceived(message);
    });

    // Connection events
    this.connection.onclose((error) => {
      console.error('Connection closed:', error);
    });

    this.connection.onreconnecting(() => {
      console.warn('Reconnecting...');
    });

    this.connection.onreconnected(() => {
      console.log('Reconnected');
    });
  }

  async start(): Promise<void> {
    try {
      await this.connection.start();
      console.log('Connected to NobyHub');
    } catch (err) {
      console.error('Failed to connect:', err);
      throw err;
    }
  }

  async stop(): Promise<void> {
    await this.connection.stop();
  }

  // Server methods
  async sendChatResponse(message: string): Promise<void> {
    try {
      await this.connection.invoke('SendChatResponse', message);
    } catch (err) {
      console.error('Failed to send chat response:', err);
      throw err;
    }
  }

  // Client method handlers
  private onChatResponseReceived(message: string): void {
    // Handle received message
    console.log('Chat response received:', message);
  }

  get state(): signalR.HubConnectionState {
    return this.connection.state;
  }
}

// Usage
const client = new NobyHubClient(() => localStorage.getItem('authToken') || '');
await client.start();
await client.sendChatResponse('Hello, server!');
```

---

## Testing

### Test Endpoint
A test endpoint is available for development:

**GET** `/api/v1/test/signalr/t1?userId={userId}`

This endpoint sends a test message to a specific user to verify SignalR functionality.

---

## Troubleshooting

### Common Issues

1. **401 Unauthorized**
   - Ensure valid JWT token is provided
   - Check token expiration
   - Verify token format in Authorization header

2. **Connection Fails**
   - Check network connectivity
   - Verify WebSocket support
   - Check firewall/proxy settings
   - Ensure CORS is configured correctly

3. **Messages Not Received**
   - Verify client method is registered before connection starts
   - Check method name case sensitivity
   - Ensure connection is in Connected state

4. **Reconnection Issues**
   - Check automatic reconnect configuration
   - Verify server is accessible
   - Monitor reconnection events

---

## Support

For questions or issues:
- Check the Swagger documentation at `/swagger`
- Review the SignalR documentation endpoint at `/api/v1/signalr-docs`
- Contact the backend team

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2025 | Initial release with NobyHub and chat functionality |
