/**
 * NOBY SignalR Hub TypeScript Definitions
 * 
 * This file contains TypeScript definitions for SignalR hubs in the NOBY.Api project.
 * Use these definitions to ensure type safety when working with SignalR connections.
 * 
 * @version 1.0
 * @generated Manual - Keep in sync with C# hub definitions
 */

/**
 * Client-side methods that the server can invoke on connected clients
 * These methods must be implemented by the client
 */
export interface INobyHubClient {
  /**
   * Receives a chat response message from the server
   * @param message - The chat message content
   */
  receiveChatResponse(message: string): Promise<void>;
}

/**
 * Server-side methods that clients can invoke on the hub
 * These methods are available on the hub connection
 */
export interface INobyHubServer {
  /**
   * Sends a chat response to the calling client
   * @param message - The message to send
   */
  sendChatResponse(message: string): Promise<void>;
}

/**
 * Hub connection configuration
 */
export interface INobyHubConfiguration {
  /**
   * Hub endpoint URL
   */
  endpoint: '/api/nobyhub';
  
  /**
   * Whether authentication is required
   */
  requiresAuthentication: true;
  
  /**
   * Recommended reconnect policy
   */
  reconnectPolicy: {
    /**
     * Enable automatic reconnection
     */
    enabled: true;
    
    /**
     * Retry delays in milliseconds
     */
    retryDelays: number[];
  };
}

/**
 * Example usage with @microsoft/signalr:
 * 
 * ```typescript
 * import * as signalR from '@microsoft/signalr';
 * import { INobyHubClient, INobyHubServer } from './noby-hub-types';
 * 
 * // Create connection
 * const connection = new signalR.HubConnectionBuilder()
 *   .withUrl('/api/nobyhub', {
 *     accessTokenFactory: () => getAuthToken()
 *   })
 *   .withAutomaticReconnect()
 *   .build();
 * 
 * // Implement client methods
 * connection.on('ReceiveChatResponse', (message: string) => {
 *   console.log('Received message:', message);
 *   // Handle the message
 * });
 * 
 * // Start connection
 * await connection.start();
 * 
 * // Invoke server methods
 * await connection.invoke('SendChatResponse', 'Hello from client!');
 * ```
 */
